/* eslint-disable no-console */
const jsonServer = require("json-server");
const server = jsonServer.create();
const path = require("path");
const router = jsonServer.router(path.join(__dirname, "db.json"));

const middlewares = jsonServer.defaults({
  static: "node_modules/json-server/dist",
});

server.use(middlewares);
server.use(jsonServer.bodyParser);

server.use(function (req, res, next) {
  setTimeout(next, 0);
});

server.use((req, res, next) => {
  if (req.method === "POST") {
    req.body.createdAt = Date.now();
    console.log("req" + req);
  }
  next();
});

server.post("/empDetails/", function (req, res, next) {
  next();
});

server.post("/empSearch/", function (req, res) {
  const data = [
    {
      id: 1,
      empid: "GBS03807",
      ename: "Sethu",
      DOJ: "15-Jun-2016",
      phone: 9840112345,
      email: "sethu.n@centrico.com",
      address: "No:1 First Cross, Anna nagar, Chennai",
    },
    {
      id: 2,
      empid: "GBS05340",
      ename: "Sreekanth",
      DOJ: "15-Jun-2019",
      phone: 9840112345,
      email: "sreekanth.pamujula@centrico.com",
      address: "No:2 First Cross, Anna nagar, Chennai",
    },
  ];
  res.json(data);
});

server.use(router);

const port = 3001;
server.listen(port, () => {
  console.log(`JSON Server is running on port ${port}`);
});
