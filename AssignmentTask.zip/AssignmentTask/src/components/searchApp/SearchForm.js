import React from "react";
import PropTypes from "prop-types";
import TextInput from "../common/TextInput";

const SearchForm = ({ employee, onSave, onChange, errors = {} }) => {
  const { id, ename, phone, email, DOJ } = employee;

  return (
    <form
      onSubmit={(e) => {
        //console.log("values passed inside searchform component are"+ JSON.stringify(employee) );
        onSave(e, { employee });
      }}
    >
      {errors.onSave && (
        <div className="alert alert-danger" role="alert">
          {errors.onSave}
        </div>
      )}

      <TextInput
        name="id"
        label="ID"
        type="text"
        value={id}
        onChange={onChange}
        error={errors.id}
      />

      <TextInput
        name="ename"
        label="NAME"
        type="text"
        value={ename}
        onChange={onChange}
        error={errors.ename}
      />

      <TextInput
        name="phone"
        label="PHONE"
        type="telephone"
        value={phone}
        onChange={onChange}
        error={errors.phone}
      />

      <TextInput
        name="email"
        label="Email"
        type="email"
        value={email}
        onChange={onChange}
        error={errors.email}
      />

      <TextInput
        name="DOJ"
        label="DOJ"
        type="date"
        value={DOJ}
        onChange={onChange}
        error={errors.DOJ}
      />

      <button type="submit" className="btn btn-primary">
        {"Search"}
      </button>
    </form>
  );
};

SearchForm.propTypes = {
  employee: PropTypes.object.isRequired,
  errors: PropTypes.object,
  onSave: PropTypes.func.isRequired,
  onChange: PropTypes.func.isRequired,
  saving: PropTypes.bool,
};

export default SearchForm;
