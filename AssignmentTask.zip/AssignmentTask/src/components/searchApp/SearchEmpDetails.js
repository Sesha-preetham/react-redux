import React, { useEffect, useState } from "react";
import { connect } from "react-redux";
import * as searchActions from "../../redux/actions/searchActions";
import PropTypes from "prop-types";
import SearchForm from "./SearchForm";
import { newEmployee } from "../../../tools/mockData";

function SearchEmpDetails({
  empDetails,
  loadEmployee,
  searchEmployee,
  ...props
}) {
  const [newemployee, setNewemployee] = useState({ ...props.newemployee });

  const [errors, setErrors] = useState({});

  useEffect(() => {
    if (empDetails.length === 0) {
      loadEmployee().catch((error) => {
        alert("Loading employees failed" + error);
      });
    }
  }, []);

  function handleChange(event) {
    const { name, value } = event.target;
    setNewemployee((prevEmployee) => ({
      ...prevEmployee,
      [name]: value,
      //[name]: name === "id" ? parseInt(value,10) : value
    }));
  }

  function formIsValid() {
    const { id, ename, DOJ, phone } = newemployee;
    const errors = {};

    if (isNaN(id)) errors.id = "Enter a valid ID";
    if (isNaN(phone)) errors.phone = "Enter a valid Phone number";
    // if(!id) errors.id= "id is required";
    if (!id && !ename && !DOJ && !phone) errors.id = "Enter a valid input";
    setErrors(errors);
    return Object.keys(errors).length === 0;
  }

  function onSearch(e, employee) {
    e.preventDefault();
    if (!formIsValid()) return;
    //console.log("form submitted");
    //console.log("values passed in searchEmpDetails Component are"+ JSON.stringify(employee));
    searchEmployee(employee).catch((error) => {
      alert("Loading employee failed" + error);
    });
    setNewemployee({ ...props.newemployee });
  }

  return (
    <>
      <div className="card h-470 border-primary" style={{ height: "470px" }}>
        <div className="card-header">SEARCH EMPLOYEE</div>
        <div className="card-body">
          <SearchForm
            employee={newemployee}
            errors={errors}
            onChange={handleChange}
            onSave={onSearch}
            empDetails={empDetails}
          />
        </div>
      </div>
    </>
  );
}

SearchEmpDetails.propTypes = {
  newemployee: PropTypes.object.isRequired,
  empDetails: PropTypes.array.isRequired,
  loadEmployee: PropTypes.func.isRequired,
  searchEmployee: PropTypes.func.isRequired,
  employee: PropTypes.object,
};

function mapStateToProps(state) {
  return {
    newemployee: newEmployee,
    empDetails: state.empDetails,
  };
}

const mapDispatchToProps = {
  loadEmployee: searchActions.loadEmployee,
  searchEmployee: (employee) => searchActions.searchEmployee(employee),
};

export default connect(mapStateToProps, mapDispatchToProps)(SearchEmpDetails);
