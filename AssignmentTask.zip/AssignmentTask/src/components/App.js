import React from "react";
import { Route, Switch } from "react-router-dom";
import PageNotFound from "./PageNotFound";
import SearchApp from "./searchApp/SearchApp";

function App() {
  return (
    <div className="mainContainer">
      <div className="container-fluid">
        <Switch>
          <Route exact path="/" component={SearchApp} />
          <Route component={PageNotFound} />
        </Switch>
      </div>
    </div>
  );
}

export default App;
