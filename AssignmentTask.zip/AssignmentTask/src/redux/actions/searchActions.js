import * as types from "./actionTypes";
import * as employeeApi from "../../api/employeeApi";

export function loadEmployeeSuccess(empDetails) {
  return { type: types.LOAD_EMPLOYEE_SUCCESS, empDetails };
}

export function searchEmployeeSuccess(empDetails) {
  return { type: types.SEARCH_EMPLOYEE_SUCCESS, empDetails };
}

export function loadEmployee() {
  return function (dispatch) {
    return employeeApi
      .getEmployee()
      .then((empDetails) => {
        //console.log("Load Action empDetails"+ JSON.stringify(empDetails));
        dispatch(loadEmployeeSuccess(empDetails));
      })
      .catch((error) => {
        throw error;
      });
  };
}

export function searchEmployee(employee) {
  //console.log("values passed in Action are"+ JSON.stringify(employee));
  //console.log("employeeID in action is" + employeeID);
  return function (dispatch) {
    return employeeApi
      .findEmployee(employee)
      .then((empDetails) => {
        //console.log("Load Action searchEmployee"+ JSON.stringify(empDetails));
        dispatch(searchEmployeeSuccess(empDetails));
      })
      .catch((error) => {
        throw error;
      });
  };
}
