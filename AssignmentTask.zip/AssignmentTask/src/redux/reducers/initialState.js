export default {
  empDetails: [],
};
