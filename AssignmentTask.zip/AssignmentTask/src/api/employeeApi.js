import { handleResponse, handleError } from "./apiUtils";
const baseUrl = process.env.API_URL + "/empDetails/";
const searchUrl = process.env.API_URL + "/empSearch/";

export async function getEmployee() {
  try {
    const result = await fetch(baseUrl);
    return handleResponse(result);
  } catch (e) {
    return handleError(e);
  }
}

export async function findEmployee(employee) {
  const settings = {
    method: "POST",
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json",
    },
    body: JSON.stringify(employee),
  };

  // console.log("Values" + JSON.stringify(employee));

  try {
    const fetchResponse = await fetch(searchUrl, settings);
    const data = await fetchResponse.json();
    //console.log("post call data : " + JSON.stringify(data) );
    return data;
  } catch (e) {
    return handleError(e);
  }
}
