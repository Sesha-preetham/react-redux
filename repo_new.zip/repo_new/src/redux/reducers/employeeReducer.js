import * as types from "../actions/actionTypes";
import initialState from "./initialState";

export default function employeeReducer(
  state = initialState.empDetails,
  action
) {
  switch (action.type) {
    case types.LOAD_EMPLOYEE_SUCCESS:
      return action.empDetails;

    case types.SEARCH_EMPLOYEE_SUCCESS: {
      // console.log({...action.empDetails});
      return [{ ...action.empDetails }];
    }
    default:
      return state;
  }
}
