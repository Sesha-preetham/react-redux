import React from "react";
//import PropTypes from "prop-types";
import { useForm } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
import * as yup from "yup";

// const schema = yup.object().shape({
//   id: yup.integer().positive(),
//   ename: yup.string(),
//   email: yup.string().email().required(),
//   phone: yup.number().positive().integer(),
//   DOJ: yup.date(),
// });

const Sample = () => {
  const { register, handleSubmit, errors } =
    useForm(); //{
    // resolver: yupResolver(schema),
    //}

  const submitForm = (data) => {
    console.log(data);
  };

  return (
    <form onSubmit={handleSubmit(submitForm)}>
      <input name="id" label="ID" ref={register} />
      <p> {errors.id && errors.id.message} </p>

      <input name="ename" label="NAME" type="text" ref={register} />
      <p> {errors.ename && errors.ename.message} </p>

      <input name="phone" label="PHONE" type="telephone" ref={register} />
      <p> {errors.phone && errors.phone.message} </p>

      <input name="email" label="Email" type="text" ref={register} />
      <p> {errors.email && errors.email.message} </p>

      <input name="DOJ" label="DOJ" type="date" ref={register} />
      <p> {errors.DOJ && errors.DOJ.message} </p>

      <button type="submit" className="btn btn-primary">
        Search
      </button>
    </form>
  );
};
export default Sample;
