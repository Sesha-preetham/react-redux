import { handleResponse, handleError } from "./apiUtils";
const baseUrl = process.env.API_URL + "/empDetails/";

export async function getEmployee() {
  try {
    const result = await fetch(baseUrl);
    return handleResponse(result);
  } catch (e) {
    return handleError(e);
  }
}

export async function searchEmployee(employeeId) {
  try {
    const result = await fetch(baseUrl + employeeId);
    return handleResponse(result);
  } catch (e) {
    return handleError(e);
  }
}
