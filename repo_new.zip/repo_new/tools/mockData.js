const empDetails = [
  {
    id: 1,
    empid: "GBS03807",
    ename: "Sethu",
    DOJ: "15-Jun-2016",
    slug: "react-auth0-authentication-security",
    phone: 9840112345,
    email: "sethu.n@centrico.com",
    address: "No:1 First Cross, Anna nagar, Chennai",
  },
  {
    id: 2,
    empid: "GBS05340",
    ename: "Sreekanth",
    DOJ: "15-Jun-2019",
    slug: "react-big-picture",
    phone: 9840112345,
    email: "sreekanth.pamujula@centrico.com",
    address: "No:2 First Cross, Anna nagar, Chennai",
  },
  {
    id: 3,
    empid: "GBS05635",
    ename: "Sakthi",
    DOJ: "15-Jun-2018",
    slug: "react-creating-reusable-components",
    phone: 9840112345,
    email: "sakthivel.k@centrico.com",
    address: "No:3 First Cross, Anna nagar, Chennai",
  },
  {
    id: 4,
    empid: "GBS06438",
    ename: "Sesha",
    DOJ: "15-Jun-2021",
    slug: "javascript-development-environment",
    phone: 9840112345,
    email: "seshakumar.t@centrico.com",
    address: "No:4 First Cross, Anna nagar, Chennai",
  },
];

const newEmployee = {
  id: "",
  empid: "",
  ename: "",
  DOJ: "",
  phone: "",
  email: "",
  address: "",
};

// Using CommonJS style export so we can consume via Node (without using Babel-node)
module.exports = {
  newEmployee,
  empDetails,
};
