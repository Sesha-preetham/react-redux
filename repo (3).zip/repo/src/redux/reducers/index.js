import { combineReducers } from "redux";
import empDetails from "./employeeReducer";

const rootReducer = combineReducers({
  empDetails
});

export default rootReducer;
