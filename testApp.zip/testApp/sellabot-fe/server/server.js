var app = require('./serverApp.js')
var modules = {
  loginModule: require('./chat/ChatService.js'),
}

function send_data(file, req, res, haltTime, successCallBack) {
  var allowedOrigins = ['http://localhost:3000', 'http://127.0.0.1:3000', 'http://localhost:3003', 'http://172.17.29.213'];
  var origin = req.headers.origin;
  if (allowedOrigins.indexOf(origin) > -1) {
    res.setHeader('Access-Control-Allow-Origin', origin);
  }
  var haltTimer = parseInt(haltTime) || 0;
  res.header('Access-Control-Allow-Methods', 'GET,PUT,POST,DELETE');
  res.header('Access-Control-Allow-Headers', 'Content-Type,Content-disposition');
  res.header('Access-Control-Allow-Origin', '*');

  app.fs.readFile('server/' + file, 'utf8', function (err, data) {
    if (!err) {
      setTimeout(function () {
        if (successCallBack) {
          successCallBack(data);
        } else {
          res.send(data);
        }

      }, haltTimer);


    }
    else
      res.send(err);
  })
}
for (var module in modules) {
  modules[module](app, send_data);
  console.log(module + ' loaded ');
}

app.listen(process.env.port)
console.log('server started in the port' + process.env.port)
