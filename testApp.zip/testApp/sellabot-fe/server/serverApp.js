var express = require('express')
var app = module.exports = express()
app.fs = require('fs');
var upperBound = '1gb';


var bodyParser = require('body-parser')
app.use( bodyParser.json() );       // to support JSON-encoded bodies
app.use(bodyParser.urlencoded({     // to support URL-encoded bodies
  extended: true,
   limit: upperBound
})); 


app.use(function (req, res, next) {
  res.setHeader('Access-Control-Allow-Origin', '*')
  //res.setHeader('Access-Control-Allow-Credentials', true)
  //res.setHeader('Access-Control-Allow-Methods', 'GET,PUT,POST,DELETE')
  res.setHeader('Access-Control-Allow-Headers', 'appversion, content-type,Content-Disposition,tid,X-CSRF-TOKEN')
  next()
})
