module.exports = function (app, sendRespFromFile) {
  app.post('/sellabot/execute/user/chat', function (req, res) {
    var jsonFile = 'chat/chat.json';
     sendRespFromFile(jsonFile, req, res)
   })
   app.post('/sellabot/execute/user/poll', function (req, res) {
    var jsonFile = 'chat/poll.json';
     sendRespFromFile(jsonFile, req, res)
   })
    app.post('/sellabot/execute/user/syncalias', function (req, res) {
    var jsonFile = 'chat/poll.json';
     sendRespFromFile(jsonFile, req, res)
   })
    app.post('/sellabot/execute/page/properties', function (req, res) {
    var jsonFile = 'chat/properties.json';
     console.log("properties")
     sendRespFromFile(jsonFile, req, res)
   })
    app.post('/sellabot/execute/services/logout', function (req, res) {
    var jsonFile = 'chat/properties.json';
    console.log("logout")
     sendRespFromFile(jsonFile, req, res)
   })
     app.post('/sellabot/execute/feedback/questions', function (req, res) {
    var jsonFile = 'chat/properties.json';
    console.log("logout")
     sendRespFromFile(jsonFile, req, res)
   })
   app.post('/sellabot/execute/user/info', function (req, res) {
    var jsonFile = 'chat/user.json';
    console.log("logout")
     sendRespFromFile(jsonFile, req, res)
   })
}
