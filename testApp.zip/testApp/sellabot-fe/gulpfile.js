var gulp = require('gulp');
var path = require('path');
var $ = require('gulp-load-plugins');

var runSequence = require('run-sequence');
var del = require('del');
var babel = require('gulp-babel')
var stylus = require('gulp-stylus')
var nib = require('nib')

var browserSync = require('browser-sync')
var rename = require('gulp-rename')
var es = require('event-stream')
var replace = require('gulp-replace')
var gutil = require('gulp-util')
var service = require('gulp-service')
var stripDebug = require('gulp-strip-debug');
var modifyFile = require('gulp-modify-file');


var reload       = browserSync.reload;


var jsFiles = {
  vendor: [

  ],
  source: [
    'assets/js/chat.js',
    'assets/js/questinario.js',
    
  ]
};

// Lint JS/JSX files


// Copy assets/js/vendor/* to assets/js
gulp.task('copy-js-vendor', function() {
  return gulp
    .src([
      'assets/vendor/react.js',
      'assets/vendor/react-dom.js'
    ])
    .pipe(gulp.dest('assets/dest'));
});


gulp.task('copy-img', function() {
  return gulp
    .src(['assets/images/*' ])
    .pipe(gulp.dest('../sellabot-web/src/main/webapp/images'));
});
gulp.task('copy-css', function() {
  return gulp
    .src(['assets/css/*' ])
    .pipe(gulp.dest('../sellabot-web/src/main/webapp/css'));
});
// Concatenate jsFiles.vendor and jsFiles.source into one JS file.
// Run copy-react and eslint before concatenating

gulp.task('jsx', function () {
  return gulp.src('assets/js/*.js')
    .pipe(babel({ presets: ['react', 'es2015'], plugins: ["transform-object-assign"] }))
    .pipe(gulp.dest('../sellabot-web/src/main/webapp/js'))
})
gulp.task('source-build', function () {
  
  $.requirejs({
    baseUrl: 'dest/js',
    name: 'app',
    out: 'chat.min.js',
    mainConfigFile:"app.js"
  })
    .pipe($.uglify({
      comments: false,
      mangle: false
    }))
    .pipe(stripDebug())
    .pipe(gulp.dest('../sellabot-web/src/main/webapp/'));
})

// Watch JS/JSX and Sass files
gulp.task('watch', function() {
  gulp.watch('assets/js/*.{js,jsx}', ['jsx']);
 
});

// BrowserSync
gulp.task('browsersync', function() {
  browserSync({
    server: {
      baseDir: '../sellabot-web/src/main/webapp'
    },
    open: false,
    online: false,
    notify: false,
  });
});


gulp.task('run:service', function () {
  service.run('server/server.js', {
    env: {
      port: 3003
    }
  });
  })
gulp.task('build', ['copy-js-vendor', 'copy-img','copy-css','jsx','run:service']);
gulp.task('default', ['build', 'browsersync', 'watch'])