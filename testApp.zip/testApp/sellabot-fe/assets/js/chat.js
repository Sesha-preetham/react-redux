define(['react', 'react-dom','polyfill','axios','jquery'], function (React, ReactDOM,polyfill,axios,jquery) {

    'use strict';
    var CommentBoxComp = React.createClass({
        render: function () {
            var question = this.props.ques
            return (
                <div>
                    <h3 className="poll-subtitle">{question.questionDesc}</h3>
                    <textarea name="1_4_9" className="poll-textarea" id="chatTextArea"></textarea>

                </div>
            )
        }
    });

    var FutureChatComp = React.createClass({
        render: function () {
            var question = this.props.ques
            return (
                <div>
                    <h3 className="poll-subtitle">{question.questionDesc}</h3>
                    {question.options.map(function (item) {
                        return (<div className="future_chat">
                            <input type="radio" name="yesno" value={item.optionId} id={'CHAT_NEEDED_' + item.optionId} />
                            <label htmlFor={'CHAT_NEEDED_' + item.optionId}> {item.optionDesc}</label></div>)
                    }.bind(this))
                    }
                </div>
            )
        }
    });

    var SimelyComp = React.createClass({
        selectedSmiley: function (event) {
            $('.smiley').removeClass('active');
            $(event.currentTarget).find('.smiley').addClass("active");
        },
        render: function () {
            var question = this.props.ques
            return (
                <div className="poll-content">
                    <h3 className="poll-subtitle">{question.questionDesc}</h3>
                    <ul className="poll-option">

                        {
                            question.options.map(function (item) {
                                return (<li>
                                    <input type="radio" name="smiley" value={item.optionId} className="poll-option__radio" id={"SMILEY_" + item.optionId} />
                                    {item.optionDesc == "Ottimo" ?
                                        <label htmlFor={"SMILEY_" + item.optionId} onClick={this.selectedSmiley}><div className='smiley Ottimo' alt="smiley" ></div></label> :
                                        item.optionDesc == "Buono" ? <label htmlFor={"SMILEY_" + item.optionId} onClick={this.selectedSmiley}><div className='smiley Buono' alt="smiley" ></div></label> :
                                            item.optionDesc == "Sufficiente" ? <label htmlFor={"SMILEY_" + item.optionId} onClick={this.selectedSmiley}><div className='smiley Sufficiente' alt="smiley" ></div></label> :
                                                item.optionDesc == "Scarso" ? <label htmlFor={"SMILEY_" + item.optionId} onClick={this.selectedSmiley}><div className='smiley Scarso' alt="smiley" ></div></label> :
                                                    item.optionDesc == "Non adeguato" ? <label htmlFor={"SMILEY_" + item.optionId} onClick={this.selectedSmiley}><div className='smiley Non_adeguato' alt="smiley" ></div></label> : null}

                                    <label className="poll-option__label">
                                        {item.optionDesc}
                                    </label>
                                </li>)
                            }.bind(this))
                        }

                    </ul>
                </div>
            )
        }
    });
    var InviaInputField = React.createClass({
        onkeyPress: function (e) {
            if (e.keyCode == 13) {
                this.props.events.messagePush(this.refs.messageText.value);
                this.refs.messageText.value = "";
            }
            else {
                this.props.events.onTyping(e);
            }
        },
        doMessagePush: function () {
            if( $(".chat-input-wrap .chat-btn").hasClass("reopen")){
                this.props.events.messageConnect();
                
            }
            else{
            if (this.refs.messageText.value) {
                this.props.events.messagePush(this.refs.messageText.value);
                this.refs.messageText.value = "";
            }
            }
        },
        render: function () {
            return (
                <div className="chat-input-wrap" >
                    <input type="text" size="20" className="chat-input" placeholder="Scrivi il tuo messaggio..." ref="messageText" onKeyDown={this.onkeyPress} />
                    <button className="chat-btn" onClick={this.doMessagePush}>invia</button>
                </div>
            )
        }
    })

    var ChatBoxContainer = React.createClass({
        getInitialState:function(){
            return{
                lastmsg:''
            }
        },
        componentDidUpdate: function () {
            $('.chat-panel-body').animate({ scrollTop: $('.chat-panel-body').prop("scrollHeight") }, 500);
            this.props.setlastMessage(this.state.lastmsg)
        },
        doRedirect: function (obj) {
            var intendtCode = obj && obj.intentCode || null;
            var url = obj && obj.url || (obj && obj.link) || null;

            if (url.indexOf('hbroute') == -1  && url.indexOf('https://SMEBANKING/')==-1) {
                var redirectURL = url.indexOf("http") == -1 ? window.location.origin + "/" + url : url;
                 var randomnumber = Math.floor((Math.random()*100)+1); 
             //   window.opener.open(redirectURL,"_blank",'Redirect',randomnumber);
                  
                window.open(redirectURL);

            } else {
                if(window.opener){
                    var reUrl = url.replace('https://SMEBANKING/','');
                    var redirectURL = window.opener.location.href + reUrl;
                    if (window.opener.location.href.indexOf("#") != -1) {
                        redirectURL =window.opener.location.href.split("#")[0] + "#" + url
                        if(url.indexOf(";")==-1){
                            redirectURL = redirectURL+";";
                        }
                    }
                    //window.opener.location.href = redirectURL;
                    window.opener.location.replace(redirectURL);
                }
            }

        },
        render: function () {
           
            return (
                <div className="chat-panel-body">
                    <div className="chat-messagein"><b>{this.props.name}</b>&nbsp;è in chat</div>
                    {this.props.messagelist.map(function (message,index) {
                        
                        if (message.sender == "BOT") {
                            var messageString = message.message || message.answer
                            var messageintent = message.intentCode || undefined;
                            var linkurl = message.url ||  message.link || undefined;
                            if(!messageString && message.action=="OPERATOR"){
                            if(this.props.operatorAvail && this.props.operatorAvail.toUpperCase()=="FALSE"){
                                messageString = "Non sono riuscita a comprendere la richiesta, se lo desideri ti posso mettere in contatto con un nostro operatore dell’assistenza. Clicca qui per proseguire";
                            }
                            else{
                                 messageString = "Non sono riuscita a comprendere la richiesta, se lo desideri puoi contattare l'assistenza clienti al numero 800.142.142 (per le chiamate da rete fissa nazionale) oppure al numero 0039.015.24.34.617 (per le chiamate dall'estero e da telefono cellulare) attivi dal lunedì al venerdì dalle ore 8.00 alle 21.00";
                            }
                        }
                            if(messageString){
                            this.state.lastmsg =message;
                            }
                            return (<div className={"chat-message chat-message--bank"+(!messageString ?" emptymessage":"")}>
                            {messageString ?
                                <img src={window.location.origin + "/sellabot/images/newstyle/icn_logo@2x.png"} className="reply-icon" />:null}

                                 {messageString ?
                                <p className="chat-message__text" id={"msg_"+index}><span className="msgString" dangerouslySetInnerHTML={{ __html: messageString }}></span></p>:null}

                                { linkurl && !this.props.isShowButton ?
                                <div className="botnavigatecontainer"> 
                                  <div className="anonymouslogin"> Per procedere devi autenticarti cliccando in alto sul tasto ACCEDI </div>
                                </div>
                                :
                                    (linkurl ||  (message.action=="OPERATOR" && this.props.operatorAvail && this.props.operatorAvail.toUpperCase()=="FALSE")) ? 
                                    <div className="botnavigatecontainer">
                                    <button className={ message.action=="OPERATOR" ?"chat-btn bot-navigate-btn operatorcls" : "chat-btn bot-navigate-btn"} onClick={ message.action=="OPERATOR" ? this.props.doOperatorRedirect :this.doRedirect.bind(this, message)}>
                                    { message.action=="OPERATOR" ? "AVVIA CHAT CON UN OPERATORE":"vai alla pagina"}
                                    {linkurl && linkurl.indexOf('hbroute') == -1 ? <img className="restore-icon" alt="restore_icon" src={window.location.origin + "/sellabot/images/out-link@2x.png"} /> : null}</button></div> :null}

                               
                            </div>)
                        } else if (message.sender != "BOT") {
                            this.state.lastmsg =message;
                            return (<div className="chat-message chat-message--user">
                                <span className="chat-message__sender initial">{message.sender}</span>
                                <span className="chat-message__sender name">{message.name}</span>
                                <p className="pull-right chat-message__text"><span className="msgString">{message.message}</span></p>
                            </div>)
                        }
                    }.bind(this))}
                     <div className="chat-messagein"><b>{this.props.name}</b>&nbsp;è uscito dalla chat</div>
                </div>
            )
        }
    })

    var ChatBotComp = React.createClass({
        getInitialState: function () {
            return {
                interval: "",
                messagelist: [],
                chatid: null,
                isStarted: false,
                doClose: false,
                redirectAgent: false,
                questionlist: [],
                showQuestion: false,
                historyStr: "",
                close: false,
                isInprogress: false,
                isComplete: false,
                sender:"",
                name:"",
                operatorAvail:null,
                typingStarted:false,
                lastMessage:null,
                operator:false,isAnonymous:false,
                categoria:null,
                isShowButton:false,
                cognome:null,
                email:null,
                channelId:null

            }
        },
        messagePush: function (messageText) {
            var self = this;
            var request = {
                "action": "chatevent",
                "chatid": self.state.chatid,
                "idevent": "chatmessage",
                "sourceIntentCode":this.getHpPageInfo(),
                "eventdata": [{
                    "name": "message",
                    "value": messageText
                }]
            }
            var messagelistArr = this.state.messagelist;
            if (messageText) {
                var temp = {};
                temp.message = messageText;
                temp.id = messagelistArr.length + 1;
                temp.sender = self.state.sender;
                temp.name = self.state.name;
                messagelistArr.push(temp);
            }
            // this.state.messagelist = Object.assign([], messagelistArr)
            this.setState({ messagelist: messagelistArr });
            axios.post(window.chatPath+'/sellabot/execute/user/chat', request).then(function (response) {
                  
                // if (!this.state.isStarted) {
                //     window.chatinterval = setInterval(function () {
                //         // self.messageRefresh();
                //         this.state.isStarted = true;
                //     }.bind(this), 1000)
                // }

            }.bind(this))
                .catch(function (error) {
                   
                }.bind(this));

        },
        getQuestions: function () {
            axios.post(window.chatPath+'/sellabot/execute/feedback/questions', request).then(function (response) {
                this.setState({ showQuestion: true, questionlist: response.data.questions });
            }.bind(this))
                .catch(function (error) {
                   
                }.bind(this));
        },
        doCloseModal: function () {
            $('#modalContent .close-mask-btn').attr("data-dismiss", "modal");
            $("#modalContent .close-mask-btn").trigger("click");
            $(".minmaxCon .modalMinimize").trigger("click");
            $("#chatmodal").empty();
            $(".minmaxCon").empty();
            $("body").removeClass("modal-open");
            

        },
        chuidiHandleClick: function (chaturl) {
            var self = this;
            var request = {
                "action": "endchat",
                "sourceIntentCode":this.getHpPageInfo()
            }
            axios.post(window.chatPath+'/sellabot/execute/user/chat', request)
                .then(function (response) {
                    clearInterval(window.chatinterval);
                   // this.logout();
                    if (!this.state.showQuestion && !this.state.redirectAgent && !this.state.doClose) {
                        axios.post(window.chatPath+'/sellabot/execute/feedback/questions', request).then(function (response) {
                            this.setState({ showQuestion: true, questionlist: response.data.questions });
                        }.bind(this)).catch(function (error) {
                            
                        }.bind(this));
                    } else {
                        if ((!this.state.doClose|| this.state.close) && (!this.state.redirectAgent || this.state.close)) {
                        
                        }
                        else if (this.state.redirectAgent) {
                            $(".chat-input-wrap .chat-input,.chat-input-wrap .chat-btn").attr("disabled", true);
                            $(".chat-input-wrap .chat-input").attr("placeholder", "Trasferire chat all'agente");
                              this.state.close = true;
                              //window.location.href = chaturl;
                              window.location.replace(chaturl);
                            //   var form = $('<form action="' + chaturl + '" method="post">' +
                            // '<input type="text" name="testoiniziale" value="' + this.state.historyStr + '" />' +
                            // '</form>');
                            // $('body').append(form);
                            // form.submit(); 
                        }
                        else if (this.state.doClose) {
                            $(".chat-input-wrap .chat-input,.chat-input-wrap .chat-btn").attr("disabled", true);
                            $(".chat-input-wrap .chat-input").attr("placeholder", "Grazie. Arrivederci..");
                            this.state.close = true;
                            this.state.doClose = false;
                        }
                        else {
                            this.state.doClose = false;
                         
                        }
                    }

                }.bind(this))
                .catch(function (error) {
                    clearInterval(window.chatinterval);
                      
                  
                });

        }, 
        setlastMessage:function(msg){
            this.state.lastMessage = msg;
        },
        onTyping: function (e) {
            var self = this;
            var request = {
                "action": "chatevent",
                "chatid": self.state.chatid,
                "idevent": "chattyping",
                "sourceIntentCode":this.getHpPageInfo(),
                "eventdata": [{
                    "name": "typing",
                    "value": true
                }]

            };
            if(!this.state.typingStarted){
            this.state.typingStarted = true;
            axios.post(window.chatPath+'/sellabot/execute/user/chat', request)
                .then(function (response) {
                      this.state.typingStarted = false;
                     if(response.data && response.data.status !="OK"){
                         this.handleException(response.data);
                     }
                }.bind(this))
                .catch(function (error) {
                  
                }.bind(this));
            }
        },
        handleException: function (data) {
            clearInterval(window.chatinterval);
              var list = Object.assign([], this.state.messagelist);
              $(".chat-input-wrap .chat-input,.chat-input-wrap .chat-btn").attr("disabled", true);
              $(".chat-input-wrap .chat-input").val('');
               if(data.errorMessageCode && data.errorMessageCode == "IM_CHAT_ID_NOT_FOUND" ){
                   $(".chat-input-wrap .chat-btn").text("RIAVVIA CHAT");
                   $(".chat-input-wrap .chat-btn").removeAttr("disabled");
                   $(".chat-input-wrap .chat-input").attr("placeholder", "Vuoi proseguire la conversazione con l'assistente virtuale?");
                   $(".chat-input-wrap .chat-btn").removeClass("disabled").addClass("reopen");
               }
              var msg = this.state.lastMessage;
              if (!msg ||(msg.action!="OPERATOR")) {
                 var i = list.length;
                 var  message = {};
                  message.action="OPERATOR"
                  message.sender ="BOT";
                 var listArr = list.push(message);
                this.setState({ messagelist: list });
              }
        },
        messageRefresh: function () {
            var self = this;
            var request = {
                "chatid": self.state.chatid
            }
            if (!this.state.isInprogress) {
                this.state.isInprogress = true;
                axios.post(window.chatPath+'/sellabot/execute/user/poll', request)
                    .then(function (response) {
                        if(response.data && response.data.status =="OK"){
                            this.state.isInprogress = false
                            var list = Object.assign([], this.state.messagelist);
                            var data = response.data.results;
                            var message = [];
                            var close = false;
                        
                            if (data.length > 0) {
                                for (var i = 0; i < data.length; i++) {
                                    message[i + 1] = {};
                                    message[i + 1].message = data[i].message;
                                    message[i + 1].sentDate = new Date();
                                    message[i + 1].nickName = data[i].sender;
                                    message[i + 1].answer = data[i].answer;
                                    if (data[i].action && data[i].action.toLowerCase() == "close") {
                                        this.state.doClose = true
                                    }
                                    if (data[i].action && data[i].action.toLowerCase() == "operator") {
                                            this.state.operator = true;
                                            $(".chat-input-wrap .chat-input,.chat-input-wrap .chat-btn").attr("disabled", true);
                                            $(".chat-input-wrap .chat-input").val('');
                                            $(".chat-input-wrap .chat-btn").text("RIAVVIA CHAT");
                                            $(".chat-input-wrap .chat-input").attr("placeholder", "Vuoi proseguire la conversazione con l'assistente virtuale?");
                                            $(".chat-input-wrap .chat-btn").removeAttr("disabled");
                                            $(".chat-input-wrap .chat-btn").removeClass("disabled").addClass("reopen");
                                        
                                    }
                                    

                                    var isAgent = true;
                                    if (data[i].sender && data[i].sender != "BOT") {
                                        isAgent = false;
                                    }
                                    message[i + 1].isAgent = isAgent;
                                    if (data[i].userJoined != null && data[i].userJoined) {
                                        self.state.agentLogged = true;
                                    }
                                };
                                var listArr = list.concat(data);
                                
                                clearInterval(window.chatinterval);
                                window.chatinterval = undefined;
                                if(!this.state.operator){
                                    window.chatinterval = setInterval(function () {
                                    self.messageRefresh();
                                    }.bind(this), window.pollDelay)
                                }
                                this.setState({ messagelist: listArr });
                            }else{
                                clearInterval(window.chatinterval);
                                window.chatinterval = undefined;
                                window.chatinterval = setInterval(function () {
                                    self.messageRefresh();
                                }.bind(this), 1000)
                            }
                            
                        } else {
                            this.handleException(response.data);
                        }
                        
                    }.bind(this))
                    .catch(function (error) {

                        this.state.isInprogress = false;
                         clearInterval(window.chatinterval);

                    }.bind(this));
            }
        },
        onClose: function () {
            if (this.state.doClose) {
                this.chuidiHandleClick();
                $(".chat-input-wrap .chat-input,.chat-input-wrap .chat-btn").addClass("disabled");
                $(".chat-input-wrap .chat-input,.chat-input-wrap .chat-btn").attr("disabled", true);
            }
        },
        messageConnect: function () {
            var self = this;
            var request = { 
                "action": "newchat",
                "sourceIntentCode":this.getHpPageInfo()
            };
            axios.post(window.chatPath+'/sellabot/execute/user/chat', request)
                .then(function (response) {
                    if(response.data && response.data.status =="OK"){
                        if($(".chat-input-wrap .chat-btn").hasClass("reopen")){
                            $(".chat-input-wrap .chat-btn").text("INVIA");
                            $(".chat-input-wrap .chat-input").attr("placeholder", "Scrivi il tuo messaggio...");
                            $(".chat-input-wrap .chat-btn,.chat-input-wrap .chat-input").removeAttr("disabled");
                            $(".chat-input-wrap .chat-btn,.chat-input-wrap .chat-input").removeClass("disabled");
                            $(".chat-input-wrap .chat-btn").removeClass("reopen");
                            this.state.operator = false;
                        }
                    this.state.chatid = response.data.chatid;
                    this.state.operatorAvail = response.data.overTime ||"";
                    window.chatinterval = undefined;
                    window.chatinterval = setInterval(function () {
                        self.messageRefresh();
                    }.bind(this), 1000)
                    }else{
                        this.handleException(response.data)
                    }
                    //this.props.setChatid(this.state.chatid);
                    // console.log(response);
                }.bind(this))
                .catch(function (error) {
                   
                }.bind(this));

        },
        printOutFunc: function () {
            if ($(".chat-panel-body").length > 0) {
              var newWin = window.open('', 'Print-Window');
                newWin.document.open();
                newWin.document.write('<html><link rel="stylesheet" type="text/css" href="css/style.css" /></head><body onload="window.print()">');
                newWin.document.write($(".chat-panel-body").html());
                newWin.document.write('</html>');
                newWin.document.close();
                setTimeout(function(){newWin.close()},100)
               
              
            }
        },
        componentDidMount: function () {
      
            var request = window &&  window.chatRequest ||{};
            axios.post(window.chatPath+"/sellabot/execute/user/syncalias",request)
            .then(function(){
                 this.messageConnect();
            }.bind(this))
            .catch(function (error) {
                   
                }.bind(this))
           
            
        },
        doOperatorRedirect:function(){
            this.state.redirectAgent= true;
            $(".chat-input-wrap .chat-input,.chat-input-wrap .chat-btn").addClass("disabled");
            $(".chat-input-wrap .chat-input,.chat-input-wrap .chat-btn").attr("disabled", true);
            this.getHistory();
           
        },
        componentWillMount:function(){
            this.getProperties();
            this.getUserInfo();
        },
        getHistory: function () {
            axios.post(window.chatPath+'/sellabot/execute/user/chat/history', {})
                .then(function (response) {
                    this.state.historyStr = response.data.history && encodeURIComponent(response.data.history) || "";
                    var chatId = response.data.chatId || "";
                    var sessionId = response.data.sessionId || "";
                     var chaturl = '/AuthenticationDelegatedServlet?delegated_service=219&SEACTION=LOGIN&SECODE=CHAT_IB&SEPARAMS=chatId='+chatId+'^CHANNEL='+this.state.channelId+'^categoria='+this.state.categoria;
                   
                    if (window.location.hostname && (window.location.hostname.indexOf("te.sella.it") != -1 || window.location.hostname.indexOf("172.17.29.47") != -1)) {
                        chaturl = 'https://pp.sella.it/AuthenticationDelegatedServlet?delegated_service=219&SEACTION=LOGIN&SECODE=CHAT_IB&SEPARAMS=chatId='+chatId+'^CHANNEL='+this.state.channelId+'^categoria='+this.state.categoria;
                    }
                    if(this.state.isAnonymous){
                        chaturl = chaturl+'^nome'+this.state.name+'^cognome'+this.state.cognome+'^email'+this.state.email 
                    }
                    
                     this.chuidiHandleClick(chaturl);
                }.bind(this))
                .catch(function (error) {
                  
                }.bind(this));
        },
        logout:function(){
            
            axios.post(window.chatPath+'/sellabot/execute/services/logout', {})
                .then(function (response) {
                   
                    
                }.bind(this))
                .catch(function (error) {
                   window.onunload = null
                });
                 window.onunload = null
                return null;
               
        },
       componentDidUpdate: function () {
           
            this.onClose();
           }, 
        conditionsCheckFunc: function () {
            var div = document.getElementById("poll-privacy-information");
            if (div.style.display == "none") {
                div.style.display = "block";
            }
            else {
                div.style.display = "none";
            }
        },
        submitChatQueries: function () {
            var self = this;
            var request = {
                "answers": [
                    {
                        "answerId": $('[name="yesno"]:checked').val(),
                        "answer": ""
                    },
                    {
                        "answerId": $('[name="smiley"]:checked').val(),
                        "answer": ""
                    },
                    {
                        "answerId": "9",
                        "answer": $("#chatTextArea").val(),
                    }
                ]
            };
            axios.post(window.chatPath+'/sellabot/execute/feedback/insert', request)
                .then(function (response) {
                    $("#first_page").hide();
                    $("#second_page").show();
                }.bind(this))
                .catch(function (error) {
                    // console.log(error);
                });
        },
        getProperties:function(){
             window.pollDelay= 5000
              axios.post(window.chatPath+'/sellabot/execute/page/properties', {code : "FE_PAGE_PROPS"})
                    .then(function (response) { 
                       
                        if(response.data && response.data.props && response.data.props.POLL_DELAY_SEC){
                             window.pollDelay= parseInt(response.data.props.POLL_DELAY_SEC)*1000;
                        }
                    }.bind(this))
                      .catch(function (error) {
                    // console.log(error);
                });
        },
        getUserInfo:function(){
            window.pollDelay= 5000
             axios.post(window.chatPath+'/sellabot/execute/user/info')
                   .then(function (response) { 
                      
                       if(response.data){
                           this.state.name= response.data.nome;
                           this.state.sender = response.data.nickName;
                           this.state.isAnonymous = response.data.isAnonymous;
                           this.state.isShowButton = response.data.isShowButton;
                           this.state.categoria = response.data.categoria;
                           this.state.cognome = response.data.cognome;
                           this.state.email = response.data.email;
                           this.state.channelId = response.data.channelId;
                       }
                   }.bind(this))
                     .catch(function (error) {
                   // console.log(error);
               });
       },
        getHpPageInfo:function(){
            var hbPageInfo = '';
            var hbPageInfoObj = window.opener ? window.opener.hbPageInfo : '';
            if(hbPageInfoObj && hbPageInfoObj.currentPageName) {
                hbPageInfo = hbPageInfoObj.currentPageName;
                if(hbPageInfoObj.currentTabName) {
                    hbPageInfo = hbPageInfo+';'+hbPageInfoObj.currentTabName;
                    if(hbPageInfoObj.currentSubTabName) {
                        hbPageInfo = hbPageInfo+';'+hbPageInfoObj.currentSubTabName;
                    }
                }
            } 
            return hbPageInfo;
        },
        render: function () {
            
            if (!this.state.showQuestion) {
                return (

                    <div className="">
                        <div className="header-wrap row">
                            <div className="chat-icon-left col-sm-6 col-xs-6">
                                <img src={window.location.origin + "/sellabot/images/logo-sellait@2x.png"} className="chat-header-logo" alt="Logo Sella.it" />
                            </div>
                            <div className="chat-icon-right col-sm-6 col-xs-6 pull-right">
                                <img src={window.location.origin + "/sellabot/images/newstyle/iconmonstr-printer-3-240.png"} className="printer-close-icon" alt="Logo Sella.it" onClick={this.printOutFunc} />
                                 <img src={window.location.origin + "/sellabot/images/newstyle/close.png"} className="printer-close-icon" alt="Close" onClick={this.chuidiHandleClick} />

                            </div>
                        </div>
                        <div className="chat-body">
                            {this.state.messagelist && this.state.messagelist.length > 0 ?
                                <ChatBoxContainer  messagelist={this.state.messagelist} name={this.state.name} doOperatorRedirect={this.doOperatorRedirect} operatorAvail={this.state.operatorAvail} setlastMessage={this.setlastMessage} isAnonymous={this.state.isAnonymous}
                                isShowButton={this.state.isShowButton}/> : null
                            }
                        </div>
                        <InviaInputField events={{ messagePush: this.messagePush, onTyping: this.onTyping,messageConnect :this.messageConnect}} />
                    </div>
                )
            } else {
                return (<div className="poll-container">
                    <div id="first_page">
                        {this.state.questionlist.map(function (question) {
                            return (<div>
                                {question.questionType == "3" && question.questionId == "2" ?
                                    <SimelyComp ques={question} /> : null}
                                {question.questionType == "3" && question.questionId == "3" ? <FutureChatComp ques={question} /> : null}
                                {question.questionType == "1" && question.questionId == "4" ? <CommentBoxComp ques={question} /> : null}
                            </div>)
                        })}
                        <p className="poll-privacy-note">
                            Partecipando al sondaggio acconsenti al trattamento dei dati per la finalità di seguito riportate.
                        <span className="poll-privacy-toggle" onClick={this.conditionsCheckFunc}>&nbsp;Leggi l'informativa privacy.</span>
                        </p>
                        <p className="poll-privacy-note poll-hide" id="poll-privacy-information" style={{ display: "none" }}>
                            <strong>Informativa ai sensi dell'art. 13 del D.Lgs. 196/03 (Codice Privacy).</strong><br />
                            Banca Sella S.p.A., con sede in Biella (BI) - 13900, Piazza Gaudenzio Sella, n. 1, in qualità di Titolare del trattamento dei dati, La informa, ai sensi dell'art. 13 del Regolamento UE 2016/679 che i dati da Lei forniti saranno trattati nel rispetto della citata legge, mediante strumenti manuali, informatici e telematici per finalità di rilevazione del grado di soddisfazione della clientela sulla qualità dei servizi resi e sull'attività svolta dalla Banca e dal Gruppo Banca Sella ed elaborazione di studi e ricerche di mercato e potranno essere comunicati alle società appartenenti al Gruppo Banca Sella ovvero controllate o collegate e società terze, che svolgano per suo conto trattamenti di dati per le medesime finalità. L'elenco dettagliato di tali soggetti può essere consultato presso i locali della Banca aperti al pubblico e sul sito internet <a href="http://www.sella.it/" target="_blank">www.sella.it.</a> 
                             Per l'esercizio dei diritti di cui all'art. 7 del Decreto Legislativo n. 196/2003, potrà scrivere a Banca Sella S.p.A. - Ufficio Reclami, con sede in Biella (BI) - 13900, Piazza Gaudenzio Sella, n. 1, oppure all'indirizzo di posta elettronica privacy@sella.it.<br />
                            L'elenco aggiornato dei responsabili del trattamento dei dati personali può essere consultato presso i locali della Banca aperti al pubblico e sul sito Internet <a href="http://www.sella.it/" target="_blank">www.sella.it</a><br />
                            Questa comunicazione è inviata sulla base dell'interesse legittimo del Titolare a valutare la qualità dei propri servizi.<br />
                            I Suoi dati di sondaggio, una volta ricevuti, sono anonimizzati.<br />
                        </p>
                        <button type="submit" name="submitPoll" id="submitPoll" className="poll-button" onClick={this.submitChatQueries}>INVIA</button>
                    </div>
                    <div id="second_page" style={{ display: "none" }} >
                        <div className="poll-content">
                            <div className="poll-thanks-check">
                                <p className="poll-thanks-check-text">
                                    GRAZIE PER LA COLLABORAZIONE<br />
                                   <span> La tua opinione è molto importante per permetterci di migliorare la qualità del nostro servizio.</span>
		                            </p>
                            </div>
                        </div>
                    </div>
                </div>)
            }
        }

    });


   return function(){
       return  ReactDOM.render(<ChatBotComp/>,document.getElementById('chatcontainer'))
   }
});