'use strict';

var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };

define(['react', 'axios'], function (React, axios) {

            'use strict';

            var InviaInputField = React.createClass({
                        displayName: 'InviaInputField',

                        onkeyPress: function onkeyPress(e) {
                                    if (e.keyCode == 13) {
                                                this.props.events.messagePush(this.refs.messageText.value);
                                                this.refs.messageText.value = "";
                                    }
                        },
                        doMessagePush: function doMessagePush() {
                                    if (this.refs.messageText.value) {
                                                this.props.events.messagePush(this.refs.messageText.value);
                                                this.refs.messageText.value = "";
                                    }
                        },
                        render: function render() {
                                    return React.createElement(
                                                'div',
                                                { className: 'chat-input-wrap' },
                                                React.createElement('input', { type: 'text', size: '20', className: 'chat-input', placeholder: 'Scrivi il tuo messaggio...', ref: 'messageText', onKeyDown: this.onkeyPress }),
                                                React.createElement(
                                                            'button',
                                                            { className: 'chat-btn', onClick: this.doMessagePush },
                                                            'invia'
                                                )
                                    );
                        }
            });

            var ChatBoxContainer = React.createClass({
                        displayName: 'ChatBoxContainer',

                        doRedirect: function doRedirect(obj) {
                                    var intendtCode = obj && obj.intentCode || null;
                                    var url = obj && obj.link || null;
                                    var hbStore = getHbStore();
                                    if (url) {
                                                var redirectURL = url.indexOf("http") == -1 ? window.location.origin + "/" + url : url;
                                                window.location.href = redirectURL;
                                    } else if (intendtCode) {
                                                $('#chatbot .minus').trigger("click");
                                                $("#modalContent .close-mask-btn").trigger("click");
                                                hbStore.dispatch(hbStore.dispatch(PageStatusAction.initpage('/MIEI_CONTI', '')));
                                    }
                        },
                        render: function render() {

                                    return React.createElement(
                                                'div',
                                                { className: 'chat-panel-body' },
                                                this.props.messagelist.map(function (message) {
                                                            if (message.sender == "BOT") {
                                                                        var messageString = message.message || message.answer;
                                                                        var messageintent = message.intentCode || undefined;
                                                                        var linkurl = message.link || undefined;
                                                                        return React.createElement(
                                                                                    'div',
                                                                                    { className: 'chat-message chat-message--bank' },
                                                                                    React.createElement('img', { src: 'images/newstyle/icn_logo@2x.png', className: 'reply-icon' }),
                                                                                    React.createElement(
                                                                                                'p',
                                                                                                { className: 'chat-message__text' },
                                                                                                messageString
                                                                                    ),
                                                                                    messageintent ? React.createElement(
                                                                                                'button',
                                                                                                { className: 'chat-btn bot-navigate-btn', onClick: this.doRedirect.bind(this, message) },
                                                                                                'vai alla pagina ',
                                                                                                linkurl ? React.createElement('img', { className: 'restore-icon', alt: 'restore_icon', src: 'images/out-link@2x.png' }) : null
                                                                                    ) : null
                                                                        );
                                                            } else if (message.sender != "BOT") {
                                                                        return React.createElement(
                                                                                    'div',
                                                                                    { className: 'chat-message chat-message--user' },
                                                                                    React.createElement(
                                                                                                'span',
                                                                                                { className: 'chat-message__sender' },
                                                                                                message.sender
                                                                                    ),
                                                                                    React.createElement(
                                                                                                'p',
                                                                                                { className: 'pull-right chat-message__text' },
                                                                                                message.message
                                                                                    )
                                                                        );
                                                            }
                                                }.bind(this))
                                    );
                        }
            });
            var ChatBotComp = React.createClass({
                        displayName: 'ChatBotComp',

                        getInitialState: function getInitialState() {
                                    return {
                                                interval: "",
                                                messagelist: null,
                                                chatid: null
                                    };
                        },
                        messagePush: function messagePush(messageText) {
                                    var self = this;
                                    var request = {
                                                "action": "chatevent",
                                                "chatid": self.state.chatid,
                                                "idevent": "chatmessage",
                                                "eventdata": [{
                                                            "name": "message",
                                                            "value": messageText
                                                }]
                                    };
                                    var messagelistArr = this.state.messagelist;
                                    if (messageText) {
                                                var temp = {};
                                                temp.value = messageText;
                                                temp.id = messagelistArr.length + 1;
                                                messagelistArr.push(temp);
                                                // alert(messagelistArr);
                                    }
                                    this.state.messagelist = _extends([], messagelistArr);
                                    axios.post('http://localhost:3003/sellabot/execute/user/chat', request);
                                    this.messageRefresh(messageText);
                        },
                        chuidiHandleClick: function chuidiHandleClick() {
                                    var self = this;
                                    var request = {
                                                "action": "endchat",
                                                "chatid": self.state.chatid
                                    };
                                    axios.post('http://localhost:3003/sellabot/execute/user/chat', request).then(function (response) {
                                                clearInterval(self.state.interval);
                                                self.setState({
                                                            chatid: "ENDCHAT"
                                                });
                                    }).catch(function (error) {});
                        },
                        messageRefresh: function messageRefresh(messageText) {
                                    var self = this;
                                    if (messageText) {
                                                var temp = {};
                                                temp.value = messageText;
                                                temp.id = this.state.messagelist.length + 1;
                                                this.state.messagelist.push(temp);
                                                // alert(messagelistArr);
                                    } else {
                                                var request = {
                                                            "chatid": self.state.chatid
                                                };
                                                axios.post('http://localhost:3003/sellabot/execute/user/poll', request).then(function (response) {
                                                            var data = response.data.results;
                                                            for (var i = 0; i < data; i += 1) {
                                                                        message[i + 1] = {};
                                                                        message[i + 1].message = data[i].message;
                                                                        message[i + 1].sentDate = new Date();
                                                                        message[i + 1].nickName = data[i].sender;
                                                                        var isAgent = true;
                                                                        if (data[i].sender && data[i].sender != "BOT") {
                                                                                    isAgent = false;
                                                                        }
                                                                        message[i + 1].isAgent = isAgent;
                                                                        if (data[i].userJoined != null && data[i].userJoined) {
                                                                                    self.state.agentLogged = true;
                                                                        }
                                                            };

                                                            this.setState({ messagelist: data });
                                                            clearInterval(window.chatinterval);
                                                }.bind(this)).catch(function (error) {});
                                    }
                        },

                        messageConnect: function messageConnect() {
                                    var self = this;
                                    var request = {
                                                "action": "newchat",
                                                "parameters": [{
                                                            "name": "AppName",
                                                            "value": "BancaSella_Chat"
                                                }, {
                                                            "name": "AppVersion",
                                                            "value": "1.0"
                                                }, {
                                                            "name": "CustomerID",
                                                            "value": "14"
                                                }, {
                                                            "name": "Lang",
                                                            "value": "it-IT"
                                                }, {
                                                            "name": "MMChannels_Chat_client_name",
                                                            "value": "SellaChat"
                                                }, {
                                                            "name": "MMChannels_Chat_client_made",
                                                            "value": "BancaSella"
                                                }, {
                                                            "name": "MMChannels_Chat_client_version",
                                                            "value": "1.0"
                                                }, {
                                                            "name": "InteractionTimeout",
                                                            "value": "30000"
                                                }, {
                                                            "name": "DevelopmentStatus",
                                                            "value": "Deployed"
                                                }, {
                                                            "name": "MMChannels_Chat_client_backend",
                                                            "value": "https://te-soa.bansel.it/osb/SellaBot/res"
                                                }]
                                    };
                                    axios.post('http://localhost:3003/sellabot/execute/user/chat', request).then(function (response) {
                                                this.state.chatid = response.data.chatid;
                                                this.props.setChatid(this.state.chatid);
                                                window.chatinterval = setInterval(function () {
                                                            self.messageRefresh();
                                                }, 1000);
                                    }.bind(this)).catch(function (error) {
                                                console.log(error);
                                    });
                        },
                        componentDidMount: function componentDidMount() {
                                    this.messageConnect();
                        },
                        render: function render() {
                                    return React.createElement(
                                                'div',
                                                { className: 'col-sm-12' },
                                                React.createElement(
                                                            'div',
                                                            { className: 'header-wrap row' },
                                                            React.createElement(
                                                                        'div',
                                                                        { className: 'chat-icon-left col-sm-6 col-xs-6' },
                                                                        React.createElement('img', { src: 'images/logo-sellait.png', className: 'chat-header-logo', alt: 'Logo Sella.it' })
                                                            ),
                                                            React.createElement(
                                                                        'div',
                                                                        { className: 'chat-icon-right col-sm-6 col-xs-6 pull-right' },
                                                                        React.createElement('img', { src: 'images/newstyle/iconmonstr-printer-3-240.png', className: 'printer-close-icon', alt: 'Logo Sella.it' })
                                                            )
                                                ),
                                                this.state.messagelist && this.state.messagelist.length > 0 ? React.createElement(ChatBoxContainer, { messagelist: this.state.messagelist }) : null,
                                                React.createElement(InviaInputField, { events: { messagePush: this.messagePush } })
                                    );
                        }

            });

            var Chat = React.createClass({
                        displayName: 'Chat',
                        render: function render() {

                                    return React.createElement('div', { className: 'test' });
                        }
            });

            return function () {
                        return ChatBotComp;
            };
});