package it.sella.sellabotcore;
import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.support.AnnotationConfigContextLoader;

import it.sella.sb.core.facade.ChatTypingFacade;
import it.sella.sb.external.im.IMservice;
import it.sella.sb.im.dto.request.ChatTypingRequest;
import it.sella.sb.im.dto.request.IMRequest;
import it.sella.sb.im.dto.response.IMResponse;
import it.sella.sb.im.response.BaseResponse.BaseStatusEnum;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(loader=AnnotationConfigContextLoader.class)
public class ChatTypingFacadeTest {
	
	@InjectMocks
	ChatTypingFacade chatTypingFacade;
	
	@Mock
	private IMservice imService;
	
	@Before()
	public void init(){
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void getChatHistory(){
		IMRequest imRequest = new IMRequest();
		imRequest.setChaturl("ChatUrl");
		imRequest.setChatid("ChatId");
		
		ChatTypingRequest chatTypingRequest = new ChatTypingRequest();
		
		IMResponse response = new IMResponse();
		response.setStatus(BaseStatusEnum.OK);
		
		Mockito.when(imService.message(imRequest)).thenReturn(response);
		chatTypingFacade.chatTyping(imRequest, chatTypingRequest);
		assertEquals(BaseStatusEnum.OK.name(), response.getStatus());
	}
	
}
