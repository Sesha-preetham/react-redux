package it.sella.sellabotcore;
import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.support.AnnotationConfigContextLoader;

import it.sella.sb.anagrafe.dto.PersonalDetails;
import it.sella.sb.core.facade.ChatHistoryFacade;
import it.sella.sb.core.im.MessageHandler;
import it.sella.sb.external.im.IMservice;
import it.sella.sb.hb.dto.SbUserDetail;
import it.sella.sb.im.IMessageDAO;
import it.sella.sb.im.dto.request.IMRequest;
import it.sella.sb.im.dto.response.IMResponse;
import it.sella.sb.im.response.BaseResponse.BaseStatusEnum;
import it.sella.sb.poll.dto.PollResponse;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(loader=AnnotationConfigContextLoader.class,classes={})
public class ChatHistoryFacadeTest {
	
	@InjectMocks
	ChatHistoryFacade chatHistoryFacade;
	
	@Mock
	private IMservice imService;
	
	@InjectMocks
	private MessageHandler messageHandler;
	
	@Mock
	private IMessageDAO messageDAO;
	
	@Before()
	public void init(){
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void getChatHistory(){
		
		IMRequest imRequest = new IMRequest();
		imRequest.setChaturl("ChatUrl");
		imRequest.setChatid("ChatId");
		
		SbUserDetail user = new SbUserDetail();
		PersonalDetails person = new PersonalDetails();
		user.setPersonalDet(person);
		
		IMResponse response = new IMResponse();
		List<Map<String, String>> transcript = new ArrayList<>();
		Map<String, String> trans = new HashMap<>();
		trans.put("channel", "chat");
		transcript.add(trans);
		response.setTranscript(transcript);
		response.setStatus(BaseStatusEnum.OK);
		
		Mockito.when(imService.message(imRequest)).thenReturn(response);
		chatHistoryFacade.getChatHistory(imRequest, user);
		assertEquals(BaseStatusEnum.OK.name(), response.getStatus());
		
	}
	
	@Mock 
	private HttpSession mockHttpSession;
	
	@Test
	public void readMessage(){
		
		List<String> messages = new ArrayList<>();
		Map<String, String> map = new HashMap<>();
		map.put("action", "chatevent");
		map.put("chatid", "g4fdkge29m7cm534n90i7bkpc3");
		map.put("idevent", "chatresult");
		List<Map<String, String>> eventDatas = new ArrayList<>();
		map.put("eventdata", eventDatas.toString());
		messages.add(map.toString());
		
		SbUserDetail user = new SbUserDetail();
		user.setAppName("SME");
		user.setBlockAllIntents(false);
		Mockito.when(this.messageDAO.readMessage(Mockito.anyString())).thenReturn(messages);
		Mockito.when(mockHttpSession.getAttribute(Mockito.anyString())).thenReturn(user);
		PollResponse response = messageHandler.readMessage("", mockHttpSession);
		assertEquals(BaseStatusEnum.OK.name(), response.getStatus());
		
	}
	
}
