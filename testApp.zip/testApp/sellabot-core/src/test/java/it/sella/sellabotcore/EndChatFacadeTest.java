package it.sella.sellabotcore;
import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.support.AnnotationConfigContextLoader;

import it.sella.sb.anagrafe.dto.PersonalDetails;
import it.sella.sb.core.facade.EndChatFacade;
import it.sella.sb.external.im.IMservice;
import it.sella.sb.hb.dto.SbUserDetail;
import it.sella.sb.im.IMessageDAO;
import it.sella.sb.im.dto.request.IMRequest;
import it.sella.sb.im.dto.response.IMResponse;
import it.sella.sb.im.response.BaseResponse.BaseStatusEnum;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(loader=AnnotationConfigContextLoader.class)
public class EndChatFacadeTest {
	
	@InjectMocks
	EndChatFacade endChatFacade;
	
	@Mock
	private IMservice imService;
	
	@Mock
	IMessageDAO messageDAO;
	
	@Before()
	public void init(){
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void getChatHistory(){
		IMRequest imRequest = new IMRequest();
		imRequest.setChaturl("ChatUrl");
		imRequest.setChatid("ChatId");
		
		SbUserDetail user = new SbUserDetail();
		PersonalDetails person = new PersonalDetails();
		user.setPersonalDet(person);
		
		IMResponse response = new IMResponse();
		response.setStatus(BaseStatusEnum.OK);
		
		Mockito.doNothing().when(messageDAO).preserveMessage(Mockito.isA(IMRequest.class), Mockito.isA(String.class) , Mockito.isA(String.class),Mockito.isA(SbUserDetail.class));
		Mockito.when(imService.message(imRequest)).thenReturn(response);
		endChatFacade.endChat(imRequest, user);
		assertEquals(BaseStatusEnum.OK.name(), response.getStatus());
	}
	
}
