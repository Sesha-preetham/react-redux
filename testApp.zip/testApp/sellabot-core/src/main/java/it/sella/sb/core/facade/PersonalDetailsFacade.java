package it.sella.sb.core.facade;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import it.sella.sb.anagrafe.IAnagrafeService;
import it.sella.sb.anagrafe.dto.MessageDetails;
import it.sella.sb.anagrafe.dto.PersonalDetails;
import it.sella.sb.common.exception.SBBaseThrowable;
import it.sella.sb.hb.dto.SbUserDetail;
import it.sella.sb.im.IMessageDAO;
import it.sella.sb.im.response.BaseResponse.BaseStatusEnum;

@Component
public class PersonalDetailsFacade {

	@Autowired
	private IAnagrafeService anagrafeService;
	
	@Autowired
	private IMessageDAO messageDAO;
	
	private static final Logger LOGGER = Logger.getLogger(PersonalDetailsFacade.class);

	public PersonalDetails getPersonalDetails(final SbUserDetail userDetail){
		LOGGER.debug("Start PersonalDetailsFacade getPersonalDetails user --> "+userDetail.getUserId());
		PersonalDetails response = new PersonalDetails();
		try {
			response = getAnagrafeService().getPersonalDetails(userDetail);
		} catch (SBBaseThrowable e) {
			LOGGER.error("PersonalDetailsFacade getPersonalDetails SBBaseThrowable error message : "+e.getMessage(),e);
			response.setStatus(BaseStatusEnum.EXCEPTION);
			response.setErrorMessageCode(e.getCode());
		} catch (Exception e) {
			LOGGER.error("PersonalDetailsFacade getPersonalDetails Exception error message : "+e.getMessage(),e);
			response.setStatus(BaseStatusEnum.EXCEPTION);
			response.setErrorMessageCode(SBBaseThrowable.SB_ERR_9999);
		}
		LOGGER.debug("End PersonalDetailsFacade getPersonalDetails user --> "+userDetail.getUserId());
		return response;
	}
	
	public void retrieveOnlineMessages(final SbUserDetail userDetail){
		if(userDetail!=null){
		LOGGER.debug("Start PersonalDetailsFacade retrieveOnlineMessages user --> "+userDetail.getUserId());
		PersonalDetails response = new PersonalDetails();
		try {
			if(userDetail.getPersonalDet()!=null){
				MessageDetails messageBO = messageDAO.retrieveOnlineMessages(userDetail);
				userDetail.getPersonalDet().setOnlineMessages(messageBO.getmMessage());
				//userDetail.getPersonalDet().setMessageDetails(messageDAO.retrieveOnlineMessages(userDetail));
			}
		} catch (SBBaseThrowable e) {
			LOGGER.error("PersonalDetailsFacade retrieveOnlineMessages SBBaseThrowable error message : "+e.getMessage(),e);
			response.setStatus(BaseStatusEnum.EXCEPTION);
			response.setErrorMessageCode(e.getCode());
		} catch (Exception e) {
			LOGGER.error("PersonalDetailsFacade retrieveOnlineMessages Exception error message : "+e.getMessage(),e);
			response.setStatus(BaseStatusEnum.EXCEPTION);
			response.setErrorMessageCode(SBBaseThrowable.SB_ERR_9999);
		}
		LOGGER.debug("End PersonalDetailsFacade getPersonalDetails user --> "+userDetail.getUserId());}
		
	}


	protected IAnagrafeService getAnagrafeService() {
		return anagrafeService;
	}

}
