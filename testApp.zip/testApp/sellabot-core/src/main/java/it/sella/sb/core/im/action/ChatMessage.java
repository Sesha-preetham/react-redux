package it.sella.sb.core.im.action;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import it.sella.sb.common.util.JsonUtil;
import it.sella.sb.hb.dto.SbUserDetail;
import it.sella.sb.im.IMessageDAO;
import it.sella.sb.im.dto.request.IMRequest;
import it.sella.sb.im.dto.response.IMResponse;
import it.sella.sb.util.SBCONSTANT;

@Component
public class ChatMessage extends IMAbstractAction {

	@Autowired
	private IMessageDAO messageDAO;
	
	@Override
	public void handleRequest(IMRequest imRequest) {
		final String request = JsonUtil.convertToString(imRequest);
		final SbUserDetail userDetail = (SbUserDetail)getSession().getAttribute(SBCONSTANT.USERDETAIL.VALUE);
		//imRequest.setSender(SBCONSTANT.CLIENT.VALUE);
		final String name = userDetail.getPersonalDet() != null ? userDetail.getPersonalDet().getNome()+" "+userDetail.getPersonalDet().getCognome() : "CLIENT" ;
		imRequest.setSender(name);
		this.messageDAO.preserveMessage(imRequest, request,null,userDetail);
		super.handleRequest(imRequest);
	}

	@Override
	public void handleResponse(IMRequest imRequest, IMResponse imResponse) {
		// TODO Auto-generated method stub
	}

}
