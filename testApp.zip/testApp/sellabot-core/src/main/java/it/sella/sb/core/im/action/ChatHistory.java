package it.sella.sb.core.im.action;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Component;

import it.sella.sb.im.dto.request.IMRequest;
import it.sella.sb.im.dto.response.IMResponse;

@Component
public class ChatHistory extends IMAbstractAction {
	
	private static final Logger LOGGER = Logger.getLogger(ChatHistory.class);

	@Override
	public void handleRequest(IMRequest imRequest) {
		LOGGER.debug("##ChatHistory #handleRequest "+imRequest.getChatid());
		super.handleRequest(imRequest);

	}

	@Override
	public void handleResponse(IMRequest imRequest, IMResponse imResponse) {
		// TODO Auto-generated method stub

	}

}
