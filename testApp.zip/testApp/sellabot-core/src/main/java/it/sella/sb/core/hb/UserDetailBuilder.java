package it.sella.sb.core.hb;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Component;

import com.google.gson.Gson;

import it.sella.sb.common.util.StringUtility;
import it.sella.sb.hb.dto.Carta;
import it.sella.sb.hb.dto.Conto;
import it.sella.sb.hb.dto.HBUserDetail;
import it.sella.sb.hb.dto.SbUserDetail;
import it.sella.sb.im.dto.request.Alias;
import it.sella.sb.im.dto.request.Interpretation;

@Component
public class UserDetailBuilder {

	private static final Logger LOGGER = Logger.getLogger(UserDetailBuilder.class);
	final static Gson gson = new Gson();
	
	public SbUserDetail parse(final HBUserDetail hbUserDetail,final SbUserDetail userDetail){

		LOGGER.debug("HB UserDetail -->"+gson.toJson(hbUserDetail));
		final List<Conto> conti = hbUserDetail.getConti();
		final List<Alias> alias = new ArrayList<Alias>();
		if(conti!=null){
			for (final Conto conto : conti) {
				if(conto.getIsProductAliasExist()) {
					alias.add(iterateConto(conto,"aliasconti"));
				}
			}
		}
		final List<Carta> carte = hbUserDetail.getCarte();
		if(carte!=null){
			for (final Carta carta : carte) {
				if(!StringUtility.isEmpty(carta.getProductAlias())) {
					alias.add(iterateCarta(carta,"aliascarte"));
				}
			}
		}
		userDetail.setAlias(alias);
		userDetail.setLang(hbUserDetail.getChoosedLocale());
		userDetail.setBank(hbUserDetail.getBank());
		LOGGER.debug("Sellabot UserDetail -->"+gson.toJson(userDetail));
		return userDetail;
	}

	public Alias iterateConto(Conto conto,String concept){
		final Alias alias = new Alias();
		alias.setConcept(concept);
		alias.setToken(conto.getProductAlias());

		final List<Interpretation> interpretations = new ArrayList<Interpretation>(1);
		final Interpretation interpretation = new Interpretation();
		interpretation.setName("numero");
		interpretation.setValue(conto.getId());
		interpretations.add(interpretation);
		//"aliasconti"
		alias.setInterpretations(interpretations);

		return alias;
	}

	public Alias iterateCarta(Carta carta,String concept){
		final Alias alias = new Alias();
		alias.setConcept(concept);
		alias.setToken(carta.getProductAlias());

		final List<Interpretation> interpretations = new ArrayList<Interpretation>(1);
		final Interpretation interpretation = new Interpretation();
		interpretation.setName("numero");
		interpretation.setValue(carta.getId());
		interpretations.add(interpretation);
		//"aliasconti"
		alias.setInterpretations(interpretations);

		return alias;
	}

}
