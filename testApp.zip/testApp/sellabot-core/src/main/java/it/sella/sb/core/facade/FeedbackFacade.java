package it.sella.sb.core.facade;

import it.sella.sb.common.exception.SBBaseThrowable;
import it.sella.sb.feedback.IFeedBackDao;
import it.sella.sb.feedback.dto.FeedBackQuestionResponse;
import it.sella.sb.feedback.dto.FeedBackRequest;
import it.sella.sb.feedback.dto.Question;
import it.sella.sb.hb.dto.SbUserDetail;
import it.sella.sb.im.response.BaseResponse;
import it.sella.sb.im.response.BaseResponse.BaseStatusEnum;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class FeedbackFacade 
{
	private static final Logger LOGGER = Logger.getLogger(FeedbackFacade.class);
	
	@Autowired
	private IFeedBackDao iFeedBackDao;
	
	public FeedBackQuestionResponse getQuestions(final SbUserDetail hbUser) {
		final FeedBackQuestionResponse response = new FeedBackQuestionResponse();
		try {	
			List<Question> questions = getiFeedBackDao().getQuestions(hbUser);
			response.setQuestions(questions);
		} catch (SBBaseThrowable e) {
			LOGGER.error("FeedbackFacade getQuestions SBBaseThrowable error message : "+e.getMessage(),e);
			response.setStatus(BaseStatusEnum.EXCEPTION);
			response.setErrorMessageCode(e.getCode());
		} catch (Exception e) {
			LOGGER.error("FeedbackFacade getQuestions Exception error message : "+e.getMessage(),e);
			response.setStatus(BaseStatusEnum.EXCEPTION);
			response.setErrorMessageCode(SBBaseThrowable.SB_ERR_9999);
		}
		return response;
	}
	
	public BaseResponse insertFeedback(final FeedBackRequest request,final SbUserDetail hbUser) {
		BaseResponse response = new BaseResponse();
		try {
			response = getiFeedBackDao().insertFeedback(request, hbUser);
			LOGGER.debug("FeedbackFacade insertFeedback response : "+response.getStatus());
		} catch (SBBaseThrowable e) {
			LOGGER.error("FeedbackFacade insertFeedback SBBaseThrowable error message : "+e.getMessage(),e);
			response.setStatus(BaseStatusEnum.EXCEPTION);
			response.setErrorMessageCode(e.getCode());
		} catch (Exception e) {
			LOGGER.error("FeedbackFacade insertFeedback Exception error message : "+e.getMessage(),e);
			response.setStatus(BaseStatusEnum.EXCEPTION);
			response.setErrorMessageCode(SBBaseThrowable.SB_ERR_9999);
		}
		return response;
	}
	

	protected IFeedBackDao getiFeedBackDao() {
		return iFeedBackDao;
	}

}
