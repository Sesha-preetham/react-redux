package it.sella.sb.core.im;

import it.sella.sb.common.exception.SBBaseThrowable;
import it.sella.sb.common.util.JsonUtil;
import it.sella.sb.common.util.StringUtility;
import it.sella.sb.core.hb.LinkBuilder;
import it.sella.sb.core.im.action.ChatMessage;
import it.sella.sb.core.im.action.ChatTyping;
import it.sella.sb.core.im.action.CheckLicense;
import it.sella.sb.core.im.action.EndChat;
import it.sella.sb.core.im.action.IMAction;
import it.sella.sb.core.im.action.NewChat;
import it.sella.sb.hb.dto.SbUserDetail;
import it.sella.sb.im.IMessageDAO;
import it.sella.sb.im.dto.request.IMRequest;
import it.sella.sb.im.dto.response.IMResponse;
import it.sella.sb.im.response.BaseResponse.BaseStatusEnum;
import it.sella.sb.poll.dto.PollMessage;
import it.sella.sb.poll.dto.PollResponse;
import it.sella.sb.util.SBCONSTANT;
import it.sella.sb.util.SBCONSTANT.EVENTDATA;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.google.gson.JsonObject;

@Component
public class MessageHandler {

	Map<String, IMAction> actions;

	@Autowired
	private CheckLicense checkLicense;
	@Autowired
	private NewChat newChat;
	@Autowired
	private ChatMessage chatMessage;
	@Autowired
	private ChatTyping chatTyping;
	@Autowired
	private EndChat endChat;
	@Autowired
	private IMessageDAO messageDAO;
	
	@Autowired
	private LinkBuilder linkBuilder;
	/*@Autowired
	private QueueSend queueSend;
	@Autowired
	private QueueRecieve queueRecieve;*/

	private final Logger log = Logger.getLogger(this.getClass());

	public void intialize(){
		this.actions = new HashMap<String, IMAction>();
		this.actions.put("checklicense", this.checkLicense);
		this.actions.put("newchat", this.newChat);
		this.actions.put("chatmessage", this.chatMessage);
		this.actions.put("chattyping", this.chatTyping);
		this.actions.put("endchat", this.endChat);
	}

	public IMResponse process(IMRequest imRequest){
		IMResponse response = new IMResponse();
		try {
			if(this.actions==null){
				intialize();
			}
			String key = imRequest.getAction();
			if(StringUtils.isNotEmpty(StringUtils.trim(imRequest.getIdevent()))){
				key = imRequest.getIdevent();
			}
			this.log.debug("key-->"+key);
			final IMAction action = this.actions.get(key);
			response = action.process(imRequest);
		} catch (SBBaseThrowable e) {
			log.error("MessageHandler process SBBaseThrowable error message : "+e.getMessage(),e);
			response.setStatus(BaseStatusEnum.EXCEPTION);
			response.setErrorMessageCode(e.getCode());
		} catch (Exception e) {
			log.error("MessageHandler process Exception error message : "+e.getMessage(),e);
			response.setStatus(BaseStatusEnum.EXCEPTION);
			response.setErrorMessageCode(SBBaseThrowable.SB_ERR_9999);
		}
		return response;
	}
	
	public void preserveMessage(final IMRequest imRequest,final String value,final SbUserDetail userDet){
		//final String request = JsonUtil.convertToString(imRequest);
		this.messageDAO.preserveMessage(imRequest,value,null,userDet);
		/*try {
			log.debug("Inserting message into JMS Queue  --> "+request);
			this.queueSend.send(request, imRequest.getChatid());
		}catch (Exception e) {
			log.error(e.getMessage(),e);
		}*/
	}



	public PollResponse readMessage(final String chatid,final HttpSession session){
		final PollResponse response = new PollResponse();
		final SbUserDetail sbUserDetail = (SbUserDetail)session.getAttribute(SBCONSTANT.USERDETAIL.VALUE);
		try {
			log.debug("MessageHandler readMessage for chatid : "+chatid);
			final List<String> messages = this.messageDAO.readMessage(chatid);
			log.debug("Messages from BOT messages size : "+messages.size());
			//processJmsMessage(chatid, sbUserDetail);
			final List<PollMessage> pollMessages = new ArrayList<>(messages.size());
			for (final String message : messages) {
				log.debug("Message from BOT for chatid : "+chatid+" message : "+message);
				final IMRequest imRequest = JsonUtil.convertToObject(message, IMRequest.class);
				final List<Map<String, String>> eventDatas = imRequest.getEventdata();
				if(SBCONSTANT.CHATMESSAGE.VALUE.equals(imRequest.getIdevent())){
					if(eventDatas!=null){
						for (final Map<String, String> eventData : eventDatas) {
							if(eventData.get(EVENTDATA.NAME.VALUE).equals(EVENTDATA.MESSAGE.VALUE)){
								final JsonObject jsonObj = new JsonObject();
								jsonObj.addProperty(EVENTDATA.MESSAGE.VALUE, (String)eventData.get(EVENTDATA.VAL.VALUE));
								final PollMessage pollMessage = JsonUtil.convertToObject(jsonObj.toString(), PollMessage.class);
								if(pollMessage != null) {
									pollMessage.setSender(SBCONSTANT.BOT.VALUE);
									if(!SBCONSTANT.BSE_SKIP_MSG.VALUE.equalsIgnoreCase(pollMessage.getMessage())){
										pollMessages.add(pollMessage);
									}
								}
							}
						}
					}
				}else if(SBCONSTANT.CHATRESULT.VALUE.equals(imRequest.getIdevent())){
					if(eventDatas!=null){
						final JsonObject jsonObj = new JsonObject();
						for (final Map<String, String> eventData : eventDatas) {
							jsonObj.addProperty(eventData.get(EVENTDATA.NAME.VALUE), (String)eventData.get(EVENTDATA.VAL.VALUE));
						}
						final PollMessage pollMessage = JsonUtil.convertToObject(jsonObj.toString(), PollMessage.class);
						if(pollMessage != null) {
							pollMessage.setSender(SBCONSTANT.BOT.VALUE);
							if( !StringUtility.isEmpty(pollMessage.getIntentCode()) && !"OPERATOR".equalsIgnoreCase(pollMessage.getAction()) && !"CLOSE".equalsIgnoreCase(pollMessage.getAction()) ){
								pollMessage.setUrl(!"BS.AreaInformativa".equalsIgnoreCase(pollMessage.getIntentArea()) ? linkBuilder.getUrlForAction(pollMessage.getIntentCode(),sbUserDetail) : "" );
							}
							
							log.info("MessageHandler readMessage()  [ AppName -- "+sbUserDetail.getAppName()+" ] , [ IntentCode -- "+ pollMessage.getIntentCode());
							
							if(sbUserDetail.getAppName().contains("SME")){//this will work for SME
								if(!sbUserDetail.getBlockAllIntents()){//this is to check for to block all the intends
									if(!sbUserDetail.getBlockParticularIntent().contains(pollMessage.getIntentCode())){//block particular intents
										
										if(!StringUtility.isEmpty(pollMessage.getLink()) && pollMessage.getLink().contains("SMEBANKING")){
											String url = "/SMEroute"+pollMessage.getLink().substring(pollMessage.getLink().indexOf("SMEBANKING")+10);
											pollMessage.setUrl(url);
											pollMessage.setLink("");
										}else{
											pollMessage.setUrl("");
										}
										
										pollMessages.add(pollMessage);
									}
								}else/* if(StringUtility.isEmpty(pollMessage.getLink()))*/{
									pollMessage.setLink("");
									pollMessage.setUrl("");	
									pollMessages.add(pollMessage);
								}
							}else{
								pollMessages.add(pollMessage);//if not SME go as usual
							}
						}
					}
				}
	
			}
			response.setResults(pollMessages);
		} catch (SBBaseThrowable e) {
			log.error("MessageHandler readMessage SBBaseThrowable error message : "+e.getMessage(),e);
			response.setStatus(BaseStatusEnum.EXCEPTION);
			response.setErrorMessageCode(e.getCode());
		} catch (Exception e) {
			log.error("MessageHandler readMessage Exception error message : "+e.getMessage(),e);
			response.setStatus(BaseStatusEnum.EXCEPTION);
			response.setErrorMessageCode(SBBaseThrowable.SB_ERR_9999);
		}
		return response;
	}

	/*private void processJmsMessage(final String chatid,
			final UserDetail sbUserDetail) {
		try {
			final List<String> messagesInJms = queueRecieve.recieve(chatid);
			log.debug("messagesInJms --> "+messagesInJms);
			for (final String message : messagesInJms) {
				final IMRequest imRequest = JsonUtil.convertToObject(message, IMRequest.class);
				final List<Map<String, String>> eventDatas = imRequest.getEventdata();
				if(SBCONSTANT.CHATMESSAGE.VALUE.equals(imRequest.getIdevent())){
					if(eventDatas!=null){
						for (final Map<String, String> eventData : eventDatas) {
							if(eventData.get(EVENTDATA.NAME.VALUE).equals(EVENTDATA.MESSAGE.VALUE)){
								final JsonObject jsonObj = new JsonObject();
								jsonObj.addProperty(EVENTDATA.MESSAGE.VALUE, (String)eventData.get(EVENTDATA.VAL.VALUE));
								final PollMessage pollMessage = JsonUtil.convertToObject(jsonObj.toString(), PollMessage.class);
								if(pollMessage != null) {
									pollMessage.setSender(SBCONSTANT.BOT.VALUE);
									log.debug("PollMessage --> "+pollMessage.toString());
								}
							}
						}
					}
				}else if(SBCONSTANT.CHATRESULT.VALUE.equals(imRequest.getIdevent())){
					if(eventDatas!=null){
						final JsonObject jsonObj = new JsonObject();
						for (final Map<String, String> eventData : eventDatas) {
							jsonObj.addProperty(eventData.get(EVENTDATA.NAME.VALUE), (String)eventData.get(EVENTDATA.VAL.VALUE));
						}
						final PollMessage pollMessage = JsonUtil.convertToObject(jsonObj.toString(), PollMessage.class);
						if(pollMessage != null) {
							pollMessage.setSender(SBCONSTANT.BOT.VALUE);
							if( !StringUtility.isEmpty(pollMessage.getIntentCode()) && !"OPERATOR".equalsIgnoreCase(pollMessage.getAction()) && !"CLOSE".equalsIgnoreCase(pollMessage.getAction()) ){
								pollMessage.setUrl(getUrlForAction(pollMessage.getIntentCode(),sbUserDetail));
							}
							log.debug("PollMessage --> "+pollMessage.toString());
						}
					}
				}
			}
		} catch (Exception e) {
			log.error("MessageHandler processJmsMessage Exception message : "+e.getMessage(),e);
		}
	}*/

	


}
