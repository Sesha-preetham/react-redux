package it.sella.sb.core.im.action;

import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import it.sella.sb.external.im.IMservice;
import it.sella.sb.hb.dto.SbUserDetail;
import it.sella.sb.im.dto.request.IMRequest;
import it.sella.sb.im.dto.response.IMResponse;
import it.sella.sb.util.SBCONSTANT;


public abstract class IMAbstractAction implements IMAction{

	private static final Logger LOGGER = Logger.getLogger(IMAbstractAction.class);

	@Autowired
	private IMservice imService;
	
	@Override
	public void handleRequest(IMRequest imRequest) {
		final HttpSession session = getSession();
		LOGGER.debug("Session Set -->"+session.getId()+" -- "+session.getAttribute(SBCONSTANT.CHATID.VALUE)+" -- "+session.getAttribute(SBCONSTANT.CHATURL.VALUE));
		if(StringUtils.isNotEmpty((String)session.getAttribute(SBCONSTANT.CHATURL.VALUE))){
			imRequest.setChaturl((String)session.getAttribute(SBCONSTANT.CHATURL.VALUE));
		}
	}

	public static HttpSession getSession() {
		final ServletRequestAttributes attr = (ServletRequestAttributes) RequestContextHolder.currentRequestAttributes();
		return attr.getRequest().getSession(true); 
	}

	@Override
	public IMResponse process(IMRequest imRequest) {
		handleRequest(imRequest);
		final IMResponse imResponse = getImService().message(imRequest);
		final SbUserDetail userDetail = (SbUserDetail)getSession().getAttribute(SBCONSTANT.USERDETAIL.VALUE);
		imResponse.setOverTime(userDetail.getOverTime());
		handleResponse(imRequest, imResponse);
		return imResponse;
	}

	protected IMservice getImService() {
		return imService;
	}

}
