package it.sella.sb.core.factory;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import it.sella.crossauthentication.identity_federation.FederationManager;
import it.sella.crossauthentication.identity_federation.FederationManagerFactory;
import it.sella.crossauthentication.identity_federation.IdentityFederationException;
import it.sella.crossauthentication.identity_federation.UserExecutionContext;
import it.sella.sb.anagrafe.IAnagrafeDAO;
import it.sella.sb.core.exception.SBCoreException;
import it.sella.sb.hb.dto.FederationInformation;

@Component
public class CrossAuthFactory 
{
	private static final Logger LOGGER = Logger.getLogger(CrossAuthFactory.class);
	
	@Value("${ENV:PRO}")
	private String env;

	@Value("${mock.userCode:}")
	private String mockUserCode;
	@Value("${mock.userToken:}")
	private String mockUserToken;
	@Value("${mock.abiCode:}")
	private String mockAbiCode;
	
	@Autowired
	private IAnagrafeDAO iAnagrafeDAO;
	
	public FederationInformation getFederationInformation() 
	{
		final FederationInformation fi = new FederationInformation();
		try {
			if ("DEV".equalsIgnoreCase(env))
			{
				fi.setUserCode(mockUserCode);
				fi.setUserToken(mockUserToken);
				fi.setAbi(mockAbiCode);
				fi.setIdSoggetto(getiAnagrafeDAO().getSubjectIdByIbcode(mockUserCode));
			}
			else
			{
				FederationManager fedarationManager = getFedarationManager();
				UserExecutionContext userExcecutionContext = getUserExcecutionContext(fedarationManager);
				fi.setUserCode(userExcecutionContext.getUserCode());
				fi.setUserToken(fedarationManager.getUserToken());
				fi.setAbi(userExcecutionContext.getUserIdentity().getAbiCode());
				LOGGER.debug("###subject### is " + fi.getUserCode() + ":This from federation user information");
				//Commented because IdSoggetto getting null from cross
				try
				{
					fi.setIdSoggetto(Long.parseLong(userExcecutionContext.getUserIdentity().getSoggettoId()));
					LOGGER.info("###subject### is " + fi.getIdSoggetto() + ":This from federation");
				}
				catch (Exception ex)
				{
					fi.setIdSoggetto(getiAnagrafeDAO().getSubjectIdByIbcode(fi.getUserCode()));
					LOGGER.info("###subject### is " + fi.getIdSoggetto() + ":This from db",ex);
				}
			}
		} 
		catch (Exception e) 
		{
			LOGGER.error("Cross Auth in error : "+e.getMessage() , e);
			throw new SBCoreException("Cross Auth in error : "+e.getMessage(),SBCoreException.SB_AUTH_ERROR, e);
		}
		return fi;
	}

	/**
	 * @return
	 * @throws IdentityFederationException
	 */
	protected FederationManager getFedarationManager() throws IdentityFederationException {
		return FederationManagerFactory.getInstance().getFederationManager();
	}

	protected UserExecutionContext getUserExcecutionContext(FederationManager federationManager) throws IdentityFederationException {
		return federationManager.getUserExecutionContext();
	}

	protected IAnagrafeDAO getiAnagrafeDAO() {
		return iAnagrafeDAO;
	}

}
