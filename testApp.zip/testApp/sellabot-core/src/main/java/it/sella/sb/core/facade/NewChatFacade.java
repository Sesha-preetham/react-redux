package it.sella.sb.core.facade;

import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import it.sella.sb.common.IIsFestivoDAO;
import it.sella.sb.common.IPropertyDao;
import it.sella.sb.common.IServiceStatusCheckDAO;
import it.sella.sb.common.exception.SBBaseThrowable;
import it.sella.sb.common.util.DateUtility;
import it.sella.sb.common.util.JsonUtil;
import it.sella.sb.common.util.StringUtility;
import it.sella.sb.external.im.IMservice;
import it.sella.sb.hb.dto.SbUserDetail;
import it.sella.sb.im.IMessageDAO;
import it.sella.sb.im.dto.request.IMRequest;
import it.sella.sb.im.dto.request.Parameter;
import it.sella.sb.im.dto.response.IMResponse;
import it.sella.sb.im.response.BaseResponse.BaseStatusEnum;
import it.sella.sb.util.SBCONSTANT;
import it.sella.sb.util.SBCONSTANT.PARAMETER;

@Component
public class NewChatFacade extends BaseChatValidationFacade {

	/*@Value("${AppName}")
	private String appname;
	@Value("${AppName_Mobile}")
	private String appname_Mobile;
	@Value("${AppName_SME}")
	private String appname_SME;
	@Value("${AppVersion}")
	private String appVersion;*/
	@Value("${CustomerID}")
	private String customerID;
	@Value("${SB_Lang}")
	private String lang;
	@Value("${MMChannels_Chat_client_name}")
	private String mmchannels_Chat_client_name;
	@Value("${MMChannels_Chat_client_made}")
	private String mmchannels_Chat_client_made;
	@Value("${MMChannels_Chat_client_version}")
	private String mmchannels_Chat_client_version;
	@Value("${InteractionTimeout}")
	private String interactionTimeout;
	@Value("${DevelopmentStatus}")
	private String developmentStatus;
	@Value("${MMChannels_Chat_client_backend}")
	private String mmchannels_Chat_client_backend;
	@Value("${ENV:PRO}")
	private String env;

	private final static String ENCRYPT_KEY = "D22A3F6BDFB3C6F4";

	@Autowired
	private IMservice imService;

	@Autowired
	private IIsFestivoDAO isFestivoDAO;

	@Autowired
	private IPropertyDao iPropertyDao;

	@Autowired
	private IMessageDAO messageDAO;

	@Autowired
	private IServiceStatusCheckDAO serviceStatusCheckDAO;

	private final Logger log = Logger.getLogger(this.getClass());

	public IMResponse newChat(final IMRequest imRequest,final SbUserDetail userDetail){
		IMResponse response = new IMResponse();
		try {
			validateNewRequestObj(imRequest,userDetail);
			imRequest.setAction(SBCONSTANT.ACTION.NEWCHAT.VALUE);
			imRequest.getParameters().addAll(getInitialParameters(userDetail));
			if(userDetail!=null){
				final Parameter alias = new Parameter();
				alias.setName(PARAMETER.ALIAS.VALUE);
				alias.setValue(userDetail.getAlias());
				imRequest.getParameters().add(alias);
				final String overTime = getOvertime(userDetail);
				//Removed below line as requested by Vasta Fabio in mail on 12-08-2019
				//				imRequest.getParameters().add(getParameter(PARAMETER.OVERTIME.VALUE, "DEV".equalsIgnoreCase(env) || "TEST".equalsIgnoreCase(env) ? "FALSE" : overTime));
				imRequest.getParameters().add(getParameter(PARAMETER.OVERTIME.VALUE, overTime));
				userDetail.setOverTime(overTime);
				response.setOverTime(overTime);
				/*try {
					log.debug("newChat Date Time : "+DateUtility.getStringFromDate(new Date(), DateUtility.DATE_TIME_FORMAT_3)+" over time : "+getOvertime());
				} catch (Exception e) {
					log.error("Exception in calculate getOvertime error message : "+e.getMessage(),e);
				}
				imRequest.getParameters().add(getParameter(PARAMETER.OVERTIME.VALUE, "FALSE"));*/
				imRequest.getParameters().add(getParameter(PARAMETER.SESSIONID.VALUE,userDetail.getUuId()));
				//if(userDetail.getFederationInformation()!=null){
				imRequest.getParameters().add(getParameter(PARAMETER.USERID.VALUE, userDetail.getUserId()));//getEncodedString(userDetail.getFederationInformation().getUserCode())
				//}
				imRequest.setSender(userDetail.getPersonalDet() != null ? userDetail.getPersonalDet().getNome()+" "+userDetail.getPersonalDet().getCognome() : "CLIENT");
			}
			response = getImService().message(imRequest);
			if(SBCONSTANT.OK.VALUE.equalsIgnoreCase(response.getResult())){
				imRequest.setChatid(response.getChatid());
				imRequest.setChaturl(response.getChaturl());
				getMessageDAO().preserveMessage(imRequest, JsonUtil.convertToString(imRequest),null,userDetail);
			}
		} catch (final SBBaseThrowable e) {
			log.error("NewChatFacade newChat SBBaseThrowable error message : "+e.getMessage(),e);
			response.setStatus(BaseStatusEnum.EXCEPTION);
			response.setErrorMessageCode(e.getCode());
		} catch (final Exception e) {
			log.error("NewChatFacade newChat Exception error message : "+e.getMessage(),e);
			response.setStatus(BaseStatusEnum.EXCEPTION);
			response.setErrorMessageCode(SBBaseThrowable.SB_ERR_9999);
		}
		log.debug("newChat response  --> "+response.getStatus());
		return response;
	}

	private String getOvertime(final SbUserDetail userDetail){
		String overTime = "TRUE";
		try {
			final boolean isFestival = getIsFestivoDAO().isFestivo(new Date());
			this.log.debug("getOvertime  isFestival-->"+isFestival);
			if(!isFestival){
				//				final Calendar cal = Calendar.getInstance();
				//				final int hour = cal.get(Calendar.HOUR_OF_DAY);
				//				final int minute = cal.get(Calendar.MINUTE);
				//				this.log.debug("getOvertime  hour --> "+hour+" minute --> "+minute);
				//				int startHour = 9;
				//				int startMinute = 00;
				//				int endHour = 17;
				//				int endMinute = 30;
				//				try {
				//					Map<String, String> propsNewChat = iPropertyDao.getPropertiesByCodice("NEWCHAT", userDetail != null && userDetail.getBank() != null ? userDetail.getBank().getBankCode() : "");
				//					if(propsNewChat != null) {
				//						final String fromTime = propsNewChat.get("OP_FROM_TIME");
				//						final String toTime = propsNewChat.get("OP_TO_TIME");
				//						this.log.debug("getOvertime from DB  fromTime --> "+fromTime+" toTime --> "+toTime);
				//						if(!StringUtility.isEmpty(fromTime) && !StringUtility.isEmpty(toTime)) {
				//							startHour = Integer.parseInt(fromTime.split(":")[0]);
				//							startMinute = Integer.parseInt(fromTime.split(":")[1]);
				//							endHour = Integer.parseInt(toTime.split(":")[0]);
				//							endMinute = Integer.parseInt(toTime.split(":")[1]);
				//						}
				//					}
				//				} catch (Exception e) {
				//					log.error("Get Overtime from DB Exception "+e.getMessage(),e);
				//					startHour = 9;
				//					startMinute = 00;
				//					endHour = 17;
				//					endMinute = 30;
				//				}
				//				if( hour > startHour && hour < endHour ) {
				//					overTime = "FALSE";
				//				} else if ( hour == startHour && minute >= startMinute) {
				//					overTime = "FALSE";
				//				} else if ( hour == endHour && minute <= endMinute ) {
				//					overTime = "FALSE";
				//				}
				final String statusF = serviceStatusCheckDAO.getServiceStatusOnDate("SELLA_BOT", UtilityBank.getBankCode(userDetail.getBancaId()));
				if (log.isDebugEnabled()) {
					log.debug("serviceStatusCheckDAO.getServiceStatusOnDate for service SELLA_BOT = '"+statusF+"'");
				}
				final boolean isOpenedHour = ( IServiceStatusCheckDAO.SERVICE_STATUS_OPENED.equals(statusF) || IServiceStatusCheckDAO.SERVICE_STATUS_OPEN.equals(statusF) ) ;
				if (log.isDebugEnabled()) {
					log.debug("isOpenedHour "+isOpenedHour);
				}
				if (isOpenedHour){
					overTime = "FALSE";
				}else{
					overTime = "TRUE";
				}
			}
			log.debug("newChat Date Time : "+DateUtility.getStringFromDate(new Date(), DateUtility.DATE_TIME_FORMAT_4)+" over time : "+overTime);
		} catch (final Exception e) {
			overTime = "FALSE";
			log.error("Exception in calculate getOvertime error message : "+e.getMessage(),e);
		}
		return overTime;
	}

	private String getEncodedString(final String value) {
		String result ="";
		if(!StringUtility.isEmpty(value)) {
			try {
				final MessageDigest sha256MsgDig = MessageDigest.getInstance("SHA-256");
				final byte[] keyBytes = ENCRYPT_KEY.getBytes();
				sha256MsgDig.update(keyBytes);
				final byte[] keyBytesWithSha256 = sha256MsgDig.digest();
				final byte[] keyBytesWithSha64 = new byte[16];
				System.arraycopy(keyBytesWithSha256, 0, keyBytesWithSha64, 0, keyBytesWithSha64.length);
				final SecretKeySpec key = new SecretKeySpec(keyBytesWithSha64, "AES");
				final Cipher c = Cipher.getInstance("AES");
				c.init(Cipher.ENCRYPT_MODE, key);

				final byte[] encValue = c.doFinal(value.getBytes("UTF-8"));
				result = it.sella.util.Base64.encode(encValue,false);
				log.debug(" getEncodedString ::  result --> "+result);
			} catch (final Exception e) {
				log.error("getEncodedString Exception message"+e.getMessage(), e);
			}
		}
		return result;
	}

	private List<Parameter> getInitialParameters(final SbUserDetail userDetail){
		final List<Parameter> parameters = new ArrayList<Parameter>();
		if(userDetail!=null){
		final String chatArea = userDetail.getIsAnonymous()? PARAMETER.PUBBLICA.VALUE : PARAMETER.PRIVATA.VALUE;
		/*String tempAppName = this.appname;

		if(StringUtility.isMobileChannel(userDetail.getChannelId())) {
			tempAppName = this.appname_Mobile;
		}else if(StringUtility.isSME(userDetail.getChannelId())) {
			tempAppName = this.appname_SME;
		}*/
		
		Map<String, String> appVersionMap = iPropertyDao.getPropertiesByCodice(SBCONSTANT.APPNAME.VALUE, userDetail.getBank() != null ? userDetail.getBank().getBankCode() : "");
		log.info(" NewChat initApplicationDetail() appVersionMap >>> "+appVersionMap); 
		String appVersion = "";
		if(appVersionMap.containsKey(userDetail.getAppName())){
			appVersion = appVersionMap.get(userDetail.getAppName());
		}else{
			appVersion = appVersionMap.get(SBCONSTANT.DEFAULT_VERSION.VALUE);
		}
		
		log.info(" NewChat initApplicationDetail() appVersion >>> "+userDetail.getAppName()+" - "+appVersion);

		parameters.add(getParameter(PARAMETER.APPNAME.VALUE, userDetail.getAppName()));
		parameters.add(getParameter(PARAMETER.APPVERSION.VALUE, appVersion));
		parameters.add(getParameter(PARAMETER.CUSTOMERID.VALUE, this.customerID));
		parameters.add(getParameter(PARAMETER.LANG.VALUE, this.lang));
		parameters.add(getParameter(PARAMETER.MMCHANNELS_CHAT_CLIENT_NAME.VALUE, this.mmchannels_Chat_client_name));
		parameters.add(getParameter(PARAMETER.MMCHANNELS_CHAT_CLIENT_MADE.VALUE, this.mmchannels_Chat_client_made));
		parameters.add(getParameter(PARAMETER.MMCHANNELS_CHAT_CLIENT_VERSION.VALUE, this.mmchannels_Chat_client_version));
		parameters.add(getParameter(PARAMETER.DEVELOPMENTSTATUS.VALUE, this.developmentStatus));
		parameters.add(getParameter(PARAMETER.MMCHANNELS_CHAT_CLIENT_BACKEND.VALUE, this.mmchannels_Chat_client_backend));
		parameters.add(getParameter(PARAMETER.CHATAREA.VALUE, chatArea));

		parameters.add(getParameter(PARAMETER.BANCAID.VALUE, userDetail.getBancaId()));
		parameters.add(getParameter(PARAMETER.LOGTIME.VALUE, userDetail.getLogTime()));
		parameters.add(getParameter(PARAMETER.CHANNELID.VALUE, userDetail.getChannelId()));
		parameters.add(getParameter(PARAMETER.USERAGENT.VALUE, userDetail.getUserAgent()));
		parameters.add(getParameter(PARAMETER.USERIPADDRESS.VALUE, userDetail.getIpAddress()));
		parameters.add(getParameter(PARAMETER.USERIPADDRESS.VALUE, userDetail.getIpAddress()));
		parameters.add(getParameter(PARAMETER.CATEGORIA.VALUE, userDetail.getCategoria()));
		log.debug("New parameter details NewChatFacade -->"+PARAMETER.BANCAID.VALUE+" -- "+userDetail.getBancaId()+" ## "+PARAMETER.LOGTIME.VALUE+" -- "+userDetail.getLogTime()+
				" ## "+PARAMETER.CHANNELID.VALUE+" -- "+userDetail.getChannelId()+" ## "+PARAMETER.USERAGENT.VALUE+" -- "+userDetail.getUserAgent()+
				" ## "+PARAMETER.USERIPADDRESS.VALUE+" -- "+userDetail.getIpAddress()+ "##" +PARAMETER.CHATAREA.VALUE+" -- "+chatArea+ " ## " +PARAMETER.CATEGORIA.VALUE+" -- "+userDetail.getCategoria()
				+" ## "+PARAMETER.APPNAME.VALUE+" -- "+userDetail.getAppName());


		String timeOut = "";
		try {
			timeOut = iPropertyDao.getPropertyValue("NEWCHAT", (userDetail.getBank() != null) ? userDetail.getBank().getBankCode() : "", "TIMEOUT");
		} catch (final Exception e) {
			log.error("Get time out from DB Exception "+e.getMessage(),e);
		}
		if(!StringUtility.isEmpty(timeOut)) {
			log.debug("Get time out from DB for user : "+userDetail.getUserId()+" time out : "+timeOut);
			parameters.add(getParameter(PARAMETER.INTERACTIONTIMEOUT.VALUE, timeOut));
		} else {
			log.debug("Get time out from Hard code for user : "+userDetail.getUserId()+" time out : "+this.interactionTimeout);
			parameters.add(getParameter(PARAMETER.INTERACTIONTIMEOUT.VALUE, this.interactionTimeout));
		}
		}
		return parameters;
	}

	private Parameter getParameter(final String name, final String value){
		final Parameter parameter = new Parameter() ;
		parameter.setName(name);
		parameter.setValue(value);
		return parameter;
	}

	protected IMservice getImService() {
		return imService;
	}

	protected IIsFestivoDAO getIsFestivoDAO() {
		return isFestivoDAO;
	}

	protected IMessageDAO getMessageDAO() {
		return messageDAO;
	}

}
