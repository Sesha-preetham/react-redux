package it.sella.sb.core.hb;


import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import it.sella.sb.common.util.StringUtility;
import it.sella.sb.core.facade.AlghoFacade;
import it.sella.sb.hb.dto.SbUserDetail;
import it.sella.sb.poll.IIntendDetailDao;
import it.sella.sb.poll.dto.IntendDetail;
import it.sella.sb.util.SBCONSTANT;

@Component
public class LinkBuilder {
	
	private static final Logger LOGGER = Logger.getLogger(AlghoFacade.class);
	
	@Value("${ENV}")
	private String env;
	
	@Autowired
	private IIntendDetailDao intendDetailDAO;

	public IIntendDetailDao getIntendDetailDAO() {
		return intendDetailDAO;
	}
	
	public String getCompleteUrlForAction(final String intentCode, final SbUserDetail sbUserDetail) {
		final String endOfUrl = getUrlForAction(intentCode, sbUserDetail);
		String openerHref = "DEV".equals(env)?"https://www.sella.tst/hbfe/index.html#":sbUserDetail.getOpenerHref();
		String openerOrigin = "DEV".equals(env)?"https://www.sella.tst":sbUserDetail.getOpenerOrigin();
		String completeUrl = openerHref; // at least we show something if no mapping found...
		if(!StringUtility.isEmpty(endOfUrl)) {
			if(endOfUrl.startsWith(SBCONSTANT.HBURL.VALUE) && !StringUtility.isEmpty(openerHref)) {
				if(openerHref.contains("#")) {
					openerHref = openerHref.split("#")[0]+"#";
				}
				completeUrl = openerHref.concat(endOfUrl);
			}else if(!StringUtility.isEmpty(openerOrigin)){
				completeUrl = openerOrigin.concat(endOfUrl);
			}
		}
		return completeUrl;
	}
	
	public String getUrlForAction(final String intentCode, final SbUserDetail sbUserDetail) {
		LOGGER.info("getUrlForAction  intentCode --> "+intentCode);
		final IntendDetail detail = getIntendDetailDAO().getIntendDetail(intentCode, sbUserDetail);
		String url = "";
		if(!StringUtility.isEmpty(detail.getMenu()) || !StringUtility.isEmpty(detail.getTab()) || 
				!StringUtility.isEmpty(detail.getSubTab()) ||  !StringUtility.isEmpty(detail.getLink()) ) {
			String menu = "";
			if(!StringUtility.isEmpty(detail.getMenu())) {
				menu = detail.getMenu();
			}
			if(!StringUtility.isEmpty(detail.getTab())) {
				menu = StringUtility.isEmpty(menu) ? detail.getTab() : menu.concat(";").concat(detail.getTab());
			}
			if(!StringUtility.isEmpty(detail.getSubTab())) {
				menu = StringUtility.isEmpty(menu) ? detail.getSubTab() : menu.concat(";").concat(detail.getSubTab());
			}
			LOGGER.info("getUrlForAction  menu --> "+menu);
			final String link = !StringUtility.isEmpty(detail.getLink()) ? detail.getLink() : "";
			url = SBCONSTANT.HBURL.VALUE.concat(!StringUtility.isEmpty(menu) ? "@".concat(menu) : "" ).concat(
					!StringUtility.isEmpty(link) ? "@".concat(link) : "");
			LOGGER.info("getUrlForAction  url --> "+url);
		} else if (!StringUtility.isEmpty(detail.getUrl())) {
			url =  detail.getUrl();
			LOGGER.info("getUrlForAction external url --> "+url);
		} else {
			LOGGER.info("getUrlForAction  url not found for intentCode --> "+intentCode);
			/*final int lastIndex = intentCode.lastIndexOf(".");
			if( lastIndex > 0) {
				url = getUrlForAction(intentCode.substring(0, lastIndex), sbUserDetail);
			} else {
				url =  "";
			}*/
		}
		LOGGER.info("getUrlForAction last url --> "+url);
		return url;
	}

}
