package it.sella.sb.core.facade;

import org.apache.log4j.Logger;

import it.sella.sb.common.exception.SBCommonException;
import it.sella.sb.common.util.StringUtility;
import it.sella.sb.hb.dto.SbUserDetail;
import it.sella.sb.im.dto.request.IMRequest;

public class BaseChatValidationFacade {

	
	private static final Logger LOGGER = Logger.getLogger(BaseChatValidationFacade.class);
	
	public void validateRequestObj(final IMRequest request) {
		if(StringUtility.isEmpty(request.getChatid())) {
			LOGGER.debug("BaseFacade validateRequestObj chat id not found for action : "+request.getAction());
			throw new SBCommonException("BaseFacade validateRequestObj chat id not found for action : "+request.getAction(), SBCommonException.SB_CHAT_ID_NOT_FOUND);
		}
		if(StringUtility.isEmpty(request.getChaturl())) {
			LOGGER.debug("BaseFacade validateRequestObj chat url not found for action : "+request.getAction());
			throw new SBCommonException("BaseFacade validateRequestObj chat url not found for action : "+request.getAction(), SBCommonException.SB_CHAT_URL_NOT_FOUND);
		}
	}
	
	public void validateNewRequestObj(final IMRequest request,final SbUserDetail userDetail) {
		/*if(!StringUtility.isEmpty(request.getChatid())) {
			log.debug("BaseFacade validateNewRequestObj chat id already present for action : "+request.getAction());
			throw new SBCommonException("BaseFacade validateNewRequestObj chat id already present for action : "+request.getAction(), SBCommonException.SB_CHAT_ID_ALREADY_PRESENT);
		}*/
		if(userDetail == null) {
			LOGGER.debug("BaseFacade validateNewRequestObj sella bot not initialized for action : "+request.getAction());
			throw new SBCommonException("BaseFacade validateNewRequestObj chat url not found for action : "+request.getAction(), SBCommonException.SB_NOT_INITIALIZED);
		}
	}

}
