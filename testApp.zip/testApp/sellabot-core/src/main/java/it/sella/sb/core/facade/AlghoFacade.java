package it.sella.sb.core.facade;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.time.DayOfWeek;
import java.time.LocalDateTime;
import java.time.MonthDay;
import java.time.format.DateTimeFormatter;
import java.util.Map;
import java.util.UUID;

import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.google.gson.Gson;

import it.sella.sb.algho.IConversationDAO;
import it.sella.sb.algho.dto.BotConfigResponse;
import it.sella.sb.algho.dto.BotLinkRequest;
import it.sella.sb.algho.dto.BotMessageRequest;
import it.sella.sb.algho.dto.BotStartRequest;
import it.sella.sb.algho.dto.ConversationDTO;
import it.sella.sb.common.IPropertyDao;
import it.sella.sb.common.IServiceStatusCheckDAO;
import it.sella.sb.common.exception.SBBaseThrowable;
import it.sella.sb.common.exception.SBCommonException;
import it.sella.sb.common.util.StringUtility;
import it.sella.sb.core.hb.LinkBuilder;
import it.sella.sb.hb.dto.SbUserDetail;
import it.sella.sb.im.IMessageDAO;
import it.sella.sb.im.response.BaseResponse;
import it.sella.sb.im.response.BaseResponse.BaseStatusEnum;
import it.sella.sb.util.SBCONSTANT;

@Component
public class AlghoFacade {
	
	private static final Logger LOGGER = Logger.getLogger(AlghoFacade.class);
	
	
	@Autowired
	private IPropertyDao propertyDao;
	
	@Autowired
	private IServiceStatusCheckDAO serviceStatusCheckDAO;
	
	@Autowired
	private IConversationDAO conversationDAO;
	
	@Autowired
	private LinkBuilder linkBuilder;
	
	@Autowired
	private IMessageDAO iMessageDAO;
	
	
	public String getContext(final SbUserDetail userDetail) {
		StringBuilder sb = new StringBuilder();
		String bank = (userDetail.getBank() != null) ? userDetail.getBank().getBankCode() : "";
		String alghoChannel = propertyDao.getPropertyValue(SBCONSTANT.ALGHO_CHANNEL.VALUE, bank, userDetail.getChannelId());
		if(StringUtility.isEmpty(alghoChannel)) {
			throw new SBCommonException("Algho channel not available", SBCommonException.SB_NOT_INITIALIZED);
		}
		sb.append(alghoChannel).append(SBCONSTANT.UNDERSCORE.VALUE);
		
		if(!userDetail.getIsAnonymous()) {
			sb.append(SBCONSTANT.AUTENTICATO.VALUE);
		}else {
			sb.append(SBCONSTANT.NONAUTENTICATO.VALUE);
		}
		sb.append(SBCONSTANT.UNDERSCORE.VALUE);
		boolean isOverTime = serviceStatusCheckDAO.isOverTime(UtilityBank.getBankCode(userDetail.getBancaId()));
		if(isOverTime) {
			sb.append(SBCONSTANT.FUORIORARIO.VALUE);
		}else {
			sb.append(SBCONSTANT.INORARIO.VALUE);
		}
		Map<String,String> weekendSpecialDays = propertyDao.getPropertiesByCodice("WEEKEND_SPECIALDAYS", bank);
		boolean isWeekendOrSpecialDay = isWeekendOrSpecialDay(weekendSpecialDays);
		if (isWeekendOrSpecialDay) {
			sb.append(SBCONSTANT.UNDERSCORE.VALUE);
			sb.append(SBCONSTANT.WEEKENDORSPECIAL.VALUE);
		}
		final String context= sb.toString();
		LOGGER.info("Algho Context --> " + context);
		return context;
	}

	private boolean isWeekendOrSpecialDay(final Map<String, String> weekendSpecialDays) {
		boolean isWeekendOrSpecialDay = false;
		String weekendDays = weekendSpecialDays.get("DAY_OF_WEEK");
		if(!StringUtility.isEmpty(weekendDays)) {
			final DayOfWeek dow = LocalDateTime.now().getDayOfWeek();
			for(String dayOfWeek : weekendDays.split(";")) {
				if(dow.compareTo(DayOfWeek.valueOf(dayOfWeek)) == 0) {
					isWeekendOrSpecialDay=true;
					break;
				}
			}
		}
		String specialDayMonthList = weekendSpecialDays.get("SPECIAL_DAY_MONTH");
		if(!isWeekendOrSpecialDay && !StringUtility.isEmpty(specialDayMonthList)) {
			for(String specialDayMonth : specialDayMonthList.split(";")) {
				if(MonthDay.now().compareTo(MonthDay.parse(specialDayMonth, DateTimeFormatter.ofPattern("dd/MM"))) == 0){
					isWeekendOrSpecialDay = true;
					break;
				}
			}
		}
		LOGGER.debug("isWeekendOrSpecialDay ::: " + isWeekendOrSpecialDay);
		return isWeekendOrSpecialDay;
	}

	public String getUserId(final SbUserDetail userDetail) {
		String userId = null;
		if(!userDetail.getIsAnonymous()) {
			//authenticated 
			String userCode = userDetail.getFederationInformation().getUserCode();
			userId = generateUserId(userCode);
		} else {
			//not autheticated
			userId = generateUserId(null);
		}
		return userId;
	}

	private String generateUserId(final String code) {
		String userId = null;
		try {
			String inputDigest = "SELLABOT_" + (StringUtility.isEmpty(code)?UUID.randomUUID().toString():code);
			LOGGER.debug("generateUserId inputDigest --> " + inputDigest);
			MessageDigest messageDigest;
			messageDigest = MessageDigest.getInstance("SHA-512");
			messageDigest.update(inputDigest.getBytes(StandardCharsets.UTF_8));
			userId = bytesToHex(messageDigest.digest());
		} catch (NoSuchAlgorithmException e) {
			LOGGER.error("NoSuchAlgorithmException generateUserId ", e);
			throw new SBCommonException("Unable to create user id", SBCommonException.SB_NOT_INITIALIZED);
		}
		LOGGER.info("generateUserId --> " + userId);
		return userId;
	}
	
	private String bytesToHex(byte[] bytes) {
		StringBuilder sb = new StringBuilder();  
		for (byte b : bytes){  
			sb.append(String.format("%02X", b).toLowerCase());  
		}  
		return sb.toString();
	}

	public BotConfigResponse getBotConfig(final SbUserDetail userDetail) {
		BotConfigResponse response = new BotConfigResponse();
		try {
			String bank = (userDetail.getBank() != null) ? userDetail.getBank().getBankCode() : "";
			Map<String,String> alghoConfiguration = propertyDao.getPropertiesByCodice(SBCONSTANT.ALGHO_CONFIG.VALUE, bank);
			alghoConfiguration.put("user-id", userDetail.getAlghoUserId()); // created on chatinit
			alghoConfiguration.put("context", userDetail.getContext()); // created on chatinit
			//Long conversationId = conversationDAO.getConversationId();
			//userDetail.setAlghoConversationId(conversationId);
			//alghoConfiguration.put("conversation-id", conversationId.toString() ); // handled by algho we cannot create
			
			Map<String,String> internalConfiguration = propertyDao.getPropertiesByCodice(SBCONSTANT.CONFIG.VALUE, bank);
			internalConfiguration.put("overTime", Boolean.toString(serviceStatusCheckDAO.isOverTime(UtilityBank.getBankCode(userDetail.getBancaId()))));
			response.setConfiguration(internalConfiguration);
			response.setBotConfiguration(alghoConfiguration);
		} catch (SBBaseThrowable e) {
			LOGGER.error("AlghoFacade getBotConfig SBBaseThrowable error message : "+e.getMessage(),e);
			response.setStatus(BaseStatusEnum.EXCEPTION);
			response.setErrorMessageCode(e.getCode());
		} catch (Exception e) {
			LOGGER.error("AlghoFacade getBotConfig Exception error message : "+e.getMessage(),e);
			response.setStatus(BaseStatusEnum.EXCEPTION);
			response.setErrorMessageCode(SBBaseThrowable.SB_ERR_9999);
		}
		return response;
	}

	public BaseResponse botStart(final SbUserDetail userDetail, final BotStartRequest request, final HttpSession session) {
		BaseResponse response = new BaseResponse();
		try {
			if(request.getConversationId() == null) {
				throw new SBCommonException("Algho conversationId not available", SBCommonException.SB_NOT_INITIALIZED);
			}
			session.setAttribute(SBCONSTANT.CHATIDLOG.VALUE, request.getConversationId().toString());
			userDetail.setChatid(request.getConversationId().toString());
			userDetail.setOpenerOrigin(request.getOpenerOrigin());
			userDetail.setOpenerHref(request.getOpenerHref());
			ConversationDTO dto = new ConversationDTO();
			dto.setConversationId(request.getConversationId());
			dto.setBotId(request.getBotId());
			dto.setUserId(userDetail.getAlghoUserId());
			dto.setChannel(userDetail.getChannelId());
			dto.setContext(userDetail.getContext());
			if(!userDetail.getIsAnonymous()) {
				dto.setCode(userDetail.getFederationInformation().getUserCode());
				if(userDetail.getFederationInformation().getIdSoggetto()!=null) {
					dto.setSoggetto(Long.toString(userDetail.getFederationInformation().getIdSoggetto()));
				}
			}else {
				dto.setName(userDetail.getPersonalDet().getNome());
				dto.setSurname(userDetail.getPersonalDet().getCognome());
				dto.setEmail(userDetail.getPersonalDet().getEmail());
			}
			dto.setBank(userDetail.getBancaId());
			conversationDAO.insertConversation(dto);
		} catch (SBBaseThrowable e) {
			LOGGER.error("AlghoFacade botReady SBBaseThrowable error message : "+e.getMessage(),e);
			response.setStatus(BaseStatusEnum.EXCEPTION);
			response.setErrorMessageCode(e.getCode());
		} catch (Exception e) {
			LOGGER.error("AlghoFacade botReady Exception error message : "+e.getMessage(),e);
			response.setStatus(BaseStatusEnum.EXCEPTION);
			response.setErrorMessageCode(SBBaseThrowable.SB_ERR_9999);
		}
		return response;
	}

	public String botHbLink(final SbUserDetail hbUserDetail, final BotLinkRequest request) {
		if(StringUtility.isEmpty(request.getIntent())) {
			throw new SBCommonException("Intent not available", SBCommonException.SB_GEN_001);
		}
		return linkBuilder.getCompleteUrlForAction(request.getIntent(), hbUserDetail);
	}

	public BaseResponse botMessage(final SbUserDetail userDetail, final BotMessageRequest request) {
		BaseResponse response = new BaseResponse();
		boolean traceMessage = true;
		try {
			String soggetto = (userDetail.getIdSogg() != null) ? userDetail.getIdSogg().toString(): null;
			String answer = null;
			Gson gson = new Gson();
			String source = null;
			Map<String,Object> alghoMessageMap  = gson.fromJson(request.getMessage(),Map.class);
			if("ALGHO_MESSAGE".equals(request.getType())){
				request.getMessage();
				answer = (alghoMessageMap.get("content") != null ) ? (String) alghoMessageMap.get("content") : null;
				source = SBCONSTANT.BOT.VALUE;
			}else if("ALGHO_SEND_MESSAGE".equals(request.getType())) {
				source = userDetail.getPersonalDet() != null ? userDetail.getPersonalDet().getNome()+" "+userDetail.getPersonalDet().getCognome() : "CLIENT" ;
				if(alghoMessageMap.get("question") != null && StringUtility.isEmpty((String)alghoMessageMap.get("question"))) {
					traceMessage = false;
				}
			}
			if(traceMessage) {
				iMessageDAO.preserveAlghoMessage(userDetail.getChatid(), soggetto, source, gson.toJson(request), answer, request.getTimestamp());
			}
		} catch (SBBaseThrowable e) {
			LOGGER.error("AlghoFacade botMessage SBBaseThrowable error message : "+e.getMessage(),e);
			response.setStatus(BaseStatusEnum.EXCEPTION);
			response.setErrorMessageCode(e.getCode());
		} catch (Exception e) {
			LOGGER.error("AlghoFacade botMessage Exception error message : "+e.getMessage(),e);
			response.setStatus(BaseStatusEnum.EXCEPTION);
			response.setErrorMessageCode(SBBaseThrowable.SB_ERR_9999);
		}
		return response;
	}


}
