package it.sella.sb.core.im.action;

import org.springframework.stereotype.Component;

import it.sella.sb.im.dto.request.IMRequest;
import it.sella.sb.im.dto.response.IMResponse;

@Component
public class CheckLicense extends IMAbstractAction {

	@Override
	public void handleRequest(IMRequest imRequest) {

	}

	@Override
	public void handleResponse(IMRequest imRequest, IMResponse imResponse) {
		// TODO Auto-generated method stub

	}

}
