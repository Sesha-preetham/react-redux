package it.sella.sb.core.exception;

import it.sella.sb.common.exception.SBBaseThrowable;


@SuppressWarnings("serial")
public class SBCoreException extends SBBaseThrowable {
	
	public SBCoreException(String msg,String code) {
		super(msg,code);
	}

	public SBCoreException(String msg,String code, Throwable t) {
		super(msg, code, t);
	}
	
	public SBCoreException(final String msg,final String code,final String[] params) {
		super(msg,code,params);
	}
	

}
