package it.sella.sb.core.facade;

public class UtilityBank {
	public static String getBankCode(final String abi){
		if ("03268".equals(abi)) return "BSE";
		else if ("03211".equals(abi)) return "SIB";
		else if ("03311".equals(abi)) return "SHB";
		else if ("36000".equals(abi)) return "CLS";
		else return null;
	}
}
