package it.sella.sb.core.facade;

import it.sella.sb.common.exception.SBBaseThrowable;
import it.sella.sb.external.im.IMservice;
import it.sella.sb.im.dto.request.ChatTypingRequest;
import it.sella.sb.im.dto.request.IMRequest;
import it.sella.sb.im.dto.response.IMResponse;
import it.sella.sb.im.response.BaseResponse.BaseStatusEnum;
import it.sella.sb.util.SBCONSTANT;

import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class ChatTypingFacade extends BaseChatValidationFacade {
	
	@Autowired
	private IMservice imService;
	
	private static final Logger LOGGER = Logger.getLogger(ChatTypingFacade.class);

	public IMResponse chatTyping(final IMRequest imRequest,final ChatTypingRequest request){
		IMResponse response = new IMResponse();
		try {
			validateRequestObj(imRequest);
			imRequest.setAction(SBCONSTANT.ACTION.CHATEVENT.VALUE);
			imRequest.setIdevent(SBCONSTANT.ACTION.CHATTYPING.VALUE);
			Map<String, String> map = new HashMap<String, String>();
			map.put(SBCONSTANT.EVENTDATA.NAME.VALUE, SBCONSTANT.EVENTDATA.TYPING.VALUE);
			map.put(SBCONSTANT.EVENTDATA.VAL.VALUE, request.isTyping() ? "TRUE" : "FALSE");
			imRequest.getEventdata().add(map);
			response = getImService().message(imRequest);
		} catch (SBBaseThrowable e) {
			LOGGER.error("ChatTypingFacade chatTyping SBBaseThrowable error message : "+e.getMessage(),e);
			response.setStatus(BaseStatusEnum.EXCEPTION);
			response.setErrorMessageCode(e.getCode());
		} catch (Exception e) {
			LOGGER.error("ChatTypingFacade chatTyping Exception error message : "+e.getMessage(),e);
			response.setStatus(BaseStatusEnum.EXCEPTION);
			response.setErrorMessageCode(SBBaseThrowable.SB_ERR_9999);
		}
		LOGGER.debug("newChat response  --> "+response.getStatus());
		return response;
	}
	
	protected IMservice getImService() {
		return imService;
	}

}
