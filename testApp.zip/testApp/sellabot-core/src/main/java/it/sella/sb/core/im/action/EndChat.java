package it.sella.sb.core.im.action;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import it.sella.sb.common.util.JsonUtil;
import it.sella.sb.hb.dto.SbUserDetail;
import it.sella.sb.im.IMessageDAO;
import it.sella.sb.im.dto.request.IMRequest;
import it.sella.sb.im.dto.response.IMResponse;
import it.sella.sb.util.SBCONSTANT;

@Component
public class EndChat extends IMAbstractAction {

	private static final Logger LOGGER = Logger.getLogger(EndChat.class);
	
	@Autowired
	private IMessageDAO messageDAO;
	
	@Override
	public void handleRequest(final IMRequest imRequest) {
		LOGGER.debug("##EndChat #handleRequest "+imRequest.getChatid());
		final SbUserDetail userDetail = (SbUserDetail)getSession().getAttribute(SBCONSTANT.USERDETAIL.VALUE); 
		imRequest.setSender(userDetail != null && userDetail.getPersonalDet() != null ? userDetail.getPersonalDet().getNome()+" "+userDetail.getPersonalDet().getCognome() : "CLIENT");
		getMessageDAO().preserveMessage(imRequest, JsonUtil.convertToString(imRequest),null,userDetail);
		super.handleRequest(imRequest);
	}

	@Override
	public void handleResponse(IMRequest imRequest, IMResponse imResponse) {
		getSession().removeAttribute(SBCONSTANT.CHATID.VALUE);
		getSession().removeAttribute(SBCONSTANT.CHATURL.VALUE);
	}

	protected IMessageDAO getMessageDAO() {
		return messageDAO;
	}

}
