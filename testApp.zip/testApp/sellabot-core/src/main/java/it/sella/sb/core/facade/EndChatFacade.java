package it.sella.sb.core.facade;

import it.sella.sb.common.exception.SBBaseThrowable;
import it.sella.sb.common.util.JsonUtil;
import it.sella.sb.external.im.IMservice;
import it.sella.sb.hb.dto.SbUserDetail;
import it.sella.sb.im.IMessageDAO;
import it.sella.sb.im.dto.request.IMRequest;
import it.sella.sb.im.dto.response.IMResponse;
import it.sella.sb.im.response.BaseResponse.BaseStatusEnum;
import it.sella.sb.util.SBCONSTANT;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class EndChatFacade extends BaseChatValidationFacade {
	
	@Autowired
	private IMservice imService;
	
	@Autowired
	private IMessageDAO messageDAO;
	
	private static final Logger LOGGER = Logger.getLogger(EndChatFacade.class);

	public IMResponse endChat(final IMRequest imRequest,final SbUserDetail userDetail){
		IMResponse response = new IMResponse();
		try {
			validateRequestObj(imRequest);
			imRequest.setAction(SBCONSTANT.ACTION.ENDCHAT.VALUE);
			imRequest.setSender(userDetail != null && userDetail.getPersonalDet() != null ? userDetail.getPersonalDet().getNome()+" "+userDetail.getPersonalDet().getCognome() : "CLIENT");
			getMessageDAO().preserveMessage(imRequest, JsonUtil.convertToString(imRequest),null,userDetail);
			response = getImService().message(imRequest);
		} catch (SBBaseThrowable e) {
			LOGGER.error("NewChatFacade newChat SBBaseThrowable error message : "+e.getMessage(),e);
			response.setStatus(BaseStatusEnum.EXCEPTION);
			response.setErrorMessageCode(e.getCode());
		} catch (Exception e) {
			LOGGER.error("NewChatFacade newChat Exception error message : "+e.getMessage(),e);
			response.setStatus(BaseStatusEnum.EXCEPTION);
			response.setErrorMessageCode(SBBaseThrowable.SB_ERR_9999);
		}
		LOGGER.debug("newChat response  --> "+response.getStatus());
		return response;
	}
	
	protected IMservice getImService() {
		return imService;
	}

	protected IMessageDAO getMessageDAO() {
		return messageDAO;
	}

}
