package it.sella.sb.core.facade;

import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import it.sella.sb.common.exception.SBBaseThrowable;
import it.sella.sb.common.exception.SBCommonException;
import it.sella.sb.common.util.JsonUtil;
import it.sella.sb.common.util.StringUtility;
import it.sella.sb.external.im.IMservice;
import it.sella.sb.hb.dto.SbUserDetail;
import it.sella.sb.im.IMessageDAO;
import it.sella.sb.im.dto.request.ChatMessageRequest;
import it.sella.sb.im.dto.request.IMRequest;
import it.sella.sb.im.dto.response.IMResponse;
import it.sella.sb.im.response.BaseResponse.BaseStatusEnum;
import it.sella.sb.util.SBCONSTANT;

@Component
public class ChatMessageFacade extends BaseChatValidationFacade {
	
	@Autowired
	private IMservice imService;
	
	@Autowired
	private IMessageDAO messageDAO;
	
	private static final Logger LOGGER = Logger.getLogger(ChatHistoryFacade.class);

	public IMResponse chatMessage(final IMRequest imRequest,final ChatMessageRequest request,final SbUserDetail userDetail){
		IMResponse response = new IMResponse();
		try {
			validateRequestObj(imRequest);
			validateChatMessage(request);
			imRequest.setAction(SBCONSTANT.ACTION.CHATEVENT.VALUE);
			imRequest.setIdevent(SBCONSTANT.ACTION.CHATMESSAGE.VALUE);
			Map<String, String> map = new HashMap<String, String>();
			map.put(SBCONSTANT.EVENTDATA.NAME.VALUE, SBCONSTANT.EVENTDATA.MESSAGE.VALUE);
			map.put(SBCONSTANT.EVENTDATA.VAL.VALUE, request.getMessage());
			imRequest.getEventdata().add(map);
			//imRequest.setSender(SBCONSTANT.CLIENT.VALUE);
			final String name = userDetail.getPersonalDet() != null ? userDetail.getPersonalDet().getNome()+" "+userDetail.getPersonalDet().getCognome() : "CLIENT" ;
			imRequest.setSender(name);
			getMessageDAO().preserveMessage(imRequest, JsonUtil.convertToString(imRequest),null,userDetail);
			response = getImService().message(imRequest);
		} catch (SBBaseThrowable e) {
			LOGGER.error("ChatTypingFacade chatTyping SBBaseThrowable error message : "+e.getMessage(),e);
			response.setStatus(BaseStatusEnum.EXCEPTION);
			response.setErrorMessageCode(e.getCode());
		} catch (Exception e) {
			LOGGER.error("ChatTypingFacade chatTyping Exception error message : "+e.getMessage(),e);
			response.setStatus(BaseStatusEnum.EXCEPTION);
			response.setErrorMessageCode(SBBaseThrowable.SB_ERR_9999);
		}
		LOGGER.debug("newChat response  --> "+response.getStatus());
		return response;
	}
	
	public void validateChatMessage(final ChatMessageRequest request) {
		if(StringUtility.isEmpty(request.getMessage())) {
			LOGGER.debug("ChatMessageFacade validateChatMessage chat message should not be empty : "+request.getMessage());
			throw new SBCommonException("ChatMessageFacade validateChatMessage chat message should not be empty : "+request.getMessage(), SBCommonException.SB_CHAT_MESSAGE_EMPTY);
		}
	}
	
	protected IMservice getImService() {
		return imService;
	}

	protected IMessageDAO getMessageDAO() {
		return messageDAO;
	}

}
