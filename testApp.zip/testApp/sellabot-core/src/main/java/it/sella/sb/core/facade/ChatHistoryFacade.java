package it.sella.sb.core.facade;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import it.sella.sb.common.exception.SBBaseThrowable;
import it.sella.sb.common.util.JsonUtil;
import it.sella.sb.common.util.StringUtility;
import it.sella.sb.external.im.IMservice;
import it.sella.sb.hb.dto.SbUserDetail;
import it.sella.sb.im.IMessageDAO;
import it.sella.sb.im.dto.request.IMRequest;
import it.sella.sb.im.dto.response.ChatHistoryResponse;
import it.sella.sb.im.dto.response.IMResponse;
import it.sella.sb.im.dto.response.Transcript;
import it.sella.sb.im.response.BaseResponse.BaseStatusEnum;
import it.sella.sb.util.SBCONSTANT;

@Component
public class ChatHistoryFacade extends BaseChatValidationFacade {

	@Autowired
	private IMservice imService;
	
	@Autowired
	private IMessageDAO messageDAO;
	
	private static final Logger LOGGER = Logger.getLogger(ChatHistoryFacade.class);
	
	

	public ChatHistoryResponse getChatHistory(final IMRequest imRequest,final SbUserDetail userDetail){
		final ChatHistoryResponse response = new ChatHistoryResponse();
		try {
			validateRequestObj(imRequest);
			imRequest.setAction(SBCONSTANT.ACTION.HISTORY.VALUE);
			final IMResponse imResponse = getImService().message(imRequest);
			StringBuilder sb = new StringBuilder();
			final String name = userDetail.getPersonalDet() != null ? userDetail.getPersonalDet().getNome()+" "+userDetail.getPersonalDet().getCognome() : "CLIENT" ;
			if(imResponse!= null && imResponse.getTranscript() != null) {
				LOGGER.debug("ImResponse Transcript size  --> "+imResponse.getTranscript().size());
				List<Transcript> transcripts = new ArrayList<Transcript>();
				for (Map<String, String> trans : imResponse.getTranscript()) {
					final Transcript transcript = JsonUtil.convertToObject(JsonUtil.convertToString(trans), Transcript.class);
					transcripts.add(transcript);
					LOGGER.debug("Map  --> "+trans);
				}
				Collections.sort(transcripts);
				for (Transcript transcript : transcripts) {
					final String direction = "in".equalsIgnoreCase(transcript.getDirection()) ? name : 
						"out".equalsIgnoreCase(transcript.getDirection()) ? "SellaBot" : transcript.getDirection();
					if(StringUtility.isEmpty(sb.toString())) {
						sb.append(direction)
						.append("-")
						.append(transcript.getData());
					} else {
						sb.append("\n")
						.append(direction)
						.append("-")
						.append(transcript.getData());
					}
					LOGGER.debug("Object  --> "+transcript);
				}
			}
			response.setHistory(sb.toString());
			if(sb.length() > 1750) {
				LOGGER.debug("History size is more then 1750 --> size : "+sb.length());
				final String limitedHistory = sb.substring(sb.length()-2000, sb.length());
				final String history = limitedHistory.substring(limitedHistory.indexOf(name));
				response.setHistory(history);
			}
			/*imRequest.setSender(SBCONSTANT.HISTORY.VALUE);
			getMessageDAO().preserveMessage(imRequest,null,sb.toString(),userDetail);*/
		} catch (SBBaseThrowable e) {
			LOGGER.error("ChatHistoryFacade getChatHistory SBBaseThrowable error message : "+e.getMessage(),e);
			response.setStatus(BaseStatusEnum.EXCEPTION);
			response.setErrorMessageCode(e.getCode());
		} catch (Exception e) {
			LOGGER.error("ChatHistoryFacade getChatHistory Exception error message : "+e.getMessage(),e);
			response.setStatus(BaseStatusEnum.EXCEPTION);
			response.setErrorMessageCode(SBBaseThrowable.SB_ERR_9999);
		}
		LOGGER.debug("ChatHistoryResponse  --> "+response.getHistory());
		return response;
	}
	
	protected IMservice getImService() {
		return imService;
	}

	protected IMessageDAO getMessageDAO() {
		return messageDAO;
	}

}
