package it.sella.sb.external.im;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import it.sella.sb.common.exception.SBBaseThrowable;
import it.sella.sb.external.exception.SBServiceException;
import it.sella.sb.im.dto.request.IMRequest;
import it.sella.sb.im.dto.response.IMResponse;
import it.sella.sb.im.response.BaseResponse.BaseStatusEnum;
import it.sella.sb.util.SBCONSTANT;

@Component
public class IMserviceImpl implements IMservice{

	@Value("${IM_URL}")
	private String url; //="http://sede.imservicelab.com:18002/External/ChatInterface/index.php";
	private static final Logger LOGGER = Logger.getLogger(IMserviceImpl.class);
	@Autowired
	TemplateHandler templateHandler;
	
	@Override
	public IMResponse message(final IMRequest imRequest){
		//		System.setProperty("java.net.useSystemProxies", "true");
		try {
			if (imRequest==null) {
				return null;
			}
			String tempUrl = this.url;
			if (LOGGER.isDebugEnabled()) {
				LOGGER.debug("IMserviceImpl imRequest -->"+imRequest);
				LOGGER.debug("imRequest.getAction()-->"+imRequest.getAction());
				LOGGER.debug("imRequest.getChaturl()-->"+imRequest.getChaturl());
				LOGGER.debug("imRequest.getSourceIntentCode()-->"+imRequest.getSourceIntentCode());
				LOGGER.debug("url -->"+this.url);
			}
			final RestTemplate restTemplate = new RestTemplate();
			final HttpComponentsClientHttpRequestFactory httpRequestFactory = new HttpComponentsClientHttpRequestFactory();
	        httpRequestFactory.setConnectTimeout(15000);
	        httpRequestFactory.setReadTimeout(40000);
			restTemplate.setRequestFactory(httpRequestFactory);
			restTemplate.setUriTemplateHandler(templateHandler);
			
			final HttpEntity<Object> entity = new HttpEntity<Object>(imRequest);//,headers
			//		restTemplate.setRequestFactory(getRequestFactory());
	
	
			if(StringUtils.isNotEmpty(imRequest.getChaturl())){
//				tempUrl = this.url+"?"+SBCONSTANT.CHATURL.VALUE+"="+imRequest.getChaturl();
				tempUrl = UriComponentsBuilder.fromUriString(url).query(SBCONSTANT.CHATURL.VALUE+"={value}").buildAndExpand(imRequest.getChaturl()).toUriString();
			}
			LOGGER.debug("tempUrl -->"+tempUrl);
	
	
			final ResponseEntity<IMResponse> responseEntity = restTemplate.exchange(tempUrl, HttpMethod.POST, entity, IMResponse.class);
			final IMResponse imResponse = responseEntity.getBody();
			LOGGER.debug("imResponse -->"+imResponse.getResult()+" -- "+imResponse.getCause());
			if(!BaseStatusEnum.OK.name().equalsIgnoreCase(imResponse.getResult())){
				LOGGER.error("IMserviceImpl service response not OK Result : "+imResponse.getResult()+" Cause : "+imResponse.getCause());
				throw new SBServiceException("IMserviceImpl Cause : "+imResponse.getCause(),SBServiceException.getErrorCode(imResponse.getCause()));
			}
			return imResponse;
		} catch (final SBBaseThrowable e) {
			throw e;
		} catch (final RestClientException e) {
			LOGGER.error("RestClientException IMserviceImpl Error Message : "+e.getMessage(), e);
			throw new SBServiceException(e.getMessage(),SBServiceException.SB_REST_SERVICE_ERR, e);
		} catch (final Exception e) {
			LOGGER.error("Exception IMserviceImpl Error Message : "+e.getMessage(), e);
			throw new SBServiceException(e.getMessage(),SBServiceException.SB_ERR_9999, e);
		}
	}

}
