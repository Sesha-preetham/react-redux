package it.sella.sb.external.jms;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.jms.Message;
import javax.jms.Queue;
import javax.jms.QueueConnection;
import javax.jms.QueueConnectionFactory;
import javax.jms.QueueReceiver;
import javax.jms.QueueSession;
import javax.jms.Session;
import javax.jms.TextMessage;
import javax.naming.Context;
import javax.naming.InitialContext;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import it.sella.sb.im.external.jms.IQueueRecieve;
import it.sella.sb.util.SBCONSTANT;

@Component
public class QueueRecieve implements IQueueRecieve {

	private static final Logger LOGGER = Logger.getLogger(QueueRecieve.class);

	public final static String JNDI_FACTORY="weblogic.jndi.WLInitialContextFactory";
	private InitialContext queueContext;
	private QueueConnectionFactory qconFactory;
	private QueueConnection qcon;
	private QueueSession qsession;
	private Queue queue;
	private QueueReceiver queueReceiver;
	@Value("${JMS_Factory}")
	private String jmsFactory;
	@Value("${JMS_QUEUE}")
	private String jmsQueueName;
	@Value("${ENV}")
	private String ENV;
	
	private final static Hashtable<String, String> env=new Hashtable<String,String>();

	@PostConstruct
	public void setUp() {
		QueueRecieve.env.put(Context.INITIAL_CONTEXT_FACTORY, JNDI_FACTORY);
		if("DEV".equals(ENV)) {
			LOGGER.debug("JMSDPProviderUrl --> t3://172.17.29.47:12001");
			QueueRecieve.env.put(Context.PROVIDER_URL,  "t3://172.17.29.47:12001" );
		} else {
			LOGGER.debug("JMSDPProviderUrl --> "+System.getProperty("JMSDPProviderUrl"));
			QueueRecieve.env.put(Context.PROVIDER_URL,  System.getProperty("JMSDPProviderUrl"));
		}
	}

	@Override
	public synchronized List<String> recieve(String chatid) {
		final List<String> imRequests = new ArrayList<String>();
		try {
			this.queueContext = new InitialContext(QueueRecieve.env);
			this.qconFactory = (QueueConnectionFactory) this.queueContext.lookup(this.jmsFactory);
			this.qcon = this.qconFactory.createQueueConnection();
			this.qsession = this.qcon.createQueueSession(false, Session.AUTO_ACKNOWLEDGE);        
			this.queue = (Queue) this.queueContext.lookup(this.jmsQueueName);
			this.queueReceiver = this.qsession.createReceiver(this.queue,SBCONSTANT.CHATID.VALUE+"='"+chatid+"'");
			this.qcon.start();
			boolean containsMsg = true;
			while(containsMsg){
				final Message rmsg = this.queueReceiver.receiveNoWait();
				String msgText;
				LOGGER.debug("rmsg-->"+rmsg);
				if(rmsg!=null){
					if (rmsg instanceof TextMessage) {
						msgText = ((TextMessage)rmsg).getText();
					} else {
						msgText = rmsg.toString();
					}
					//FIXME Once stable have to remove the split logic
					if(msgText.contains("|||")){
						String[] messages = msgText.split("\\|\\|\\|");
						msgText = messages[0];
						LOGGER.debug("Request chat id --> "+chatid+" : Response chat id --> "+messages[1]);
					}
					LOGGER.debug("Message Received: "+chatid+"-->"+ msgText );
					imRequests.add(msgText);
				}else{
					containsMsg = false;
				}
			}

			this.qsession.close();
			this.qcon.close();
		} catch (final Exception e) {
			LOGGER.error("QueueRecieve Exception message --> "+e.getMessage(),e);
		}
		return imRequests;
	}

}
