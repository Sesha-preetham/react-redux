package it.sella.sb.external.im;

import java.net.URI;
import java.util.Map;

import org.springframework.stereotype.Component;
import org.springframework.web.util.DefaultUriTemplateHandler;
import org.springframework.web.util.UriComponents;
import org.springframework.web.util.UriComponentsBuilder;

@Component
public class TemplateHandler extends DefaultUriTemplateHandler {
	
	@Override
	public URI expand(final String uriTemplate, final Map<String, ?> uriVariables) {
		final UriComponentsBuilder uriComponentsBuilder = initUriComponentsBuilder(uriTemplate);
		final UriComponents uriComponents = uriComponentsBuilder.build().expand(uriVariables);
		return insertBaseUrl(uriComponents);
	}

	@Override
	public URI expand(final String uriTemplate, final Object... uriVariableValues) {
		final UriComponentsBuilder uriComponentsBuilder = initUriComponentsBuilder(uriTemplate);
		final UriComponents uriComponents = uriComponentsBuilder.build().expand(uriVariableValues);
		return insertBaseUrl(uriComponents);
	}

}
