package it.sella.sb.external.jms;

import java.util.Hashtable;

import javax.annotation.PostConstruct;
import javax.jms.Queue;
import javax.jms.QueueConnection;
import javax.jms.QueueConnectionFactory;
import javax.jms.QueueSender;
import javax.jms.QueueSession;
import javax.jms.Session;
import javax.jms.TextMessage;
import javax.naming.Context;
import javax.naming.InitialContext;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import it.sella.sb.im.external.jms.IQueueSend;
import it.sella.sb.util.SBCONSTANT;

@Component
public class QueueSend implements IQueueSend {

	private static final Logger LOGGER = Logger.getLogger(QueueSend.class);

	public final static String JNDI_FACTORY="weblogic.jndi.WLInitialContextFactory";
	private InitialContext queueContext;
	private QueueConnectionFactory qconFactory;
	private QueueConnection qcon;
	private QueueSession qsession;
	private Queue queue;
	private QueueSender qsender;
	@Value("${JMS_Factory}")
	private String jmsFactory;
	@Value("${JMS_QUEUE}")
	private String jmsQueueName;
	@Value("${ENV}")
	private String ENV;
	
	private final static Hashtable<String, String> env=new Hashtable<String,String>();

	@PostConstruct
	public void setUp() {
		QueueSend.env.put(Context.INITIAL_CONTEXT_FACTORY, JNDI_FACTORY);
		if("DEV".equals(ENV)) {
			LOGGER.debug("JMSDPProviderUrl --> t3://172.17.29.47:12001");
			QueueSend.env.put(Context.PROVIDER_URL,  "t3://172.17.29.47:12001" );
		} else {
			LOGGER.debug("JMSDPProviderUrl --> "+System.getProperty("JMSDPProviderUrl"));
			QueueSend.env.put(Context.PROVIDER_URL,  System.getProperty("JMSDPProviderUrl"));
		}
	}

	@Override
	public synchronized void send(String message,String chatid) {
		try {
			this.queueContext = new InitialContext(QueueSend.env);
			this.qconFactory = (QueueConnectionFactory) this.queueContext.lookup(this.jmsFactory);
			this.qcon = this.qconFactory.createQueueConnection();
			this.qsession = this.qcon.createQueueSession(false, Session.AUTO_ACKNOWLEDGE);        
			this.queue = (Queue) this.queueContext.lookup(this.jmsQueueName);
			this.qsender = this.qsession.createSender(this.queue);
			this.qcon.start();
			//		message.setJMSDeliveryMode(DeliveryMode.PERSISTENT);
			final TextMessage msg = this.qsession.createTextMessage();
			final String messageToSend = message != null ? message : "";
			//FIXME For testing purpose we concat the chatid. Once stable have to remove the concat
			msg.setText(messageToSend.concat("|||").concat(chatid));
			msg.setStringProperty(SBCONSTANT.CHATID.VALUE, chatid);
			LOGGER.debug("Message Send: "+chatid+"--"+ msg.getText() );
			this.qsender.send(msg);

			this.qsender.close();
			this.qsession.close();
			this.qcon.close();
		} catch (final Exception e) {
			LOGGER.error("QueueSend Exception message --> "+e.getMessage(),e);
		}
	}


}
