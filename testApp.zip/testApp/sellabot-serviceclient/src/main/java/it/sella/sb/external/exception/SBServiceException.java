package it.sella.sb.external.exception;

import it.sella.sb.common.exception.SBBaseThrowable;

import java.util.HashMap;
import java.util.Map;


@SuppressWarnings("serial")
public class SBServiceException extends SBBaseThrowable {
	
	public static final String SB_REST_SERVICE_ERR = "SB_REST_SERVICE_ERR";
	public static final String SB_992 = "IM_CHAT_ID_NOT_FOUND";
	public static final String SB_993 = "IM_WS_COMMUNICATION_ERR";
	public static final String SB_994 = "IM_CHAT_ID_EVENT_NOT_SUPPORTED";
	public static final String SB_995 = "IM_MISSING_CHANEL_BE_ERR";
	public static final String SB_996 = "IM_REQ_PARAM_MISSING";
	public static final String SB_997 = "IM_ACTION_NOT_FOUND";
	public static final String SB_998 = "IM_REQ_JSON_ERR";
	public static final String SB_999 = "IM_GEN_ERR";
	public static final String SB_IM_ERROR = "SB_IM_ERROR";
	public static final String SB_SOA_001 = "XML_SOA_ERROR";
	public static final String SB_SOA_002 = "XML_SOA_EXCEPTION";
	
	private static Map<String, String> errCodes = null;
	
	public static String getErrorCode(final String key){
		if(errCodes == null) {
			errCodes = new HashMap<String, String>();
			errCodes.put("992", SB_992);
			errCodes.put("993", SB_993);
			errCodes.put("994", SB_994);
			errCodes.put("995", SB_995);
			errCodes.put("996", SB_996);
			errCodes.put("997", SB_997);
			errCodes.put("998", SB_998);
			errCodes.put("999", SB_999);
		}
		return errCodes.containsKey(key) ? errCodes.get(key) : SB_IM_ERROR;
	}
	
	
	public SBServiceException(String msg,String code) {
		super(msg,code);
	}

	public SBServiceException(String msg,String code, Throwable t) {
		super(msg, code, t);
	}
	
	public SBServiceException(final String msg,final String code,final String[] params) {
		super(msg,code,params);
	}
	

}
