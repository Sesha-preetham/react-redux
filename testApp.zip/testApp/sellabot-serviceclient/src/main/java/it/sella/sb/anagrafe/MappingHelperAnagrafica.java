package it.sella.sb.anagrafe;
import it.sella.sb.anagrafe.dto.DataNascita;
import it.sella.sb.anagrafe.dto.PersonalDetails;
import it.sella.sb.common.util.DateUtility;
import it.sella.schema.canalidiretti.anagrafe.GetPersonaFisicaRequestType;
import it.sella.schema.canalidiretti.anagrafe.GetPersonaFisicaRequestType.GetPersonaFisicaInput;
import it.sella.schema.canalidiretti.anagrafe.GetPersonaFisicaResponseType;
import it.sella.schema.canalidiretti.anagrafe.GetPersonaFisicaResponseType.GetPersonaFisicaOutput;
import it.sella.schema.canalidiretti.anagrafe.ObjectFactory;
import it.sella.schema.infrastructure.Persone;
import it.sella.schema.infrastructure.Soggetto;

public class MappingHelperAnagrafica {
	
	public static GetPersonaFisicaRequestType mappingPersonaFisicaInput(final Long idSoggetto) {
		final ObjectFactory obj = new ObjectFactory();
		final GetPersonaFisicaRequestType request = obj.createGetPersonaFisicaRequestType();
		final GetPersonaFisicaInput input = new GetPersonaFisicaInput();
		final Soggetto soggetto = new Soggetto();
		soggetto.setIDSoggetto(idSoggetto);
		input.setSoggettoId(soggetto);
		request.setGetPersonaFisicaInput(input);
		return request;
	}
	
	public static PersonalDetails mappingPersonaFisicaOutput(final GetPersonaFisicaResponseType resp) {
		final PersonalDetails response = new PersonalDetails();
		if (resp!=null){
			GetPersonaFisicaOutput psOut=resp.getGetPersonaFisicaOutput();
			if (psOut!=null){
				Persone p = psOut.getPersone();
				if (p!=null){
					DataNascita dn = new DataNascita();
					response.setDataNascita(dn);
					response.setCognome(p.getCognome());
					response.setNome(p.getNome());
					dn.setCittaNascitaCodice(p.getCITTAOFBIRTH());
					dn.setNazioneNascitaCodice(p.getNAZIONEOFBIRTH());
					if (p.getDATEOFBIRTH()!=null) {
						dn.setDataNascita(DateUtility.getStringFromDate(p.getDATEOFBIRTH().toGregorianCalendar().getTime(), DateUtility.DATE_FORMAT_1) );
					}
					dn.setIntststring(p.getINTSTSTRING());
				}
			}
		}
		return response;
	}
	
}
