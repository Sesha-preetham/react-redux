package it.sella.sb.external.soa;

import org.apache.log4j.Logger;

import it.sella.jaxws.NEWExternalWSClientFactory;
import it.sella.jaxws.exception.SOAException;
import it.sella.sb.external.exception.SBServiceException;

public abstract class AbstractSOAServerFactory extends NEWExternalWSClientFactory 
{
	private static final Logger LOGGER = Logger.getLogger(AbstractSOAServerFactory.class);
	
	protected <T> T callWebServiceMethod(Object request) throws SBServiceException
	{
		return callTheWebServiceMethod(request, null);
	}
	
	protected <T> T callWebServiceMethod(Object request, String token) throws SBServiceException
	{
		return callTheWebServiceMethod(request,token);
	}
	
	
	public <T> T callTheWebServiceMethod(Object request, String token) throws SBServiceException
	{
		try
		{
			return super.callWebServiceMethod(request, token);
		}
		catch (SOAException se)
		{
			throw new SBServiceException(se.getMessage(), SBServiceException.SB_SOA_002, se);
		}
		catch (Exception s)
		{
			LOGGER.error("###SOA UNEXPECTED ERROR###",s);
			throw new SBServiceException(s.getMessage(),SBServiceException.SB_SOA_001,s);
		}
	}
}
