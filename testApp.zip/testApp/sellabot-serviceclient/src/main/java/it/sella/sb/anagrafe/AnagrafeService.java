package it.sella.sb.anagrafe;

import javax.xml.ws.Service;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import it.sella.contract.canalidiretti.anagrafe.Anagrafe;
import it.sella.sb.anagrafe.dto.PersonalDetails;
import it.sella.sb.external.exception.SBServiceException;
import it.sella.sb.external.soa.AbstractSOAServerFactory;
import it.sella.sb.hb.dto.SbUserDetail;
import it.sella.schema.canalidiretti.anagrafe.GetPersonaFisicaRequestType;
import it.sella.schema.canalidiretti.anagrafe.GetPersonaFisicaResponseType;

@Component
public class AnagrafeService extends AbstractSOAServerFactory implements IAnagrafeService {
	
	private static final Logger LOGGER = Logger.getLogger(AnagrafeService.class);
		
	@Value("${wsdl-anagrafe}")
	private String url;
	
	@Override
	protected Class<? extends Service> getServiceClass() {
		return Anagrafe.class;
	}

	@Override
	public String getWSDLUrl() {
		return url;
	}
	
	public PersonalDetails getPersonalDetails(final SbUserDetail userDet)
	{
		LOGGER.debug("Start AnagrafeService getPersonalDetails sogg --> "+userDet.getIdSogg());
		try {
			final GetPersonaFisicaRequestType request = MappingHelperAnagrafica.mappingPersonaFisicaInput(userDet.getIdSogg());
			final GetPersonaFisicaResponseType resp = (GetPersonaFisicaResponseType)callWebServiceMethod(request);
			final PersonalDetails response = MappingHelperAnagrafica.mappingPersonaFisicaOutput(resp);
			LOGGER.debug("End AnagrafeService getPersonalDetails response --> "+response.toString());
			return response;
		} catch (final SBServiceException e) {
			LOGGER.error("AnagrafeService getPersonalDetails EXCEPTION failed for the user = " + userDet.getUserId(), e);
			throw e;
		}
	}
	
}
