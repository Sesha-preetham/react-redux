package it.sella.sb.serviceclient;

import org.junit.Test;

import it.sella.sb.external.exception.SBServiceException;

public class PojoTestCase extends AbstractPojoTester {

	@Test
	public void testSBServiceException() {
		testPojo(SBServiceException.class);
	}
	
}
