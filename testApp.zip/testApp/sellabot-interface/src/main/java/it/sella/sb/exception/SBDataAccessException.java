package it.sella.sb.exception;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.List;

import org.springframework.dao.DataAccessException;

public class SBDataAccessException extends DataAccessException implements ISBException {

	private static final long serialVersionUID = 6957445939321979572L;
	public SBError[] bGErrors;

	public SBDataAccessException(){
		this(SBError.MSG_101);
	}


	public SBDataAccessException(final String message, final Throwable throwable) {
		super(message, throwable);
	}

	public SBDataAccessException(final SBError bgError){
		super(bgError.getConcatErrMsg());
		this.bGErrors = new SBError[]{bgError};
	}

	@Override
	public List<ExceptionMessage> getExceptionMessage() {
		final StringWriter errors = new StringWriter();
		this.printStackTrace(new PrintWriter(errors));
		final List<ExceptionMessage> exceptionMessages = new ArrayList<ExceptionMessage>();
		for (final SBError sbError : this.bGErrors) {
			exceptionMessages.add(new ExceptionMessage(sbError, null,errors.toString()));
		}
		return exceptionMessages;
	}

	@Override
	public SBError[]  getBGError() {
		return this.getBGError();
	}



}
