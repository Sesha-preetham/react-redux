package it.sella.sb.feedback.dto;

public class Answer {

	private String answerId;
	
	private String answer;
	
	@Override
	public String toString() {
		return "answerId --> "+answerId+"; answer --> "+answer;
	}

	public String getAnswerId() {
		return answerId;
	}

	public void setAnswerId(String answerId) {
		this.answerId = answerId;
	}

	public String getAnswer() {
		return answer;
	}

	public void setAnswer(String answer) {
		this.answer = answer;
	}
	
}
