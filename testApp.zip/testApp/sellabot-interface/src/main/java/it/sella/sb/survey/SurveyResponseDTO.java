package it.sella.sb.survey;

import it.sella.sb.im.response.BaseResponse;

public class SurveyResponseDTO extends BaseResponse {
	/**
	 * 
	 */
	private static final long serialVersionUID = -1697023017072907873L;
	
	private ClientSurveyResponseDTO data;

	public ClientSurveyResponseDTO getData() {
		return data;
	}

	public void setData(ClientSurveyResponseDTO data) {
		this.data = data;
	}
	
}
