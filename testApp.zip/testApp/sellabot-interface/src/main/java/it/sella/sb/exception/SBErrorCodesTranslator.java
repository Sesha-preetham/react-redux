package it.sella.sb.exception;

import java.sql.SQLException;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.support.SQLErrorCodeSQLExceptionTranslator;

public class SBErrorCodesTranslator extends SQLErrorCodeSQLExceptionTranslator {

	@Override
	protected DataAccessException customTranslate(final String task, final String sql,final SQLException sqlEx) {
		this.logger.debug("SQLError --> "+ sqlEx.getMessage());
		return new SBDataAccessException(SBError.SQL_ERR.getSQLErrorMsg(sqlEx));
	}

}
