package it.sella.sb.algho;

import it.sella.sb.algho.dto.ConversationDTO;

public interface IConversationDAO {
	
	public void insertConversation(ConversationDTO dto);
	
}
