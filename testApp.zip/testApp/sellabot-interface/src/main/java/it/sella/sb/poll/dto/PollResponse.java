package it.sella.sb.poll.dto;

import java.util.List;

import it.sella.sb.im.response.BaseResponse;

@SuppressWarnings("serial")
public class PollResponse extends BaseResponse
{
	private List<PollMessage> results;

	public List<PollMessage> getResults() {
		return results;
	}

	public void setResults(List<PollMessage> results) {
		this.results = results;
	}

}
