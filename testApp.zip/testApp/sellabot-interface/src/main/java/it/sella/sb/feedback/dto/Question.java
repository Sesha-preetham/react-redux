package it.sella.sb.feedback.dto;

import java.util.ArrayList;
import java.util.List;

public class Question implements Comparable<Question> {

	private String questionId;
	
	private String questionDesc;
	
	private String questionType;
	
	private Integer questionOrder;
	
	private List<Option> options;
	
	@Override
	public int compareTo(Question question) {
		Integer questionId1 = this.questionOrder;
		Integer questionId2 = question.questionOrder;
		if(questionId1.equals(questionId2)) {
			return 0;  
		} else if(questionId1 > questionId2) {
			return 1;  
		} else {
			return -1;  
		}
	}
		
	@Override
	public String toString() {
		return "questionId --> "+questionId+"; questionDesc --> "+questionDesc+"; questionType --> "+questionType+
				"; questionOrder --> "+questionOrder+"; options --> "+options;
	}

	public String getQuestionId() {
		return questionId;
	}

	public void setQuestionId(String questionId) {
		this.questionId = questionId;
	}

	public String getQuestionDesc() {
		return questionDesc;
	}

	public void setQuestionDesc(String questionDesc) {
		this.questionDesc = questionDesc;
	}

	public String getQuestionType() {
		return questionType;
	}

	public void setQuestionType(String questionType) {
		this.questionType = questionType;
	}

	public List<Option> getOptions() {
		if( options ==null ) {
			options = new ArrayList<Option>();
		}
		return options;
	}

	public void setOptions(List<Option> options) {
		this.options = options;
	}

	public Integer getQuestionOrder() {
		return questionOrder;
	}

	public void setQuestionOrder(Integer questionOrder) {
		this.questionOrder = questionOrder;
	}
	
	
}
