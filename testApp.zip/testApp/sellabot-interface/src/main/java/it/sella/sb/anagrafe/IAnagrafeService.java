package it.sella.sb.anagrafe;

import it.sella.sb.anagrafe.dto.PersonalDetails;
import it.sella.sb.hb.dto.SbUserDetail;

public interface IAnagrafeService {
	
	public PersonalDetails getPersonalDetails(final SbUserDetail userDet);

}
