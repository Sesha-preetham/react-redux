package it.sella.sb.feedback;

import it.sella.sb.feedback.dto.FeedBackRequest;
import it.sella.sb.feedback.dto.Question;
import it.sella.sb.hb.dto.SbUserDetail;
import it.sella.sb.im.response.BaseResponse;

import java.util.List;

public interface IFeedBackDao {
	
	public List<Question> getQuestions(final SbUserDetail sbUser);
	
	public BaseResponse insertFeedback(final FeedBackRequest request,final SbUserDetail sbUser);

}
