package it.sella.sb.poll;

import it.sella.sb.hb.dto.SbUserDetail;
import it.sella.sb.poll.dto.IntendDetail;

public interface IIntendDetailDao {
	
	public IntendDetail getIntendDetail(final String intendCode,final SbUserDetail sbUser);

}
