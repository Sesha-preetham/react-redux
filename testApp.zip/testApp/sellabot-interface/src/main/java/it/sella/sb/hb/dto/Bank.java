package it.sella.sb.hb.dto;

public class Bank {

	private String numEstCell;
	private String pi;
	private String numVerde;
	private String frase;
	private String sigla;
	private String bankCode;

	public String getNumEstCell() {
		return this.numEstCell;
	}
	public void setNumEstCell(String numEstCell) {
		this.numEstCell = numEstCell;
	}
	public String getPi() {
		return this.pi;
	}
	public void setPi(String pi) {
		this.pi = pi;
	}
	public String getNumVerde() {
		return this.numVerde;
	}
	public void setNumVerde(String numVerde) {
		this.numVerde = numVerde;
	}
	public String getFrase() {
		return this.frase;
	}
	public void setFrase(String frase) {
		this.frase = frase;
	}
	public String getSigla() {
		return this.sigla;
	}
	public void setSigla(String sigla) {
		this.sigla = sigla;
	}
	public String getBankCode() {
		return this.bankCode;
	}
	public void setBankCode(String bankCode) {
		this.bankCode = bankCode;
	}

}
