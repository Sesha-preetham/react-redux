package it.sella.sb.im.dto.request;

public class EventData {

	String name;
	Object value;

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Object getValue() {
		return this.value;
	}

	public void setValue(Object value) {
		this.value = value;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		if(this.name!=null){
			builder.append("");
		}
		return builder.toString();
	}


}
