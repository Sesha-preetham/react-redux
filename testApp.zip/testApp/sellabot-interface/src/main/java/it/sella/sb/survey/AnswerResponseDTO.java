package it.sella.sb.survey;

public class AnswerResponseDTO {

	private QuestionDTO nextSurvey;
	
	public QuestionDTO getNextSurvey() {
		return nextSurvey;
	}
	public void setNextSurvey(QuestionDTO nextSurvey) {
		this.nextSurvey = nextSurvey;
	}
	
}
