package it.sella.sb.util;

public enum SQL {

	VALUE;

	public enum COLUMN{
		MSGTXT("msgtxt"),
		ID("ID"),
		PHONE("PHONE"),
		SMS_KEY("SMS_KEY"),
		STATE("STATE"),
		SUR_ID("SUR_ID"),
		ATYPE("aType"),
		QID("qId"),
		QTEXT("qText"),
		AID("aId"),
		ACODE("aCode"),
		ALABEL("aLabel"),
		
		;
		public final String VALUE;
		COLUMN(final String value){
			this.VALUE = value;
		}
	}

	public enum QUERY{
		MESSAGEINSERT("messageInsert"),
		POLLMESSAGE("pollMessage");
		public final String ID;
		QUERY(final String id){
			this.ID = id;
		}
	}

}
