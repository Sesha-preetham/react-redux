package it.sella.sb.im;

import java.util.List;

import it.sella.sb.anagrafe.dto.MessageDetails;
import it.sella.sb.hb.dto.SbUserDetail;
import it.sella.sb.im.dto.request.IMRequest;

public interface IMessageDAO {

	public void preserveAlghoMessage(final String chatId, final String soggetto, final String source, final String message, final String answer, final Long timestamp);
	public void preserveMessage(final IMRequest imRequest,final String imRequestString,final String history,final SbUserDetail userDet);
	public List<String> readMessage(final String chatid);
	
	public MessageDetails retrieveOnlineMessages(final SbUserDetail userDetail);

}
