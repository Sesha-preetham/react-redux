package it.sella.sb.anagrafe;


public interface IAnagrafeDAO {
	
	public long getSubjectIdByIbcode(final String ibcode);

}
