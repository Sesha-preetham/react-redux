package it.sella.sb.common;

import java.util.Date;

public interface IIsFestivoDAO {
	
	public boolean isFestivo(final Date checkDate);

}
