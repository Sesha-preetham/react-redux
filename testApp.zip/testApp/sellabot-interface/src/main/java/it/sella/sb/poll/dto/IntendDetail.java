package it.sella.sb.poll.dto;

import java.io.Serializable;

@SuppressWarnings("serial")
public class IntendDetail implements Serializable{

	String menu;
	
	String tab;
	
	String subTab;
	
	String url;
	
	String link;
	
	String lable;

	public String getMenu() {
		return menu;
	}

	public void setMenu(String menu) {
		this.menu = menu;
	}

	public String getTab() {
		return tab;
	}

	public void setTab(String tab) {
		this.tab = tab;
	}

	public String getSubTab() {
		return subTab;
	}

	public void setSubTab(String subTab) {
		this.subTab = subTab;
	}

	public String getLink() {
		return link;
	}

	public void setLink(String link) {
		this.link = link;
	}

	public String getLable() {
		return lable;
	}

	public void setLable(String lable) {
		this.lable = lable;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}
	
}
