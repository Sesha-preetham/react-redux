package it.sella.sb.im.dto.response;

import java.io.Serializable;

import com.google.gson.annotations.SerializedName;

@SuppressWarnings("serial")
public class Transcript implements Serializable,Comparable<Transcript>{

	@SerializedName("Turn")
	private String turn;
	
	@SerializedName("Time")
	private String time;
	
	@SerializedName("Channel")
	private String channel;
	
	@SerializedName("Direction")
	private String direction;
	
	@SerializedName("Data")
	private String data;
	
	@Override
	public int compareTo(Transcript trans) {
		Long time1 = Long.parseLong(this.time);
		Long time2 = Long.parseLong(trans.time);
		if(time1.equals(time2)) {
			return 0;  
		} else if(time1 > time2) {
			return 1;  
		} else {
			return -1;  
		}
	}
	
	@Override
	public String toString() {
		return "Turn --> "+turn+"; Time --> "+time+"; Channel --> "+channel+"; Direction --> "+direction+"; Data --> "+data;
	}

	public String getTurn() {
		return turn;
	}

	public void setTurn(String turn) {
		this.turn = turn;
	}

	public String getTime() {
		return time;
	}

	public void setTime(String time) {
		this.time = time;
	}

	public String getChannel() {
		return channel;
	}

	public void setChannel(String channel) {
		this.channel = channel;
	}

	public String getDirection() {
		return direction;
	}

	public void setDirection(String direction) {
		this.direction = direction;
	}

	public String getData() {
		return data;
	}

	public void setData(String data) {
		this.data = data;
	}

}
