package it.sella.sb.common;

import java.util.List;
import java.util.Map;

public interface IPropertyDao {

	public Map<String, String> getPropertiesByCodice(String codice,
			String banca);

	public String getPropertyValue(String codice, String banca,
			String key);

	public List<String> getParamValue(final String banca, final String channel);
}