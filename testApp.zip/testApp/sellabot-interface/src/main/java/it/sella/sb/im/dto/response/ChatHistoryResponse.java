package it.sella.sb.im.dto.response;

import it.sella.sb.im.response.BaseResponse;

@SuppressWarnings("serial")
public class ChatHistoryResponse extends BaseResponse{

	private String history;
	private String chatId;

	public String getHistory() {
		return history;
	}

	public void setHistory(String history) {
		this.history = history;
	}

	public String getChatId() {
		return chatId;
	}

	public void setChatId(String chatId) {
		this.chatId = chatId;
	}
}
