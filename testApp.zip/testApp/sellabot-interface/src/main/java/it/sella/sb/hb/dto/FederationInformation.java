package it.sella.sb.hb.dto;

import java.io.Serializable;

@SuppressWarnings("serial")
public class FederationInformation implements Serializable 
{
	private String userCode;
	private String userToken;
	private String abi;
	private Long idSoggetto;
	
	public String getUserCode() {
		return userCode;
	}
	public void setUserCode(String userCode) {
		this.userCode = userCode;
	}
	public String getUserToken() {
		return userToken;
	}
	public void setUserToken(String userToken) {
		if (userToken != null && userToken.trim().length()>0) 
		{
			this.userToken = userToken.replaceAll("\\n", "").replaceAll("\\r", "");
		}
		else
		{
			this.userToken = userToken;
		}
	}
	public String getAbi() {
		return abi;
	}
	public void setAbi(String abi) {
		this.abi = abi;
	}
	public String getSender()
	{
		return "InternetBanking";
	}
	public Long getIdSoggetto() {
		return idSoggetto;
	}
	public void setIdSoggetto(Long idSoggetto) {
		this.idSoggetto = idSoggetto;
	}
	@Override
	public String toString() {
		return "FederationInformation [userCode=" + userCode + ", userToken="
				+ userToken + ", abi=" + abi + ", idSoggetto=" + idSoggetto
				+ "]";
	}
	
	
}
