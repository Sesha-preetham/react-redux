package it.sella.sb.util;

public enum SBCONSTANT {
	OK("OK"),
	CHATID("chatid"),
	CHATIDLOG("chatidlog"),
	USERDETAIL("userdetail"),
	ABI_ANONYMOUS_USER("03268"),
	CHATURL("chatUrl"),
	CLIENT("Client"),
	BOT("BOT"),
	HBURL("/hbroute"),
	CHATMESSAGE("chatmessage"),
	CHATRESULT("chatresult"),
	ANONYMOUS("ANONYMOUS"),
	ANO("ANO"),
	NYMOUS("NYMOUS"),
	NOME("nome"),
	COGNOME("cognome"),
	EMAIL("email"),
	HISTORY("HISTORY"),
	CHANNEL("CHANNEL"),
	SURVEY_DETAILS("SURVEY_DETAILS"),
	SUR_STARTED("SUR_STARTED"),
	SUR_COMPL("SUR_COMPL"),
	CONSENT("CONSENT"),
	CONSENT_UPDATED("CONSENT_UPDATED"),
	YES("YES"),
	INITIAL("INITIAL"),
	CONTINUE("CONTINUE"),
	END("END"),
	BSE("BSE"),
	BSE_SKIP_MSG("Come posso aiutarti su argomenti inerenti all’utilizzo del sito web di Banca Sella?"),
	APPNAME("APPNAME"),
	DEFAULT_VERSION("DefaultVersion"),
	
	// for algho integration
	USE_ALGHO("USE_ALGHO"),
	ALGHO_CHANNEL("ALGHO_CHANNEL"),
	ACTIVE("ACTIVE"),
	Y("Y"),
	UNDERSCORE("_"),
	FUORIORARIO("FuoriOrario"),
	INORARIO("InOrario"), 
	AUTENTICATO("Autenticato"),
	NONAUTENTICATO("NonAutenticato"), 
	TRUE("TRUE"), 
	ALGHO_CONFIG("ALGHO_CONFIG"), 
	CONFIG("CONFIG"), 
	ALGHO("ALGHO"),
	ALGHO_MESSAGE("ALGHO_MESSAGE"),
	ALGHO_SEND_MESSAGE("ALGHO_SEND_MESSAGE"),
	REDIRECT_PAGE("redirectPage"),
	WEEKENDORSPECIAL("WeekendOSpeciale"),
	;

	public String VALUE;

	private SBCONSTANT(final String value) {
		this.VALUE = value;
	}

	public enum PARAMETER{
		APPNAME("AppName"),
		APPVERSION("AppVersion"),
		CUSTOMERID("CustomerID"),
		LANG("Lang"),
		MMCHANNELS_CHAT_CLIENT_NAME("MMChannels_Chat_client_name"),
		MMCHANNELS_CHAT_CLIENT_MADE("MMChannels_Chat_client_made"),
		MMCHANNELS_CHAT_CLIENT_VERSION("MMChannels_Chat_client_version"),
		INTERACTIONTIMEOUT("InteractionTimeout"),
		MMCHANNELS_CHAT_CLIENT_BACKEND("MMChannels_Chat_client_backend"),
		DEVELOPMENTSTATUS("DevelopmentStatus"),
		ALIAS("Alias"),
		USERID("UserId"),
		CHATAREA("ChatArea"),
		OVERTIME("OverTime"),
		SESSIONID("SessionId"),
		BANCAID("BancaId"),
		LOGTIME("LogTime"),
		CHANNELID("ChannelId"),
		USERAGENT("UserAgent"),
		CATEGORIA("Categoria"),
		USERIPADDRESS("UserIPAddress"),
		//Parameter Value
		PRIVATA("privata"),
		PUBBLICA("pubblica");

		public String VALUE;
		PARAMETER(final String value){
			this.VALUE = value;
		}
	}

	public enum EVENTDATA{
		MESSAGE("message"),
		NAME("name"),
		VAL("value"),
		INTENTNAME("IntentName"),
		ANSWER("Answer"),
		INTENTCODE("IntentCode"),
		INTENTAREA("IntentArea"),
		ACTION("Action"),
		OPERATORSKILL("OperatorSkill"),
		LINK("Link"),
		TYPING("typing");

		public String VALUE;
		EVENTDATA(final String value){
			this.VALUE = value;
		}
	}
	
	public enum ACTION{
		NEWCHAT("newchat"),
		ENDCHAT("endchat"),
		HISTORY("gettranscription"),
		CHATEVENT("chatevent"),
		CHATMESSAGE("chatmessage"),
		CHATTYPING("chattyping");
		
		public String VALUE;
		ACTION(final String value){
			this.VALUE = value;
		}
	}


}


