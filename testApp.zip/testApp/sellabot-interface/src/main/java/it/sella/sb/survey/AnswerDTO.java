package it.sella.sb.survey;

public class AnswerDTO {
	
	private Long id;
	private String labelcode;
	private String value;
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getLabelcode() {
		return labelcode;
	}
	public void setLabelcode(String labelcode) {
		this.labelcode = labelcode;
	}
	public String getValue() {
		return value;
	}
	public void setValue(String value) {
		this.value = value;
	}
	
}
