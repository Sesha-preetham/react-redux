package it.sella.sb.im.external.jms;

public interface IQueueSend {

	public void send(String message,String chatid);
}
