package it.sella.sb.survey;

import it.sella.sb.im.response.BaseResponse;

public class QuestionAnswerResponseDTO extends BaseResponse {

	private static final long serialVersionUID = 1304892096247520551L;

	private AnswerResponseDTO data;

	public synchronized AnswerResponseDTO getData() {
		return data;
	}

	public synchronized void setData(AnswerResponseDTO data) {
		this.data = data;
	}
	
}
