package it.sella.sb.feedback.dto;


public class Option {

	private String optionId;
	
	private String optionDesc;
	
	private String other;
	
	@Override
	public String toString() {
		return "optionId --> "+optionId+"; optionDesc --> "+optionDesc+"; other --> "+other;
	}

	public String getOptionId() {
		return optionId;
	}

	public void setOptionId(String optionId) {
		this.optionId = optionId;
	}

	public String getOptionDesc() {
		return optionDesc;
	}

	public void setOptionDesc(String optionDesc) {
		this.optionDesc = optionDesc;
	}

	public String getOther() {
		return other;
	}

	public void setOther(String other) {
		this.other = other;
	}

}
