package it.sella.sb.im.response;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

@SuppressWarnings("serial")
public class FEMessage implements Serializable {

	private String messageCode;
	private List<String> messageParams = new ArrayList<>();
	private String messageFEFields="*";
	
	public List<String> getMessageParams() {
		return messageParams;
	}
	public void setMessageParams(List<String> messageParams) {
		this.messageParams = messageParams;
	}	
	public String getMessageCode() {
		return messageCode;
	}
	public void setMessageCode(String messageCode) {
		this.messageCode = messageCode;
	}
	public String getMessageFEFields() {
		return messageFEFields;
	}
	public void setMessageFEFields(String messageFEFields) {
		this.messageFEFields = messageFEFields;
	}
	

}
