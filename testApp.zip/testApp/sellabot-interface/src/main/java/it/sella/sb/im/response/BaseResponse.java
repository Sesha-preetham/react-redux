package it.sella.sb.im.response;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@SuppressWarnings("serial")
public class BaseResponse implements Serializable
{
	public enum BaseStatusEnum {
		OK, KO, EXCEPTION;
	}

	private String status=BaseStatusEnum.OK.toString();
	
	private final List<FEMessage> errors = new ArrayList<>();

	public String getErrorMessageCode() {
		return errors.size()>0?errors.get(0).getMessageCode():null;
	}

	public void setErrorMessageCode(final String errorMessageCode)
	{
		final FEMessage be = new FEMessage();
		be.setMessageCode(errorMessageCode);
		addError(be);
	}

	public void setErrorMessageCode(final String errorMessageCode,final String args[])
	{
		final FEMessage be = new FEMessage();
		be.setMessageCode(errorMessageCode);
		if(args != null) {
			be.setMessageParams(Arrays.asList(args));
		}
		addError(be);
	}

	public void addError(final FEMessage msg)
	{
		errors.add(msg);
	}

	public List<FEMessage> getErrors()
	{
		return errors;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(final BaseStatusEnum bse) {
		this.status = bse.name();
	}

	

}
