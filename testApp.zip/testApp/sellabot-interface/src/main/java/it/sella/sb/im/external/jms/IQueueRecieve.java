package it.sella.sb.im.external.jms;

import java.util.List;

public interface IQueueRecieve {

	public List<String> recieve(String chatid);
}
