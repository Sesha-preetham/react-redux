package it.sella.sb.common;

public interface IServiceStatusCheckDAO 
{
	public static final String SERVICE_STATUS_CLOSED = "C";
	public static final String SERVICE_STATUS_OPEN = "O";
	public static final String SERVICE_STATUS_OPENED = "OPENED";
	boolean checkServiceOpen(final String serviceName, final String bankCode) ;
	String getServiceStatusOnDate(final String serviceName, final String bankCode);
	String getServiceStatusOnDate(final String serviceName, final String bankCode, final String platform);
	boolean isOverTime(final String bankCode);
}
