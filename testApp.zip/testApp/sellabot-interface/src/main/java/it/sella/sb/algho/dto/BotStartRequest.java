package it.sella.sb.algho.dto;

public class BotStartRequest {
	
	private Long conversationId;
	private String botId;
	private String openerOrigin;
	private String openerHref;
	
	
	public Long getConversationId() {
		return conversationId;
	}

	public void setConversationId(Long conversationId) {
		this.conversationId = conversationId;
	}

	public String getBotId() {
		return botId;
	}

	public void setBotId(String botId) {
		this.botId = botId;
	}

	public String getOpenerOrigin() {
		return openerOrigin;
	}

	public void setOpenerOrigin(String openerOrigin) {
		this.openerOrigin = openerOrigin;
	}

	public String getOpenerHref() {
		return openerHref;
	}

	public void setOpenerHref(String openerHref) {
		this.openerHref = openerHref;
	}

}
