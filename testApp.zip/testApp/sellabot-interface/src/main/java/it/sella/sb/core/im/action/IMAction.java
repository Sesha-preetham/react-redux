package it.sella.sb.core.im.action;

import it.sella.sb.im.dto.request.IMRequest;
import it.sella.sb.im.dto.response.IMResponse;

public interface IMAction {

	public void handleRequest(IMRequest imRequest);

	public void handleResponse(IMRequest imRequest,IMResponse imResponse);

	public IMResponse process(IMRequest imRequest);

}
