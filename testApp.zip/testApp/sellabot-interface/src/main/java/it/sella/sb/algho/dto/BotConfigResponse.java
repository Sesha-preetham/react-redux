package it.sella.sb.algho.dto;

import java.util.Map;

import it.sella.sb.im.response.BaseResponse;

public class BotConfigResponse extends BaseResponse {

	/**
	 * 
	 */
	private static final long serialVersionUID = 5142494380665715804L;
	
	private Map<String,String> botConfiguration;
	private Map<String,String> configuration;

	public Map<String,String> getBotConfiguration() {
		return botConfiguration;
	}

	public void setBotConfiguration(Map<String,String> botConfiguration) {
		this.botConfiguration = botConfiguration;
	}

	public Map<String,String> getConfiguration() {
		return configuration;
	}

	public void setConfiguration(Map<String,String> configuration) {
		this.configuration = configuration;
	}

}
