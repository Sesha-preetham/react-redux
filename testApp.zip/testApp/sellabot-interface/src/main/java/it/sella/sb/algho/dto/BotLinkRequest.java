package it.sella.sb.algho.dto;

public class BotLinkRequest {
	
	private String intent;

	public String getIntent() {
		return intent;
	}

	public void setIntent(String intent) {
		this.intent = intent;
	}
}
