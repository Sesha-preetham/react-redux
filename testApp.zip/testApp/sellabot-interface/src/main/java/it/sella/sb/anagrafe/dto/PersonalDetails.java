package it.sella.sb.anagrafe.dto;

import it.sella.sb.im.response.BaseResponse;
import it.sella.sb.util.SBCONSTANT;

@SuppressWarnings("serial")
public class PersonalDetails extends BaseResponse {
	private String nome=SBCONSTANT.ANO.VALUE;
	private String cognome=SBCONSTANT.NYMOUS.VALUE;
	private String codiceFiscale;
	private DataNascita dataNascita;
	private String statoCivile;
	private String email;
	private String sesso;
	private String nickName;
	private Boolean isAnonymous=Boolean.TRUE;
	private Boolean isShowButton=Boolean.FALSE;
	private Boolean isMobile=Boolean.FALSE;
	private String operatorParam;
	private String channelId;
	private String categoria;
	private String cnctrToken;
	private Boolean isSME=Boolean.FALSE;
	
	private String onlineMessages;//from hb messages
	
	private MessageDetails messageDetails;

	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getCognome() {
		return cognome;
	}
	public void setCognome(String cognome) {
		this.cognome = cognome;
	}
	public String getCodiceFiscale() {
		return codiceFiscale;
	}
	public void setCodiceFiscale(String codiceFiscale) {
		this.codiceFiscale = codiceFiscale;
	}
	public DataNascita getDataNascita() {
		return dataNascita;
	}
	public void setDataNascita(DataNascita dataNascita) {
		this.dataNascita = dataNascita;
	}
	public String getStatoCivile() {
		return statoCivile;
	}
	public void setStatoCivile(String statoCivile) {
		this.statoCivile = statoCivile;
	}
	public String getSesso() {
		return sesso;
	}
	public void setSesso(String sesso) {
		this.sesso = sesso;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getNickName() {
		return nickName;
	}
	public void setNickName(String nickName) {
		this.nickName = nickName;
	}
	public Boolean getIsAnonymous() {
		return isAnonymous;
	}
	public void setIsAnonymous(Boolean isAnonymous) {
		this.isAnonymous = isAnonymous;
	}
	public String getOperatorParam() {
		return operatorParam;
	}
	public void setOperatorParam(String operatorParam) {
		this.operatorParam = operatorParam;
	}
	public String getChannelId() {
		return channelId;
	}
	public void setChannelId(String channelId) {
		this.channelId = channelId;
	}
	public String getCategoria() {
		return categoria;
	}
	public void setCategoria(String categoria) {
		this.categoria = categoria;
	}
	public Boolean getIsShowButton() {
		return isShowButton;
	}
	public void setIsShowButton(Boolean isShowButton) {
		this.isShowButton = isShowButton;
	}

	public Boolean getIsMobile() {
		return isMobile;
	}
	public void setIsMobile(Boolean isMobile) {
		this.isMobile = isMobile;
	}
	public String getCnctrToken() {
		return cnctrToken;
	}
	public void setCnctrToken(String cnctrToken) {
		this.cnctrToken = cnctrToken;
	}
	public String getOnlineMessages() {
		return onlineMessages;
	}
	public void setOnlineMessages(String onlineMessages) {
		this.onlineMessages = onlineMessages;
	}
	
	public MessageDetails getMessageDetails() {
		return messageDetails;
	}
	public void setMessageDetails(MessageDetails messageDetails) {
		this.messageDetails = messageDetails;
	}
	public Boolean getIsSME() {
		return isSME;
	}
	public void setIsSME(Boolean isSME) {
		this.isSME = isSME;
	}
	@Override
	public String toString() {
		return "PersonalDetails [nome=" + nome + ", cognome=" + cognome + ", codiceFiscale=" + codiceFiscale
				+ ", dataNascita=" + dataNascita + ", statoCivile=" + statoCivile
				+ ", sesso=" + sesso+ ", NickName="  +nickName+ ", email="+email+ ", Anonymous=" +isAnonymous+
				", isShowButton="+isShowButton+", categoria="+categoria+", channelId="+channelId+", isMobile="+isMobile+"]";
	}

}
