package it.sella.sb.im.dto.request;

import java.util.Map;

public class ChatResult extends AbstractRequest {

	private Map<String, String> eventdata;

	public Map<String, String> getEventdata() {
		return this.eventdata;
	}

	public void setEventdata(Map<String, String> eventdata) {
		this.eventdata = eventdata;
	}


}
