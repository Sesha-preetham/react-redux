package it.sella.sb.hb.dto;

import java.util.List;

public class HBUserDetail {

	private String nome; 
	private String cogNome; 
	private String userId; 
	private String chatid; 
	private String overTime; 
	private Bank bank; 
	private List<String> availableLocale; 
	private String choosedLocale; 
	private List<Conto> conti; 
	private List<Carta> carte;
	
	public String getNome() {
		return this.nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getCogNome() {
		return this.cogNome;
	}
	public void setCogNome(String cogNome) {
		this.cogNome = cogNome;
	}
	public String getUserId() {
		return this.userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getChatid() {
		return this.chatid;
	}
	public void setChatid(String chatid) {
		this.chatid = chatid;
	}
	public String getOverTime() {
		return this.overTime;
	}
	public void setOverTime(String overTime) {
		this.overTime = overTime;
	}
	public Bank getBank() {
		return this.bank;
	}
	public void setBank(Bank bank) {
		this.bank = bank;
	}
	public List<String> getAvailableLocale() {
		return this.availableLocale;
	}
	public void setAvailableLocale(List<String> availableLocale) {
		this.availableLocale = availableLocale;
	}
	public String getChoosedLocale() {
		return this.choosedLocale;
	}
	public void setChoosedLocale(String choosedLocale) {
		this.choosedLocale = choosedLocale;
	}
	public List<Conto> getConti() {
		return this.conti;
	}
	public void setConti(List<Conto> conti) {
		this.conti = conti;
	}
	public List<Carta> getCarte() {
		return this.carte;
	}
	public void setCarte(List<Carta> carte) {
		this.carte = carte;
	}

}
