package it.sella.sb.hb.dto;


import java.io.Serializable;

@SuppressWarnings("serial")
public class Carta implements Serializable
{

	private String id;
	private String contoAppoggioMascherato;
	private String descCarta;
	private String productMasked;
	private String productAlias;
	private int position;
	private String defaultAlias;
	private Boolean securityDeposit;
	private Boolean account;
	private String userAlias;
	private Boolean card;
	private Boolean prepagata;
	private String type;
	private String status;
	private String network;
	private String expiryDate;


	public String getId() {
		return this.id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getContoAppoggioMascherato() {
		return this.contoAppoggioMascherato;
	}
	public void setContoAppoggioMascherato(String contoAppoggioMascherato) {
		this.contoAppoggioMascherato = contoAppoggioMascherato;
	}
	public String getDescCarta() {
		return this.descCarta;
	}
	public void setDescCarta(String descCarta) {
		this.descCarta = descCarta;
	}
	public String getProductMasked() {
		return this.productMasked;
	}
	public void setProductMasked(String productMasked) {
		this.productMasked = productMasked;
	}
	public String getProductAlias() {
		return this.productAlias;
	}
	public void setProductAlias(String productAlias) {
		this.productAlias = productAlias;
	}
	public int getPosition() {
		return this.position;
	}
	public void setPosition(int position) {
		this.position = position;
	}
	public String getDefaultAlias() {
		return this.defaultAlias;
	}
	public void setDefaultAlias(String defaultAlias) {
		this.defaultAlias = defaultAlias;
	}
	public Boolean getSecurityDeposit() {
		return this.securityDeposit;
	}
	public void setSecurityDeposit(Boolean securityDeposit) {
		this.securityDeposit = securityDeposit;
	}
	public Boolean getAccount() {
		return this.account;
	}
	public void setAccount(Boolean account) {
		this.account = account;
	}
	public String getUserAlias() {
		return this.userAlias;
	}
	public void setUserAlias(String userAlias) {
		this.userAlias = userAlias;
	}
	public Boolean getCard() {
		return this.card;
	}
	public void setCard(Boolean card) {
		this.card = card;
	}
	public Boolean getPrepagata() {
		return this.prepagata;
	}
	public void setPrepagata(Boolean prepagata) {
		this.prepagata = prepagata;
	}
	public String getType() {
		return this.type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getStatus() {
		return this.status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getNetwork() {
		return this.network;
	}
	public void setNetwork(String network) {
		this.network = network;
	}
	public String getExpiryDate() {
		return this.expiryDate;
	}
	public void setExpiryDate(String expiryDate) {
		this.expiryDate = expiryDate;
	}

}
