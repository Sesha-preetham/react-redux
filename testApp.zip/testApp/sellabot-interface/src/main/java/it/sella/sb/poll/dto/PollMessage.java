package it.sella.sb.poll.dto;

import it.sella.sb.common.util.StringUtility;

import java.io.Serializable;

import com.google.gson.annotations.SerializedName;

public class PollMessage implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -2702490018349505269L;

	private String sender;
	
	private String message;
	
	@SerializedName("Answer")
	private String answer;
	
	@SerializedName("IntentName")
	private String intentName;
	
	@SerializedName("IntentCode")
	private String intentCode;
	
	@SerializedName("Action")
	private String action;
	
	@SerializedName("OperatorSkill")
	private String operatorSkill;
	
	@SerializedName("Link")
	private String link;
	
	@SerializedName("IntentArea")
	private String intentArea;
	
	private String url;

	public String getSender() {
		return this.sender;
	}
	public void setSender(String sender) {
		this.sender = sender;
	}
	public String getMessage() {
		if(!StringUtility.isEmpty(message)){
			message = message.replaceAll("\\r|\\n", "<br/>");
		}
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public String getAnswer() {
		if(!StringUtility.isEmpty(answer)){
			answer = answer.replaceAll("\\r|\\n", "<br/>");
		}
		return answer;
	}
	public void setAnswer(String answer) {
		this.answer = answer;
	}
	public String getIntentName() {
		return intentName;
	}
	public void setIntentName(String intentName) {
		this.intentName = intentName;
	}
	public String getIntentCode() {
		return intentCode;
	}
	public void setIntentCode(String intentCode) {
		this.intentCode = intentCode;
	}
	public String getAction() {
		return action;
	}
	public void setAction(String action) {
		this.action = action;
	}
	public String getOperatorSkill() {
		return operatorSkill;
	}
	public void setOperatorSkill(String operatorSkill) {
		this.operatorSkill = operatorSkill;
	}
	public String getLink() {
		return link;
	}
	public void setLink(String link) {
		this.link = link;
	}
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	
	@Override
	public String toString() {
		return "sender --> "+sender+"; message --> "+message+"; answer --> "+answer+"; intentName --> "+intentName+"; intentCode --> "+intentCode+"; action --> "+action+
				"; operatorSkill --> "+operatorSkill+"; link --> "+link+"; url --> "+url;
	}
	public String getIntentArea() {
		return intentArea;
	}
	public void setIntentArea(String intentArea) {
		this.intentArea = intentArea;
	}
	
}
