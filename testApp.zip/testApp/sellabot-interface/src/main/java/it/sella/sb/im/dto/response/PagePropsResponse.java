package it.sella.sb.im.dto.response;

import java.util.HashMap;
import java.util.Map;

import it.sella.sb.im.response.BaseResponse;

@SuppressWarnings("serial")
public class PagePropsResponse extends BaseResponse {

	private Map<String, String> props;

	public Map<String, String> getProps() {
		if(props == null) {
			props = new HashMap<String, String>();
		}
		return props;
	}

	public void setProps(Map<String, String> props) {
		this.props = props;
	}

	

}
