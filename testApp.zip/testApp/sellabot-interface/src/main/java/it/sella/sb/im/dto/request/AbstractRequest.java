package it.sella.sb.im.dto.request;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;

public class AbstractRequest {
	private String action;
	private String idevent;

	private String chatid;
	private String chaturl;
	private List<Parameter> parameters;
	private String pollMessage;
	private String sender;
	private String sourceIntentCode;


	public String getIdevent() {
		return this.idevent;
	}

	public void setIdevent(String idevent) {
		this.idevent = idevent;
	}

	public String getChatid() {
		return this.chatid;
	}

	public void setChatid(String chatid) {
		this.chatid = chatid;
	}

	public String getAction() {
		return this.action;
	}

	public void setAction(String action) {
		this.action = action;
	}

	public List<Parameter> getParameters() {
		if(this.parameters == null){
			this.parameters = new ArrayList<Parameter>();
		}
		return this.parameters;
	}

	public void setParameters(List<Parameter> parameters) {
		this.parameters = parameters;
	}

	@JsonIgnore
	public String getChaturl() {
		return this.chaturl;
	}

	@JsonIgnore
	public void setChaturl(String chaturl) {
		this.chaturl = chaturl;
	}

	@JsonIgnore
	public String getPollMessage() {
		return this.pollMessage;
	}

	@JsonIgnore
	public void setPollMessage(String pollMessage) {
		this.pollMessage = pollMessage;
	}

	//@JsonIgnore
	public String getSender() {
		return this.sender;
	}

	//@JsonIgnore
	public void setSender(String sender) {
		this.sender = sender;
	}

	public String getSourceIntentCode() {
		return sourceIntentCode;
	}

	public void setSourceIntentCode(String sourceIntentCode) {
		this.sourceIntentCode = sourceIntentCode;
	}

}
