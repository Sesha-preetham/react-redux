package it.sella.sb.feedback.dto;

import it.sella.sb.im.response.BaseResponse;

import java.util.List;

@SuppressWarnings("serial")
public class FeedBackQuestionResponse extends BaseResponse {

	private List<Question> questions;

	public List<Question> getQuestions() {
		return questions;
	}

	public void setQuestions(List<Question> questions) {
		this.questions = questions;
	}
	
}
