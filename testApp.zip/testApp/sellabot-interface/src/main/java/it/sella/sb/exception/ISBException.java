package it.sella.sb.exception;

import java.util.List;

public interface ISBException {

	public List<ExceptionMessage> getExceptionMessage();
	public SBError[] getBGError();

}
