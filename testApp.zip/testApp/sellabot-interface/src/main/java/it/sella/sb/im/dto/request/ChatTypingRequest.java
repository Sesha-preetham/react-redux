package it.sella.sb.im.dto.request;


public class ChatTypingRequest extends ChatRequest {

	private boolean typing = true;

	public boolean isTyping() {
		return typing;
	}

	public void setTyping(boolean typing) {
		this.typing = typing;
	}

}
