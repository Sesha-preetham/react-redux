package it.sella.sb.hb.dto;

import java.io.Serializable;

@SuppressWarnings("serial")
public class Conto implements Serializable
{
	private String id;
	private String descServizio;
	private String intestazione;
	private String descDivisa;
	private String productMasked;
	private String productAlias;
	private boolean isProductAliasExist;

	public boolean getIsProductAliasExist() {
		return isProductAliasExist;
	}
	public void setIsProductAliasExist(boolean isProductAliasExist) {
		this.isProductAliasExist = isProductAliasExist;
	}
	public String getId() {
		return this.id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getDescServizio() {
		return this.descServizio;
	}
	public void setDescServizio(String descServizio) {
		this.descServizio = descServizio;
	}
	public String getIntestazione() {
		return this.intestazione;
	}
	public void setIntestazione(String intestazione) {
		this.intestazione = intestazione;
	}
	public String getDescDivisa() {
		return this.descDivisa;
	}
	public void setDescDivisa(String descDivisa) {
		this.descDivisa = descDivisa;
	}
	public String getProductMasked() {
		return this.productMasked;
	}
	public void setProductMasked(String productMasked) {
		this.productMasked = productMasked;
	}
	public String getProductAlias() {
		return this.productAlias;
	}
	public void setProductAlias(String productAlias) {
		this.productAlias = productAlias;
	}


}
