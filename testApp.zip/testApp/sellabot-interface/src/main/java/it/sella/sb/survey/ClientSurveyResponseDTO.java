package it.sella.sb.survey;

public class ClientSurveyResponseDTO {
	
	private SurveyDTO client;

	public SurveyDTO getClient() {
		return client;
	}

	public void setClient(SurveyDTO client) {
		this.client = client;
	}
	
}
