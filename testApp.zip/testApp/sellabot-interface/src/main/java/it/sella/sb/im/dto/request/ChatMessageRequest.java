package it.sella.sb.im.dto.request;

public class ChatMessageRequest extends ChatRequest {

	private String message;

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

}
