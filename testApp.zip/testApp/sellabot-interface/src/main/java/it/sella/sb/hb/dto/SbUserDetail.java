package it.sella.sb.hb.dto;

import java.util.ArrayList;
import java.util.List;

import it.sella.sb.anagrafe.dto.PersonalDetails;
import it.sella.sb.im.dto.request.Alias;
import it.sella.sb.util.SBCONSTANT;

public class SbUserDetail {

	private PersonalDetails personalDet;
	private List<Alias> alias;
	private String chatid;
	private String lang="it";
	private Bank bank;
	private FederationInformation federationInformation;
	private String uuId;
	private String overTime;
	private String logTime;
	private String bancaId;
	private String channelId;
	private String userAgent;
	private String ipAddress;
	private Boolean isAnonymous=Boolean.TRUE;
	private String categoria;
	private String appName;
	private Boolean blockAllIntents=Boolean.FALSE;
	private List<String> blockParticularIntent = new ArrayList<>();
	
	//algho integration
	private Boolean useAlgho=Boolean.FALSE;
	private String context;
	private String alghoUserId;
	private Long alghoConversationId;
	private String openerOrigin;
	private String openerHref;

	public List<Alias> getAlias() {
		return this.alias;
	}
	public void setAlias(List<Alias> alias) {
		this.alias = alias;
	}
	public String getUserId() {
		return this.federationInformation != null ? this.federationInformation.getUserCode() : SBCONSTANT.ANONYMOUS.VALUE;
	}
	public String getChatid() {
		return this.chatid;
	}
	public void setChatid(String chatid) {
		this.chatid = chatid;
	}
	public String getLang() {
		return this.lang;
	}
	public void setLang(String lang) {
		this.lang = lang;
	}
	public Bank getBank() {
		return bank;
	}
	public void setBank(Bank bank) {
		this.bank = bank;
	}
	public FederationInformation getFederationInformation() {
		return federationInformation;
	}
	public void setFederationInformation(FederationInformation federationInformation) {
		this.federationInformation = federationInformation;
	}
	public Long getIdSogg() {
		//FIXME
		return this.federationInformation != null ? this.federationInformation.getIdSoggetto() : 0L;
	}
	public PersonalDetails getPersonalDet() {
		return personalDet;
	}
	public void setPersonalDet(PersonalDetails personalDet) {
		this.personalDet = personalDet;
	}
	public String getUuId() {
		return uuId;
	}
	public void setUuId(String uuId) {
		this.uuId = uuId;
	}
	public String getOverTime() {
		return overTime;
	}
	public void setOverTime(String overTime) {
		this.overTime = overTime;
	}
	public String getLogTime() {
		return logTime;
	}
	public void setLogTime(String logTime) {
		this.logTime = logTime;
	}
	public String getBancaId() {
		return bancaId;
	}
	public void setBancaId(String bancaId) {
		this.bancaId = bancaId;
	}
	public String getChannelId() {
		return channelId;
	}
	public void setChannelId(String channelId) {
		this.channelId = channelId;
	}
	public String getUserAgent() {
		return userAgent;
	}
	public void setUserAgent(String userAgent) {
		this.userAgent = userAgent;
	}
	public String getIpAddress() {
		return ipAddress;
	}
	public void setIpAddress(String ipAddress) {
		this.ipAddress = ipAddress;
	}
	public Boolean getIsAnonymous() {
		return isAnonymous;
	}
	public void setIsAnonymous(Boolean isAnonymous) {
		this.isAnonymous = isAnonymous;
	}
	public String getCategoria() {
		return categoria;
	}
	public void setCategoria(String categoria) {
		this.categoria = categoria;
	}
	public String getAppName() {
		return appName;
	}
	public void setAppName(String appName) {
		this.appName = appName;
	}
	public Boolean getBlockAllIntents() {
		return blockAllIntents;
	}
	public void setBlockAllIntents(Boolean blockAllIntents) {
		this.blockAllIntents = blockAllIntents;
	}
	public List<String> getBlockParticularIntent() {
		return blockParticularIntent;
	}
	public void setBlockParticularIntent(List<String> blockParticularIntent) {
		this.blockParticularIntent = blockParticularIntent;
	}
	public Boolean getUseAlgho() {
		return useAlgho;
	}
	public void setUseAlgho(Boolean useAlgho) {
		this.useAlgho = useAlgho;
	}
	public String getContext() {
		return context;
	}
	public void setContext(String context) {
		this.context = context;
	}
	public String getAlghoUserId() {
		return alghoUserId;
	}
	public void setAlghoUserId(String alghoUserId) {
		this.alghoUserId = alghoUserId;
	}
	public Long getAlghoConversationId() {
		return alghoConversationId;
	}
	public void setAlghoConversationId(Long alghoConversationId) {
		this.alghoConversationId = alghoConversationId;
	}
	public String getOpenerOrigin() {
		return openerOrigin;
	}
	public void setOpenerOrigin(String openerOrigin) {
		this.openerOrigin = openerOrigin;
	}
	public String getOpenerHref() {
		return openerHref;
	}
	public void setOpenerHref(String openerHref) {
		this.openerHref = openerHref;
	}
}
