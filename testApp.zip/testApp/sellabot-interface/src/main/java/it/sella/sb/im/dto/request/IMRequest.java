package it.sella.sb.im.dto.request;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class IMRequest extends AbstractRequest{

	private List<Map<String, String>> eventdata;


	public List<Map<String, String>> getEventdata() {
		if(this.eventdata == null){
			this.eventdata = new ArrayList<Map<String, String>>();
		}
		return this.eventdata;
	}

	public void setEventdata(List<Map<String, String>> eventdata) {
		this.eventdata = eventdata;
	}
	
	@Override
	public String toString() {
		final StringBuilder builder = new StringBuilder();
		builder.append("$eventId-->").append(this.getIdevent()).append("$chatId-->").append(this.getChatid()).append("$action-->")
		.append(this.getAction()).append("$sourceIntentCode-->").append(this.getSourceIntentCode());
		if(this.getParameters() != null && !this.getParameters().isEmpty()) {
			builder.append("$parameters-->");
			for (Parameter param : this.getParameters()) {
				builder.append(" Name : ").append(param.getName()).append(" Value : ").append(param.getValue());
			}
		}
		if(eventdata != null && !eventdata.isEmpty()) {
			builder.append(" $eventdata --> ").append(eventdata);
		}
		//		builder.
		//String.format("EventId=%s,ChatId=%s,Action=%s,Eventdata=%s,=%s,=%s,{to=%s, body=%s}", getTo(), getBody());
		return builder.toString();
	}
	
}
