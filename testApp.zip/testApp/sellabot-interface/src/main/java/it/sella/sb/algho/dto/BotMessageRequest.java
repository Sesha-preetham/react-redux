package it.sella.sb.algho.dto;

import it.sella.sb.util.SBCONSTANT;

public class BotMessageRequest {
	
	private String system = SBCONSTANT.ALGHO.VALUE;
	private String type;
	private String message;
	private Long timestamp;
	
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public Long getTimestamp() {
		return timestamp;
	}
	public void setTimestamp(Long timestamp) {
		this.timestamp = timestamp;
	}

}
