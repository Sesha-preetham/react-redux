package it.sella.sb.survey;

public class SurveyRequestDTO {

	private String type;
	private Long surveyId;
	private Long quesId;
	
	private AnswerDTO answer;
	
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public Long getSurveyId() {
		return surveyId;
	}
	public void setSurveyId(Long surveyId) {
		this.surveyId = surveyId;
	}
	public Long getQuesId() {
		return quesId;
	}
	public void setQuesId(Long quesId) {
		this.quesId = quesId;
	}
	public AnswerDTO getAnswer() {
		return answer;
	}
	public void setAnswer(AnswerDTO answer) {
		this.answer = answer;
	}
	
	
}
