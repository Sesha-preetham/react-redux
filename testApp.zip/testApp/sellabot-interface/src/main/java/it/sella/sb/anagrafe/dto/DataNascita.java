/**
 * 
 */
package it.sella.sb.anagrafe.dto;

import java.io.Serializable;

/**
 * @author con663
 *
 */
@SuppressWarnings("serial")
public class DataNascita implements Serializable{
	private String dataNascita;
	private String cittaNascitaCodice;
	private String cittaNascita;
	private String nazioneNascitaCodice;
	private String nazioneNascita;
	private String nazionalita;
	private String intststring;
	private String provinciaNascita;	
	public String getDataNascita() {
		return dataNascita;
	}
	public void setDataNascita(String dataNascita) {
		this.dataNascita = dataNascita;
	}
	public String getCittaNascitaCodice() {
		return cittaNascitaCodice;
	}
	public void setCittaNascitaCodice(String cittaNascitaCodice) {
		this.cittaNascitaCodice = cittaNascitaCodice;
	}
	public String getCittaNascita() {
		return cittaNascita;
	}
	public void setCittaNascita(String cittaNascita) {
		this.cittaNascita = cittaNascita;
	}
	public String getNazioneNascitaCodice() {
		return nazioneNascitaCodice;
	}
	public void setNazioneNascitaCodice(String nazioneNascitaCodice) {
		this.nazioneNascitaCodice = nazioneNascitaCodice;
	}
	public String getNazioneNascita() {
		return nazioneNascita;
	}
	public void setNazioneNascita(String nazioneNascita) {
		this.nazioneNascita = nazioneNascita;
	}
	public String getNazionalita() {
		return nazionalita;
	}
	public void setNazionalita(String nazionalita) {
		this.nazionalita = nazionalita;
	}
	public String getIntststring() {
		return intststring;
	}
	public void setIntststring(String intststring) {
		this.intststring = intststring;
	}
	public String getProvinciaNascita() {
		return provinciaNascita;
	}
	public void setProvinciaNascita(String provinciaNascita) {
		this.provinciaNascita = provinciaNascita;
	}
	@Override
	public String toString() {
		return "DataNascita [dataNascita=" + dataNascita + ", cittaNascitaCodice=" + cittaNascitaCodice
				+ ", cittaNascita=" + cittaNascita + ", nazioneNascitaCodice=" + nazioneNascitaCodice
				+ ", nazioneNascita=" + nazioneNascita + ", nazionalita=" + nazionalita + ", intststring=" + intststring
				+ ", provinciaNascita=" + provinciaNascita + "]";
	}
}
