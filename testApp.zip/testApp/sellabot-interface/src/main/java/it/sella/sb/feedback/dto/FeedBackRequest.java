package it.sella.sb.feedback.dto;

import java.io.Serializable;
import java.util.List;

@SuppressWarnings("serial")
public class FeedBackRequest implements Serializable {

	private List<Answer> answers;

	public List<Answer> getAnswers() {
		return answers;
	}

	public void setAnswers(List<Answer> answers) {
		this.answers = answers;
	}


	
}
