package it.sella.sb.anagrafe.dto;

public class MessageDetails {

	private String mId;
	private String mTitle;
	private String mMessage;
	private String mMessageShort;
	private String mPosition;
	private String mMakeSections;
	
	public String getmId() {
		return mId;
	}
	public void setmId(String mId) {
		this.mId = mId;
	}
	public String getmTitle() {
		return mTitle;
	}
	public void setmTitle(String mTitle) {
		this.mTitle = mTitle;
	}
	public String getmMessage() {
		return mMessage;
	}
	public void setmMessage(String mMessage) {
		this.mMessage = mMessage;
	}
	public String getmMessageShort() {
		return mMessageShort;
	}
	public void setmMessageShort(String mMessageShort) {
		this.mMessageShort = mMessageShort;
	}
	public String getmPosition() {
		return mPosition;
	}
	public void setmPosition(String mPosition) {
		this.mPosition = mPosition;
	}
	public String getmMakeSections() {
		return mMakeSections;
	}
	public void setmMakeSections(String mMakeSections) {
		this.mMakeSections = mMakeSections;
	}
	@Override
	public String toString() {
		return "MessageDetails [mId=" + mId + ", mTitle=" + mTitle + ", mMessage=" + mMessage + ", mMessageShort="
				+ mMessageShort + ", mPosition=" + mPosition + ", mMakeSections=" + mMakeSections + "]";
	}
	
}
