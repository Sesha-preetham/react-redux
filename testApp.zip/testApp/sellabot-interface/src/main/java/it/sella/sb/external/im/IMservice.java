package it.sella.sb.external.im;

import it.sella.sb.im.dto.request.IMRequest;
import it.sella.sb.im.dto.response.IMResponse;


public interface IMservice {

	public IMResponse message(IMRequest imRequest);
}
