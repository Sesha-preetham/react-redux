package it.sella.sb.datasource;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.support.SQLErrorCodeSQLExceptionTranslator;
import org.springframework.transaction.PlatformTransactionManager;

public interface ISBDataSource {

	public void setDataSource(final  javax.sql.DataSource dataSource);
	public void setErrorCodeSQLExceptionTranslator(final SQLErrorCodeSQLExceptionTranslator errorCodeSQLExceptionTranslator);
	public void setTransactionManager(final PlatformTransactionManager transactionManager);
	public JdbcTemplate getJdbcTemplate();
	
}
