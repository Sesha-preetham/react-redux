package it.sella.sb.im.dto.request;


public class ChatRequest {

	private String sourceIntentCode;

	protected String getSourceIntentCode() {
		return sourceIntentCode;
	}

	protected void setSourceIntentCode(String sourceIntentCode) {
		this.sourceIntentCode = sourceIntentCode;
	}

	

}
