package it.sella.sb.survey;

import java.beans.BeanInfo;
import java.beans.Introspector;
import java.beans.PropertyDescriptor;
import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.junit.Assert;
import org.junit.Before;

import it.sella.util.Log4Debug;
import it.sella.util.Log4DebugFactory;

public abstract class AbstractPojoTester {
	private static final Log4Debug log4Debug = Log4DebugFactory.getLog4Debug(AbstractPojoTester.class);

	private final Map<Class<?>, Object> testValues = new HashMap<Class<?>, Object>();

	private final Map<Class<?>, Object> classValues = new HashMap<Class<?>, Object>();
	
	protected void addTestValue(final Class<?> propertyType, final Object testValue) {
		testValues.put(propertyType, testValue);
	}

	protected void addClassValues(final Class<?> propertyType, final Object testValue) {
		classValues.put(propertyType, testValue);
	}

	@SuppressWarnings("rawtypes")
	@Before
	public void setUpTestValues() throws Exception {
		addTestValue(String.class, "TEST STRING");
		addTestValue(int.class, 123);
		addTestValue(Integer.class, 123);
		addTestValue(double.class, 123.0);
		addTestValue(Double.class, 123.0);
		addTestValue(long.class, 1234L);
		addTestValue(Long.class, 1234L);
		addTestValue(boolean.class, true);
		addTestValue(Boolean.class, true);
		addTestValue(java.util.Date.class, new Date());
		addTestValue(java.math.BigInteger.class, new BigInteger("123"));
		addTestValue(java.util.ArrayList.class, new ArrayList());
		addTestValue(java.util.List.class, new ArrayList());
		addTestValue(java.util.Map.class, new HashMap());
		addTestValue(Object.class, new Object());
		addClassValues(String.class, "TEST Excep");
		addClassValues(Throwable.class, new Throwable());
		addClassValues(Object.class, new Object());

	}
	
	private void testPropertyOnlyRead(final Object pojo, final PropertyDescriptor propertyDescriptor) {
		try {
			final Method readMethod = propertyDescriptor.getReadMethod();
			if (readMethod != null) {
				readMethod.invoke(pojo);
			}
		} catch (final Exception e) {
			log4Debug.debug("testProperty >> ", e.getMessage());
		}
	}

	protected void testException(final Class<?> clazz) {
		try {
			final Constructor<?>[] allConstructors = clazz.getDeclaredConstructors();
			Object obj = null;
			for (final Constructor<?> ctor : allConstructors) {
				final Class<?>[] pType = ctor.getParameterTypes();
				if (pType.length == 0) {
					obj = ctor.newInstance();
				} else if (pType.length == 1) {
					obj = ctor.newInstance(classValues.get(pType[0].getName()));
				} else if (pType.length == 2) {
					obj = ctor.newInstance(classValues.get(pType[0].getName()), classValues.get(pType[1].getName()));
				} else if (pType.length == 3) {
					obj = ctor.newInstance(classValues.get(pType[0].getName()), classValues.get(pType[1].getName()), classValues.get(pType[2].getName()));
				}

			}
			if (obj != null) {
				obj.toString();
				final BeanInfo pojoInfo = Introspector.getBeanInfo(clazz);
				for (final PropertyDescriptor propertyDescriptor : pojoInfo.getPropertyDescriptors()) {
					testPropertyOnlyRead(obj, propertyDescriptor);
				}
			}

		} catch (final Exception e) {
			log4Debug.debug("testException >> ", e.getMessage()," >> Class >>", clazz);
		}
	}
	
	protected void testPojo(final Class<?> pojoClass, final String... methodNames) {
		try {
			if(pojoClass.isEnum()) {
				testEnum(pojoClass);
				return;
			}
			if (pojoClass.isInterface() ||  pojoClass.isAnnotation()) {
				return;
			}
			testPojo(pojoClass, pojoClass.newInstance(), methodNames);
		} catch (final Exception e) {
			log4Debug.debug("testPojo >> ", e.getMessage(), ">> Class >>", pojoClass.getName());
		}
	}
	
	protected void testPojo(final Class<?> pojoClass, final Object obj, final String... methodNames) {
		try {
			if (pojoClass.isInterface() || pojoClass.isEnum() || pojoClass.isAnnotation()) {
				return;
			}
			obj.toString();
			final BeanInfo pojoInfo = Introspector.getBeanInfo(pojoClass);
			for (final PropertyDescriptor propertyDescriptor : pojoInfo.getPropertyDescriptors()) {
				testProperty(obj, propertyDescriptor);
			}
			for (String method : methodNames) {
				testMethod(obj, method, null);
			}
		} catch (final Exception e) {
			log4Debug.debug("testPojo with Obj >> ", e.getMessage(), ">> Class >>", pojoClass.getName());
		}
	}
	
	private void testProperty(final Object obj, final PropertyDescriptor propertyDescriptor) {
		try {
			final Class<?> propertyType = propertyDescriptor.getPropertyType();
			final Object testValue = testValues.get(propertyType);
			final Method writeMethod = propertyDescriptor.getWriteMethod();
			final Method readMethod = propertyDescriptor.getReadMethod();
			if (readMethod != null && writeMethod != null) {
				writeMethod.invoke(obj, testValue);
				readMethod.invoke(obj);
				if (testValue != null) {
					Assert.assertEquals(readMethod.invoke(obj), testValue);
				}
			} else if (writeMethod != null && readMethod == null) {
				writeMethod.invoke(obj, testValue);
				String method = "is" + writeMethod.getName().substring(3);
				Method invoke = findInObject(obj, method, propertyType);
				if (invoke == null) {
					method = "is" + writeMethod.getName().substring(5);
					invoke = findInObject(obj, method, propertyType);
				}
				if (invoke != null) {
					invoke.invoke(obj);
				}
			}

		} catch (final Exception e) {
			log4Debug.debug("testProperty >> ", e.getMessage());
		}
	}

	private void testMethod(Object obj, String method, Class<?> propertyType) {
		try {
			Method invoke = findInObject(obj, method, propertyType);
			if (invoke != null) {
				invoke.invoke(obj);
			}
		} catch (final Exception e) {
			log4Debug.debug("testMethod >> ", e.getMessage());
		}
	}
	
	private Method findInObject(final Object o, final String method, final Class<?> input) {
		final Method[] m = o.getClass().getMethods();
		Method ret = null;
		for (int i = 0; i < m.length; i++) {
			if (m[i].getName().equalsIgnoreCase(method)) {
				final Class<?> cls = m[i].getReturnType();
				if (input ==null) {
					ret = m[i];
				} else if (cls != null && cls.getName().equals(input.getName())) {
					ret = m[i];
				}
			}
		}
		return ret;
	}
	
	protected <T> void testEnum(Class<T> pojoClass) {
		try {
			if (pojoClass.isEnum()) {
				T[] enumConstants = pojoClass.getEnumConstants();
				Method[] methods = pojoClass.getDeclaredMethods();
				if(methods != null && enumConstants.length >1 ) {					
					for (Method method : methods) {
						if (method.getName().startsWith("get")) {
							method.invoke(enumConstants[0]);
						}
					}
				}
			}
		} catch (Exception e) {
			log4Debug.debug("testEnum >> ", e.getMessage(), ">> Class >>", pojoClass.getName());
		}
	}
}
