package it.sella.sb.survey;

import org.junit.Test;

import it.sella.sb.anagrafe.dto.DataNascita;
import it.sella.sb.anagrafe.dto.MessageDetails;
import it.sella.sb.anagrafe.dto.PersonalDetails;
import it.sella.sb.feedback.dto.Answer;
import it.sella.sb.feedback.dto.FeedBackQuestionResponse;
import it.sella.sb.feedback.dto.FeedBackRequest;
import it.sella.sb.feedback.dto.Option;
import it.sella.sb.feedback.dto.Question;
import it.sella.sb.hb.dto.Bank;
import it.sella.sb.hb.dto.Carta;
import it.sella.sb.hb.dto.Conto;
import it.sella.sb.hb.dto.FederationInformation;
import it.sella.sb.hb.dto.HBUserDetail;
import it.sella.sb.hb.dto.SbUserDetail;
import it.sella.sb.im.dto.request.AbstractRequest;
import it.sella.sb.im.dto.request.Alias;
import it.sella.sb.im.dto.request.ChatMessageRequest;
import it.sella.sb.im.dto.request.ChatRequest;
import it.sella.sb.im.dto.request.ChatResult;
import it.sella.sb.im.dto.request.ChatTypingRequest;
import it.sella.sb.im.dto.request.EventData;
import it.sella.sb.im.dto.request.IMRequest;
import it.sella.sb.im.dto.request.Interpretation;
import it.sella.sb.im.dto.request.PagePropsRequest;
import it.sella.sb.im.dto.request.Parameter;
import it.sella.sb.im.dto.response.ChatHistoryResponse;
import it.sella.sb.im.dto.response.IMResponse;
import it.sella.sb.im.dto.response.PagePropsResponse;
import it.sella.sb.im.dto.response.Transcript;
import it.sella.sb.im.response.BaseResponse;
import it.sella.sb.im.response.FEMessage;
import it.sella.sb.poll.dto.IntendDetail;
import it.sella.sb.poll.dto.PollMessage;
import it.sella.sb.poll.dto.PollResponse;
import it.sella.sb.util.SBCONSTANT;
import it.sella.sb.util.SQL;
import it.sella.sb.util.SQL.COLUMN;
import it.sella.sb.util.SQL.QUERY;

public class PojoTestCase extends AbstractPojoTester {

	@Test
	public void testAnswerDTO() {
		testPojo(AnswerDTO.class);
	}

	@Test
	public void testSurveyDTO() {
		testPojo(SurveyDTO.class);
	}
	
	@Test
	public void testAnswerResponseDTO() {
		testPojo(AnswerResponseDTO.class);
	}
	
	@Test
	public void testClientSurveyResponseDTO() {
		testPojo(ClientSurveyResponseDTO.class);
	}
	
	@Test
	public void testQuestionAnswerResponseDTO() {
		testPojo(QuestionAnswerResponseDTO.class);
	}

	@Test
	public void testQuestionDTO() {
		testPojo(QuestionDTO.class);
	}
	
	@Test
	public void testSurveyRequestDTO() {
		testPojo(SurveyRequestDTO.class);
	}
	
	@Test
	public void testSurveyResponseDTO() {
		testPojo(SurveyResponseDTO.class);
	}
	
	@Test
	public void testIntendDetail() {
		testPojo(IntendDetail.class);
	}
	
	@Test
	public void testPollMessage() {
		testPojo(PollMessage.class);
	}
	
	@Test
	public void testPollResponse() {
		testPojo(PollResponse.class);
	}
	
	@Test
	public void testFEMessage() {
		testPojo(FEMessage.class);
	}
	
	@Test
	public void testBaseResponse() {
		testPojo(BaseResponse.class);
	}
	
	@Test
	public void testChatHistoryResponse() {
		testPojo(ChatHistoryResponse.class);
	}
	
	@Test
	public void testIMResponse() {
		testPojo(IMResponse.class);
	}
	
	@Test
	public void testPagePropsResponse() {
		testPojo(PagePropsResponse.class);
	}
	
	@Test
	public void testPagePropsRequest() {
		testPojo(PagePropsRequest.class);
	}
	
	@Test
	public void testTranscript() {
		testPojo(Transcript.class);
	}
	
	@Test
	public void testAbstractRequest() {
		testPojo(AbstractRequest.class);
	}
	
	@Test
	public void testAlias() {
		testPojo(Alias.class);
	}
	
	@Test
	public void testChatMessageRequest() {
		testPojo(ChatMessageRequest.class);
	}
	
	@Test
	public void testChatRequest() {
		testPojo(ChatRequest.class);
	}
	
	@Test
	public void testChatTypingRequest() {
		testPojo(ChatTypingRequest.class);
	}
	
	@Test
	public void testChatResult() {
		testPojo(ChatResult.class);
	}
	
	@Test
	public void testEventData() {
		testPojo(EventData.class);
	}
	
	@Test
	public void testIMRequest() {
		testPojo(IMRequest.class);
	}
	
	@Test
	public void testInterpretation() {
		testPojo(Interpretation.class);
	}
	
	@Test
	public void testParameter() {
		testPojo(Parameter.class);
	}
	
	@Test
	public void testBank() {
		testPojo(Bank.class);
	}
	
	@Test
	public void testCarta() {
		testPojo(Carta.class);
	}
	
	@Test
	public void testConto() {
		testPojo(Conto.class);
	}
	
	@Test
	public void testFederationInformation() {
		testPojo(FederationInformation.class);
	}
	
	@Test
	public void testHBUserDetail() {
		testPojo(HBUserDetail.class);
	}
	
	@Test
	public void testSbUserDetail() {
		testPojo(SbUserDetail.class);
	}
	
	@Test
	public void testAnswer() {
		testPojo(Answer.class);
	}
	
	@Test
	public void testFeedBackQuestionResponse() {
		testPojo(FeedBackQuestionResponse.class);
	}
	
	@Test
	public void testFeedBackRequest() {
		testPojo(FeedBackRequest.class);
	}
	
	@Test
	public void testOption() {
		testPojo(Option.class);
	}
	
	@Test
	public void testQuestion() {
		testPojo(Question.class);
	}
	
	@Test
	public void testDataNascita() {
		testPojo(DataNascita.class);
	}
	
	@Test
	public void testMessageDetails() {
		testPojo(MessageDetails.class);
	}
	
	@Test
	public void testPersonalDetails() {
		testPojo(PersonalDetails.class);
	}
	
	@Test
	public void testSQL() {
		testPojo(SQL.class);
	}
	
	@Test
	public void testPARAMETER() {
		testPojo(SBCONSTANT.PARAMETER.class);
	}
	
	@Test
	public void testACTION() {
		testPojo(SBCONSTANT.ACTION.class);
	}
	
	@Test
	public void testEVENTDATA() {
		testPojo(SBCONSTANT.EVENTDATA.class);
	}
	
	@Test
	public void testQUERY() {
		testPojo(QUERY.class);
	}
	
	@Test
	public void testCOLUMN() {
		testPojo(COLUMN.class);
	}
}
