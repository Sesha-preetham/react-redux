package it.sella.sb.common;

import java.text.ParseException;
import java.util.Date;

import org.junit.Test;

import it.sella.sb.common.exception.SBBaseThrowable;
import it.sella.sb.common.exception.SBCommonException;
import it.sella.sb.common.util.DateUtility;
import it.sella.sb.common.util.StringUtility;

public class PojoTestCase extends AbstractPojoTester {

	@Test
	public void isEmpty() {
		StringUtility.isEmpty("test");
	}
	@Test
	public void isMobileChannel() {
		StringUtility.isMobileChannel("test");
	}
	@Test
	public void isSME() {
		StringUtility.isSME("test");
	}
	@Test
	public void isEmail() {
		StringUtility.isEmail("test");
	}
	@Test
	public void trim() {
		StringUtility.trim("test");
	}
	@Test
	public void testDateUtility() {
		testPojo(DateUtility.class);
	}
	@Test
	public void getDateFromString() throws ParseException {
		DateUtility.getDateFromString("31/12/1998", "dd/MM/yyyy");
	}
	@Test
	public void getStringFromDateForPrinting() {
		DateUtility.getStringFromDateForPrinting(new Date(), "dd/MM/yyyy");
	}
	@Test
	public void getStringFromDate() {
		DateUtility.getStringFromDate(new Date(), "dd/MM/yyyy");
	}
	@Test
	public void testSBBaseThrowable() {
		testPojo(SBBaseThrowable.class);
	}
	@Test
	public void testSBCommonException() {
		testPojo(SBCommonException.class);
	}

}
