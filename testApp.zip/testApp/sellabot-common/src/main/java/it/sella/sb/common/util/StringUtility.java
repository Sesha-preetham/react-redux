package it.sella.sb.common.util;

public class StringUtility {

	public static boolean isEmpty(final String value) {
		return ((value == null) || (value.trim().length() == 0));
	}

	public static boolean isMobileChannel(final String channel) {
		boolean isMobileChannel = false;
		if((channel!=null) && (channel.contains("_ios") || channel.contains("_android")) ) {
			isMobileChannel = true;
		}
		return isMobileChannel;
	}

	public static boolean isSME(final String channel) {
		boolean isSME = false;
		if(channel!=null && channel.contains("SME")) {
			isSME = true;
		}
		return isSME;
	}
	
	public static boolean isEmail(final String channel) {
		boolean isEmail = false;
		if(channel!=null && channel.contains("BSE_EMAIL")) {
			isEmail = true;
		}
		return isEmail;
	}
	
	public static String trim(String value){
		if(value!=null){
	        value = value.trim();		
		}
		
		return value;
	}

}
