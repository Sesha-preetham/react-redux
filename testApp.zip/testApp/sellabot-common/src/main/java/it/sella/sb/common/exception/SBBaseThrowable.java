package it.sella.sb.common.exception;

@SuppressWarnings("serial")
public abstract class SBBaseThrowable extends RuntimeException 
{
	public static final String SB_ERR_9999 = "ERR-9999";
	public static final String SB_GEN_001 = "TECH_ERROR";
	public static final String SB_AUTH_ERROR = "HB_AUTH_ERR";
	public static final String SB_SERVICE_IN_PROGRESS = "SERVICE_IN_EXECUTION_PROGRESS";
	public static final String SB_HTTP_CLIENT_EXP="HB_HTTP_CLIENT_EXP";
	public static final String SB_DATE_PARSE_ERROR = "DATE_PARSE_ERROR";
	public static final String SB_XML_001 = "XML_PARSE_ERROR";
	
	private String code=SB_ERR_9999;
	private String[] params; 
	
	public SBBaseThrowable(String msg, String code)
	{
		super(msg);
		this.code = code!=null?code:SB_ERR_9999;
	}
	
	public SBBaseThrowable(String msg, String code,Throwable t)
	{
		super(msg,t);
		this.code = code!=null?code:SB_ERR_9999;;
	}
	
	public SBBaseThrowable(String msg, String code, String[] params)
	{
		super(msg);
		this.code = code!=null?code:SB_ERR_9999;
		this.params = params;
	}
	
	public SBBaseThrowable(String msg, String code,String[] params,Throwable t)
	{
		super(msg,t);
		this.code = code!=null?code:SB_ERR_9999;
		this.params = params;
	}
	
	public String getCode() {
		return code;
	}
	
	public String[] getParams() {
		return params;
	}
}
