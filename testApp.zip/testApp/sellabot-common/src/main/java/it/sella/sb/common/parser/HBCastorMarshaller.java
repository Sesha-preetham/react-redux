package it.sella.sb.common.parser;

import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.log4j.Logger;
import org.springframework.core.io.ClassPathResource;
import org.springframework.oxm.castor.CastorMappingException;
import org.springframework.oxm.castor.CastorMarshaller;
import org.springframework.stereotype.Component;

@Component
public class HBCastorMarshaller{

	private static final Logger LOGGER = Logger.getLogger(HBCastorMarshaller.class);

	private boolean ignoreExtraAttributes;
	private boolean ignoreExtraElements;
	private Map<String, Class<?>> mappingLocations;
	private Map<Class<?>, CastorMarshaller> marshallers;

	public void afterPropertiesSet(){
		final Iterator<Entry<String, Class<?>>> iterator = mappingLocations.entrySet().iterator();
		marshallers = new HashMap<Class<?>, CastorMarshaller>();
		while(iterator.hasNext()){
			try {
				final Entry<String, Class<?>> entry = iterator.next();
				final CastorMarshaller castorMarshaller = new CastorMarshaller();
				castorMarshaller.setIgnoreExtraAttributes(getIgnoreExtraAttributes());
				castorMarshaller.setIgnoreExtraElements(getIgnoreExtraElements());
				castorMarshaller.setMappingLocation(new ClassPathResource(entry.getKey()));
				marshallers.put(entry.getValue(), castorMarshaller);
				castorMarshaller.afterPropertiesSet();
			} catch (CastorMappingException | IOException e) {
				LOGGER.error("Error creating unMarshaller", e);
			}
		}
	}

	public boolean getIgnoreExtraAttributes() {
		return ignoreExtraAttributes;
	}

	public void setIgnoreExtraAttributes(final boolean ignoreExtraAttributes) {
		this.ignoreExtraAttributes = ignoreExtraAttributes;
	}

	public boolean getIgnoreExtraElements() {
		return ignoreExtraElements;
	}

	public void setIgnoreExtraElements(final boolean ignoreExtraElements) {
		this.ignoreExtraElements = ignoreExtraElements;
	}

	public Map<String, Class<?>> getMappingLocations() {
		return mappingLocations;
	}

	public void setMappingLocations(final Map<String, Class<?>> mappingLocations) {
		this.mappingLocations = mappingLocations;
	}

	public Map<Class<?>, CastorMarshaller> getMarshallers() {
		return marshallers;
	}

	public void setMarshallers(final Map<Class<?>, CastorMarshaller> marshallers) {
		this.marshallers = marshallers;
	}

}
