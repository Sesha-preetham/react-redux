package it.sella.sb.common.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class DateUtility {
	
	public static final String DATE_FORMAT_1 = "dd/MM/yyyy";
	public static final String DATE_FORMAT_2 = "dd-MM-yyyy";
	public static final String DATE_FORMAT_3 = "ddMMyyyy";
	public static final String DATE_FORMAT_4 = "yyyyMMdd";
	public static final String DATE_FORMAT_5 = "yyyy-MM-dd";
	public static final String DATE_TIME_FORMAT_1 = "EEE MMM dd hh:mm:ss z yyyy";
	public static final String DATE_TIME_FORMAT_2 = "yyyy-MM-dd'T'hh:mm:ss";
	public static final String DATE_TIME_FORMAT_3 = "dd/MM/yyyy hh:mm:ss";
	public static final String DATE_TIME_FORMAT_4 = "dd/MM/yyyy hh:mm:ss a";
	public static final String DATE_TIME_FORMAT_5 = "yyyy-MM-dd hh:mm:ss";
	public static final String DATE_TIME_FORMAT_6 = "dd-MM-yyyy hh:mm:ss";
	
	public static Date getDateFromString(final String s, final String format) throws ParseException
	{
		if (s == null || format == null)
		{
			return null;
		}

		final SimpleDateFormat sdf = new SimpleDateFormat(format);
		return sdf.parse(s);
	}
	
	public static String getStringFromDateForPrinting(final Date d, final String format)
	{
		final String ret = getStringFromDate(d,format);
		if (ret == null) {
			return "";
		} else {
			return ret;
		}
	}
	
	public static String getStringFromDate(final Date d, final String format)
	{
		if (d == null || format == null) {
			return null;
		}
		final SimpleDateFormat sdf = new SimpleDateFormat(format);
		return sdf.format(d);
	}

}
