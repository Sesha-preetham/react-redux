package it.sella.sb.common.util;

import org.apache.log4j.Logger;

import com.google.gson.Gson;

import it.sella.sb.common.exception.SBCommonException;

public class JsonUtil {
	private static final Logger LOGGER = Logger.getLogger(JsonUtil.class);
	//	private final static ObjectMapper mapper = new ObjectMapper();
	private final static Gson gson = new Gson();

	public static<T> String convertToString(T t) {
		String value=null;
		value = gson.toJson(t); 
		return value;
	}

	public static<T> T convertToObject(String value, Class<T> t) {
		T object = null;  
		try {
			object =  (T) gson.fromJson(value,t);
		} catch (final Exception e) {
			LOGGER.error("Error Parsing String to Object"+e.getMessage(),e);
			throw new SBCommonException("Error Parsing String to Object"+e.getMessage(), SBCommonException.SB_JSON_PARSE_ERR,e);
		}
		return object;
	}

}
