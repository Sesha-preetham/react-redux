package it.sella.sb.common.exception;


@SuppressWarnings("serial")
public class SBCommonException extends SBBaseThrowable {
	
	public static final String SB_JSON_PARSE_ERR = "JSON_PARSE_ERROR";	
	public static final String SB_CHAT_ID_NOT_FOUND = "SB_CHAT_ID_NOT_FOUND";	
	public static final String SB_CHAT_URL_NOT_FOUND = "SB_CHAT_URL_NOT_FOUND";	
	public static final String SB_CHAT_ID_ALREADY_PRESENT = "SB_CHAT_ID_ALREADY_PRESENT";	
	public static final String SB_NOT_INITIALIZED = "SB_NOT_INITIALIZED";	
	public static final String SB_CHAT_MESSAGE_EMPTY = "SB_CHAT_MESSAGE_EMPTY";
	
	public SBCommonException(String msg,String code) {
		super(msg,code);
	}

	public SBCommonException(String msg,String code, Throwable t) {
		super(msg, code, t);
	}
	
	public SBCommonException(final String msg,final String code,final String[] params) {
		super(msg,code,params);
	}
	

}
