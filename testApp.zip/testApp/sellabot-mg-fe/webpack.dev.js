const { merge } = require("webpack-merge");
const common = require("./webpack.common");
var mock = require("./server/build/express-server-build");

var HTMLWebpackPlugin = require("html-webpack-plugin");
var HTMLWebpackPluginConfig = new HTMLWebpackPlugin({
  template: __dirname + "/app/index.html",
  filename: "index.html",
  inject: "body",
});

module.exports = merge(common, {
  plugins: [HTMLWebpackPluginConfig],
  mode: "development",
  devtool: "inline-source-map",
  devServer: {
    host: "localhost",
    port: 9080,
    open: true,
  },
  module: {
    rules: [
      {
        test: /\.(html)$/,
        use: [
          {
            loader: "html-loader",
          },
        ],
      },
      {
        test: /\.(png|jp(e*)g|svg|gif|woff|woff2|eot|ttf)$/,
        use: [
          {
            loader: "url-loader",
          },
        ],
      },
      {
        test: /\.css$/,
        use: [
          {
            loader: "style-loader",
          },
          {
            loader: "css-loader",
          },
        ],
      },
    ],
  },
});
