var path = require("path");
const { merge } = require("webpack-merge");
const common = require("./webpack.common.js");

const TerserPlugin = require("terser-webpack-plugin");
const MiniCssExtractPlugin = require("mini-css-extract-plugin");
const OptimizeCSSAssetsPlugin = require("optimize-css-assets-webpack-plugin");

module.exports = merge(common, {
  mode: "production",
  output: {
    filename: "bundle.js",
    path: path.resolve("../sellabot-web/src/main/webapp/build/scripts"),
    publicPath: "build/scripts/",
  },
  plugins: [
    new MiniCssExtractPlugin({
      filename: "../styles/styles.css",
    }),
  ],
  optimization: {
    minimize: true,
    minimizer: [
      new TerserPlugin({
        cache: true,
        parallel: true,
        extractComments: false,
        terserOptions: {
          toplevel: true,
          ie8: true,
          warnings: false,
          compress: {
            drop_console: true,
          },
          mangle: true,
          output: {
            comments: false, // remove comments
            ascii_only: true,
          },
        },
      }),
      new OptimizeCSSAssetsPlugin({}),
    ],
    splitChunks: {
      cacheGroups: {
        vendors: {
          chunks: "all",
          filename: "vendor.js",
          test: /node_modules/,
          priority: 20,
        },
        styles: {
          name: "styles",
          test: /\.css$/,
          chunks: "all",
          enforce: true,
        },
      },
    },
  },
  module: {
    rules: [
      {
        test: /\.(png|jp(e*)g|svg|gif|woff|woff2|eot|ttf)$/,
        use: [
          {
            loader: "url-loader",
          },
        ],
      },
      {
        test: /\.css$/,
        use: [
          {
            loader: MiniCssExtractPlugin.loader,
          },
          {
            loader: "css-loader",
          },
        ],
      },
    ],
  },
});
