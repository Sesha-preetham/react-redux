import React from "react";
import TestRenderer from "react-test-renderer";

import CModal from "../../scripts/ChatFE/CommonComponents/CModal";

describe("<Button />", () => {
  it("React Test Renderer", () => {
    const testRenderer = TestRenderer.create(
      <CModal
        configuration={{
          uniqueID: "errorDialog",
          modalShow: true,
        }}
      >
        <p>Test</p>
      </CModal>
    );
    const testInstance = testRenderer.root;
    expect(testInstance.props.configuration.uniqueID).toBe("errorDialog");
    expect(testInstance.props.configuration.modalShow).toBe(true);
    expect(testRenderer.toJSON()).toMatchSnapshot();
  });
});
