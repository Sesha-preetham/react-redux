import React, { useReducer, useEffect, useState } from "react";
import Axios from "axios";
import { chatInitialState, chatReducer } from "./ChatFE/Reducer/ChatReducer";
import { findFinalComponentByKey } from "./ChatFE/Routes/ChatFEComponents";
import { isLocal, beServiceUrls } from "./ChatFE/Client/ClientProperties";

export const ChatFEContext = React.createContext(null);

const App = () => {
  const [mount, setMount] = useState(false);
  const [state, dispatch] = useReducer(chatReducer, chatInitialState);
  const { showQuestion, showErrorCourtesyPage = false } = state;

  useEffect(() => {
    isLocal
      ? Axios.post(beServiceUrls().loadDevEnv, {})
          .then((response) => {
            setMount(true);
          })
          .catch((error) => {
            console.log(error);
          })
      : setMount(true);
  }, []);

  let CurrentChatFEComponent;

  let mainContainer = document.getElementById("chatcontainer");
  let useAlgho = mainContainer.getAttribute("useAlgho");

  if (showErrorCourtesyPage) {
    CurrentChatFEComponent = findFinalComponentByKey(
      "CHAT_ERROR_COURTESY_PAGE"
    );
  } else if (!showQuestion && useAlgho === "true") {
    CurrentChatFEComponent = findFinalComponentByKey("CHAT_ALGHO_MODULE");
  } else if (!showQuestion) {
    CurrentChatFEComponent = findFinalComponentByKey("CHAT_MODULE");
  } else {
    CurrentChatFEComponent = findFinalComponentByKey("QUESTIONNAIRE_MODULE");
  }

  return (
    <ChatFEContext.Provider value={{ state, dispatch }}>
      {mount && <CurrentChatFEComponent />}
    </ChatFEContext.Provider>
  );
};

export default App;
