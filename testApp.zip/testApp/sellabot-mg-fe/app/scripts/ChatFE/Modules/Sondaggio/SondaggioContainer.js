import React, { useContext, useRef, useEffect, useState } from "react";
import { ChatFEContext } from "../../../App";

import Axios from "axios";
import { beServiceUrls } from "../../Client/ClientProperties";
import SondaggioSella from "./SondaggioSella";

const SondaggioContainer = () => {
  let chatFEContext = useContext(ChatFEContext);

  let { questionlist } = chatFEContext.state;

  let submitChatQueries = () => {
    // let request = {
    //   answers: [
    //     {
    //       answerId: $('[name="yesno"]:checked').val(),
    //       answer: "",
    //     },
    //     {
    //       answerId: $('[name="smiley"]:checked').val(),
    //       answer: "",
    //     },
    //     {
    //       answerId: $("#chatTextArea").attr("data-optionId"),
    //       answer: $("#chatTextArea").val(),
    //     },
    //   ],
    // };

    let answers = [];
    questionlist.map((ques) => {
      if (ques.questionType == 1) {
        let answer = {
          answerId: $("#chatTextArea_" + ques.questionId).attr("data-optionId"),
          answer: $("#chatTextArea_" + ques.questionId).val(),
        }
        answers.push(answer);
      } else if (ques.questionType == 2) {
        let answer = {
          answerId:  $('[name=yesno_'+ques.questionId+']:checked').val(),
          answer: "",
        }
        answers.push(answer);
      } else if (ques.questionType == 3) {
        let answer = {
          answerId: $('[name=smiley_'+ques.questionId+']:checked').val(),
          answer: "",
        }
        answers.push(answer);
      }
    });

    let request = { answers: answers };

    Axios.post(beServiceUrls().submitanswer, request)
      .then((response) => {
        $("#first_page").hide();
        $("#poll-privacy-information").hide();
        $("#second_page").show();
      })
      .catch((error) => {
        // console.log(error);
      });
  };

  return (
    <div className="poll-container">
      <SondaggioSella
        questionlist={questionlist}
        submitChatQueries={submitChatQueries}
      />
    </div>
  );
};

export default SondaggioContainer;
