import React from "react";
import { v4 as uuidv4 } from "uuid";

const Simely = (props) => {
  let { ques: question } = props;

  let selectedSmiley = (event) => {
    $(".smiley").removeClass("active");
    $(event.currentTarget).find(".smiley").addClass("active");
  };

  return (
    <div className="poll-content">
      <h3 className="poll-subtitle">{question.questionDesc}</h3>
      <ul className="poll-option">
        {question.options.map((item) => {
          return (
            <li key={uuidv4()}>
              <input
                id={`SMILEY_${item.optionId}`}
                type="radio"
                name={`smiley_${question.questionId}`}
                className="poll-option__radio"
                value={item.optionId}
              />
              <label
                htmlFor={`SMILEY_${item.optionId}`}
                onClick={selectedSmiley}
              >
                <div
                  className={`smiley ${
                    item.optionDesc == "Ottimo"
                      ? "Ottimo"
                      : item.optionDesc == "Buono"
                      ? "Buono"
                      : item.optionDesc == "Sufficiente"
                      ? "Sufficiente"
                      : item.optionDesc == "Scarso"
                      ? "Scarso"
                      : item.optionDesc == "Non adeguato" && "Non_adeguato"
                  }`}
                  alt="smiley"
                />
              </label>

              <label className="poll-option__label">{item.optionDesc}</label>
            </li>
          );
        })}
      </ul>
    </div>
  );
};

export default Simely;
