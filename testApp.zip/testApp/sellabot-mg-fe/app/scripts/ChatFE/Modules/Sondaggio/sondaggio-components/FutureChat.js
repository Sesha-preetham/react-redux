import React from "react";
import { v4 as uuidv4 } from "uuid";

const FutureChat = (props) => {
  let { ques: question } = props;

  return (
    <div>
      <h3 className="poll-subtitle">{question.questionDesc}</h3>
      {question.options.map((item) => {
        return (
          <div key={uuidv4()} className="future_chat">
            <input
              type="radio"
              id={`CHAT_NEEDED_${item.optionId}`}
              name={`yesno_${question.questionId}`}
              value={item.optionId}
            />
            <label htmlFor={`CHAT_NEEDED_${item.optionId}`}>
              {` ${item.optionDesc}`}
            </label>
          </div>
        );
      })}
    </div>
  );
};

export default FutureChat;
