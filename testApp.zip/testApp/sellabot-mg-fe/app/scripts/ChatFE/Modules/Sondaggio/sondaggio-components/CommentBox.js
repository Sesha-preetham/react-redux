import React from "react";

const CommentBox = (props) => {
  let { ques: question } = props;
  let optionId = question.options[0].optionId;
  return (
    <div>
      <h3 className="poll-subtitle">{question.questionDesc}</h3>
      <textarea
        id={`chatTextArea_${question.questionId}`}
        name="1_4_9"
        className="poll-textarea"
        data-optionid={optionId}
      />
    </div>
  );
};

export default CommentBox;
