import React from "react";
import { v4 as uuidv4 } from "uuid";

import Simely from "./sondaggio-components/Simely";
import FutureChat from "./sondaggio-components/FutureChat";
import CommentBox from "./sondaggio-components/CommentBox";

const SondaggioSella = (props) => {
  const { questionlist, submitChatQueries } = props;
  return (
    <>
      <p
        id="poll-privacy-information"
        className="poll-privacy-note poll-hide"
        style={{ display: "block" }}
      >
        <div className="titleCenter">
        Prima di salutarci, ti invitiamo a rispondere a queste brevi domande 
        per permetterci di migliorare costantemente la qualit&agrave; del servizio fornito
        </div>
        <br></br>
      </p>
      <div id="first_page">
        {questionlist.map((question) => {
          return (
            <div key={uuidv4()}>
              {question.questionType == 3 && <Simely ques={question} />}
              {question.questionType == 2 && <FutureChat ques={question} />}
              {question.questionType == 1 && <CommentBox ques={question} />}
            </div>
          );
        })}
        <div className="poll-privacy-note-footer">
        <div className="footerTitle">
        Informativa Privacy ai sensi dell'art. 13 del Regolamento UE 2016/679
        </div>
        <div>
        Ti informiamo che Banca Sella, in qualit&agrave; di Titolare del trattamento, 
        tratter&agrave; i tuoi dati al fine di migliorare i servizi offerti alla propria clientela, 
        nel rispetto della normativa vigente in materia di protezione dei dati personali.
        </div>
        Per maggiori dettagli, ti invitiamo a consultare&nbsp;
        <a href="https://www.sella.it/banca-on-line/privacy/informativa" target="_blank">l'Informativa Privacy</a>&nbsp;
        disponibile sul sito .
        <a href="https://www.sella.it/" target="_blank">www.sella.it</a>&nbsp;
        <br></br>
        </div>
        <button
          type="submit"
          id="submitPoll"
          name="submitPoll"
          className="poll-button"
          onClick={submitChatQueries}
        >
          INVIA
        </button>
      </div>
      <div id="second_page" style={{ display: "none" }}>
        <div className="poll-content">
          <div className="poll-thanks-check">
            <p className="poll-thanks-check-text">
              GRAZIE PER LA COLLABORAZIONE
              <br></br>
              <span>
                {" "}
                La tua opinione &egrave; molto importante per permetterci di
                migliorare la qualit&agrave; del nostro servizio.
              </span>
            </p>
          </div>
        </div>
      </div>
    </>
  );
};

export default SondaggioSella;
