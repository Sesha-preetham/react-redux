import React, { useContext, useEffect } from "react";

import { ChatFEContext } from "../../../App";
import logosellait2x from "../../../../images/logo-sellait@2x.png";
import iconmonstrprinter3240 from "../../../../images/newstyle/iconmonstr-printer-3-240.png";
import closepng from "../../../../images/newstyle/close.png";
import CModal from "../../CommonComponents/CModal";

const ChatHeader = React.forwardRef((props, ref) => {
  let chatFEContext = useContext(ChatFEContext);

  let { dispatch } = chatFEContext;

  const { chuidiHandleClick } = props;

  let { isWebBrowser,closeDialog } = chatFEContext.state;

  let printOutFunc = () => {
    if ($(".chat-panel-body").length > 0) {
      let newWin = window.open("", "Print-Window");
      newWin.document.open();
      newWin.document.write(
        '<html><link rel="stylesheet" type="text/css" href="css/style.css" /></head><body onload="window.print()">'
      );
      newWin.document.write($(".chat-panel-body").html());
      newWin.document.write("</html>");
      newWin.document.close();
      setTimeout(() => {
        newWin.close();
      }, 100);
    }
  };

  let closeDialogFunction = () => {
    dispatch({
      type: "UPDATE_CHAT_STATE",
      payload: { closeDialog: false },
    });
  };

  let chuidiHandleClickFunction = () => {
    dispatch({
        type: "UPDATE_CHAT_STATE",
        payload: { closeDialog: true },
    });
  }

  return (
    <>
    <CModal
        configuration={{
          uniqueID: "closeDialog",
          modalShow: closeDialog,
          modalCloseShow: true,
          events: {
            onClose: closeDialogFunction,
          },
        }}
      >
        <p>
        Sei sicuro di voler chiudere la chat?
        </p>
        <button
          id="js-send-mail"
          className="blue-btn js-modal-close"
          onClick={chuidiHandleClick}
        >
          CONFERMA
        </button>
      </CModal>
      <div className="header-wrap row">
        <div className="chat-icon-left col-sm-6 col-xs-6">
          <img
            src={logosellait2x}
            className="chat-header-logo"
            alt="Logo Sella.it"
          ></img>
        </div>
        <div className="chat-icon-right col-sm-6 col-xs-6 pull-right">
          {isWebBrowser ? (
            <img
              src={iconmonstrprinter3240}
              className="printer-close-icon"
              alt="Logo Sella.it"
              onClick={printOutFunc}
            ></img>
          ) : (
            ""
          )}
          <img
            src={closepng}
            className="printer-close-icon"
            alt="Logo Sella.it"
            onClick={chuidiHandleClickFunction}
          ></img>
        </div>
      </div>
    </>
  );
});

export default ChatHeader;
