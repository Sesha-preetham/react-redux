import Axios from "axios";
import React, { useContext, useEffect, useRef, useState } from "react";
import { ChatFEContext } from "../../../App";
import { beServiceUrls, isMock } from "../../Client/ClientProperties";
import CModal from "../../CommonComponents/CModal";
import ChatHeader from "./ChatHeader";
import ChatInviaInputField from "./ChatInviaInputField";
import ChatMessageArea from "./ChatMessageArea";
import { getHpPageInfo } from "../../Services/ChatService";

const ChatComponent = () => {
  let chatFEContext = useContext(ChatFEContext);

  let { dispatch } = chatFEContext;

  let { chatid, showModal, onlineMessages, messagelist } = chatFEContext.state;

  useEffect(() => {
    let request = (window && window.chatRequest) || {};
    Axios.post(beServiceUrls().syncalias, request)
      .then(() => {
        messageConnect();
      })
      .catch((error) => {});
  }, []);

  useEffect(() => {
    getProperties();
    getUserInfo();
  }, []);

  useEffect(() => {
    let { chatid } = chatFEContext.state;
    console.log("useEffect", chatid);
    clearInterval(window.chatinterval);
    window.chatinterval = undefined;
    if (chatid) {
      window.chatinterval = setInterval(() => {
        messageRefresh();
      }, 1000);
    }
  }, [chatid]);

  let getProperties = () => {
    window.pollDelay = 5000;
    Axios.post(beServiceUrls().properties, {
      code: "FE_PAGE_PROPS",
    })
      .then((response) => {
        if (
          response.data &&
          response.data.props &&
          response.data.props.POLL_DELAY_SEC
        ) {
          window.pollDelay =
            parseInt(response.data.props.POLL_DELAY_SEC) * 1000;
          window.sessionDelay =
            parseInt(response.data.props.SESSION_DELAY_MIN) * 1000;
        }
      })
      .catch((error) => {
        // console.log(error);
      });
  };

  let getUserInfo = () => {
    window.pollDelay = 5000;
    Axios.post(beServiceUrls().info)
      .then((response) => {
        if (response.data) {
          dispatch({
            type: "UPDATE_CHAT_STATE",
            payload: {
              name: response.data.nome,
              sender: response.data.nickName,
              isAnonymous: response.data.isAnonymous,
              isShowButton: response.data.isShowButton,
              categoria: response.data.categoria,
              cognome: response.data.cognome,
              email: response.data.email,
              channelId: response.data.channelId,
              isMobile: response.data.isMobile,
              cnctrToken: response.data.cnctrToken,
              onlineMessages: response.data.onlineMessages,
              isSME:response.data.isSME,
            },
          });
          if (response.data.onlineMessages) {
            dispatch({
              type: "UPDATE_CHAT_STATE",
              payload: {
                showModal: true,
              },
            });
          }
        }
      })
      .catch((error) => {
        // console.log(error);
      });
  };

  let chuidiHandleClick = (chaturl) => {
    let request = {
      action: "endchat",
      sourceIntentCode: getHpPageInfo(),
    };
    Axios.post(beServiceUrls().chat, request)
      .then((response) => {
        let {
          showQuestion,
          redirectAgent,
          doClose,
          close,
        } = chatFEContext.state;
        clearInterval(window.chatinterval);
        if (!showQuestion && !redirectAgent && !doClose) {
          Axios.post(beServiceUrls().questions, request)
            .then((response) => {
              dispatch({
                type: "UPDATE_CHAT_STATE",
                payload: {
                  showQuestion: true,
                  questionlist: response.data.questions,
                },
              });
            })
            .catch((error) => {});
        } else {
          if ((!doClose || close) && (!redirectAgent || close)) {
          } else if (redirectAgent) {
            $(".chat-input-wrap .chat-input,.chat-input-wrap .chat-btn").attr(
              "disabled",
              true
            );
            $(".chat-input-wrap .chat-input").attr(
              "placeholder",
              "Trasferire chat all'agente"
            );
            close = true;
            window.location.replace(chaturl);
          } else if (doClose) {
            $(".chat-input-wrap .chat-input,.chat-input-wrap .chat-btn").attr(
              "disabled",
              true
            );
            $(".chat-input-wrap .chat-input").attr(
              "placeholder",
              "Grazie. Arrivederci.."
            );
            dispatch({
              type: "UPDATE_CHAT_STATE",
              payload: {
                doClose: false,
                close: true,
              },
            });
          } else {
            dispatch({
              type: "UPDATE_CHAT_STATE",
              payload: {
                doClose: false,
              },
            });
          }
        }
      })
      .catch((error) => {
        let { exceptioncount } = chatFEContext.state;
        exceptioncount = exceptioncount + 1;
        if (exceptioncount > 100) {
          clearInterval(window.chatinterval);
        }
      });
  };

  let setlastMessage = (msg) => {
    let { lastMessage } = chatFEContext.state;
    lastMessage = msg;
  };

  let handleException = (data) => {
    clearInterval(window.chatinterval);
    $(".chat-input-wrap .chat-input,.chat-input-wrap .chat-btn").attr(
      "disabled",
      true
    );
    $(".chat-input-wrap .chat-input").val("");
    if (
      data.errorMessageCode &&
      data.errorMessageCode == "IM_CHAT_ID_NOT_FOUND"
    ) {
      if (window.chatSessionInterval) {
        clearInterval(window.chatSessionInterval);
      }
      window.chatSessionInterval = setInterval(() => {
        window.close();
        window.close();
      }, window.sessionDelay);
      $(".chat-input-wrap .chat-btn").text("RIAVVIA CHAT");
      $(".chat-input-wrap .chat-btn").removeAttr("disabled");
      $(".chat-input-wrap .chat-input").attr(
        "placeholder",
        "Vuoi proseguire la conversazione con l'assistente virtuale?"
      );
      $(".chat-input-wrap .chat-btn")
        .removeClass("disabled")
        .addClass("reopen");
    }
    dispatch({
      type: "UPDATE_CHAT_MESSAGE_LIST_ON_REFRESH",
      payload: { data: [] },
    });
  };

  let messageRefresh = (messageText) => {
    let { chatid, operator, agentLogged, exceptioncount } = chatFEContext.state;
    let request = {
      chatid: chatid,
      // FE MOCK ONLY
      mockPoll: isMock ? feMockPoll : undefined,
    };
    if (!isInprogress) {
      isInprogress = true;
      Axios.post(beServiceUrls().poll, request)
        .then((response) => {
          if (response.data && response.data.status == "OK") {
            isInprogress = false;
            let data = response.data.results;
            let message = [];
            if (data.length > 0) {
              for (let i = 0; i < data.length; i++) {
                message[i + 1] = {};
                message[i + 1].message = data[i].message;
                message[i + 1].sentDate = new Date();
                message[i + 1].nickName = data[i].sender;
                message[i + 1].answer = data[i].answer;
                if (data[i].action && data[i].action.toLowerCase() == "close") {
                  dispatch({
                    type: "UPDATE_CHAT_STATE",
                    payload: {
                      doClose: true,
                    },
                  });
                }
                if (
                  data[i].action &&
                  data[i].action.toLowerCase() == "operator"
                ) {
                  if (window.chatSessionInterval) {
                    clearInterval(window.chatSessionInterval);
                  }
                  window.chatSessionInterval = setInterval(() => {
                    window.close();
                    window.close();
                  }, window.sessionDelay);
                  operator = true;
                  $(
                    ".chat-input-wrap .chat-input,.chat-input-wrap .chat-btn"
                  ).attr("disabled", true);
                  $(".chat-input-wrap .chat-input").val("");
                  $(".chat-input-wrap .chat-btn").text("RIAVVIA CHAT");
                  $(".chat-input-wrap .chat-input").attr(
                    "placeholder",
                    "Vuoi proseguire la conversazione con l'assistente virtuale?"
                  );
                  $(".chat-input-wrap .chat-btn").removeAttr("disabled");
                  $(".chat-input-wrap .chat-btn")
                    .removeClass("disabled")
                    .addClass("reopen");
                }

                let isAgent = true;
                if (data[i].sender && data[i].sender != "BOT") {
                  isAgent = false;
                }
                message[i + 1].isAgent = isAgent;
                if (data[i].userJoined != null && data[i].userJoined) {
                  agentLogged = true;
                }
              }
              clearInterval(window.chatinterval);
              window.chatinterval = undefined;
              if (!operator) {
                window.chatinterval = setInterval(() => {
                  messageRefresh();
                }, window.pollDelay);
              }
              dispatch({
                type: "UPDATE_CHAT_MESSAGE_LIST_ON_REFRESH",
                payload: { data },
              });
            } else {
              clearInterval(window.chatinterval);
              window.chatinterval = undefined;
              window.chatinterval = setInterval(() => {
                messageRefresh();
              }, 1000);
            }
          } else {
            handleException(response.data);
          }
        })
        .catch((error) => {
          isInprogress = false;
          exceptioncount = exceptioncount + 1;
          if (exceptioncount > 100) {
            clearInterval(window.chatinterval);
          }
        });
    }
  };

  let messageConnect = () => {
    let request = {
      action: "newchat",
      sourceIntentCode: getHpPageInfo(),
    };
    Axios.post(beServiceUrls().chat, request)
      .then((response) => {
        let operator;
        if (response.data && response.data.status == "OK") {
          if ($(".chat-input-wrap .chat-btn").hasClass("reopen")) {
            $(".chat-input-wrap .chat-btn").text("INVIA");
            $(".chat-input-wrap .chat-input").attr(
              "placeholder",
              "Scrivi il tuo messaggio..."
            );
            $(
              ".chat-input-wrap .chat-btn,.chat-input-wrap .chat-input"
            ).removeAttr("disabled");
            $(
              ".chat-input-wrap .chat-btn,.chat-input-wrap .chat-input"
            ).removeClass("disabled");
            $(".chat-input-wrap .chat-btn").removeClass("reopen");
            dispatch({
              type: "UPDATE_CHAT_STATE",
              payload: {
                operator: false,
              },
            });
          }
          if (response.data.chatid) {
            dispatch({
              type: "UPDATE_CHAT_STATE",
              payload: {
                chatid: response.data.chatid,
              },
            });
          }
          dispatch({
            type: "UPDATE_CHAT_STATE",
            payload: {
              operatorAvail: response.data.overTime || "",
            },
          });
        } else {
          handleException(response.data);
        }
      })
      .catch((error) => {});
  };

  let closeModal = () => {
    dispatch({
      type: "UPDATE_CHAT_STATE",
      payload: {
        showModal: false,
      },
    });
  };

  return (
    <div className="">
      <CModal
        configuration={{
          uniqueID: "showModal",
          modalShow: showModal,
          modalCloseShow: true,
          events: {
            onClose: closeModal,
          },
        }}
      >
        <p>{onlineMessages}</p>
        <button id="closeModal" className="blue-btn" onClick={closeModal}>
          Close
        </button>
      </CModal>
      <ChatHeader chuidiHandleClick={chuidiHandleClick} />
      <div className="chat-body">
        {messagelist && messagelist.length > 0 && (
          <ChatMessageArea
            setlastMessage={setlastMessage}
            chuidiHandleClick={chuidiHandleClick}
          />
        )}
      </div>
      <ChatInviaInputField
        messageConnect={messageConnect}
        handleException={handleException}
      />
    </div>
  );
};

export default ChatComponent;
