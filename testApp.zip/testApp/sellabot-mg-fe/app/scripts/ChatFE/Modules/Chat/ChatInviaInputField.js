import React, { useRef, useContext } from "react";
import Axios from "axios";
import { beServiceUrls } from "../../Client/ClientProperties";
import { ChatFEContext } from "../../../App";
import { getHpPageInfo } from "../../Services/ChatService";

const ChatInviaInputField = (props) => {
  let chatFEContext = useContext(ChatFEContext);
  let messageText = useRef();

  const { handleException, messageConnect } = props;

  let { dispatch } = chatFEContext;

  let messagePush = (messageText) => {
    let { chatid, sender, name } = chatFEContext.state;
    var request = {
      action: "chatevent",
      chatid: chatid,
      idevent: "chatmessage",
      sourceIntentCode: getHpPageInfo(),
      eventdata: [
        {
          name: "message",
          value: messageText,
        },
      ],
    };
    var messagelistArr = [];
    if (messageText) {
      var temp = {};
      temp.message = messageText;
      temp.id = messagelistArr.length + 1;
      temp.sender = sender;
      temp.name = name;
      messagelistArr.push(temp);
    }
    dispatch({
      type: "UPDATE_CHAT_MESSAGE_LIST",
      payload: { messagelist: [...messagelistArr] },
    });
    Axios.post(beServiceUrls().chat, request)
      .then((response) => {
        // if (!this.state.isStarted) {
        //     window.chatinterval = setInterval(function () {
        //         // self.messageRefresh();
        //         this.state.isStarted = true;
        //     }.bind(this), 1000)
        // }
      })
      .catch((error) => {});
  };

  let onTyping = (e) => {
    let { chatid, typingStarted } = chatFEContext.state;
    var request = {
      action: "chatevent",
      chatid: chatid,
      idevent: "chattyping",
      sourceIntentCode: getHpPageInfo(),
      eventdata: [
        {
          name: "typing",
          value: true,
        },
      ],
    };
    if (!typingStarted) {
      typingStarted = true;
      Axios.post(beServiceUrls().chat, request)
        .then((response) => {
          typingStarted = false;
          if (response.data && response.data.status != "OK") {
            handleException(response.data);
          }
        })
        .catch((error) => {});
    }
  };

  let onkeyPress = (e) => {
    if (e.keyCode == 13) {
      messagePush(messageText.current.value);
      messageText.current.value = "";
    } else {
      onTyping(e);
    }
  };

  let doMessagePush = () => {
    if ($(".chat-input-wrap .chat-btn").hasClass("reopen")) {
      clearInterval(window.chatSessionInterval);
      messageConnect();
    } else {
      if (messageText.current.value) {
        messagePush(messageText.current.value);
        messageText.current.value = "";
      }
    }
  };

  return (
    <div className="chat-input-wrap">
      <input
        ref={messageText}
        type="text"
        size="20"
        className="chat-input"
        placeholder="Scrivi il tuo messaggio..."
        onKeyDown={onkeyPress}
      />
      <button className="chat-btn" onClick={doMessagePush}>
        invia
      </button>
    </div>
  );
};

export default ChatInviaInputField;
