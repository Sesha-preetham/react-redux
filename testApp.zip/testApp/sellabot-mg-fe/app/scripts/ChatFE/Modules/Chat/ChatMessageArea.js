import React, { useState, useContext, useEffect, useRef } from "react";
import Axios from "axios";
import { v4 as uuidv4 } from "uuid";

import { beServiceUrls } from "../../Client/ClientProperties";
import { ChatFEContext } from "../../../App";
import icn_logo2x from "../../../../images/newstyle/icn_logo@2x.png";
import outlink2x from "../../../../images/out-link@2x.png";

const ChatMessageArea = (props) => {
  let chatFEContext = useContext(ChatFEContext);

  let [lastmsg, setLastmsg] = useState("");

  const { chuidiHandleClick, setlastMessage } = props;

  let { dispatch } = chatFEContext;

  let {
    name,
    messagelist,
    operatorAvail,
    isMobile,
    isShowButton,
    redirectAgent,
    isSME,
  } = chatFEContext.state;

  useEffect(() => {
    $(".chat-panel-body").animate(
      { scrollTop: $(".chat-panel-body").prop("scrollHeight") },
      500
    );
    setlastMessage(lastmsg);
    onClose();
  });

  // DO OPERATOR REDIRECT
  useEffect(() => {
    let { redirectAgent } = chatFEContext.state;
    if (redirectAgent) {
      getHistory();
    }
  }, [redirectAgent]);

  let getHistory = () => {
    Axios.post(beServiceUrls().history, {})
      .then((response) => {
        let {
          historyStr,
          channelId,
          categoria,
          isAnonymous,
          name,
          cognome,
          email,
          isMobile,
          cnctrToken,
          isSME,
        } = chatFEContext.state;
        historyStr =
          (response.data.history &&
            encodeURIComponent(response.data.history)) ||
          "";
        let chatId = response.data.chatId || "";
        let sessionId = response.data.sessionId || "";
        let chaturl =
          "/AuthenticationDelegatedServlet?delegated_service=219&SEACTION=LOGIN&SECODE=CHAT_IB&SEPARAMS=chatId=" +
          chatId +
          "^CHANNEL=" +
          channelId +
          "^categoria=" +
          categoria;
        //window.location.hostname && (window.location.hostname.indexOf("te.sella.it") != -1 ||)
        if (window.location.hostname.indexOf("172.17.29.47") != -1) {
          chaturl =
            "https://pp.sella.it/AuthenticationDelegatedServlet?delegated_service=219&SEACTION=LOGIN&SECODE=CHAT_IB&SEPARAMS=chatId=" +
            chatId +
            "^CHANNEL=" +
            channelId +
            "^categoria=" +
            categoria;
        }
        if (isAnonymous) {
          chaturl =
            "/Chat/?nome=" +
            name +
            "&cognome=" +
            cognome +
            "&email=" +
            email +
            "&chatId=" +
            chatId +
            "&CHANNEL=" +
            channelId +
            "&categoria=" +
            categoria;
        }

        if (isMobile && !isAnonymous) {
          //chaturl='/sellabot/Redirect.jsp';
          chaturl =
            "/Chat/?chatId=" +
            chatId +
            "&CHANNEL=" +
            channelId +
            "&categoria=" +
            categoria +
            "&redirect=false&cnctrtoken=" +
            cnctrToken;
        }

        chuidiHandleClick(chaturl);
      })
      .catch((error) => {});
  };

  let doOperatorRedirect = () => {
    dispatch({
      type: "UPDATE_CHAT_STATE",
      payload: {
        redirectAgent: true,
      },
    });
    $(".chat-input-wrap .chat-input,.chat-input-wrap .chat-btn").addClass(
      "disabled"
    );
    $(".chat-input-wrap .chat-input,.chat-input-wrap .chat-btn").attr(
      "disabled",
      true
    );
  };

  let doRedirect = (obj) => {
    let intendtCode = (obj && obj.intentCode) || null;
    let url = (obj && obj.url) || (obj && obj.link) || null;

    if (url.indexOf("hbroute") == -1 && url.indexOf("SMEroute")==-1) {
      let redirectURL =
        url.indexOf("http") == -1 ? window.location.origin + "/" + url : url;
      let randomnumber = Math.floor(Math.random() * 100 + 1);
      //   window.opener.open(redirectURL,"_blank",'Redirect',randomnumber);

      window.open(redirectURL);
    } else {
      if (window.opener) {
        let redirectURL = "";
        if(url.indexOf("SMEroute")==-1){
          redirectURL = window.opener.location.href + url;
          if (window.opener.location.href.indexOf("#") != -1) {
            redirectURL = window.opener.location.href.split("#")[0] + "#" + url;
            if (url.indexOf(";") == -1) {
              redirectURL = redirectURL + ";";
            }
          }
        }else{
          let reUrl = url.replace("SMEroute","business");
          redirectURL = window.opener.location.origin + reUrl;
        }
        
        //window.opener.location.href = redirectURL;
        window.opener.location.replace(redirectURL);
      }
    }
  };

  let onClose = () => {
    let { doClose } = chatFEContext.state;

    if (doClose) {
      chuidiHandleClick();
      $(
        ".chat-input-wrap .chat-input,.chat-input-wrap .chat-btn,.chat-input-wrap .input-file-upload"
      ).addClass("disabled");
      $(
        ".chat-input-wrap .chat-input,.chat-input-wrap .chat-btn,.chat-input-wrap .input-file-upload"
      ).attr("disabled", true);
    }
  };

  return (
    <div className="chat-panel-body">
      <div className="chat-messagein">
        <b>{name}</b>
        &nbsp; &egrave; in chat
      </div>
      {messagelist.map((message, index) => {
        if (message.sender == "BOT") {
          let messageString = message.message || message.answer;
          let messageintent = message.intentCode || undefined;
          let messageintentArea = message.intentArea || undefined;
          let linkurl = message.url || message.link || undefined;
          if (!messageString && message.action == "OPERATOR") {
            if (operatorAvail && operatorAvail.toUpperCase() == "FALSE") {
              messageString =
                "Per approfondire la tua richiesta posso metterti in contatto tramite chat con un operatore. Per proseguire seleziona la voce che avvia la chat";
            } else {
              messageString =(isSME ?  "Non sono riuscita a comprendere la richiesta, se lo desideri puoi contattare l’assistenza clienti al numero 0039.0152434650, attivo dal lunedì al venerdì dalle 8 alle 13 e dalle 14,30 alle 18." :
                "Per approfondire la tua richiesta puoi contattare l'assistenza clienti al numero 800.142.142 (per le chiamate da rete fissa nazionale) oppure al numero 0039.015.24.34.617 (per le chiamate dall'estero e da telefono cellulare) attivi dal lunedì al venerdì dalle ore 8.00 alle 21.00");
            }
          }
          if (messageString) {
            lastmsg = message;
          }
          return (
            <div
              key={uuidv4()}
              className={`chat-message chat-message--bank ${
                !messageString ? "emptymessage" : ""
              }`}
            >
              {messageString ? (
                <>
                  <img src={icn_logo2x} className="reply-icon"></img>
                  <p className="chat-message__text" id={`msg_${index}`}>
                    <span
                      className="msgString"
                      // dangerouslySetInnerHTML={{ _html: messageString }}
                    >
                      {messageString}
                    </span>
                  </p>
                </>
              ) : null}
              {!(isMobile && message.url) &&
              !message.link &&
              linkurl &&
              !isShowButton &&
              "BS.AreaInformativa" != messageintentArea &&
              "BS.Professionalita" != messageintentArea &&
              message.action != "OPERATOR" ? 
              (message.action == "CONTINUE" &&
                  !message.link &&
                  "BS.InternetBanking" == messageintentArea ?
                  null
                  : (
                    <div className="botnavigatecontainer">
                      <div className="anonymouslogin">
                        {" "}
                      Per proseguire accedi con i tuoi codici ai servizi online (dall’home page di sella.it o app Sella seleziona “accedi”). Se non hai ancora i codici scegli “Richiedi codici”
                      {" "}
                      </div>
                    </div>
                  )
                ) 
              : (!(isMobile && message.url) && linkurl) ||
                (message.action == "OPERATOR" &&
                  operatorAvail &&
                  operatorAvail.toUpperCase() == "FALSE") ? (
                <div className="botnavigatecontainer">
                  <button
                    className={`${
                      message.action == "OPERATOR"
                        ? "chat-btn bot-navigate-btn operatorcls"
                        : "chat-btn bot-navigate-btn"
                    }`}
                    onClick={
                      message.action == "OPERATOR"
                        ? () => {
                            doOperatorRedirect();
                          }
                        : () => {
                            doRedirect(message);
                          }
                    }
                  >
                    {message.action == "OPERATOR"
                      ? "AVVIA CHAT CON UN OPERATORE"
                      : "vai alla pagina"}
                    {linkurl && linkurl.indexOf("hbroute") == -1 ? (
                      <img
                        className="restore-icon"
                        alt="restore_icon"
                        src={outlink2x}
                      ></img>
                    ) : null}
                  </button>
                </div>
              ) : null}
            </div>
          );
        } else if (message.sender != "BOT") {
          lastmsg = message;
          return (
            <div key={uuidv4()} className="chat-message chat-message--user">
              <span className="chat-message__sender initial">
                {message.sender}
              </span>
              <span className="chat-message__sender name">{message.name}</span>
              <p className="pull-right chat-message__text">
                <span className="msgString">{message.message}</span>
              </p>
            </div>
          );
        }
      })}
      <div className="chat-messagein">
        <b>{name}</b>
        &nbsp; &egrave; uscito dalla chat
      </div>
    </div>
  );
};

export default ChatMessageArea;
