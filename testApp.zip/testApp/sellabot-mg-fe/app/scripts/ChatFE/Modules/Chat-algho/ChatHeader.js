import React, { useContext, useEffect } from "react";

import { ChatFEContext } from "../../../App";
import logosellait2x from "../../../../images/logo-sellait@2x.png";
import iconmonstrprinter3240 from "../../../../images/newstyle/iconmonstr-printer-3-240.png";
import closepng from "../../../../images/newstyle/close.png";
import CModal from "../../CommonComponents/CModal";

const ChatHeader = React.forwardRef((props, ref) => {
  let chatFEContext = useContext(ChatFEContext);

  let { dispatch } = chatFEContext;

  const { handleChiudiChat } = props;

  let {
    isWebBrowser,
    closeDialog,
    showGoToAgentButton = false,
  } = chatFEContext.state;

  let printOutFunc = () => {
    let sr = $("#algho")[0].shadowRoot;
    let srN = $(sr);
    let m  = srN.find('.container-message-display');
     //.childNodes[1].childNodes[12].childNodes[1].childNodes[0].childNodes[2];
    let panelBody = $(m);
    if (panelBody.length > 0) {
      let newWin = window.open("", "Print-Window");
      newWin.document.open();
      newWin.document.write(
        '<html><link rel="stylesheet" type="text/css" href="css/style.css" /></head><body onload="window.print()">'
      );
      newWin.document.write('<style>');
      newWin.document.write('.message-date{text-align: center;} .myself-message{text-align: right; } .other-message{ text-align: left; }');
      newWin.document.write('</style>');

      newWin.document.write(panelBody.html());
      newWin.document.write("</html>");
      newWin.document.close();
      setTimeout(() => {
        newWin.close();
      }, 2000);
    }
  };

  let closeDialogFunction = () => {
    dispatch({
      type: "UPDATE_CHAT_STATE",
      payload: { closeDialog: false },
    });
  };

  let chuidiHandleClickFunction = () => {
    dispatch({
      type: "UPDATE_CHAT_STATE",
      payload: { closeDialog: true },
    });
  };

  const handleStartAgentChat = () => {
    dispatch({
      type: "UPDATE_CHAT_STATE",
      payload: { redirectAgent: true },
    });

  };

  return (
    <>
      <CModal
        configuration={{
          uniqueID: "closeDialog",
          modalShow: closeDialog,
          modalCloseShow: true,
          events: {
            onClose: closeDialogFunction,
          },
        }}
      >
        <p>Sei sicuro di voler chiudere la chat?</p>
        <button
          id="js-send-mail"
          className="blue-btn js-modal-close"
          onClick={handleChiudiChat}
        >
          CONFERMA
        </button>
      </CModal>
      <div className="header-wrap row chat-algho-header">
        <div className="chat-icon-left">
          <img
            src={logosellait2x}
            className="chat-header-logo"
            alt="Logo Sella.it"
          ></img>
        </div>

        <div className="chat-central-container ">
          {showGoToAgentButton && (
            <button
              className="chat-btn  bot-navigate-btn operatorcls chat-agent-btn"
              onClick={handleStartAgentChat}
            >
              AVVIA CHAT CON OPERATORE
            </button>
          )}
        </div>

        <div className="chat-icon-right pull-right">
          {isWebBrowser ? (
            <img
              src={iconmonstrprinter3240}
              className="printer-close-icon"
              alt="Logo Sella.it"
              onClick={printOutFunc}
            ></img>
          ) : (
            ""
          )}
          <img
            src={closepng}
            className="printer-close-icon"
            alt="Logo Sella.it"
            onClick={chuidiHandleClickFunction}
          ></img>
        </div>
      </div>
    </>
  );
});

export default ChatHeader;
