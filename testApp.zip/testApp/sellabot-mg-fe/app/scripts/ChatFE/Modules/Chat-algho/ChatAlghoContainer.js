import React, { useContext, useEffect, useState } from "react";
import CModal from "../../CommonComponents/CModal";
import { ChatFEContext } from "../../../App";
import ChatHeader from "./ChatHeader";
import QuestitContainer from "./QuestitContainer";
import Axios from "axios";
import { beServiceUrls } from "../../Client/ClientProperties";
import GlobalSpinner from "../../CommonComponents/GlobalSpinner";

const ChatAlghoContainer = () => {
  const chatFEContext = useContext(ChatFEContext);

  const { dispatch } = chatFEContext;

  const { showModal, onlineMessages, redirectAgent, isShadowRootAvailable = true, showSpinner = false } = chatFEContext.state;

  const [alghoConfiguration, setAlghoConfiguration] = useState();

  const [mountAlgho, setMountAlgho] = useState(false);



  useEffect(() => {
    if(!isShadowRootAvailable){
      dispatch({
        type: "UPDATE_CHAT_STATE",
        payload: {
          showErrorCourtesyPage: true,
        },
      });
      return;
    }
    getUserInfo();
    syncAlias().then(() => {
      getAlghoConfig();
    });
  }, []);

  const syncAlias = () => {
    let request = (window && window.chatRequest) || {};
    return Axios.post(beServiceUrls().syncalias, request).catch((error) => {});
  };

  const getAlghoConfig = () => {
    Axios.post(beServiceUrls().botconfig).then((response = {}) => {
      if (response.data) {
        const { botConfiguration = {}, configuration = {} } = response.data;
        setAlghoConfiguration({
          botConfiguration,
          configuration,
        });
      }
    });
  };

  useEffect(() => {
    if (alghoConfiguration) {
      const { configuration } = alghoConfiguration;
      const { forceAgentRedirect = "N", overTime } = configuration;
      if (forceAgentRedirect === "Y") {
        if (overTime === "false") {
          dispatch({
            type: "UPDATE_CHAT_STATE",
            payload: {
              redirectAgent: true,
            },
          });
        }else{
          dispatch({
            type: "UPDATE_CHAT_STATE",
            payload: {
              showErrorCourtesyPage: true,
            },
          });
        }
      } else {
        setMountAlgho(true);
        dispatch({
          type: "UPDATE_CHAT_STATE",
          payload: {
            showSpinner: true,
            spinnerId:"GlobalSpinnerId",
          },
        });
      }
    }
  }, [alghoConfiguration]);

  useEffect(() => {
    if (!redirectAgent) return;
    const { chatid } = chatFEContext.state;
    const {
      channelId,
      categoria,
      isAnonymous,
      name,
      cognome,
      email,
      isMobile,
      cnctrToken,
    } = chatFEContext.state;

    let chaturl =
      "/AuthenticationDelegatedServlet?delegated_service=219&SEACTION=LOGIN&SECODE=CHAT_IB&SEPARAMS=chatId=" +
      chatid +
      "^CHANNEL=" +
      channelId +
      "^categoria=" +
      categoria;
    if (isAnonymous) {
      chaturl =
        "/Chat/?nome=" +
        name +
        "&cognome=" +
        cognome +
        "&email=" +
        email +
        "&chatId=" +
        chatid +
        "&CHANNEL=" +
        channelId +
        "&categoria=" +
        categoria;
    }

    if (isMobile && !isAnonymous) {
      //chaturl='/sellabot/Redirect.jsp';
      chaturl =
        "/Chat/?chatId=" +
        chatid +
        "&CHANNEL=" +
        channelId +
        "&categoria=" +
        categoria +
        "&redirect=false&cnctrtoken=" +
        cnctrToken;
    }
    window.location.replace(chaturl);
  }, [redirectAgent]);

  const getUserInfo = () => {
    Axios.post(beServiceUrls().info)
      .then((response) => {
        if (response.data) {
          dispatch({
            type: "UPDATE_CHAT_STATE",
            payload: {
              name: response.data.nome,
              sender: response.data.nickName,
              isAnonymous: response.data.isAnonymous,
              isShowButton: response.data.isShowButton,
              categoria: response.data.categoria,
              cognome: response.data.cognome,
              email: response.data.email,
              channelId: response.data.channelId,
              isMobile: response.data.isMobile,
              cnctrToken: response.data.cnctrToken,
              onlineMessages: response.data.onlineMessages,
              isSME: response.data.isSME,
            },
          });
          if (response.data.onlineMessages) {
            dispatch({
              type: "UPDATE_CHAT_STATE",
              payload: {
                showModal: true,
              },
            });
          }
        }
      })
      .catch((error) => {
        // console.log(error);
      });
  };

  const onCloseOnlineMessagesModal = () => {
    dispatch({
      type: "UPDATE_CHAT_STATE",
      payload: {
        showModal: false,
      },
    });
  };

  const handleChiudiChat = () => {
    const { showQuestion, redirectAgent } = chatFEContext.state;
    if (!showQuestion) {
      Axios.post(beServiceUrls().questions, {})
        .then((response) => {
          dispatch({
            type: "UPDATE_CHAT_STATE",
            payload: {
              showQuestion: true,
              questionlist: response.data.questions,
            },
          });
        })
        .catch((error) => {});
    }
  };

  return (
    <div className="">
      <CModal
        configuration={{
          uniqueID: "showModal",
          modalShow: showModal,
          modalCloseShow: true,
          events: {
            onClose: onCloseOnlineMessagesModal,
          },
        }}
      >
        <p>{onlineMessages}</p>
        <button
          id="closeModal"
          className="blue-btn"
          onClick={onCloseOnlineMessagesModal}
        >
          Chiudi
        </button>
      </CModal>
      <ChatHeader handleChiudiChat={handleChiudiChat} />
      {mountAlgho &&
      <>
       <GlobalSpinner id={"GlobalSpinnerId"} showSpinnerVal={showSpinner} />
      <QuestitContainer configuration={alghoConfiguration} />
      </>
      }
    </div>
  );
};

export default ChatAlghoContainer;
