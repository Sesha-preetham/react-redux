import Axios from "axios";
import React, { useEffect, useContext, useRef } from "react";
import { ChatFEContext } from "../../../App";
import { beServiceUrls } from "../../Client/ClientProperties";

const QuestitContainer = (props = {}) => {
  const { configuration = {} } = props;

  let chatFEContext = useContext(ChatFEContext);

  const { dispatch } = chatFEContext;

  const contextStateRef = useRef(chatFEContext.state);

  let algho;

  const loadAlgho = (configuration) => {
    const { botConfiguration = {}, configuration: internalConfig = {}} = configuration;
    const { botScript = "" } = internalConfig;
    const tag = document.createElement("algho-viewer");
    tag.setAttribute("id", "algho");

    //tag.setAttribute("api-url", "https://www.sella.pre");
    //tag.setAttribute("api-path", "/algho");
    
    tag.setAttribute(
      "theme",
      "bg-color: #fafafa; bg-color-gradient: #fafafa; primary-color: #0033cc; primary-color-text: #0033cc; fg-color: #454545; fg-color-widget: #fff; bg-color-widget: #00cb4d; fg-color-bot: #454545; fg-color-user: #fff; bg-color-user: #009ee8; bg-color-bot: #fff; border-color: #00cb4d; timestamp-color-user: #fff; timestamp-color-bot: #8c8c8c; caption-color: #8c8c8c; fg-button-color: #0033cc; fg-button-color-active: #003ffd; fg-button-color-hover: #003ffd; bg-button-color-hover: #f8f8f8; bg-color-card: #f3f6ff; fg-other-color: #111; bg-other-color: #f3f6ff; border-other-color: #daddea; fg-color-input: #454545; border-color-input: #847f7f; box-shadow: 0px 3px 6px #00000040; text-shadow: 0px 3px 6px #00000040;"
    );
    tag.setAttribute("font", "manrope");
    tag.setAttribute("font-family", "Manrope");

    for (const p in botConfiguration) {
      tag.setAttribute(p, botConfiguration[p]);
    }
    document.getElementById("chat-questit-continer").appendChild(tag);

    const script = document.createElement("script");
    script.setAttribute("id", "algho-viewer-module");
    script.setAttribute("type", "text/javascript");
    script.setAttribute("defer", "defer");
    script.setAttribute(
      "src",
      botScript
    );
    document.getElementById("chat-questit-continer").appendChild(script);

    algho = document.getElementById("algho");
    return refreshListener();
  };

  const refreshListener = () => {
    algho.addEventListener("alghoLoaded", handleAlghoLoaded, false);
    algho.addEventListener("alghoReady", handleAlghoReady, false);
    algho.addEventListener("alghoMessage", handleAlghoMessage, false);
    algho.addEventListener("alghoMicrophone", handleAlghoMicrofone, false);
    algho.addEventListener("alghoShow", handleAlghoShow, false);
    algho.addEventListener("alghoHide", handleAlghoHide, false);
    algho.addEventListener("alghoSendMessage", handleAlghoSendMessage, false);
    algho.addEventListener("alghoRequestOperator", handleAlghoRequestOperator, false);

    return () => {
      algho.removeEventListener("alghoLoaded", handleAlghoLoaded);
      algho.removeEventListener("alghoReady", handleAlghoReady);
      algho.removeEventListener("alghoMessage", handleAlghoMessage);
      algho.removeEventListener("alghoMicrophone", handleAlghoMicrofone);
      algho.removeEventListener("alghoShow", handleAlghoShow);
      algho.removeEventListener("alghoHide", handleAlghoHide);
      algho.removeEventListener("alghoSendMessage", handleAlghoSendMessage);
      algho.removeEventListener("alghoRequestOperator", handleAlghoRequestOperator, false);

    } 
  }

  useEffect(() => {
    contextStateRef.current=chatFEContext.state;
  }, [chatFEContext.state]);

  const documentHeight = () => {
    let timeoutId = setTimeout(() => {
      const doc = document.documentElement;
      doc.style.setProperty('--doc-height', `${window.innerHeight}px`)
     }, 200);
   }
   

  useEffect(() => {
    window.addEventListener('resize', documentHeight)
    documentHeight()
    loadAlgho(configuration);
  }, []);

  const handleAlghoRequestOperator = (event) => {
    console.log("handleAlghoRequestOperator", event);
    dispatch({
      type: "UPDATE_CHAT_STATE",
      payload: {
        redirectAgent: true,
      },
    });
  }

  const handleAlghoLoaded = (event) => {
    console.log("handleAlghoLoaded", event);
  };

  const handleAlghoMessage = (event = {}) => {
    const { detail = {} } = event;
    console.log("handleAlghoMessage", detail);
    Axios.post(beServiceUrls().botmessage, {
      type: "ALGHO_MESSAGE",
      message: JSON.stringify(detail),
      timestamp: new Date().getTime()
    });
  };

  const handleAlghoReady = (event) => {
    console.log("handleAlghoReady", event);
    dispatch({
      type: "UPDATE_CHAT_STATE",
      payload: {
        spinnerId:"GlobalSpinnerId",
        showSpinner: false,
      },
    });
  };

  const handleAlghoMicrofone = (status) => {
    console.log("handleAlghoMicrofone", status);
  };

  const handleAlghoShow = (event) => {
    console.log("handleAlghoShow", event);
  };

  const handleAlghoHide = (event) => {
    console.log("handleAlghoHide", event);
  };

  const handleAlghoSendMessage = (event = {}) => {
    const { configuration: internalConfig = {}} = configuration;
    const { useAlghoRequestOperatorEvent = "N" } = internalConfig;
    const { detail = {} } = event;
    const { chatid } = contextStateRef.current;
    console.log("handleAlghoSendMessage", detail, chatFEContext.state, chatid);
    const { requestOperator = false, conversationId, botId } = detail;
    if (!chatid) {
      dispatch({
        type: "UPDATE_CHAT_STATE",
        payload: {
          chatid: conversationId
        },
      })
      Axios.post(beServiceUrls().botstart, {
        botId: botId,
        conversationId: conversationId,
        openerOrigin: (window.opener) ? window.opener.location.origin: null,
        openerHref: (window.opener) ? window.opener.location.href: null
      }).then(() => {
        Axios.post(beServiceUrls().botmessage, {
          type: "ALGHO_SEND_MESSAGE",
          message: JSON.stringify(detail),
          timestamp: new Date().getTime()
        });
      }).catch((err) => {
          //console.err(err)
        });
    }else{
      Axios.post(beServiceUrls().botmessage, {
        type: "ALGHO_SEND_MESSAGE",
        message: JSON.stringify(detail),
        timestamp: new Date().getTime()
      });
    }
    if (requestOperator && useAlghoRequestOperatorEvent === "N") {
      dispatch({
        type: "UPDATE_CHAT_STATE",
        payload: {
          redirectAgent: true,
        },
      });
      /*dispatch({
        type: "UPDATE_CHAT_STATE",
        payload: {
          showGoToAgentButton: true,
        },
      });*/
    }
  };

  return (
    <div
      id="chat-questit-continer"
    ></div>
  );
};

export default QuestitContainer;
