import React, { useContext } from "react";
import { ChatFEContext } from "../../../App";

const ErrorCourtesyPage = () => {
  const chatFEContext = useContext(ChatFEContext);

  const { isShadowRootAvailable = true } = chatFEContext.state;

  return (
    <div className="error-courtesy-page-container">
      <div id="error-courtesy-page">
        <div className="error-courtesy-page-content">
          <div className="error-courtesy-page-check">
            <div className="error-courtesy-page-check-image" />
            {!isShadowRootAvailable ? (
              <p className="error-courtesy-page-check-text">
                Il servizio di assistenza via chat è disponibile sui browser Google Chrome, Safari o Microsoft Edge. In alternativa siamo a disposizione al numero verde 800.142.142 (da fisso) o al numero +39 015.2434617 da mobile e dall'estero, dalle ore 8 alle 21, dal lunedì al venerdì.
              </p>
            ) : (
              <p className="error-courtesy-page-check-text">
                Il servizio di assistenza via chat al momento non è disponibile.
                <br />
                <br />
                <span>
                  {" "}
                  Per richiedere il <b>blocco delle carte</b> o dei{" "}
                  <b>codici di accesso ai servizi online</b> chiama l’
                  <b>800.66.33.99</b> (da cellulare/estero +39 015.24.34.614).{" "}
                  <br />
                  Ci scusiamo per il disagio.
                </span>
              </p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default ErrorCourtesyPage;
