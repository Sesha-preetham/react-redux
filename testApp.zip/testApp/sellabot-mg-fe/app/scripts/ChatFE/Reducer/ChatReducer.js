window.isInprogress = false;

export const chatInitialState = {
  interval: "",
  messagelist: [],
  chatid: null,
  isStarted: false,
  doClose: false,
  redirectAgent: false,
  questionlist: [],
  showQuestion: false,
  historyStr: "",
  close: false,
  //isInprogress: false,
  isComplete: false,
  sender: "",
  name: "",
  operatorAvail: null,
  typingStarted: false,
  lastMessage: null,
  operator: false,
  isAnonymous: false,
  categoria: null,
  isShowButton: false,
  cognome: null,
  email: null,
  channelId: null,
  isMobile: false,
  isSME: false,
  exceptioncount: 0,
  onlineMessages: "",
  showModal: false,
  spinnerId:"",
  showSpinner:false,
  closeDialog: false,
  showErrorCourtesyPage: false,
  isWebBrowser:
    navigator.userAgent.toLowerCase().indexOf("mobi") < 0 &&
    navigator.userAgent.toLowerCase().indexOf("android") < 0,
  isIE: window.document.documentMode?true:false,
  isShadowRootAvailable: (document.head.attachShadow || document.head.createShadowRoot)?true:false
};

export const chatReducer = (state, action) => {
  switch (action.type) {
    case "UPDATE_CHAT_STATE":
      console.log("UPDATE_CHAT_STATE");
      console.log("prevState", state);
      console.log("currentState", action.payload);
      return {
        ...state,
        ...action.payload,
      };
    case "UPDATE_CHAT_MESSAGE_LIST":
      console.log("UPDATE_CHAT_MESSAGE_LIST");
      console.log("prevState", state.messagelist);
      console.log("currentState", action.payload);
      return {
        ...state,
        messagelist: [...state.messagelist, ...action.payload.messagelist],
        // messagelist: [...action.payload.messagelist],
      };
    case "UPDATE_CHAT_MESSAGE_LIST_ON_REFRESH":
      console.log("UPDATE_CHAT_MESSAGE_LIST_ON_REFRESH");
      console.log("prevState", state.messagelist);
      console.log("currentState", action.payload);

      return {
        ...state,
        messagelist: [...state.messagelist, ...action.payload.data],
      };
    case "UPDATE_CHAT_MESSAGE_LIST_ON_EXCEPTION":
      console.log("UPDATE_CHAT_MESSAGE_LIST_ON_EXCEPTION");
      console.log("prevState", state.messagelist);
      console.log("currentState", action.payload);

      let list = [...state.messagelist];
      let msg = state.lastMessage;

      if (!msg || msg.action != "OPERATOR") {
        var i = list.length;
        var message = {};
        message.action = "OPERATOR";
        message.sender = "BOT";
        return {
          ...state,
          messagelist: [...list.concat(message)],
        };
      }
    case "RESET_CHAT":
      return chatInitialState;
    default:
      return state;
  }
};
