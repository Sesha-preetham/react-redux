const InitUrls = {
  loadDevEnv:
    "/sellabot/chatinit?CHANNEL=Sella_sito_free&nome=Shenba&cognome=P&email=shenba%40test.com&categoria=CHAT_WebSella_CF",

  // SELLA BOT URLs
  info: "/sellabot/execute/user/info",
  properties: "/sellabot/execute/page/properties",
  chat: "/sellabot/execute/user/chat",
  poll: "/sellabot/execute/user/poll",
  syncalias: "/sellabot/execute/user/syncalias",
  history: "/sellabot/execute/user/chat/history",
  questions: "/sellabot/execute/feedback/questions",
  submitanswer: "/sellabot/execute/feedback/insert",

  //for algho integration
  botconfig: "/sellabot/execute/bot/config",
  botstart: "/sellabot/execute/bot/start",
  botmessage: "/sellabot/execute/bot/message",
};

export default InitUrls;
