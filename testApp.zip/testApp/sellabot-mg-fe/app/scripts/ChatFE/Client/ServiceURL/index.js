import InitUrls from "./InitUrl";

const concatUrlBaseWithRestUrls = (urlBase, urlsObject) => {
  let immutableUrlsObject = { ...urlsObject };
  for (let url in immutableUrlsObject) {
    immutableUrlsObject[url] = urlBase + immutableUrlsObject[url];
  }
  return immutableUrlsObject;
};

const BEUrls = (urlBase) => {
  const urlsListObject = {
    ...InitUrls,
  };

  return {
    ...concatUrlBaseWithRestUrls(urlBase, urlsListObject),
  };
};

export default BEUrls;
