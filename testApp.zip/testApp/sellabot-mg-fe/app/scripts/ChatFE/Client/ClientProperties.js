import BEUrls from "./ServiceURL/index";

export const isLocal = false;
export const isMock = false;
if(isMock){
  window.feMockPoll = "empty"; // "one" or "two" or "three" or "four" or "five"
}
export const urlBase = isMock ? "http://localhost:9090" : isLocal ? "http://localhost:8080" : "";
export const serviceUrls = BEUrls(urlBase);

export function beServiceUrls() {
  return serviceUrls;
}
