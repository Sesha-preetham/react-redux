import React from "react";
import PropTypes from "prop-types";
import { v4 as uuidv4 } from "uuid";

const CModal = (props) => {
  const { configuration } = props;
  const {
    uniqueID = uuidv4(),
    modalShow = false,
    modalCloseShow = false,
    modalCss = {},
    events = {},
  } = configuration;
  const {
    modalClass = "",
    modalInnerClass = "",
    modalCloseClass = "",
    modalContentClass = "",
  } = modalCss;
  const {
    onClose = () => {
      console.log("CModal onClose");
    },
  } = events;
  return (
    <>
      {modalShow && (
        <div id={uniqueID} className={`modal ${modalClass}`}>
          <div className={`modal-inner ${modalInnerClass}`}>
            {modalCloseShow && (
              <span
                className={`modal-close ${modalCloseClass}`}
                onClick={onClose}
              ></span>
            )}
            <div className={`modal-content ${modalContentClass}`}>
              {props.children}
            </div>
          </div>
        </div>
      )}
    </>
  );
};

CModal.propsTypes = {
  configuration: PropTypes.shape({
    uniqueID: PropTypes.string.isRequired,
    modalShow: PropTypes.bool.isRequired,
    modalCloseShow: PropTypes.bool.isRequired,
    modalCss: PropTypes.shape({
      modalClass: PropTypes.string,
      modalInnerClass: PropTypes.string,
      modalCloseClass: PropTypes.string,
      modalContentClass: PropTypes.string,
    }),
    events: PropTypes.shape({
      onClose: PropTypes.func.isRequired,
    }),
  }).isRequired,
};
export default CModal;
