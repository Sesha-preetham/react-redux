import React,{ useContext, useEffect, useState }  from "react";
import { ChatFEContext } from "../../../scripts/App";

const GlobalSpinner = (props) => {

const {id , showSpinnerVal = false } = props;

const chatFEContext = useContext(ChatFEContext);
const { spinnerId = "", showSpinner = false } = chatFEContext.state;



  return (
    (id == spinnerId )
    ?
    <div>
      <div class={ showSpinnerVal ? "loader-container" : "" }>
        <div class="loader">
          <div class="jawn"></div>
        </div>
      </div>
    </div>
    :
    <>
    </>
  );
};

export default GlobalSpinner;
