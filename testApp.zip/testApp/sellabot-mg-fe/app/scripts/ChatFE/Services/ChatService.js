export const getHpPageInfo = () => {
  let hbPageInfo = "";
  let hbPageInfoObj = window.opener ? window.opener.hbPageInfo : "";
  if (hbPageInfoObj && hbPageInfoObj.currentPageName) {
    hbPageInfo = hbPageInfoObj.currentPageName;
    if (hbPageInfoObj.currentTabName) {
      hbPageInfo = hbPageInfo + ";" + hbPageInfoObj.currentTabName;
      if (hbPageInfoObj.currentSubTabName) {
        hbPageInfo = hbPageInfo + ";" + hbPageInfoObj.currentSubTabName;
      }
    }
  }
  return hbPageInfo;
};
