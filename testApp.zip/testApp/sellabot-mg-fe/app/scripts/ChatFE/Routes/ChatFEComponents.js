import React from "react";
import ChatAlghoContainer from "../Modules/Chat-algho/ChatAlghoContainer";
import ChatComponent from "../Modules/Chat/ChatComponent";
import ErrorCourtesyPage from "../Modules/CourtesyPage/ErrorCourtesyPage";
import SondaggioContainer from "../Modules/Sondaggio/SondaggioContainer";

const ChatFEComponents = {
  CHAT_MODULE: () => {
    return <ChatComponent />;
  },
  CHAT_ALGHO_MODULE: () => {
    return <ChatAlghoContainer />;
  },
  CHAT_ERROR_COURTESY_PAGE: () => {
    return <ErrorCourtesyPage />
  },
  QUESTIONNAIRE_MODULE: () => {
    return <SondaggioContainer />;
  },
  noMatch: () => {
    return <div>Oops Something went wrong!</div>;
  },
};

export const findFinalComponentByKey = (keyName) => {
  if (ChatFEComponents[keyName]) {
    return ChatFEComponents[keyName];
  } else {
    return ChatFEComponents.noMatch;
  }
};
