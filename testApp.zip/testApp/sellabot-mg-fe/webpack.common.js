var webpack = require("webpack");
var path = require("path");

const { CleanWebpackPlugin } = require("clean-webpack-plugin");

var WebpackProviderPlugin = new webpack.ProvidePlugin({
  $: "jquery"
});

module.exports = {
  entry: __dirname + "/app/index.js",
  plugins: [new CleanWebpackPlugin(), WebpackProviderPlugin],
  module: {
    rules: [
      {
        test: /\.js$/,
        exclude: /node-modules/,
        use: {
          loader: "babel-loader"
        }
      }
    ]
  },
  resolve: {
    extensions: [".js"],
    modules: ["node_modules/", path.resolve(__dirname, "./app/")]
  }
};
