var webpack = require("webpack");
var path = require("path");

const { CleanWebpackPlugin } = require("clean-webpack-plugin");
const TerserPlugin = require("terser-webpack-plugin");

module.exports = {
  entry: __dirname + "/src/express-server.js",
  plugins: [new CleanWebpackPlugin()],
  optimization: {
    minimizer: [
      new TerserPlugin({
        cache: true,
        parallel: true,
        terserOptions: {
          toplevel: true,
          ie8: true,
          warnings: true,
          compress: {
            drop_console: true
          },
          mangle: true,
          output: {
            comments: false // remove comments
          }
        }
      })
    ]
  },
  mode: "production",
  target: "node",
  output: {
    filename: "express-server-build.js",
    path: path.resolve("./server/build")
  },
  module: {
    rules: [
      {
        test: /\.js$/,
        exclude: /node-modules/,
        use: {
          loader: "babel-loader"
        }
      }
    ]
  },
  resolve: {
    extensions: [".js"],
    modules: ["node_modules/", path.resolve(__dirname, "./src/")]
  }
};
