import express from "express";
import cors from "cors";
import bodyParser from "body-parser";
import fs from "fs";
import { loadPostUrls, findPathByPostUrl } from "./express-urls";

const app = express();
const postServiceUrls = loadPostUrls();

app.use((req, res, next) => {
  res.header("Access-Control-Allow-Origin", "*");
  res.header(
    "Access-Control-Allow-Headers",
    "Origin, X-Requested-With, Content-Type, Accept"
  );
  next();
});

const corsOptions = {
  origin: '*',
  optionsSuccessStatus: 200 // some legacy browsers (IE11, various SmartTVs) choke on 204
}

app.options('*', cors(corsOptions));
 
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());


app.post(postServiceUrls, cors(), (req, res) => {
  let servicePath = req.path;
  servicePath = servicePath.substring(1, servicePath.length);
  let path = findPathByPostUrl(servicePath);
  console.log(
    "--------------- ExpressJS servicePath: POST METHOD " + servicePath
  );
  readFile(path, (err, data) => {
    res.send(data);
    console.log(err);
  });
});
let readFile = (file, cbk) => {
  fs.readFile(file, (err, data) => {
    if (err) {
      cbk(err);
      return;
    }
    try {
      cbk(null, data);
    } catch (exception) {
      cbk(exception);
    }
  });
};

app.post("/sellabot/execute/user/poll", (req, res) => {
  console.log(req);
  let pollPaths = {
    empty: "server/src/init/poll0.json",
    one: "server/src/init/poll1.json",
    two: "server/src/init/poll2.json",
    three: "server/src/init/poll3.json",
    four: "server/src/init/poll4.json",
    five: "server/src/init/poll5.json",
  };
  readFile(pollPaths[req.body.mockPoll], (err, data) => {
    res.send(data);
    console.log(err);
  });
});

app.listen(9090, () => {
  console.log("----------------- ExpressJS Started on PORT 8090");
});
