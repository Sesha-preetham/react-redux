import initUrlsWithPath from "./init/InitUrlsWithPath";

const postServiceUrlsWithPath = [...initUrlsWithPath];

export const loadPostUrls = () => {
  let length = postServiceUrlsWithPath.length;
  let returnPostServiceUrls = [];
  for (let i = 0; i < length; i++) {
    returnPostServiceUrls.push(postServiceUrlsWithPath[i].postUrl);
  }
  return returnPostServiceUrls;
};

export const findPathByPostUrl = postUrl => {
  let index = postServiceUrlsWithPath.findIndex(postServiceUrl => {
    return postServiceUrl.postUrl === "/" + postUrl;
  });
  return postServiceUrlsWithPath[index].path;
};
