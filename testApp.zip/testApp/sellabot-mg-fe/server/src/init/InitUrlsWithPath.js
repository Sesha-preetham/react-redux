const initUrlsWithPath = [
  {
    postUrl: "/sellabot/chatinit",
    path: "server/src/init/info.json",
  },
  {
    postUrl: "/sellabot/execute/user/info",
    path: "server/src/init/info.json",
  },
  {
    postUrl: "/sellabot/execute/page/properties",
    path: "server/src/init/properties.json",
  },
  {
    postUrl: "/sellabot/execute/bot/config",
    path: "server/src/init/botconfig.json",
  },
  {
    postUrl: "/sellabot/execute/bot/start",
    path: "server/src/init/botconfig.json",
  },
  {
    postUrl: "/sellabot/execute/bot/message",
    path: "server/src/init/botconfig.json",
  },
  {
    postUrl: "/sellabot/execute/user/syncalias",
    path: "server/src/init/syncalias.json",
  },
  {
    postUrl: "/sellabot/execute/user/chat",
    path: "server/src/init/chat.json",
  },
  {
    postUrl: "/sellabot/execute/feedback/questions",
    path: "server/src/init/questions.json",
  },
  {
    postUrl: "/sellabot/execute/feedback/insert",
    path: "server/src/init/insert.json",
  },
];

export default initUrlsWithPath;
