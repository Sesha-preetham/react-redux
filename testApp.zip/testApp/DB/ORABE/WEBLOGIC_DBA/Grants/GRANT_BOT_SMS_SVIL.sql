begin
std_pkg_antutil.do_grant('weblogic_dba', 'bot_sms_tr', 'svil_team40', 'select,insert,update,delete');
std_pkg_antutil.do_grant('weblogic_dba', 'bot_sms_tr_qa', 'svil_team40', 'select,insert,update,delete');
std_pkg_antutil.do_grant('weblogic_dba', 'bot_sms_que', 'svil_team40', 'select,insert,update,delete');
std_pkg_antutil.do_grant('weblogic_dba', 'bot_sms_ans', 'svil_team40', 'select,insert,update,delete');
std_pkg_antutil.do_grant('weblogic_dba', 'bot_sms_aty', 'svil_team40', 'select,insert,update,delete');
std_pkg_antutil.do_grant('weblogic_dba', 'bot_sms_sur', 'svil_team40', 'select,insert,update,delete');
end;
/