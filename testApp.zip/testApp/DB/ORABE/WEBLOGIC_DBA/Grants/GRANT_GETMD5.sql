begin
	std_pkg_antutil.do_grant('weblogic_dba', 'getmd5', 'BTWEB_BE', 'execute');
end;
/