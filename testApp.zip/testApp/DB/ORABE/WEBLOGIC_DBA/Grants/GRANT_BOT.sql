begin
std_pkg_antutil.do_grant('weblogic_dba', 'BOT_PA_INTERFACE', 'HBBE', 'execute');
end;
/