begin
	std_pkg_antutil.do_grant('weblogic_dba', 'bot_sms_tr', 'BTWEB_BE', 'select,insert,update,delete');
	std_pkg_antutil.do_grant('weblogic_dba', 'bot_sms_tr_qa', 'BTWEB_BE', 'select,insert,update,delete');
	std_pkg_antutil.do_grant('weblogic_dba', 'bot_sms_que', 'BTWEB_BE', 'select,insert,update,delete');
	std_pkg_antutil.do_grant('weblogic_dba', 'bot_sms_ans', 'BTWEB_BE', 'select,insert,update,delete');
	std_pkg_antutil.do_grant('weblogic_dba', 'bot_sms_aty', 'BTWEB_BE', 'select,insert,update,delete');
	std_pkg_antutil.do_grant('weblogic_dba', 'bot_sms_sur', 'BTWEB_BE', 'select,insert,update,delete');
	std_pkg_antutil.do_grant('weblogic_dba', 'bot_sms_tr_seq', 'BTWEB_BE', 'select');
	
	
	std_pkg_antutil.do_grant('weblogic_dba', 'bot_sms_tr', 'CONSULTA_IB', 'select');
	std_pkg_antutil.do_grant('weblogic_dba', 'bot_sms_tr_qa', 'CONSULTA_IB', 'select');
	std_pkg_antutil.do_grant('weblogic_dba', 'bot_sms_que', 'CONSULTA_IB', 'select');
	std_pkg_antutil.do_grant('weblogic_dba', 'bot_sms_ans', 'CONSULTA_IB', 'select');
	std_pkg_antutil.do_grant('weblogic_dba', 'bot_sms_aty', 'CONSULTA_IB', 'select');
	std_pkg_antutil.do_grant('weblogic_dba', 'bot_sms_sur', 'CONSULTA_IB', 'select');
end;
/