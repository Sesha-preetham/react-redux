insert into weblogic_dba.bot_sms_aty(type)
values('BUTTON');
insert into weblogic_dba.bot_sms_aty(type)
values('TEXT');
insert into weblogic_dba.bot_sms_aty(type)
values('END');


insert into weblogic_dba.bot_sms_sur(code,sms_body,init_que_id)
values('POSTE_SURVEY','Ciao hai gi�i codici di accesso? ${bot_link}',null);

insert into weblogic_dba.bot_sms_que(code,text,aty_id)
values('WELCOME','Ciao, sono qui per aiutarti. Hai gi� richiesto i codici demo per provare la nuova piattaforma di trading?',(select id from weblogic_dba.bot_sms_aty where type='BUTTON'));
insert into weblogic_dba.bot_sms_que(code,text,aty_id)
values('INFO_INTEREST','Sei interessato a ricevere maggiori informazioni?',(select id from weblogic_dba.bot_sms_aty where type='BUTTON'));
insert into weblogic_dba.bot_sms_que(code,text,aty_id)
values('BYE_NEG','Grazie, ti ricordiamo che in ogni momento nell''area autenticata Poste potrai aderire all''iniziativa',(select id from weblogic_dba.bot_sms_aty where type='END'));
insert into weblogic_dba.bot_sms_que(code,text,aty_id)
values('ACP_CONS','Accettazione del consenso',(select id from weblogic_dba.bot_sms_aty where type='BUTTON'));
insert into weblogic_dba.bot_sms_que(code,text,aty_id)
values('BYE_POS','Grazie, sarai ricontattato a breve',(select id from weblogic_dba.bot_sms_aty where type='END'));

insert into weblogic_dba.bot_sms_ans(code,ans_label,que_pnt_id,que_nxt_id)
values('WELCOME-Y','SI',(select id from weblogic_dba.bot_sms_que where code='WELCOME'),(select id  from weblogic_dba.bot_sms_que where code='INFO_INTEREST')); 
insert into weblogic_dba.bot_sms_ans(code,ans_label,que_pnt_id,que_nxt_id)
values('WELCOME-N','NO',(select id from weblogic_dba.bot_sms_que where code='WELCOME'),(select id  from weblogic_dba.bot_sms_que where code='BYE_NEG')); 
insert into weblogic_dba.bot_sms_ans(code,ans_label,que_pnt_id,que_nxt_id)
values('INFO_INTEREST-Y','SI',(select id from weblogic_dba.bot_sms_que where code='INFO_INTEREST'),(select id  from weblogic_dba.bot_sms_que where code='ACP_CONS'));
insert into weblogic_dba.bot_sms_ans(code,ans_label,que_pnt_id,que_nxt_id)
values('INFO_INTEREST-N','NO',(select id from weblogic_dba.bot_sms_que where code='INFO_INTEREST'),(select id  from weblogic_dba.bot_sms_que where code='BYE_NEG'));
insert into weblogic_dba.bot_sms_ans(code,ans_label,que_pnt_id,que_nxt_id)
values('ACP_CONS-Y','SI',(select id from weblogic_dba.bot_sms_que where code='ACP_CONS'),(select id  from weblogic_dba.bot_sms_que where code='BYE_POS'));
insert into weblogic_dba.bot_sms_ans(code,ans_label,que_pnt_id,que_nxt_id)
values('ACP_CONS-N','NO',(select id from weblogic_dba.bot_sms_que where code='ACP_CONS'),(select id  from weblogic_dba.bot_sms_que where code='BYE_NEG'));

update weblogic_dba.bot_sms_sur
set init_que_id=(select id from weblogic_dba.bot_sms_que where code='WELCOME')
where code='POSTE_SURVEY';

commit;
