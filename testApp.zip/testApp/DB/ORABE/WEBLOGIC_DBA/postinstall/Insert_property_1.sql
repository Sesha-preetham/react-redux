begin
	delete from BOT_TR_PROPERTY where bot_tri_code = 'NEWCHAT' and bot_tri_parameter ='TIMEOUT';
	delete from BOT_TR_PROPERTY where bot_tri_code = 'NEWCHAT' and bot_tri_parameter ='OP_FROM_TIME';
	delete from BOT_TR_PROPERTY where bot_tri_code = 'NEWCHAT' and bot_tri_parameter ='OP_TO_TIME';
	delete from BOT_TR_PROPERTY where bot_tri_code = 'FE_PAGE_PROPS' and bot_tri_parameter ='POLL_DELAY_SEC';
	
	insert into BOT_TR_PROPERTY (bot_tri_code,bot_tri_parameter,bot_tri_value,Bot_Tri_Description,Bot_Tri_Bank)
	values ('NEWCHAT','TIMEOUT','30000','Im interaction timeout','*');
	insert into BOT_TR_PROPERTY (bot_tri_code,bot_tri_parameter,bot_tri_value,Bot_Tri_Description,Bot_Tri_Bank)
	values ('NEWCHAT','OP_FROM_TIME','09:00','Operator available from','*');
	insert into BOT_TR_PROPERTY (bot_tri_code,bot_tri_parameter,bot_tri_value,Bot_Tri_Description,Bot_Tri_Bank)
	values ('NEWCHAT','OP_TO_TIME','17:30','Operator available to','*');
	insert into BOT_TR_PROPERTY (bot_tri_code,bot_tri_parameter,bot_tri_value,Bot_Tri_Description,Bot_Tri_Bank)
	values ('FE_PAGE_PROPS','POLL_DELAY_SEC','5','Poll time delay','*');
commit;
end;
/