
delete BOT_TR_PROPERTY where BOT_TRI_CODE in ('ALGHO_CONFIG','USE_ALGHO', 'ALGHO_CHANNEL','CONFIG');

insert into BOT_TR_PROPERTY (BOT_TRI_CODE, BOT_TRI_PARAMETER, BOT_TRI_VALUE, BOT_TRI_DESCRIPTION, BOT_TRI_BANK, BOT_TRI_DATAINS)
values ('USE_ALGHO', 'ACTIVE', 'Y', 'Activate algho usage', '*', to_date('13-10-2022', 'dd-mm-yyyy'));

insert into BOT_TR_PROPERTY (BOT_TRI_CODE, BOT_TRI_PARAMETER, BOT_TRI_VALUE, BOT_TRI_DESCRIPTION, BOT_TRI_BANK, BOT_TRI_DATAINS)
values ('ALGHO_CONFIG', 'bot-id', '0e62d74bc0b7818c5462ae9c371fcd8e', 'bot-id', '*', to_date('13-10-2022', 'dd-mm-yyyy'));

insert into BOT_TR_PROPERTY (BOT_TRI_CODE, BOT_TRI_PARAMETER, BOT_TRI_VALUE, BOT_TRI_DESCRIPTION, BOT_TRI_BANK, BOT_TRI_DATAINS)
values ('ALGHO_CONFIG', 'question-id', '285710', 'question-id', '*', to_date('13-10-2022', 'dd-mm-yyyy'));

insert into BOT_TR_PROPERTY (BOT_TRI_CODE, BOT_TRI_PARAMETER, BOT_TRI_VALUE, BOT_TRI_DESCRIPTION, BOT_TRI_BANK, BOT_TRI_DATAINS)
values ('ALGHO_CONFIG', 'question-repeat', 'true', 'question-repeat', '*', to_date('13-10-2022', 'dd-mm-yyyy'));

insert into BOT_TR_PROPERTY (BOT_TRI_CODE, BOT_TRI_PARAMETER, BOT_TRI_VALUE, BOT_TRI_DESCRIPTION, BOT_TRI_BANK, BOT_TRI_DATAINS)
values ('ALGHO_CONFIG', 'auto-hide-message', 'true', 'auto-hide-message', '*', to_date('13-10-2022', 'dd-mm-yyyy'));

insert into BOT_TR_PROPERTY (BOT_TRI_CODE, BOT_TRI_PARAMETER, BOT_TRI_VALUE, BOT_TRI_DESCRIPTION, BOT_TRI_BANK, BOT_TRI_DATAINS)
values ('ALGHO_CONFIG', 'widget', 'false', 'widget', '*', to_date('13-10-2022', 'dd-mm-yyyy'));

insert into BOT_TR_PROPERTY (BOT_TRI_CODE, BOT_TRI_PARAMETER, BOT_TRI_VALUE, BOT_TRI_DESCRIPTION, BOT_TRI_BANK, BOT_TRI_DATAINS)
values ('ALGHO_CONFIG', 'open', 'true', 'open', '*', to_date('13-10-2022', 'dd-mm-yyyy'));

insert into BOT_TR_PROPERTY (BOT_TRI_CODE, BOT_TRI_PARAMETER, BOT_TRI_VALUE, BOT_TRI_DESCRIPTION, BOT_TRI_BANK, BOT_TRI_DATAINS)
values ('ALGHO_CONFIG', 'inline', 'true', 'inline', '*', to_date('13-10-2022', 'dd-mm-yyyy'));

insert into BOT_TR_PROPERTY (BOT_TRI_CODE, BOT_TRI_PARAMETER, BOT_TRI_VALUE, BOT_TRI_DESCRIPTION, BOT_TRI_BANK, BOT_TRI_DATAINS)
values ('ALGHO_CONFIG', 'width', '100%', 'width', '*', to_date('13-10-2022', 'dd-mm-yyyy'));

insert into BOT_TR_PROPERTY (BOT_TRI_CODE, BOT_TRI_PARAMETER, BOT_TRI_VALUE, BOT_TRI_DESCRIPTION, BOT_TRI_BANK, BOT_TRI_DATAINS)
values ('ALGHO_CONFIG', 'height', '100%', 'height', '*', to_date('13-10-2022', 'dd-mm-yyyy'));

insert into BOT_TR_PROPERTY (BOT_TRI_CODE, BOT_TRI_PARAMETER, BOT_TRI_VALUE, BOT_TRI_DESCRIPTION, BOT_TRI_BANK, BOT_TRI_DATAINS)
values ('ALGHO_CONFIG', 'theme-style', 'light', 'theme-style', '*', to_date('13-10-2022', 'dd-mm-yyyy'));

insert into BOT_TR_PROPERTY (BOT_TRI_CODE, BOT_TRI_PARAMETER, BOT_TRI_VALUE, BOT_TRI_DESCRIPTION, BOT_TRI_BANK, BOT_TRI_DATAINS)
values ('ALGHO_CONFIG', 'bot-icon', 'true', 'bot-icon', '*', to_date('13-10-2022', 'dd-mm-yyyy'));

insert into BOT_TR_PROPERTY (BOT_TRI_CODE, BOT_TRI_PARAMETER, BOT_TRI_VALUE, BOT_TRI_DESCRIPTION, BOT_TRI_BANK, BOT_TRI_DATAINS)
values ('ALGHO_CONFIG', 'hide-infos', 'true', 'hide-infos', '*', to_date('13-10-2022', 'dd-mm-yyyy'));

insert into BOT_TR_PROPERTY (BOT_TRI_CODE, BOT_TRI_PARAMETER, BOT_TRI_VALUE, BOT_TRI_DESCRIPTION, BOT_TRI_BANK, BOT_TRI_DATAINS)
values ('ALGHO_CONFIG', 'hide-settings', 'true', 'hide-infos', '*', to_date('13-10-2022', 'dd-mm-yyyy'));

insert into BOT_TR_PROPERTY (BOT_TRI_CODE, BOT_TRI_PARAMETER, BOT_TRI_VALUE, BOT_TRI_DESCRIPTION, BOT_TRI_BANK, BOT_TRI_DATAINS)
values ('ALGHO_CONFIG', 'dhi', 'false', 'dhi', '*', to_date('13-10-2022', 'dd-mm-yyyy'));

insert into BOT_TR_PROPERTY (BOT_TRI_CODE, BOT_TRI_PARAMETER, BOT_TRI_VALUE, BOT_TRI_DESCRIPTION, BOT_TRI_BANK, BOT_TRI_DATAINS)
values ('ALGHO_CONFIG', 'voice', 'false', 'voice', '*', to_date('13-10-2022', 'dd-mm-yyyy'));

insert into BOT_TR_PROPERTY (BOT_TRI_CODE, BOT_TRI_PARAMETER, BOT_TRI_VALUE, BOT_TRI_DESCRIPTION, BOT_TRI_BANK, BOT_TRI_DATAINS)
values ('ALGHO_CONFIG', 'sound', 'false', 'sound', '*', to_date('13-10-2022', 'dd-mm-yyyy'));

insert into BOT_TR_PROPERTY (BOT_TRI_CODE, BOT_TRI_PARAMETER, BOT_TRI_VALUE, BOT_TRI_DESCRIPTION, BOT_TRI_BANK, BOT_TRI_DATAINS)
values ('ALGHO_CONFIG', 'link-preview', 'true', 'link-preview', '*', to_date('13-10-2022', 'dd-mm-yyyy'));

insert into BOT_TR_PROPERTY (BOT_TRI_CODE, BOT_TRI_PARAMETER, BOT_TRI_VALUE, BOT_TRI_DESCRIPTION, BOT_TRI_BANK, BOT_TRI_DATAINS)
values ('ALGHO_CONFIG', 'link-opener', 'https://www.sella.pre/sellabot/execute/bot/hblink', 'link-opener', '*', to_date('13-10-2022', 'dd-mm-yyyy'));

insert into BOT_TR_PROPERTY (BOT_TRI_CODE, BOT_TRI_PARAMETER, BOT_TRI_VALUE, BOT_TRI_DESCRIPTION, BOT_TRI_BANK, BOT_TRI_DATAINS)
values ('ALGHO_CONFIG', 'link-text', 'VAI ALLA PAGINA', 'link-text', '*', to_date('13-10-2022', 'dd-mm-yyyy'));

insert into BOT_TR_PROPERTY (BOT_TRI_CODE, BOT_TRI_PARAMETER, BOT_TRI_VALUE, BOT_TRI_DESCRIPTION, BOT_TRI_BANK, BOT_TRI_DATAINS)
values ('ALGHO_CONFIG', 'link-auto-open', 'false', 'link-auto-open', '*', to_date('13-10-2022', 'dd-mm-yyyy'));


insert into BOT_TR_PROPERTY (BOT_TRI_CODE, BOT_TRI_PARAMETER, BOT_TRI_VALUE, BOT_TRI_DESCRIPTION, BOT_TRI_BANK, BOT_TRI_DATAINS)
values ('ALGHO_CHANNEL', 'Sella_sito_free', 'IB', 'ALGHO_CHANNEL', '*', to_date('13-10-2022', 'dd-mm-yyyy'));
insert into BOT_TR_PROPERTY (BOT_TRI_CODE, BOT_TRI_PARAMETER, BOT_TRI_VALUE, BOT_TRI_DESCRIPTION, BOT_TRI_BANK, BOT_TRI_DATAINS)
values ('ALGHO_CHANNEL', 'Sella_sito_IB_authenticated', 'IB', 'ALGHO_CHANNEL', '*', to_date('13-10-2022', 'dd-mm-yyyy'));
insert into BOT_TR_PROPERTY (BOT_TRI_CODE, BOT_TRI_PARAMETER, BOT_TRI_VALUE, BOT_TRI_DESCRIPTION, BOT_TRI_BANK, BOT_TRI_DATAINS)
values ('ALGHO_CHANNEL', 'Sella_app_authenticated_android', 'APP', 'ALGHO_CHANNEL', '*', to_date('13-10-2022', 'dd-mm-yyyy'));
insert into BOT_TR_PROPERTY (BOT_TRI_CODE, BOT_TRI_PARAMETER, BOT_TRI_VALUE, BOT_TRI_DESCRIPTION, BOT_TRI_BANK, BOT_TRI_DATAINS)
values ('ALGHO_CHANNEL', 'Sella_app_authenticated_ios', 'APP', 'ALGHO_CHANNEL', '*', to_date('13-10-2022', 'dd-mm-yyyy'));
insert into BOT_TR_PROPERTY (BOT_TRI_CODE, BOT_TRI_PARAMETER, BOT_TRI_VALUE, BOT_TRI_DESCRIPTION, BOT_TRI_BANK, BOT_TRI_DATAINS)
values ('ALGHO_CHANNEL', 'Sella_app_free_android', 'APP', 'ALGHO_CHANNEL', '*', to_date('13-10-2022', 'dd-mm-yyyy'));
insert into BOT_TR_PROPERTY (BOT_TRI_CODE, BOT_TRI_PARAMETER, BOT_TRI_VALUE, BOT_TRI_DESCRIPTION, BOT_TRI_BANK, BOT_TRI_DATAINS)
values ('ALGHO_CHANNEL', 'Sella_app_free_ios', 'APP', 'ALGHO_CHANNEL', '*', to_date('13-10-2022', 'dd-mm-yyyy'));
insert into BOT_TR_PROPERTY (BOT_TRI_CODE, BOT_TRI_PARAMETER, BOT_TRI_VALUE, BOT_TRI_DESCRIPTION, BOT_TRI_BANK, BOT_TRI_DATAINS)
values ('ALGHO_CHANNEL', 'SME', 'SME', 'ALGHO_CHANNEL', '*', to_date('13-10-2022', 'dd-mm-yyyy'));
insert into BOT_TR_PROPERTY (BOT_TRI_CODE, BOT_TRI_PARAMETER, BOT_TRI_VALUE, BOT_TRI_DESCRIPTION, BOT_TRI_BANK, BOT_TRI_DATAINS)
values ('ALGHO_CHANNEL', 'BSE_EMAIL_free', 'EMAIL', 'ALGHO_CHANNEL', '*', to_date('13-10-2022', 'dd-mm-yyyy'));

insert into BOT_TR_PROPERTY (BOT_TRI_CODE, BOT_TRI_PARAMETER, BOT_TRI_VALUE, BOT_TRI_DESCRIPTION, BOT_TRI_BANK, BOT_TRI_DATAINS)
values ('CONFIG', 'botScript', 'https://virtualassistant.sella.pre/algho-viewer.min.js', 'botScript', '*', to_date('13-10-2022', 'dd-mm-yyyy'));
insert into BOT_TR_PROPERTY (BOT_TRI_CODE, BOT_TRI_PARAMETER, BOT_TRI_VALUE, BOT_TRI_DESCRIPTION, BOT_TRI_BANK, BOT_TRI_DATAINS)
values ('CONFIG', 'forceAgentRedirect', 'N', 'force redirect to agent chat', '*', to_date('13-10-2022', 'dd-mm-yyyy'));

commit;