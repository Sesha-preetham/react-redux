update weblogic_dba.bot_sms_sur
set sms_body='Se desideri informazioni in merito alla piattaforma demo di trading clicca qui ${bot_link}'
where code='POSTE_SURVEY';

update weblogic_dba.bot_sms_que
set text='Ciao, sono qui per aiutarti. Desideri ulteriori informazioni sulla demo della piattaforma trading?'
where code='WELCOME';

update weblogic_dba.bot_sms_que
set text='Grazie per il tempo che ci hai dedicato.'
where code='BYE_NEG';

update weblogic_dba.bot_sms_que
set text='Grazie, abbiamo preso in carico la tua richiesta, ti ricontatteremo al pi� presto.'
where code='BYE_POS';

update weblogic_dba.bot_sms_que
set text='Vuoi essere ricontattato?'
where code='ACP_CONS';

update weblogic_dba.bot_sms_ans
set que_nxt_id = (select id from weblogic_dba.bot_sms_que where code='ACP_CONS')
where code='WELCOME-Y';

delete weblogic_dba.bot_sms_tr_qa;
delete weblogic_dba.bot_sms_ans where que_pnt_id = (select id from weblogic_dba.bot_sms_que where code='INFO_INTEREST');
delete weblogic_dba.bot_sms_que where code='INFO_INTEREST';

commit;