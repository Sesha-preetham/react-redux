begin

	delete from ib_tr_property where IB_TRI_CODICE in('MsExchangeMail365.UserName','MsExchangeMail365.Password');

	insert into ib_tr_property(IB_TRI_CODICE,ib_tri_nomeparametro,ib_tri_value,ib_tri_descrizione,ib_tri_banca,ib_tri_datains)
	values('MsExchangeMail365.UserName','USERNAME','Y2NleGNoYW5nZUBjZW50cmljby50ZWNo','M365 UserName','*',sysdate);
	insert into ib_tr_property(IB_TRI_CODICE,ib_tri_nomeparametro,ib_tri_value,ib_tri_descrizione,ib_tri_banca,ib_tri_datains)
	values('MsExchangeMail365.Password','PASSWORD','OTk5OTk5OTk5','M365 Password','*',sysdate);
	
commit;
end;
/