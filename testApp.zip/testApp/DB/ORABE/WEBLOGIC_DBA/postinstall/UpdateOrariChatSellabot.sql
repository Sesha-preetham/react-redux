update weblogic_dba.bot_tr_property t set t.bot_tri_value='09:00' where t.bot_tri_code='NEWCHAT' and t.bot_tri_parameter='OP_FROM_TIME';
update weblogic_dba.bot_tr_property t set t.bot_tri_value='17:30' where t.bot_tri_code='NEWCHAT' and t.bot_tri_parameter='OP_TO_TIME';
commit;