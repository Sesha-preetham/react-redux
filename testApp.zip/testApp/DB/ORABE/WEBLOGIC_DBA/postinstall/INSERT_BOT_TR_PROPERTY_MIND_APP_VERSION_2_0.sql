insert into weblogic_dba.BOT_TR_PROPERTY (BOT_TRI_CODE,BOT_TRI_PARAMETER,BOT_TRI_VALUE,BOT_TRI_DESCRIPTION,BOT_TRI_BANK)
values ('APPNAME','BancaSella_Chat','2.0','New version MIND APP','*');

insert into weblogic_dba.BOT_TR_PROPERTY (BOT_TRI_CODE,BOT_TRI_PARAMETER,BOT_TRI_VALUE,BOT_TRI_DESCRIPTION,BOT_TRI_BANK)
values ('APPNAME','BancaSella_AppMobile','2.0','New version MIND APP','*');

insert into weblogic_dba.BOT_TR_PROPERTY (BOT_TRI_CODE,BOT_TRI_PARAMETER,BOT_TRI_VALUE,BOT_TRI_DESCRIPTION,BOT_TRI_BANK)
values ('APPNAME','BancaSella_Email','2.0','New version MIND APP','*');

insert into weblogic_dba.BOT_TR_PROPERTY (BOT_TRI_CODE,BOT_TRI_PARAMETER,BOT_TRI_VALUE,BOT_TRI_DESCRIPTION,BOT_TRI_BANK)
values ('APPNAME','SMEBanking_Chat','2.0','New version MIND APP','*');

insert into weblogic_dba.BOT_TR_PROPERTY (BOT_TRI_CODE,BOT_TRI_PARAMETER,BOT_TRI_VALUE,BOT_TRI_DESCRIPTION,BOT_TRI_BANK)
values ('APPNAME','BancaSella_Chat_PRO','2.0','New version MIND APP','*');

insert into weblogic_dba.BOT_TR_PROPERTY (BOT_TRI_CODE,BOT_TRI_PARAMETER,BOT_TRI_VALUE,BOT_TRI_DESCRIPTION,BOT_TRI_BANK)
values ('APPNAME','BancaSella_AppMobile_PRO','2.0','New version MIND APP','*');

insert into weblogic_dba.BOT_TR_PROPERTY (BOT_TRI_CODE,BOT_TRI_PARAMETER,BOT_TRI_VALUE,BOT_TRI_DESCRIPTION,BOT_TRI_BANK)
values ('APPNAME','SMEBanking_Chat_PRO','2.0','New version MIND APP','*');

commit;