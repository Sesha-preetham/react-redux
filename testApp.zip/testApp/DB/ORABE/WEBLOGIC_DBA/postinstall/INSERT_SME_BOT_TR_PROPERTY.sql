begin
	delete from BOT_TR_PROPERTY where bot_tri_code = 'BLOCKED_INTEND';
	
	insert into BOT_TR_PROPERTY(bot_tri_code,BOT_TRI_PARAMETER,BOT_TRI_VALUE,BOT_TRI_DESCRIPTION,BOT_TRI_BANK)
	values('BLOCKED_INTEND','SMEBanking_Chat_PRO','*','Blocked intentCodes for PRO','*');
	
commit;
end;
/