update weblogic_dba.bot_sms_sur
set sms_body='Vuoi scoprire tutte le funzionalit� e i vantaggi della piattaforma di trading online SellaXTrading?�Clicca qui ${bot_link}'
where code='POSTE_SURVEY';

update weblogic_dba.bot_sms_que
set text='Ciao, sono l''assistente virtuale. Desideri maggiori informazioni sulle funzionalit� e i vantaggi della piattaforma SellaXTrading?'
where code='WELCOME';

update weblogic_dba.bot_sms_que
set text='Grazie per il tempo che ci hai dedicato!'
where code='BYE_NEG';

update weblogic_dba.bot_sms_que
set text='Grazie, abbiamo preso in carico la tua richiesta! Ti ricontatteremo al pi� presto.'
where code='BYE_POS';

update weblogic_dba.bot_sms_que
set text='Vuoi essere ricontattato dai nostri operatori?'
where code='ACP_CONS';


commit;