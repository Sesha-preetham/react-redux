begin	
	
    update BOT_TR_PROPERTY set BOT_TRI_VALUE = 'ZZZ',BOT_TRI_DATAINS=sysdate where BOT_TRI_PARAMETER = 'SMEBanking_Chat' and BOT_TRI_CODE = 'BLOCKED_INTEND';
	
	update BOT_TR_PROPERTY set BOT_TRI_VALUE = 'ZZZ',BOT_TRI_DATAINS=sysdate where BOT_TRI_PARAMETER = 'SMEBanking_Chat_PRO' and BOT_TRI_CODE = 'BLOCKED_INTEND';
	
commit;
end;
/