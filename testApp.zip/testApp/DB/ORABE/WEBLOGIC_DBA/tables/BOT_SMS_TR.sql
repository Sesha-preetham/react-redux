begin
  std_pkg_antutil.doft('weblogic_dba','bot_sms_tr','y');
end;
/

create table weblogic_dba.bot_sms_tr(
   id number primary key,
   phone varchar2(20),
   state varchar2(15),
   sur_id number,
   sms_key varchar2(16),
   sms_md5 varchar2(35),
   consent varchar2(1),
   ins_date date,
   sms_sent date,
   sms_sched date,
   sur_compl date,
   sur_started date,
   valid varchar2(1) default 'Y',
   constraint fk_bot_sms_sur_id foreign key(sur_id) REFERENCES weblogic_dba.bot_sms_sur (id)
)
/

-- grant/revoke object privileges 
begin
   std_pkg_antutil.do_grant('weblogic_dba', 'bot_sms_tr', 'hbbe',  'select,insert,update,delete');
  std_pkg_antutil.do_grant('weblogic_dba', 'bot_sms_tr', 'univ_ora', 'all');
end;
/