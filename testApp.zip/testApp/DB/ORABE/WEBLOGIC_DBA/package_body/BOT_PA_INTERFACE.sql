CREATE OR REPLACE PACKAGE BODY BOT_PA_INTERFACE AS
  PROCEDURE BOT_PR_GET_RESPONSE_MSG(CHATID  IN IB_TR_BOT_MESSAGE.SM_CHAT_ID%TYPE, MESSAGE OUT IB_TR_BOT_MESSAGE.SM_MESSAGE_TEXT%TYPE) AS
    L_MESSAGE IB_TR_BOT_MESSAGE.SM_MESSAGE_TEXT%TYPE := NULL;
    L_ROWID   ROWID;
    L_RN      NUMBER;
  BEGIN
    BEGIN
      SELECT MSGTXT, ROWID, RN
        INTO L_MESSAGE, L_ROWID, L_RN
        FROM (SELECT M.SM_MESSAGE_TEXT MSGTXT,
                     ROWID,
                     ROW_NUMBER() OVER(ORDER BY M.SM_TIME ASC) AS RN
                FROM IB_TR_BOT_MESSAGE M
               WHERE M.SM_CHAT_ID = CHATID
                 AND M.SM_SOURCE = 'BOT'
                 AND M.SM_STATUS IS NULL)
       WHERE RN = 1;
    
      UPDATE IB_TR_BOT_MESSAGE BM
         SET BM.SM_STATUS = 'READ'
       WHERE ROWID = L_ROWID;
    EXCEPTION
      WHEN OTHERS THEN
        L_MESSAGE := NULL;
    END;
    MESSAGE := L_MESSAGE;
  END BOT_PR_GET_RESPONSE_MSG;
  
  FUNCTION BOT_GET_RECALL_PHONE(iv_ibcode IN VARCHAR2) return varchar2 is
	lCur sys_refcursor;
	lvSA_INTERNET_CODE     VARCHAR2(8)      := NULL;               
	lnSA_SERVICE_ID        NUMBER           := NULL;                 
	lnSA_ID_SOGGETTO       NUMBER           := NULL;
	lnSA_ID                NUMBER           := NULL;
	lvSA_NUM_CELL          VARCHAR2(36)     := NULL;      
	ldSA_START_ABIL        DATE             := NULL;
	ldLAST_DATE            DATE             := NULL;
	lnID_SOGGETTO          NUMBER           := NULL;
	ov_num_cell            varchar2(36)     := NULL;
  BEGIN
	  lCur := applicazioni_dba.sms_pkg_utility.GET_SAID_STABIL_NCEL_FROM_SA13C(pvSA_INTERNET_CODE => iv_ibcode ,pnSA_ID_SOGGETTO => null, pnSA_SERVICE_ID => null);
	  loop 
		fetch lCur into lnSA_ID,lvSA_INTERNET_CODE,lnSA_SERVICE_ID,lnSA_ID_SOGGETTO,ldSA_START_ABIL,lvSA_NUM_CELL;
		exit when lCur%NOTFOUND;
		-- get sms conferma phone
		if lnSA_SERVICE_ID = 57 then
		  ov_num_cell := lvSA_NUM_CELL;
		  exit;
		end if;
		-- if sms conferma not available, use last updated sms service
		if ldLAST_DATE is null then
		  ldLAST_DATE := ldSA_START_ABIL;
		  ov_num_cell := lvSA_NUM_CELL;
		end if;
		if ldSA_START_ABIL > ldLAST_DATE then
		  ldLAST_DATE := ldSA_START_ABIL;
		  ov_num_cell := lvSA_NUM_CELL;
		end if;
	  end loop;
	  close lCur;  
	  -- if not found, take it from anagrafe
	  if ov_num_cell is null then
		lnID_SOGGETTO := weblogic_dba.ivrs_ibcode_util.getIdSoggettoByIbCode(iv_ibcode);
		ov_num_cell := applicazioni_dba.oto_pa_utility.retrieveUserMobileNumber(userSoggettoId => lnID_SOGGETTO);
	  end if;
	  return ov_num_cell;
  END BOT_GET_RECALL_PHONE;
  
  FUNCTION BOT_IS_OVERTIME(iv_bank in varchar2) RETURN VARCHAR2 IS
	ov_overtime varchar2(8) := 'FALSE';
	ov_status varchar(16);
  BEGIN
	/*
	if(weblogic_dba.ib_pkg_calendar.isfestivo(checkdate => sysdate)) then
		ov_overtime := 'TRUE';
	else
		ov_status := weblogic_dba.ib_pkg_functionStatusHandler.getFunctionStatus(inBank => iv_bank ,inFunctName => 'SELLA_BOT', inPlatform => 'IB');
		if ( ov_status = 'CLOSED' ) THEN
			ov_overtime := 'TRUE';
		end if;
	end if;
	*/
	ov_status := weblogic_dba.ib_pkg_functionStatusHandler.getFunctionStatus(inBank => iv_bank ,inFunctName => 'SELLA_BOT', inPlatform => 'IB');
	if ( ov_status = 'CLOSED' ) THEN
		ov_overtime := 'TRUE';
	end if;
	return ov_overtime;
  END BOT_IS_OVERTIME;
  
END BOT_PA_INTERFACE;
/
SHOW ERRORS PACKAGE BODY BOT_PA_INTERFACE;
/

