exec std_pkg_antutil.do_grant('IB_DBA', 'IB_PA_HB_MESSAGGI', 'SVIL_TEAM40', 'EXECUTE');
exec std_pkg_antutil.do_grant('IB_DBA', 'ib_tr_hb_visualizzazioni', 'SVIL_TEAM40', 'select,insert,update,delete');
exec std_pkg_antutil.do_grant('IB_DBA', 'ib_tr_hb_messaggi', 'SVIL_TEAM40', 'select,insert,update,delete');
exec std_pkg_antutil.do_grant('IB_DBA', 'ib_ma_hb_section', 'SVIL_TEAM40', 'select,insert,update,delete');
