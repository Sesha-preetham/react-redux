begin
  
insert into homebanking_dba.hb_pa_botactions (ba_im_code, ba_url)
values ('SME-ACC.COD', '/business//auth-code');

insert into homebanking_dba.hb_pa_botactions (ba_im_code, ba_url)
values ('SME-ASG.ATT', '/business/check-book/activate/compile');

insert into homebanking_dba.hb_pa_botactions (ba_im_code, ba_url)
values ('SME-ASG.LST', '/business/check-book/list');

insert into homebanking_dba.hb_pa_botactions (ba_im_code, ba_url)
values ('SME-ASG.NEW.CIR', '/business/check-book/request/compile');

insert into homebanking_dba.hb_pa_botactions (ba_im_code, ba_url)
values ('SME-ASG.NEW.LIB', '/business/check-book/request/compile');

insert into homebanking_dba.hb_pa_botactions (ba_im_code, ba_url)
values ('SME-ASG.NUM', '/business/check-book/list');

insert into homebanking_dba.hb_pa_botactions (ba_im_code, ba_url)
values ('SME-ASS.DEL', '/business/help/corporate');

insert into homebanking_dba.hb_pa_botactions (ba_im_code, ba_url)
values ('SME-ASS.RIN.CASA', '/business/help/corporate');

insert into homebanking_dba.hb_pa_botactions (ba_im_code, ba_url)
values ('SME-ASS.RIN.FAM', '/business/help/corporate');

insert into homebanking_dba.hb_pa_botactions (ba_im_code, ba_url)
values ('SME-ASS.RIN.PER', '/business/help/corporate');

insert into homebanking_dba.hb_pa_botactions (ba_im_code, ba_url)
values ('SME-ASS.RIN.RCA', '/business/help/corporate');

insert into homebanking_dba.hb_pa_botactions (ba_im_code, ba_url)
values ('SME-BLN.ANN.MAV', '/business/operation-list/payments');

insert into homebanking_dba.hb_pa_botactions (ba_im_code, ba_url)
values ('SME-BLN.ERR.LIQ', '/business/bank-account-transactions/list');

insert into homebanking_dba.hb_pa_botactions (ba_im_code, ba_url)
values ('SME-BLN.LST.CBI', '/business/operation-list/payments');

insert into homebanking_dba.hb_pa_botactions (ba_im_code, ba_url)
values ('SME-BLN.LST.MAV', '/business/operation-list/payments');

insert into homebanking_dba.hb_pa_botactions (ba_im_code, ba_url)
values ('SME-BLN.LST.PST', '/business/operation-list/payments');

insert into homebanking_dba.hb_pa_botactions (ba_im_code, ba_url)
values ('SME-BLM.NEW.CBI', '/business/payment-slip/cbill-pa/compile');

insert into homebanking_dba.hb_pa_botactions (ba_im_code, ba_url)
values ('SME-BLN.NEW.ENTI', '/business/payment-slip/blank-bill/compile');

insert into homebanking_dba.hb_pa_botactions (ba_im_code, ba_url)
values ('SME-BLN.NEW.IMU', '/business/payment-slip/blank-bill/compile');

insert into homebanking_dba.hb_pa_botactions (ba_im_code, ba_url)
values ('SME-BLN.NEW.MAV', '/business/payment-slip/mav-rav/compile');

insert into homebanking_dba.hb_pa_botactions (ba_im_code, ba_url)
values ('SME-BLN.NEW.PST', '/business/payment-slip/blank-bill/compile');

insert into homebanking_dba.hb_pa_botactions (ba_im_code, ba_url)
values ('SME-BLN.RIC.CBI', '/business/operation-list/payments');

insert into homebanking_dba.hb_pa_botactions (ba_im_code, ba_url)
values ('SME-BLN.RIC.MAV', '/business/operation-list/payments');

insert into homebanking_dba.hb_pa_botactions (ba_im_code, ba_url)
values ('SME-BLN.RIC.PST', '/business/operation-list/payments');

insert into homebanking_dba.hb_pa_botactions (ba_im_code, ba_url)
values ('SME-BLT.LST', '/business/operation-list/payments');

insert into homebanking_dba.hb_pa_botactions (ba_im_code, ba_url)
values ('SME-BLT.RIC', '/business/operation-list/payments');

insert into homebanking_dba.hb_pa_botactions (ba_im_code, ba_url)
values ('SME-BOL.LST', '/business/operation-list/payments');

insert into homebanking_dba.hb_pa_botactions (ba_im_code, ba_url)
values ('SME-BOL.NEW.OK', '/business/payment-slip/car-tax/compile');

insert into homebanking_dba.hb_pa_botactions (ba_im_code, ba_url)
values ('SME-BOL.NEW.RIT', '/business/payment-slip/cbill-pa/compile');

insert into homebanking_dba.hb_pa_botactions (ba_im_code, ba_url)
values ('SME-BOL.RIC', '/business/operation-list/payments');

insert into homebanking_dba.hb_pa_botactions (ba_im_code, ba_url)
values ('SME-BON.ANN.CON', '/business/bank-transfers/recurrent');

insert into homebanking_dba.hb_pa_botactions (ba_im_code, ba_url)
values ('SME-BON.ANN.PRE', '/business/operation-list/payments');

insert into homebanking_dba.hb_pa_botactions (ba_im_code, ba_url)
values ('SME-BON.CRO', '/business/operation-list/payments');

insert into homebanking_dba.hb_pa_botactions (ba_im_code, ba_url)
values ('SME-BON.ERR.LIQ', '/business/bank-account-transactions/list');

insert into homebanking_dba.hb_pa_botactions (ba_im_code, ba_url)
values ('SME-BON.LST.CON', '/business/bank-account-transactions/list');

insert into homebanking_dba.hb_pa_botactions (ba_im_code, ba_url)
values ('SME-BON.LST.GIR', '/business/bank-account-transactions/list');

insert into homebanking_dba.hb_pa_botactions (ba_im_code, ba_url)
values ('SME-BON.LST.STD', '/business/bank-account-transactions/list');

insert into homebanking_dba.hb_pa_botactions (ba_im_code, ba_url)
values ('SME-BON.MOD.CON', '/business/bank-transfers/recurrent');

insert into homebanking_dba.hb_pa_botactions (ba_im_code, ba_url)
values ('SME-BON.NEW.CNT', '/business/bank-transfers/single/compile');

insert into homebanking_dba.hb_pa_botactions (ba_im_code, ba_url)
values ('SME-BON.NEW.CON', '/business/bank-transfers/single/compile');

insert into homebanking_dba.hb_pa_botactions (ba_im_code, ba_url)
values ('SME-BON.NEW.GIR', '/business/bank-transfers/single/compile');

insert into homebanking_dba.hb_pa_botactions (ba_im_code, ba_url)
values ('SME-BON.NEW.IMM', '/business/bank-transfers/single/compile');

insert into homebanking_dba.hb_pa_botactions (ba_im_code, ba_url)
values ('SME-BON.NEW.URG', '/business/bank-transfers/single/compile');

insert into homebanking_dba.hb_pa_botactions (ba_im_code, ba_url)
values ('SME-BON.STI', '/business/bank-transfer-salary/single/compile');

insert into homebanking_dba.hb_pa_botactions (ba_im_code, ba_url)
values ('SME-BOX.ASK', '/business/inbox/list');

insert into homebanking_dba.hb_pa_botactions (ba_im_code, ba_url)
values ('SME-BOX.OPEN', '/business/inbox/list');

insert into homebanking_dba.hb_pa_botactions (ba_im_code, ba_url)
values ('SME-CAR.ATT', '/business/bank-cards/list');

insert into homebanking_dba.hb_pa_botactions (ba_im_code, ba_url)
values ('SME-CAR.CON', '/business/inbox/list');

insert into homebanking_dba.hb_pa_botactions (ba_im_code, ba_url)
values ('SME-CAR.DET', '/business/bank-cards/list');

insert into homebanking_dba.hb_pa_botactions (ba_im_code, ba_url)
values ('SME-CAR.DIS', '/business/bank-cards/list');

insert into homebanking_dba.hb_pa_botactions (ba_im_code, ba_url)
values ('SME-CAR.EC', '/business/inbox/list');

insert into homebanking_dba.hb_pa_botactions (ba_im_code, ba_url)
values ('SME-CAR.LST', '/business/bank-cards/list');

insert into homebanking_dba.hb_pa_botactions (ba_im_code, ba_url)
values ('SME-CAR.MDF.ALI', '/business/bank-cards/list');

insert into homebanking_dba.hb_pa_botactions (ba_im_code, ba_url)
values ('SME-CAR.MDF.ABI', '/business/bank-cards/list');

insert into homebanking_dba.hb_pa_botactions (ba_im_code, ba_url)
values ('SME-CAR.MDF.LMT', '/business/bank-cards/list');

insert into homebanking_dba.hb_pa_botactions (ba_im_code, ba_url)
values ('SME-CAR.MOV', '/business/bank-card-transactions/list');

insert into homebanking_dba.hb_pa_botactions (ba_im_code, ba_url)
values ('SME-CAR.NEW', '/business/bank-cards/list');

insert into homebanking_dba.hb_pa_botactions (ba_im_code, ba_url)
values ('SME-CAR.RIC', '/business/bank-recharge-transfer/recharge/compile');

insert into homebanking_dba.hb_pa_botactions (ba_im_code, ba_url)
values ('SME-CAR.RIN', '/business/bank-cards/list');

insert into homebanking_dba.hb_pa_botactions (ba_im_code, ba_url)
values ('SME-CAR.SAL', '/business/bank-cards/list');

insert into homebanking_dba.hb_pa_botactions (ba_im_code, ba_url)
values ('SME-CAR.SOS', '/business/bank-cards/list');

insert into homebanking_dba.hb_pa_botactions (ba_im_code, ba_url)
values ('SME-CC.CON', '/business/inbox/list');


insert into homebanking_dba.hb_pa_botactions (ba_im_code, ba_url)
values ('SME-CC.EC.DET', '/business/inbox/list');

insert into homebanking_dba.hb_pa_botactions (ba_im_code, ba_url)
values ('SME-CC.EC.EXP', '/business/inbox/list');

insert into homebanking_dba.hb_pa_botactions (ba_im_code, ba_url)
values ('SME-CC.EC.STA', '/business/inbox/list');

insert into homebanking_dba.hb_pa_botactions (ba_im_code, ba_url)
values ('SME-CC.EC.ISEE', '/business/inbox/list');

insert into homebanking_dba.hb_pa_botactions (ba_im_code, ba_url)
values ('SME-CC.LST', '/business/bank-accounts/list');

insert into homebanking_dba.hb_pa_botactions (ba_im_code, ba_url)
values ('SME-CC.MDF', '/business/bank-accounts/list');

insert into homebanking_dba.hb_pa_botactions (ba_im_code, ba_url)
values ('SME-CC.MOV.DET', '/business/bank-account-transactions/list');

insert into homebanking_dba.hb_pa_botactions (ba_im_code, ba_url)
values ('SME-CC.MOV.EXP', '/business/bank-account-transactions/list');

insert into homebanking_dba.hb_pa_botactions (ba_im_code, ba_url)
values ('SME-CC.MOV.STA', '/business/bank-account-transactions/list');

insert into homebanking_dba.hb_pa_botactions (ba_im_code, ba_url)
values ('SME-CC.NEW.ANT', '/business/help/corporate');

insert into homebanking_dba.hb_pa_botactions (ba_im_code, ba_url)
values ('SME-CC.NEW.POR', '/business/help/corporate');

insert into homebanking_dba.hb_pa_botactions (ba_im_code, ba_url)
values ('SME-CC.NEW.STD', '/business/help/corporate');

insert into homebanking_dba.hb_pa_botactions (ba_im_code, ba_url)
values ('SME-CC.PPR', '/business/bank-account-transactions/list');

insert into homebanking_dba.hb_pa_botactions (ba_im_code, ba_url)
values ('SME-CC.SAL.ATT', '/business/bank-account-transactions/balance');

insert into homebanking_dba.hb_pa_botactions (ba_im_code, ba_url)
values ('SME-CC.SAL.DATA', '/business/bank-account-transactions/balance');

insert into homebanking_dba.hb_pa_botactions (ba_im_code, ba_url)
values ('SME-COL.MDF', '/business/collaborator/single/compile');

insert into homebanking_dba.hb_pa_botactions (ba_im_code, ba_url)
values ('SME-COL.PRO', '/business/collaborator/single/compile');

insert into homebanking_dba.hb_pa_botactions (ba_im_code, ba_url)
values ('SME-COL.NEW', '/business/collaborator/single/compile');

insert into homebanking_dba.hb_pa_botactions (ba_im_code, ba_url)
values ('SME-F24.NN', '/business/operation-list/payments');

insert into homebanking_dba.hb_pa_botactions (ba_im_code, ba_url)
values ('SME-F24.BOZ', '/business/f24s/drafts');

insert into homebanking_dba.hb_pa_botactions (ba_im_code, ba_url)
values ('SME-F24.ERR.STM', '/business/operation-list/payments');

insert into homebanking_dba.hb_pa_botactions (ba_im_code, ba_url)
values ('SME-F24.LST', '/business/operation-list/payments');

insert into homebanking_dba.hb_pa_botactions (ba_im_code, ba_url)
values ('SME-F24.NEW', '/business/f24s/new');

insert into homebanking_dba.hb_pa_botactions (ba_im_code, ba_url)
values ('SME-FD.DEL', '/business/help/corporate');

insert into homebanking_dba.hb_pa_botactions (ba_im_code, ba_url)
values ('SME-FD.MDF', '/business/help/corporate');

insert into homebanking_dba.hb_pa_botactions (ba_im_code, ba_url)
values ('SME-FIN.FID.DET', '/business/help/corporate');

insert into homebanking_dba.hb_pa_botactions (ba_im_code, ba_url)
values ('SME-FIN.FID.RIC', '/business/help/corporate');

insert into homebanking_dba.hb_pa_botactions (ba_im_code, ba_url)
values ('SME-FIN.MUT.AMM', '/business/help/corporate');

insert into homebanking_dba.hb_pa_botactions (ba_im_code, ba_url)
values ('SME-FIN.MUT.ANN', '/business/help/corporate');

insert into homebanking_dba.hb_pa_botactions (ba_im_code, ba_url)
values ('SME-FIN.MUT.DEL', '/business/help/corporate');

insert into homebanking_dba.hb_pa_botactions (ba_im_code, ba_url)
values ('SME-FIN.MUT.INT', '/business/help/corporate');

insert into homebanking_dba.hb_pa_botactions (ba_im_code, ba_url)
values ('SME-FIN.MUT.RAT', '/business/help/corporate');

insert into homebanking_dba.hb_pa_botactions (ba_im_code, ba_url)
values ('SME-FIN.MUT.NEG', '/business/help/corporate');

insert into homebanking_dba.hb_pa_botactions (ba_im_code, ba_url)
values ('SME-FIN.MUT.STA', '/business/help/corporate');

insert into homebanking_dba.hb_pa_botactions (ba_im_code, ba_url)
values ('SME-FIN.PRE.RIF', '/business/help/corporate');

insert into homebanking_dba.hb_pa_botactions (ba_im_code, ba_url)
values ('SME-LIB.NEW', '/business/help/corporate');

insert into homebanking_dba.hb_pa_botactions (ba_im_code, ba_url)
values ('SME-OPE.AUT', '/business//to-be-authorized-operations/list');

commit;

insert into homebanking_dba.hb_pa_botactions (ba_im_code, ba_url)
values ('SME-OPE.LST', '/business/operation-list/payments');

insert into homebanking_dba.hb_pa_botactions (ba_im_code, ba_url)
values ('SME-PRO.AVV.CLO', '/business/notification-settings');

insert into homebanking_dba.hb_pa_botactions (ba_im_code, ba_url)
values ('SME-PRO.AVV.MDF', '/business/notification-settings');

insert into homebanking_dba.hb_pa_botactions (ba_im_code, ba_url)
values ('SME-PRO.AVV.SMS', '/business/notification-settings');

insert into homebanking_dba.hb_pa_botactions (ba_im_code, ba_url)
values ('SME-PRO.RBRMDF', '/business/contacts/list');

insert into homebanking_dba.hb_pa_botactions (ba_im_code, ba_url)
values ('SME-PRO.REF', '/business/help/corporate');

insert into homebanking_dba.hb_pa_botactions (ba_im_code, ba_url)
values ('SME-RCR.LST', '/business/operation-list/payments');

insert into homebanking_dba.hb_pa_botactions (ba_im_code, ba_url)
values ('SME-RCR.NEW', '/business/phone-recharges/compile');

insert into homebanking_dba.hb_pa_botactions (ba_im_code, ba_url)
values ('SME-RCR.RBR', '/business/contacts/single');

insert into homebanking_dba.hb_pa_botactions (ba_im_code, ba_url)
values ('SME-RIBA.ANN', '/business/bank-riba/list');

insert into homebanking_dba.hb_pa_botactions (ba_im_code, ba_url)
values ('SME-RIBA.LST', '/business/bank-riba/list');

insert into homebanking_dba.hb_pa_botactions (ba_im_code, ba_url)
values ('SME-RIBA.PAG.MAN', '/business/bank-riba/manual');

insert into homebanking_dba.hb_pa_botactions (ba_im_code, ba_url)
values ('SME-RIBA.PAG.OLD', '/business/bank-riba/expired');

insert into homebanking_dba.hb_pa_botactions (ba_im_code, ba_url)
values ('SME-RIBA.PAG.SCA', '/business/bank-riba/list');

insert into homebanking_dba.hb_pa_botactions (ba_im_code, ba_url)
values ('SME-RID.NEW', '/business/bank-debit/new-debit/compile');

insert into homebanking_dba.hb_pa_botactions (ba_im_code, ba_url)
values ('SME-RIS.CD.DEL', '/business/help/corporate');

insert into homebanking_dba.hb_pa_botactions (ba_im_code, ba_url)
values ('SME-RIS.CD.NEW', '/business/help/corporate');

insert into homebanking_dba.hb_pa_botactions (ba_im_code, ba_url)
values ('SME-RIS.MIX.DEL', '/business/help/corporate');

insert into homebanking_dba.hb_pa_botactions (ba_im_code, ba_url)
values ('SME-RIS.MIX.NEW', '/business/help/corporate');

insert into homebanking_dba.hb_pa_botactions (ba_im_code, ba_url)
values ('SME-RIS.TRD.DEL', '/business/help/corporate');

insert into homebanking_dba.hb_pa_botactions (ba_im_code, ba_url)
values ('SME-RIS.TRD.NEW', '/business/help/corporate');

insert into homebanking_dba.hb_pa_botactions (ba_im_code, ba_url)
values ('SME-TLP.DOM', '/business/help/corporate');

insert into homebanking_dba.hb_pa_botactions (ba_im_code, ba_url)
values ('SME-VAE.TC', '/business/help/corporate');

commit;

exception when others then 
  rollback;
end;
/

