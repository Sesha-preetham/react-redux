import "core-js/stable"

import React from "react";
import ReactDOM from "react-dom";

import "./css/chat/style.css";
import App from "./scripts/App";

ReactDOM.render(<App />, document.getElementById("surveycontainer"));
