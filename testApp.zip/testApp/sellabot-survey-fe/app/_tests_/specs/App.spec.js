import React from "react";
import TestRenderer from "react-test-renderer";
import App from "../../scripts/App";

describe("<App />", () => {
  it("React Test Renderer", () => {
    const testRenderer = TestRenderer.create(<App />);
    expect(testRenderer.toJSON()).toMatchSnapshot();
  });
});
