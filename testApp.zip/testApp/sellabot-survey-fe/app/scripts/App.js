import React, { useReducer } from "react";

import { chatInitialState, chatReducer } from "./ChatFE/Reducer/ChatReducer";
import { findFinalComponentByKey } from "./ChatFE/Routes/ChatFEComponents";

export const ChatFEContext = React.createContext(null);

const App = () => {
  const [state, dispatch] = useReducer(chatReducer, chatInitialState);

  let CurrentChatFEComponent = findFinalComponentByKey("CHAT_MODULE");

  return (
    <ChatFEContext.Provider value={{ state, dispatch }}>
      <CurrentChatFEComponent />
    </ChatFEContext.Provider>
  );
};

export default App;
