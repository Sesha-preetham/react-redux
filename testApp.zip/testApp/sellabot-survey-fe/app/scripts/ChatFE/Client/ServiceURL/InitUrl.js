const InitUrls = {
  // SELLA BOT URLs
  preference: "/srvbot/preference",
  answer: "/srvbot/answer",
  continue: "/srvbot/continue"
};

export default InitUrls;
