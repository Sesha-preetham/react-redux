import BEUrls from "./ServiceURL/index";

export const isMock = false;

export const urlBase = isMock ? "http://localhost:9090" : "";
export const serviceUrls = BEUrls(urlBase);

export function beServiceUrls() {
  return serviceUrls;
}
