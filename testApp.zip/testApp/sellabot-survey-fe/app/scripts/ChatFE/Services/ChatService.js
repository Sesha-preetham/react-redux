import Axios from "axios";
import { v4 as uuidv4 } from "uuid";

import { beServiceUrls } from "../Client/ClientProperties";
import SurveyBotError from "../Utils/SurveyBotError";

export const surveyPrefService = async (request = {}) => {
  let prefResponse = await Axios.post(beServiceUrls().preference, request)
    .then((response) => {
      return response.data;
    })
    .then((responseData) => {
      if (responseData && responseData.status == "OK") {
        return responseData.data;
      } else if (responseData && responseData.status == "EXCEPTION") {
        throw new SurveyBotError(responseData.errorMessageCode);
      }
    })
    .then((responseClientData) => {
      return responseClientData.client;
    })
    .catch((err) => {
      throw err;
    });
  return prefResponse;
};

export const surveyAnswerService = async (request = {}) => {
  let nextSurveyData = await Axios.post(beServiceUrls().answer, request)
    .then((response) => {
      return response.data;
    })
    .then((responseData) => {
      if (responseData && responseData.status == "OK") {
        return responseData.data;
      } else if (responseData && responseData.status == "EXCEPTION") {
        throw new SurveyBotError(responseData.errorMessageCode);
      }
    })
    .then((responseClientData) => {
      return responseClientData.nextSurvey;
    })
    .catch((err) => {
      throw err;
    });
  return nextSurveyData;
};

export const surveyContinueService = async (request = {}) => {
  let surveys = await Axios.post(beServiceUrls().continue, request)
    .then((response) => {
      return response.data;
    })
    .then((responseData) => {
      if (responseData && responseData.status == "OK") {
        return responseData.data;
      } else if (responseData && responseData.status == "EXCEPTION") {
        throw new SurveyBotError(responseData.errorMessageCode);
      }
    })
    .then((responseClientData) => {
      return responseClientData.surveys;
    })
    .catch((err) => {
      throw new Error(err);
    });
  return surveys;
};

export const addUniqueIdProgressInSurveys = (surveys = []) => {
  surveys.map((survey, index) => {
    survey.uniqueId = uuidv4();
    survey.progress = "UNANSWERED";
    survey.value = "";
    return survey;
  });
  return [...surveys];
};

export const updateProgressAndValueKVPByUniqueIdInSurveys = (
  progress = "",
  value = "",
  uniqueId = "",
  surveys = []
) => {
  let index = surveys.findIndex((survey) => {
    return survey.uniqueId === uniqueId;
  });
  let updateSurvey = surveys[index];
  updateSurvey.progress = progress;
  if (value) {
    updateSurvey.value = value;
  }
  return [...surveys];
};
