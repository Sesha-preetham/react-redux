import React from "react";

import logosellait2x from "../../../../images/logo-sellait@2x.png";

const ChatHeader = React.forwardRef((props, ref) => {
  return (
    <>
      <div className="header-wrap row">
        <div className="chat-icon-left col-sm-6 col-xs-6">
          <img
            src={logosellait2x}
            className="chat-header-logo"
            alt="Logo Sella.it"
          ></img>
        </div>
        {/* <div className="chat-icon-right col-sm-6 col-xs-6 pull-right">
          {isWebBrowser ? (
            <img
              src={iconmonstrprinter3240}
              className="printer-close-icon"
              alt="Logo Sella.it"
              onClick={() => {}}
            ></img>
          ) : (
            ""
          )}
          <img
            src={closepng}
            className="printer-close-icon"
            alt="Logo Sella.it"
            onClick={chuidiHandleClick}
          ></img>
        </div> */}
      </div>
    </>
  );
});

export default ChatHeader;
