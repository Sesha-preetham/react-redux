import React, { useContext, useEffect } from "react";

import { ChatFEContext } from "../../../App";
import CModal from "../../CommonComponents/CModal";
import ChatHeader from "./ChatHeader";
import ChatMessageArea from "./ChatMessageArea";

import {
  addUniqueIdProgressInSurveys,
  surveyAnswerService,
  surveyPrefService,
} from "../../Services/ChatService";

const ChatComponent = () => {
  let chatFEContext = useContext(ChatFEContext);

  let { dispatch } = chatFEContext;

  let { surveys, modal } = chatFEContext.state;
  let { modalShow, modalContent } = modal;

  useEffect(() => {
    onMount();
  }, []);

  let onMount = async () => {
    let prefResponse;
    try {
      prefResponse = await surveyPrefService();
    } catch (error) {
      console.error(error);
      onModalTrigger({
        modalShow: true,
        modalContent: error.message,
      });
    }

    let tempClientData = {};

    console.log(prefResponse);

    if (prefResponse) {
      tempClientData = {
        ...tempClientData,
        surveyId: prefResponse.surveyId ? prefResponse.surveyId : "",
        code: prefResponse.code ? prefResponse.code : "",
        name: prefResponse.name ? prefResponse.name : "",
        nickName: prefResponse.nickName ? prefResponse.nickName : "",
        email: prefResponse.email ? prefResponse.email : "",
        companyId: prefResponse.companyId ? prefResponse.companyId : "",
        companyCode: prefResponse.companyCode ? prefResponse.companyCode : "",
        contactNumber: prefResponse.contactNumber
          ? prefResponse.contactNumber
          : "",
      };
    }
    let tempSurveys = [];

    if (prefResponse) {
      try {
        let nextSurveyData = await surveyAnswerService({
          type: "INITIAL",
          surveyId: prefResponse.surveyId && prefResponse.surveyId,
        });
        if (nextSurveyData) {
          tempSurveys = [...tempSurveys, nextSurveyData];
        }
      } catch (error) {
        console.error(error);
        onModalTrigger({
          modalShow: true,
          modalContent: error.message,
        });
      }
    }
    dispatch({
      type: "UPDATE_SURVEY_STATE",
      payload: {
        clientData: {
          ...tempClientData,
        },
        surveys: addUniqueIdProgressInSurveys(tempSurveys),
      },
    });
  };

  const onModalTrigger = (modal) => {
    dispatch({
      type: "UPDATE_SURVEY_STATE",
      payload: {
        modal: {
          modalShow: modal.modalShow,
          modalContent: modal.modalContent,
        },
      },
    });
  };

  return (
    <div className="">
      <CModal
        configuration={{
          uniqueID: "errorShowModal",
          modalShow: modalShow,
          modalCloseShow: true,
          events: {
            onClose: () => {
              onModalTrigger({
                modalShow: false,
                modalContent: "",
              });
            },
          },
        }}
      >
        <p className="error-modal-text">{modalContent}</p>
        <button
          id="closeModal"
          className="orange-btn"
          onClick={() => {
            onModalTrigger({
              modalShow: false,
              modalContent: "",
            });
          }}
        >
          Close
        </button>
      </CModal>
      <ChatHeader />
      <div className="chat-body">
        {surveys && surveys.length > 0 && (
          <ChatMessageArea onModalTrigger={onModalTrigger} />
        )}
      </div>
    </div>
  );
};

export default ChatComponent;
