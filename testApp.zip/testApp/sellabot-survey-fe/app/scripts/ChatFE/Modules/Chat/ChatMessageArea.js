import React, { useContext, useState, useEffect, useRef } from "react";
import { v4 as uuidv4 } from "uuid";

import ChatInput from "../../CommonComponents/ChatInput";
import ChatTextLoading from "../../CommonComponents/ChatTextLoading";
import { ChatFEContext } from "../../../App";
import icn_logo2x from "../../../../images/newstyle/icn_logo@2x.png";
import { surveyAnswerService } from "../../Services/ChatService";
import ChatButtonList from "../../CommonComponents/ChatButton";

const ChatMessageArea = (props) => {
  let chatFEContext = useContext(ChatFEContext);

  let chatPanelBodyRef = useRef();

  let { dispatch } = chatFEContext;

  let { clientData, surveys } = chatFEContext.state;
  let { surveyId, name, nickName, companyId, companyCode } = clientData;

  const { onModalTrigger } = props;

  const chatScrollDown = () => {
    $(chatPanelBodyRef.current).animate(
      { scrollTop: $(chatPanelBodyRef.current).prop("scrollHeight") },
      500
    );
  };

  const onClickAnswer = async (questionId, currentAnswer) => {
    console.log(currentAnswer);

    let requestData = {
      type: "CONTINUE",
      surveyId: surveyId,
      quesId: questionId,
      answer: {
        id: currentAnswer.id,
        labelcode: currentAnswer.labelcode,
        value: currentAnswer.value,
      },
    };

    dispatch({
      type: "UPDATE_SURVEY_LIST_BY_UNIQUEID",
      payload: {
        progress: "LOADING",
        uniqueId: currentAnswer.uniqueId,
      },
    });

    let nextSurveyData;
    try {
      nextSurveyData = await surveyAnswerService(requestData);
    } catch (error) {
      console.error(error);
      onModalTrigger({
        modalShow: true,
        modalContent: error.message,
      });
    }
    if (nextSurveyData) {
      dispatch({
        type: "UPDATE_SURVEY_LIST_BY_UNIQUEID",
        payload: {
          value: currentAnswer.labelcode,
          progress: "ANSWERED",
          uniqueId: currentAnswer.uniqueId,
        },
      });
      dispatch({
        type: "UPDATE_SURVEY_LIST",
        payload: {
          surveys: [nextSurveyData],
        },
      });
      chatScrollDown();
    }
  };

  return (
    <div ref={chatPanelBodyRef} className="chat-panel-body">
      {surveys.map((survey, index) => {
        let messageString = survey.question ? survey.question : "";

        return (
          <div key={uuidv4()}>
            <div
              className={`chat-message chat-message--bank ${
                !messageString ? "emptymessage" : ""
              }`}
            >
              {messageString ? (
                <>
                  <img src={icn_logo2x} className="reply-icon"></img>
                  <p className="chat-message__text" id={`msg_${index}`}>
                    <span className="msgString">{messageString}</span>
                  </p>
                </>
              ) : null}
            </div>

            {survey.progress == "ANSWERED" ? (
              <div className="chat-message chat-message--user">
                <span className="chat-message__sender initial">ME</span>
                <span className="chat-message__sender name">{name}</span>
                <p className="pull-right chat-message__text">
                  <span className="msgString">{survey.value}</span>
                </p>
              </div>
            ) : survey.progress == "UNANSWERED" && survey.type == "BUTTON" ? (
              <ChatButtonList
                uniqueId={survey.uniqueId}
                questionId={survey.id}
                answers={survey.answers}
                onClick={onClickAnswer}
              />
            ) : survey.progress == "UNANSWERED" &&
              survey.type == "PHONENUMBER" ? (
              <ChatInput
                defaultValue="9876XXXXXX"
                onClick={(object) => {
                  console.log(object);
                }}
              />
            ) : survey.progress == "LOADING" ? (
              <ChatTextLoading />
            ) : null}
          </div>
        );
      })}
    </div>
  );
};

export default ChatMessageArea;
