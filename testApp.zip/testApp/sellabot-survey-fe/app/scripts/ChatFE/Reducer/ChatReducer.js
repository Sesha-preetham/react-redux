import {
  addUniqueIdProgressInSurveys,
  updateProgressAndValueKVPByUniqueIdInSurveys,
} from "../Services/ChatService";

window.isInprogress = false;

export const chatInitialState = {
  modal: {
    modalShow: false,
    modalContent: "",
  },
  clientData: {
    surveyId: "",
    code: "",
    name: "",
    nickName: "",
    email: "",
    companyId: "",
    companyCode: "",
    contactNumber: "",
  },
  surveys: [],
  isWebBrowser:
    navigator.userAgent.toLowerCase().indexOf("mobi") < 0 &&
    navigator.userAgent.toLowerCase().indexOf("android") < 0,
};

export const chatReducer = (state, action) => {
  switch (action.type) {
    case "UPDATE_SURVEY_STATE":
      return {
        ...state,
        ...action.payload,
      };
    case "UPDATE_SURVEY_LIST":
      console.log("UPDATE_SURVEY_LIST");
      console.log("prevState", state.surveys);
      console.log("currentState", action.payload);
      return {
        ...state,
        surveys: [
          ...state.surveys,
          ...addUniqueIdProgressInSurveys(action.payload.surveys),
        ],
      };
    case "UPDATE_SURVEY_LIST_BY_UNIQUEID":
      console.log("UPDATE_SURVEY_LIST_BY_UNIQUEID");
      console.log("prevState", state.surveys);
      console.log("currentState", action.payload);
      return {
        ...state,
        surveys: [
          ...updateProgressAndValueKVPByUniqueIdInSurveys(
            action.payload.progress,
            action.payload.value,
            action.payload.uniqueId,
            state.surveys
          ),
        ],
      };
    case "RESET_CHAT":
      return chatInitialState;
    default:
      return state;
  }
};
