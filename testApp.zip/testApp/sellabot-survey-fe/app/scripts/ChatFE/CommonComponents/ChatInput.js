import React, { useState } from "react";

const ChatInput = (props) => {
  const { defaultValue = "", onClick = () => {} } = props;
  const [value, setValue] = useState(defaultValue);

  const onChangePhoneNumber = (event) => {
    setValue(event.target.value);
  };

  const onClickPhoneNumber = () => {
    onClick({
      currentValue: value,
    });
  };

  return (
    <div className="answer-area">
      <div className="answer-area-phonenumber">
        <input
          type="text"
          className="phonenumber-input"
          onChange={onChangePhoneNumber}
          value={value}
        />
        <button className="phonenumber-btn" onClick={onClickPhoneNumber}>
          enter
        </button>
      </div>
    </div>
  );
};

export default ChatInput;
