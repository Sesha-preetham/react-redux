import React from "react";

const ChatTextLoading = (props) => {
  return (
    <div className="answer-area">
      <div className="answer-area-loading">
        <div className="loader"></div>
      </div>
    </div>
  );
};

export default ChatTextLoading;
