import React from "react";
import { v4 as uuidv4 } from "uuid";

const ChatButton = (props) => {
  const { onClickButton, answer } = props;
  return (
    <div className="answer-area-boolean">
      <button
        className="boolean-btn"
        type="button"
        onClick={() => {
          onClickButton({ ...answer });
        }}
      >
        {answer.labelcode}
      </button>
    </div>
  );
};

const ChatButtonList = (props) => {
  const { uniqueId = "", questionId, onClick = () => {}, answers = [] } = props;
  return (
    <div className="answer-area">
      {answers.map((answer, index) => {
        return (
          <ChatButton
            key={uuidv4()}
            questionId={questionId}
            answer={answer}
            onClickButton={(currentObject) => {
              onClick(questionId, {
                uniqueId,
                ...currentObject,
              });
            }}
          />
        );
      })}
    </div>
  );
};

export default ChatButtonList;
