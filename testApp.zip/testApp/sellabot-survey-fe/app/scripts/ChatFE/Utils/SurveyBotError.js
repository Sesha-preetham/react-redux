export default class SurveyBotError extends Error {
  constructor(message) {
    super(message);
    this.name = "SurveyBotError";
    this.message = message;
  }

  toJSON() {
    return {
      error: {
        name: this.name,
        message: this.message,
        stacktrace: this.stack,
      },
    };
  }
}
