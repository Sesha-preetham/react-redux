import React from "react";
import ChatComponent from "../Modules/Chat/ChatComponent";

const ChatFEComponents = {
  CHAT_MODULE: () => {
    return <ChatComponent />;
  },
  noMatch: () => {
    return <div>Oops Something went wrong!</div>;
  },
};

export const findFinalComponentByKey = (keyName) => {
  if (ChatFEComponents[keyName]) {
    return ChatFEComponents[keyName];
  } else {
    return ChatFEComponents.noMatch;
  }
};
