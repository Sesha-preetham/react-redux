const initUrlsWithPath = [
  {
    postUrl: "/srvbot/preference",
    path: "server/src/init/preference.json",
  },
  {
    postUrl: "/srvbot/answer",
    path: "server/src/init/answer.json",
  },
  {
    postUrl: "/srvbot/continue",
    path: "server/src/init/continue.json",
  },
];

export default initUrlsWithPath;
