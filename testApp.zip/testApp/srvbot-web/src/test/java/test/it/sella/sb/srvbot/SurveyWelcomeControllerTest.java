package test.it.sella.sb.srvbot;

import static org.junit.Assert.assertEquals;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.support.AnnotationConfigContextLoader;
import org.springframework.test.util.ReflectionTestUtils;

import it.sella.sb.dao.survey.SurveyDAO;
import it.sella.sb.im.response.BaseResponse.BaseStatusEnum;
import it.sella.sb.survey.AnswerResponseDTO;
import it.sella.sb.survey.QuestionAnswerResponseDTO;
import it.sella.sb.survey.SurveyDTO;
import it.sella.sb.survey.SurveyRequestDTO;
import it.sella.sb.survey.SurveyResponseDTO;
import it.sella.sb.surveybot.controller.SurveyWelcomeController;
import it.sella.sb.surveybot.facade.SurveyFacade;
import it.sella.sb.util.SBCONSTANT;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(loader=AnnotationConfigContextLoader.class)
public class SurveyWelcomeControllerTest {

	//private static final Logger LOGGER = Logger.getLogger(SurveyWelcomeControllerTest.class);
	
	@Spy
	SurveyWelcomeController surveyWelcomeController;
	
	@InjectMocks
	SurveyFacade surveyFacade;
	
	@Mock
	SurveyDAO surveyDAO;
	
	@Before()
	public void init(){
		MockitoAnnotations.initMocks(this);
		ReflectionTestUtils.setField(surveyWelcomeController, "surveyFacade", surveyFacade);
	}
	
	@Test()
	public void getInitCall(){
		
		HttpServletRequest httpRequest = Mockito.mock(HttpServletRequest.class);
		HttpSession httpSession = Mockito.mock(HttpSession.class);
		
		SurveyDTO surveyDTO = new SurveyDTO();
		surveyDTO.setSmsKey("ABCD");
		
		Mockito.doNothing().when(surveyDAO).updateSurveyDetails(Mockito.anyString(),Mockito.anyLong(),Mockito.anyBoolean(),Mockito.anyString());
		Mockito.when(surveyDAO.getCustomerSurveyDetails(Mockito.anyString())).thenReturn(surveyDTO);
		
		surveyWelcomeController.getSurvey("", httpRequest, httpSession);
		assertEquals("ABCD", surveyDTO.getSmsKey());
	}
	
	@Test()
	public void getPreferenceCall(){
		HttpServletRequest httpRequest = Mockito.mock(HttpServletRequest.class);
		HttpSession httpSession = Mockito.mock(HttpSession.class);
		
		SurveyDTO surveyDTO = new SurveyDTO();
		surveyDTO.setSmsKey("ABCD");
		
		Mockito.when(httpSession.getAttribute(SBCONSTANT.SURVEY_DETAILS.VALUE)).thenReturn(surveyDTO);
		
		SurveyResponseDTO response = surveyWelcomeController.preference(httpRequest, httpSession);
		assertEquals(BaseStatusEnum.OK.name(), response.getStatus());
	}
	
	@Test()
	public void getAnswerCall(){
		HttpSession httpSession = Mockito.mock(HttpSession.class);
		
		SurveyRequestDTO request = new SurveyRequestDTO();
		request.setType("INITIAL");
		request.setSurveyId(61L);
		
		SurveyDTO surveyDTO = new SurveyDTO();
		surveyDTO.setSmsKey("ABCD");
		surveyDTO.setSurveyId(61L);
		
		AnswerResponseDTO answerResponseDTO =  new AnswerResponseDTO();
		
		Mockito.when(httpSession.getAttribute(SBCONSTANT.SURVEY_DETAILS.VALUE)).thenReturn(surveyDTO);
		Mockito.when(surveyDAO.answer(request)).thenReturn(answerResponseDTO);
		
		QuestionAnswerResponseDTO response = surveyWelcomeController.answer(request, httpSession);
		assertEquals(BaseStatusEnum.OK.name(), response.getStatus());
	}

}
