package it.sella.sb.surveybot.filter;

import java.io.IOException;
import java.io.Serializable;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

import org.apache.log4j.Logger;
/*
 * Solve the UTF-8 Encoding, Forcing it on all Pages
 */
public class UTF8Filter implements Filter, Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private static final Logger LOGGER = Logger.getLogger(UTF8Filter.class);

	@Override
	public void destroy() {
		
	}

	@Override
	public void doFilter(ServletRequest request,
			ServletResponse response, FilterChain chain) throws IOException, ServletException 
	{
		try {
			LOGGER.debug("<------ UTF8Filter doFilter start ------>");
			request.setCharacterEncoding("UTF-8");
			response.setCharacterEncoding("UTF-8");
			chain.doFilter(request, response);
			LOGGER.debug("<------ UTF8Filter doFilter end ------>");
		} catch (Exception e) {
			LOGGER.error("<------ Exception UTF8Filter doFilter() ------>"+e.getMessage(),e);
		}
		
	}

	@Override
	public void init(FilterConfig arg0) throws ServletException 
	{

	}

}
