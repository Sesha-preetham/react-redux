package it.sella.sb.surveybot.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import it.sella.sb.survey.QuestionAnswerResponseDTO;
import it.sella.sb.survey.SurveyDTO;
import it.sella.sb.survey.SurveyRequestDTO;
import it.sella.sb.survey.SurveyResponseDTO;
import it.sella.sb.surveybot.facade.SurveyFacade;
import it.sella.sb.util.SBCONSTANT;

@Controller
public class SurveyWelcomeController {

	@Autowired
	SurveyFacade surveyFacade;
	
	private static final Logger LOGGER = Logger.getLogger(SurveyWelcomeController.class);

	@RequestMapping(value = "/{smskey}", method = { RequestMethod.GET })
	public String getSurvey(@PathVariable String smskey, final HttpServletRequest request, HttpSession httpSession) {
		LOGGER.info("Inside SurveyWelcomeController getSurvey() smsKey ---> "+smskey);
		SurveyDTO surveyDTO = surveyFacade.getWelcomeSurveydDetails(smskey);
		httpSession.setAttribute(SBCONSTANT.SURVEY_DETAILS.VALUE, surveyDTO);
		LOGGER.info("Inside SurveyWelcomeController getSurvey() surveyID "+surveyDTO.getSurveyId());
		return "survey";
	}
	
	@RequestMapping(value = "/preference", method = { RequestMethod.POST }, produces="application/json")
	public @ResponseBody SurveyResponseDTO preference(final HttpServletRequest request, HttpSession httpSession) {
		LOGGER.info("Inside SurveyWelcomeController preference()");
		SurveyResponseDTO response = surveyFacade.preference(httpSession);
		LOGGER.info("Inside SurveyWelcomeController preference() surveyID " + response.getData().getClient().getSurveyId());
		return response;
	}
	
	@RequestMapping(value = "/answer", method = { RequestMethod.POST }, produces="application/json")
	public @ResponseBody QuestionAnswerResponseDTO answer(@RequestBody SurveyRequestDTO request, HttpSession httpSession) {
		LOGGER.info("Inside SurveyWelcomeController answer() surveyID " + request.getSurveyId());
		QuestionAnswerResponseDTO response  = surveyFacade.answer(request, httpSession);
		LOGGER.info("Inside SurveyWelcomeController answer() ");
		return response;
	}

}
