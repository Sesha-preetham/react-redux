package it.sella.sb.surveybot.filter;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import it.sella.sb.survey.SurveyDTO;

@Component("sessionFilter")
public class SessionFilter extends BaseFilter implements Filter {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(SessionFilter.class);

	@Override
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain filterChain)
			throws IOException, ServletException {
		LOGGER.info(" SessionFilter doFilter() >>> ");

		final HttpServletRequest hReq = (HttpServletRequest) request;
		final HttpServletResponse hRes = (HttpServletResponse) response;
		hRes.addHeader("Cache-Control","no-cache, no-store, must-validate");//HTTP 1.1
		hRes.addHeader("Pragma", "no-cache");//HTTP 1.0
		hRes.setDateHeader("Expires", 0);//prevents caching at the proxy server
        
        //IE compatibility for last version usage
		hRes.addHeader("X-UA-Compatible","IE=edge");		
		hRes.addHeader("X-FRAME-OPTIONS", "SAMEORIGIN");
		
		HttpSession session = hReq.getSession();
		SurveyDTO surveyDTO = (SurveyDTO) session.getAttribute("SURVEY_DETAILS");
		if (session != null) {
			if (isValidUrl(hReq) && (surveyDTO == null || surveyDTO.getSmsKey() == null)) {
				LOGGER.info(" SessionFilter doFilter session not avilable >>> ");
				hRes.sendError(HttpServletResponse.SC_FORBIDDEN);
			} else {
				filterChain.doFilter(request, response);
			}
		}
	}
	
	private boolean isValidUrl (final HttpServletRequest hReq) {
		LOGGER.debug(" RequestURI :: " +hReq.getRequestURI() != null ? hReq.getRequestURI() : "null");
		return hReq.getRequestURI() != null
				&& (hReq.getRequestURI().endsWith("/preference") || hReq.getRequestURI().endsWith("/answer"));
	}
	
	@Override
	public void init(FilterConfig filterConfig) throws ServletException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void destroy() {
		// TODO Auto-generated method stub
		
	}
}
