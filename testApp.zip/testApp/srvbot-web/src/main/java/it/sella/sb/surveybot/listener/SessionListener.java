package it.sella.sb.surveybot.listener;

import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpSessionEvent;
import javax.servlet.http.HttpSessionListener;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

import it.sella.sb.common.util.StringUtility;
import it.sella.sb.dao.survey.SurveyDAO;
import it.sella.sb.survey.SurveyDTO;

public class SessionListener implements HttpSessionListener {

	private static final Logger LOGGER = Logger.getLogger(SessionListener.class);
	
	@Autowired
	SurveyDAO surveyDAO;

	@Override
	public void sessionCreated(HttpSessionEvent paramHttpSessionEvent) {
		LOGGER.debug("SessionCreated -->"+paramHttpSessionEvent.getSession().getId());
	}

	@Override
	public void sessionDestroyed(HttpSessionEvent paramHttpSessionEvent) {
		HttpSession session = paramHttpSessionEvent.getSession();
		String isConsentUpdated = (String)session.getAttribute("CONSENT_UPDATED");
		SurveyDTO surveyDTO = (SurveyDTO)session.getAttribute("SURVEY_DETAILS");
		if(StringUtility.isEmpty(isConsentUpdated) && surveyDTO!=null){
			LOGGER.info("SessionDestroyed getSmsKey-->"+surveyDTO.getSmsKey());
			LOGGER.info("SessionDestroyed getSurveyId-->"+surveyDTO.getSurveyId());
			surveyDAO.updateSurveyDetails("CONSENT", surveyDTO.getId(),false,"N");
		}
	}

}
