package it.sella.sb.surveybot.facade;

import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import it.sella.sb.common.exception.SBBaseThrowable;
import it.sella.sb.dao.survey.SurveyDAO;
import it.sella.sb.im.response.BaseResponse.BaseStatusEnum;
import it.sella.sb.survey.AnswerResponseDTO;
import it.sella.sb.survey.ClientSurveyResponseDTO;
import it.sella.sb.survey.QuestionAnswerResponseDTO;
import it.sella.sb.survey.SurveyDTO;
import it.sella.sb.survey.SurveyRequestDTO;
import it.sella.sb.survey.SurveyResponseDTO;
import it.sella.sb.util.SBCONSTANT;

@Component
public class SurveyFacade {
	
	@Autowired
	SurveyDAO surveyDAO;
	
	private static final Logger LOGGER = Logger.getLogger(SurveyFacade.class);
	
	public SurveyDTO getWelcomeSurveydDetails(final String smsKey){
		LOGGER.info("Inside SurveyFacade getWelcomeSurveydDetails()");
		SurveyDTO surveyDTO =null;
		try {
			surveyDTO = surveyDAO.getCustomerSurveyDetails(smsKey);
			surveyDAO.updateSurveyDetails(SBCONSTANT.SUR_STARTED.VALUE, surveyDTO.getId(),true,null);//to update survey start date
		} catch (SBBaseThrowable e) {
			LOGGER.error("SurveyFacade getWelcomeSurveydDetails() SBBaseThrowable error message : "+e.getMessage(),e);
		} catch (Exception e) {
			LOGGER.error("SurveyFacade getWelcomeSurveydDetails() chatHistory Exception error message : "+e.getMessage(),e);
		}
		return surveyDTO;
	}
	
	public SurveyResponseDTO preference(final HttpSession httpSession){
		LOGGER.info("Inside SurveyFacade preference()");
		SurveyResponseDTO response = new SurveyResponseDTO();
		try {
			SurveyDTO surveyDTO = (SurveyDTO) httpSession.getAttribute(SBCONSTANT.SURVEY_DETAILS.VALUE);
			ClientSurveyResponseDTO data = new ClientSurveyResponseDTO();
			data.setClient(surveyDTO);
			response.setData(data);
			LOGGER.info("Exit SurveyFacade preference()");
		} catch (SBBaseThrowable e) {
			LOGGER.error("SurveyFacade preference() SBBaseThrowable error message : "+e.getMessage(),e);
			response.setStatus(BaseStatusEnum.EXCEPTION);
			response.setErrorMessageCode(e.getCode());
		} catch (Exception e) {
			LOGGER.error("SurveyFacade preference() chatHistory Exception error message : "+e.getMessage(),e);
			response.setStatus(BaseStatusEnum.EXCEPTION);
			response.setErrorMessageCode(SBBaseThrowable.SB_ERR_9999);
		}
		return response;
	}
	
	public QuestionAnswerResponseDTO answer(final SurveyRequestDTO request, final HttpSession httpSession){
		LOGGER.info("Inside SurveyFacade answer()");
		SurveyDTO surveyDTO = (SurveyDTO) httpSession.getAttribute(SBCONSTANT.SURVEY_DETAILS.VALUE);
		QuestionAnswerResponseDTO response = new QuestionAnswerResponseDTO();
		AnswerResponseDTO answerResponseDTO=null;
		String nextQueType="";
		try {
			
			if(SBCONSTANT.INITIAL.VALUE.equalsIgnoreCase(request.getType())){
				answerResponseDTO = surveyDAO.answer(request);
			}else {
				final Long answerId = request.getAnswer().getId();
				final Long questionId = request.getQuesId();
				nextQueType = surveyDAO.getNextQuestionType(questionId, answerId);
				LOGGER.info("Inside SurveyFacade answer() nextQueType >>> " + nextQueType);
				if(SBCONSTANT.END.VALUE.equalsIgnoreCase(nextQueType)){
					answerResponseDTO = surveyDAO.getEndQuestionDetails(questionId, answerId);
					surveyDAO.updateSurveyDetails(SBCONSTANT.SUR_COMPL.VALUE, surveyDTO.getId(),true,null);// to update the survey end time
					if(request.getAnswer().getValue().contains("CONS-Y")){
						surveyDAO.updateSurveyDetails(SBCONSTANT.CONSENT.VALUE, surveyDTO.getId(),false,"Y");
					}else{
						surveyDAO.updateSurveyDetails(SBCONSTANT.CONSENT.VALUE, surveyDTO.getId(),false,"N");
					}
					httpSession.setAttribute(SBCONSTANT.CONSENT_UPDATED.VALUE, SBCONSTANT.YES.VALUE);
				}else{
					answerResponseDTO = surveyDAO.answer(request);//continue call
				}
			}
			response.setData(answerResponseDTO);
			LOGGER.info("Exit SurveyFacade answer()");
			
			//below is to trace the question and answers
			if(!SBCONSTANT.INITIAL.VALUE.equalsIgnoreCase(request.getType())){
				surveyDAO.botSMSTrace(request, (SurveyDTO) httpSession.getAttribute(SBCONSTANT.SURVEY_DETAILS.VALUE));
				LOGGER.info("Trace Inserted Successfully!!!");
			}
			
			//below is to invalidate session
			if(SBCONSTANT.END.VALUE.equalsIgnoreCase(nextQueType)){
				httpSession.invalidate();
			}
		} catch (SBBaseThrowable e) {
			LOGGER.error("SurveyFacade answer() SBBaseThrowable error message : "+e.getMessage(),e);
			response.setStatus(BaseStatusEnum.EXCEPTION);
			response.setErrorMessageCode(e.getCode());
		} catch (Exception e) {
			LOGGER.error("SurveyFacade answer() chatHistory Exception error message : "+e.getMessage(),e);
			response.setStatus(BaseStatusEnum.EXCEPTION);
			response.setErrorMessageCode(SBBaseThrowable.SB_ERR_9999);
		}
		return response;
	}

}
