'use strict';

require.config({
    urlArgs: "v=74",
    paths: {
        'react': 'vendor/react',
        'react-dom': 'vendor/react-dom',
        'axios': 'vendor/axios.min',
        'jquery': 'vendor/jquery.min',
        'polyfill': 'vendor/polyfill'
    },
    shim: {
        'axios': { deps: ['polyfill'] }
    }
});
require(['chat'], function (Chat) {
    window.chatPath = window.location.hostname.indexOf("localhost") != -1 ? "http://localhost:8080" : "";
    Chat();
}, function (err) {});
require.onError = function (error) {
    console.error('ERROR: unable to load module', error.stack);
};