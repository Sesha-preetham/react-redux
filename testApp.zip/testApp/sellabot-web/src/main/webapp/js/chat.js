'use strict';

var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };

define(['react', 'react-dom', 'polyfill', 'axios', 'jquery'], function (React, ReactDOM, polyfill, axios, jquery) {

    'use strict';

    var CommentBoxComp = React.createClass({
        displayName: 'CommentBoxComp',

        render: function render() {
            var question = this.props.ques;
            var optionId = question.options[0].optionId;
            return React.createElement(
                'div',
                null,
                React.createElement(
                    'h3',
                    { className: 'poll-subtitle' },
                    question.questionDesc
                ),
                React.createElement('textarea', { name: '1_4_9', 'data-optionId':optionId, className: 'poll-textarea', id: 'chatTextArea' })
            );
        }
    });

    var FutureChatComp = React.createClass({
        displayName: 'FutureChatComp',

        render: function render() {
            var question = this.props.ques;
            return React.createElement(
                'div',
                null,
                React.createElement(
                    'h3',
                    { className: 'poll-subtitle' },
                    question.questionDesc
                ),
                question.options.map(function (item) {
                    return React.createElement(
                        'div',
                        { className: 'future_chat' },
                        React.createElement('input', { type: 'radio', name: 'yesno', value: item.optionId, id: 'CHAT_NEEDED_' + item.optionId }),
                        React.createElement(
                            'label',
                            { htmlFor: 'CHAT_NEEDED_' + item.optionId },
                            ' ',
                            item.optionDesc
                        )
                    );
                }.bind(this))
            );
        }
    });

    var SimelyComp = React.createClass({
        displayName: 'SimelyComp',

        selectedSmiley: function selectedSmiley(event) {
            $('.smiley').removeClass('active');
            $(event.currentTarget).find('.smiley').addClass("active");
        },
        render: function render() {
            var question = this.props.ques;
            return React.createElement(
                'div',
                { className: 'poll-content' },
                React.createElement(
                    'h3',
                    { className: 'poll-subtitle' },
                    question.questionDesc
                ),
                React.createElement(
                    'ul',
                    { className: 'poll-option' },
                    question.options.map(function (item) {
                        return React.createElement(
                            'li',
                            null,
                            React.createElement('input', { type: 'radio', name: 'smiley', value: item.optionId, className: 'poll-option__radio', id: "SMILEY_" + item.optionId }),
                            item.optionDesc == "Ottimo" ? React.createElement(
                                'label',
                                { htmlFor: "SMILEY_" + item.optionId, onClick: this.selectedSmiley },
                                React.createElement('div', { className: 'smiley Ottimo', alt: 'smiley' })
                            ) : item.optionDesc == "Buono" ? React.createElement(
                                'label',
                                { htmlFor: "SMILEY_" + item.optionId, onClick: this.selectedSmiley },
                                React.createElement('div', { className: 'smiley Buono', alt: 'smiley' })
                            ) : item.optionDesc == "Sufficiente" ? React.createElement(
                                'label',
                                { htmlFor: "SMILEY_" + item.optionId, onClick: this.selectedSmiley },
                                React.createElement('div', { className: 'smiley Sufficiente', alt: 'smiley' })
                            ) : item.optionDesc == "Scarso" ? React.createElement(
                                'label',
                                { htmlFor: "SMILEY_" + item.optionId, onClick: this.selectedSmiley },
                                React.createElement('div', { className: 'smiley Scarso', alt: 'smiley' })
                            ) : item.optionDesc == "Non adeguato" ? React.createElement(
                                'label',
                                { htmlFor: "SMILEY_" + item.optionId, onClick: this.selectedSmiley },
                                React.createElement('div', { className: 'smiley Non_adeguato', alt: 'smiley' })
                            ) : null,
                            React.createElement(
                                'label',
                                { className: 'poll-option__label' },
                                item.optionDesc
                            )
                        );
                    }.bind(this))
                )
            );
        }
    });
    var InviaInputField = React.createClass({
        displayName: 'InviaInputField',

        onkeyPress: function onkeyPress(e) {
            if (e.keyCode == 13) {
                this.props.events.messagePush(this.refs.messageText.value);
                this.refs.messageText.value = "";
            } else {
                this.props.events.onTyping(e);
            }
        },
        doMessagePush: function doMessagePush() {
            if ($(".chat-input-wrap .chat-btn").hasClass("reopen")) {
            	clearInterval(window.chatSessionInterval);
                this.props.events.messageConnect();
            } else {
                if (this.refs.messageText.value) {
                    this.props.events.messagePush(this.refs.messageText.value);
                    this.refs.messageText.value = "";
                }
            }
        },
        render: function render() {
            return React.createElement(
                'div',
                { className: 'chat-input-wrap' },
                React.createElement('input', { type: 'text', size: '20', className: 'chat-input', placeholder: 'Scrivi il tuo messaggio...', ref: 'messageText', onKeyDown: this.onkeyPress }),
                React.createElement(
                    'button',
                    { className: 'chat-btn', onClick: this.doMessagePush },
                    'invia'
                )
            );
        }
    });

    var ChatBoxContainer = React.createClass({
        displayName: 'ChatBoxContainer',

        getInitialState: function getInitialState() {
            return {
                lastmsg: ''
            };
        },
        componentDidUpdate: function componentDidUpdate() {
            $('.chat-panel-body').animate({ scrollTop: $('.chat-panel-body').prop("scrollHeight") }, 500);
            this.props.setlastMessage(this.state.lastmsg);
        },
        doRedirect: function doRedirect(obj) {
            var intendtCode = obj && obj.intentCode || null;
            var url = obj && obj.url || obj && obj.link || null;

            if (url.indexOf('hbroute') == -1) {
                var redirectURL = url.indexOf("http") == -1 ? window.location.origin + "/" + url : url;
                var randomnumber = Math.floor(Math.random() * 100 + 1);
                //   window.opener.open(redirectURL,"_blank",'Redirect',randomnumber);

                window.open(redirectURL);
            } else {
                if (window.opener) {
                    var redirectURL = window.opener.location.href + url;
                    if (window.opener.location.href.indexOf("#") != -1) {
                        redirectURL = window.opener.location.href.split("#")[0] + "#" + url;
                        if (url.indexOf(";") == -1) {
                            redirectURL = redirectURL + ";";
                        }
                    }
                    //window.opener.location.href = redirectURL;
                    window.opener.location.replace(redirectURL);
                }
            }
        },
        render: function render() {

            return React.createElement(
                'div',
                { className: 'chat-panel-body' },
                React.createElement(
                    'div',
                    { className: 'chat-messagein' },
                    React.createElement(
                        'b',
                        null,
                        this.props.name
                    ),
                    '\xA0\xE8 in chat'
                ),
                this.props.messagelist.map(function (message, index) {

                    if (message.sender == "BOT") {
                        var messageString = message.message || message.answer;
                        var messageintent = message.intentCode || undefined;
                        var messageintentArea = message.intentArea || undefined; 
                        var linkurl = message.url || message.link || undefined;
                        if (!messageString && message.action == "OPERATOR") {
                            if (this.props.operatorAvail && this.props.operatorAvail.toUpperCase() == "FALSE") {
                                messageString = "Non sono riuscita a comprendere la richiesta, se lo desideri ti posso mettere in contatto con un nostro operatore dell’assistenza. Clicca qui per proseguire";
                            } else {
                                messageString = "Non sono riuscita a comprendere la richiesta, se lo desideri puoi contattare l'assistenza clienti al numero 800.142.142 (per le chiamate da rete fissa nazionale) oppure al numero 0039.015.24.34.617 (per le chiamate dall'estero e da telefono cellulare) attivi dal lunedì al venerdì dalle ore 8.00 alle 21.00";
                            }
                        }
                        if (messageString) {
                            this.state.lastmsg = message;
                        }
                        return React.createElement(
                            'div',
                            { className: "chat-message chat-message--bank" + (!messageString ? " emptymessage" : "") },
                            messageString ? React.createElement('img', { src: window.location.origin + "/sellabot/images/newstyle/icn_logo@2x.png", className: 'reply-icon' }) : null,
                            messageString ? React.createElement(
                                'p',
                                { className: 'chat-message__text', id: "msg_" + index },
                                React.createElement('span', { className: 'msgString', dangerouslySetInnerHTML: { __html: messageString } })
                            ) : null,
                            ((!(this.props.isMobile && message.url)) && !message.link && linkurl && !this.props.isShowButton && "BS.AreaInformativa"!=messageintentArea && "BS.Professionalita"!=messageintentArea && message.action != "OPERATOR" ) ? React.createElement(
                                'div',
                                { className: 'botnavigatecontainer' },
                                React.createElement(
                                    'div',
                                    { className: 'anonymouslogin' },
                                    ' Per procedere devi autenticarti cliccando in alto sul tasto ACCEDI '
                                )
                            ) : ((!(this.props.isMobile && message.url)) && linkurl) || message.action == "OPERATOR" && this.props.operatorAvail && this.props.operatorAvail.toUpperCase() == "FALSE" ? React.createElement(
                                'div',
                                { className: 'botnavigatecontainer' },
                                React.createElement(
                                    'button',
                                    { className: message.action == "OPERATOR" ? "chat-btn bot-navigate-btn operatorcls" : "chat-btn bot-navigate-btn", onClick: message.action == "OPERATOR" ? this.props.doOperatorRedirect : this.doRedirect.bind(this, message) },
                                    message.action == "OPERATOR" ? "AVVIA CHAT CON UN OPERATORE" : "vai alla pagina",
                                    linkurl && linkurl.indexOf('hbroute') == -1 ? React.createElement('img', { className: 'restore-icon', alt: 'restore_icon', src: window.location.origin + "/sellabot/images/out-link@2x.png" }) : null
                                )
                            ) : null
                        );
                    } else if (message.sender != "BOT") {
                        this.state.lastmsg = message;
                        return React.createElement(
                            'div',
                            { className: 'chat-message chat-message--user' },
                            React.createElement(
                                'span',
                                { className: 'chat-message__sender initial' },
                                message.sender
                            ),
                            React.createElement(
                                'span',
                                { className: 'chat-message__sender name' },
                                message.name
                            ),
                            React.createElement(
                                'p',
                                { className: 'pull-right chat-message__text' },
                                React.createElement(
                                    'span',
                                    { className: 'msgString' },
                                    message.message
                                )
                            )
                        );
                    }
                }.bind(this)),
                React.createElement(
                    'div',
                    { className: 'chat-messagein' },
                    React.createElement(
                        'b',
                        null,
                        this.props.name
                    ),
                    '\xA0\xE8 uscito dalla chat'
                )
            );
        }
    });

    var ChatBotComp = React.createClass({
        displayName: 'ChatBotComp',

        getInitialState: function getInitialState() {
            return {
                interval: "",
                messagelist: [],
                chatid: null,
                isStarted: false,
                doClose: false,
                redirectAgent: false,
                questionlist: [],
                showQuestion: false,
                historyStr: "",
                close: false,
                isInprogress: false,
                isComplete: false,
                sender: "",
                name: "",
                operatorAvail: null,
                typingStarted: false,
                lastMessage: null,
                operator: false, isAnonymous: false,
                categoria: null,
                isShowButton: false,
                cognome: null,
                email: null,
                channelId: null,
                isMobile: false,
                exceptioncount:0,
                onlineMessages:"",
                showModal:false
            };
        },
        messagePush: function messagePush(messageText) {
            var self = this;
            var request = {
                "action": "chatevent",
                "chatid": self.state.chatid,
                "idevent": "chatmessage",
                "sourceIntentCode": this.getHpPageInfo(),
                "eventdata": [{
                    "name": "message",
                    "value": messageText
                }]
            };
            var messagelistArr = this.state.messagelist;
            if (messageText) {
                var temp = {};
                temp.message = messageText;
                temp.id = messagelistArr.length + 1;
                temp.sender = self.state.sender;
                temp.name = self.state.name;
                messagelistArr.push(temp);
            }
            // this.state.messagelist = Object.assign([], messagelistArr)
            this.setState({ messagelist: messagelistArr });
            axios.post(window.chatPath + '/sellabot/execute/user/chat', request).then(function (response) {

                // if (!this.state.isStarted) {
                //     window.chatinterval = setInterval(function () {
                //         // self.messageRefresh();
                //         this.state.isStarted = true;
                //     }.bind(this), 1000)
                // }

            }.bind(this)).catch(function (error) {}.bind(this));
        },
        getQuestions: function getQuestions() {
            axios.post(window.chatPath + '/sellabot/execute/feedback/questions', request).then(function (response) {
                this.setState({ showQuestion: true, questionlist: response.data.questions });
            }.bind(this)).catch(function (error) {}.bind(this));
        },
        doCloseModal: function doCloseModal() {
            $('#modalContent .close-mask-btn').attr("data-dismiss", "modal");
            $("#modalContent .close-mask-btn").trigger("click");
            $(".minmaxCon .modalMinimize").trigger("click");
            $("#chatmodal").empty();
            $(".minmaxCon").empty();
            $("body").removeClass("modal-open");
        },
        chuidiHandleClick: function chuidiHandleClick(chaturl) {
            var self = this;
            var request = {
                "action": "endchat",
                "sourceIntentCode": this.getHpPageInfo()
            };
            axios.post(window.chatPath + '/sellabot/execute/user/chat', request).then(function (response) {
                clearInterval(window.chatinterval);
                // this.logout();
                if (!this.state.showQuestion && !this.state.redirectAgent && !this.state.doClose) {
                    axios.post(window.chatPath + '/sellabot/execute/feedback/questions', request).then(function (response) {
                        this.setState({ showQuestion: true, questionlist: response.data.questions });
                    }.bind(this)).catch(function (error) {}.bind(this));
                } else {
                    if ((!this.state.doClose || this.state.close) && (!this.state.redirectAgent || this.state.close)) {} else if (this.state.redirectAgent) {
                        $(".chat-input-wrap .chat-input,.chat-input-wrap .chat-btn").attr("disabled", true);
                        $(".chat-input-wrap .chat-input").attr("placeholder", "Trasferire chat all'agente");
                        this.state.close = true;
                        //window.location.href = chaturl;
                        window.location.replace(chaturl);
                        //   var form = $('<form action="' + chaturl + '" method="post">' +
                        // '<input type="text" name="testoiniziale" value="' + this.state.historyStr + '" />' +
                        // '</form>');
                        // $('body').append(form);
                        // form.submit(); 
                    } else if (this.state.doClose) {
                        $(".chat-input-wrap .chat-input,.chat-input-wrap .chat-btn").attr("disabled", true);
                        $(".chat-input-wrap .chat-input").attr("placeholder", "Grazie. Arrivederci..");
                        this.state.close = true;
                        this.state.doClose = false;
                    } else {
                        this.state.doClose = false;
                    }
                }
            }.bind(this)).catch(function (error) {
            	this.state.exceptioncount=this.state.exceptioncount+1;
            	if(this.state.exceptioncount>100){
            		clearInterval(window.chatinterval);
            	}
            });
        },
        setlastMessage: function setlastMessage(msg) {
            this.state.lastMessage = msg;
        },
        onTyping: function onTyping(e) {
            var self = this;
            var request = {
                "action": "chatevent",
                "chatid": self.state.chatid,
                "idevent": "chattyping",
                "sourceIntentCode": this.getHpPageInfo(),
                "eventdata": [{
                    "name": "typing",
                    "value": true
                }]

            };
            if (!this.state.typingStarted) {
                this.state.typingStarted = true;
                axios.post(window.chatPath + '/sellabot/execute/user/chat', request).then(function (response) {
                    this.state.typingStarted = false;
                    if (response.data && response.data.status != "OK") {
                        this.handleException(response.data);
                    }
                }.bind(this)).catch(function (error) {}.bind(this));
            }
        },
        handleException: function handleException(data) {
            clearInterval(window.chatinterval);
            var list = _extends([], this.state.messagelist);
            $(".chat-input-wrap .chat-input,.chat-input-wrap .chat-btn").attr("disabled", true);
            $(".chat-input-wrap .chat-input").val('');
            if (data.errorMessageCode && data.errorMessageCode == "IM_CHAT_ID_NOT_FOUND") {
            	if(window.chatSessionInterval){
            		clearInterval(window.chatSessionInterval);
            	}
            	window.chatSessionInterval = setInterval(function () {
            		window.close();
					window.close();
            	}.bind(this), window.sessionDelay);
                $(".chat-input-wrap .chat-btn").text("RIAVVIA CHAT");
                $(".chat-input-wrap .chat-btn").removeAttr("disabled");
                $(".chat-input-wrap .chat-input").attr("placeholder", "Vuoi proseguire la conversazione con l'assistente virtuale?");
                $(".chat-input-wrap .chat-btn").removeClass("disabled").addClass("reopen");
            }
            var msg = this.state.lastMessage;
            if (!msg || msg.action != "OPERATOR") {
                var i = list.length;
                var message = {};
                message.action = "OPERATOR";
                message.sender = "BOT";
                var listArr = list.push(message);
                this.setState({ messagelist: list });
            }
        },
        messageRefresh: function messageRefresh() {
            var self = this;
            var request = {
                "chatid": self.state.chatid
            };
            if (!this.state.isInprogress) {
                this.state.isInprogress = true;
                axios.post(window.chatPath + '/sellabot/execute/user/poll', request).then(function (response) {
                    if (response.data && response.data.status == "OK") {
                        this.state.isInprogress = false;
                        var list = _extends([], this.state.messagelist);
                        var data = response.data.results;
                        var message = [];
                        var close = false;

                        if (data.length > 0) {
                            for (var i = 0; i < data.length; i++) {
                                message[i + 1] = {};
                                message[i + 1].message = data[i].message;
                                message[i + 1].sentDate = new Date();
                                message[i + 1].nickName = data[i].sender;
                                message[i + 1].answer = data[i].answer;
                                if (data[i].action && data[i].action.toLowerCase() == "close") {
                                    this.state.doClose = true;
                                }
                                if (data[i].action && data[i].action.toLowerCase() == "operator") {
                                	if(window.chatSessionInterval){
                                		clearInterval(window.chatSessionInterval);
                                	}
                                	window.chatSessionInterval = setInterval(function () {
                                		window.close();
                                		window.close();
                                	}.bind(this), window.sessionDelay);
                                    this.state.operator = true;
                                    $(".chat-input-wrap .chat-input,.chat-input-wrap .chat-btn").attr("disabled", true);
                                    $(".chat-input-wrap .chat-input").val('');
                                    $(".chat-input-wrap .chat-btn").text("RIAVVIA CHAT");
                                    $(".chat-input-wrap .chat-input").attr("placeholder", "Vuoi proseguire la conversazione con l'assistente virtuale?");
                                    $(".chat-input-wrap .chat-btn").removeAttr("disabled");
                                    $(".chat-input-wrap .chat-btn").removeClass("disabled").addClass("reopen");
                                }

                                var isAgent = true;
                                if (data[i].sender && data[i].sender != "BOT") {
                                    isAgent = false;
                                }
                                message[i + 1].isAgent = isAgent;
                                if (data[i].userJoined != null && data[i].userJoined) {
                                    self.state.agentLogged = true;
                                }
                            };
                            var listArr = list.concat(data);

                            clearInterval(window.chatinterval);
                            window.chatinterval = undefined;
                            if (!this.state.operator) {
                                window.chatinterval = setInterval(function () {
                                    self.messageRefresh();
                                }.bind(this), window.pollDelay);
                            }
                            this.setState({ messagelist: listArr });
                        } else {
                            clearInterval(window.chatinterval);
                            window.chatinterval = undefined;
                            window.chatinterval = setInterval(function () {
                                self.messageRefresh();
                            }.bind(this), 1000);
                        }
                    } else {
                        this.handleException(response.data);
                    }
                }.bind(this)).catch(function (error) {

                    this.state.isInprogress = false;
                    this.state.exceptioncount = this.state.exceptioncount+1;
                    if(this.state.exceptioncount>100){
                    	clearInterval(window.chatinterval);
                    }
                }.bind(this));
            }
        },
        onClose: function onClose() {
            if (this.state.doClose) {
                this.chuidiHandleClick();
                $(".chat-input-wrap .chat-input,.chat-input-wrap .chat-btn").addClass("disabled");
                $(".chat-input-wrap .chat-input,.chat-input-wrap .chat-btn").attr("disabled", true);
            }
        },
        messageConnect: function messageConnect() {
            var self = this;
            var request = {
                "action": "newchat",
                "sourceIntentCode": this.getHpPageInfo()
            };
            axios.post(window.chatPath + '/sellabot/execute/user/chat', request).then(function (response) {
                if (response.data && response.data.status == "OK") {
                    if ($(".chat-input-wrap .chat-btn").hasClass("reopen")) {
                        $(".chat-input-wrap .chat-btn").text("INVIA");
                        $(".chat-input-wrap .chat-input").attr("placeholder", "Scrivi il tuo messaggio...");
                        $(".chat-input-wrap .chat-btn,.chat-input-wrap .chat-input").removeAttr("disabled");
                        $(".chat-input-wrap .chat-btn,.chat-input-wrap .chat-input").removeClass("disabled");
                        $(".chat-input-wrap .chat-btn").removeClass("reopen");
                        this.state.operator = false;
                    }
                    this.state.chatid = response.data.chatid;
                    this.state.operatorAvail = response.data.overTime || "";
                    window.chatinterval = undefined;
                    window.chatinterval = setInterval(function () {
                        self.messageRefresh();
                    }.bind(this), 1000);
                } else {
                    this.handleException(response.data);
                }
                //this.props.setChatid(this.state.chatid);
                // console.log(response);
            }.bind(this)).catch(function (error) {}.bind(this));
        },
        printOutFunc: function printOutFunc() {
            if ($(".chat-panel-body").length > 0) {
                var newWin = window.open('', 'Print-Window');
                newWin.document.open();
                newWin.document.write('<html><link rel="stylesheet" type="text/css" href="css/style.css" /></head><body onload="window.print()">');
                newWin.document.write($(".chat-panel-body").html());
                newWin.document.write('</html>');
                newWin.document.close();
                setTimeout(function () {
                    newWin.close();
                }, 100);
            }
        },
        componentDidMount: function componentDidMount() {

            var request = window && window.chatRequest || {};
            axios.post(window.chatPath + "/sellabot/execute/user/syncalias", request).then(function () {
                this.messageConnect();
            }.bind(this)).catch(function (error) {}.bind(this));
        },
        doOperatorRedirect: function doOperatorRedirect() {
            this.state.redirectAgent = true;
            $(".chat-input-wrap .chat-input,.chat-input-wrap .chat-btn").addClass("disabled");
            $(".chat-input-wrap .chat-input,.chat-input-wrap .chat-btn").attr("disabled", true);
            this.getHistory();
        },
        componentWillMount: function componentWillMount() {
            this.getProperties();
            this.getUserInfo();
        },
        getHistory: function getHistory() {
            axios.post(window.chatPath + '/sellabot/execute/user/chat/history', {}).then(function (response) {
                this.state.historyStr = response.data.history && encodeURIComponent(response.data.history) || "";
                var chatId = response.data.chatId || "";
                var sessionId = response.data.sessionId || "";
                var chaturl = '/AuthenticationDelegatedServlet?delegated_service=219&SEACTION=LOGIN&SECODE=CHAT_IB&SEPARAMS=chatId=' + chatId + '^CHANNEL=' + this.state.channelId + '^categoria=' + this.state.categoria;
                //window.location.hostname && (window.location.hostname.indexOf("te.sella.it") != -1 ||)
                if (window.location.hostname.indexOf("172.17.29.47") != -1) {
                    chaturl = 'https://pp.sella.it/AuthenticationDelegatedServlet?delegated_service=219&SEACTION=LOGIN&SECODE=CHAT_IB&SEPARAMS=chatId=' + chatId + '^CHANNEL=' + this.state.channelId + '^categoria=' + this.state.categoria;
                }
                if (this.state.isAnonymous) {
                    chaturl = '/Chat/?nome=' + this.state.name + '&cognome=' + this.state.cognome + '&email=' + this.state.email+'&chatId=' + chatId + '&CHANNEL=' + this.state.channelId + '&categoria=' + this.state.categoria;
                }
                
                if(this.state.isMobile&&!this.state.isAnonymous){
                	//chaturl='/sellabot/Redirect.jsp';
                	chaturl = '/Chat/?chatId=' + chatId + '&CHANNEL=' + this.state.channelId + '&categoria=' + this.state.categoria+ '&redirect=false&cnctrtoken='+this.state.cnctrToken;
                }

                this.chuidiHandleClick(chaturl);
            }.bind(this)).catch(function (error) {}.bind(this));
        },
        logout: function logout() {

            axios.post(window.chatPath + '/sellabot/execute/services/logout', {}).then(function (response) {}.bind(this)).catch(function (error) {
                window.onunload = null;
            });
            window.onunload = null;
            return null;
        },
        componentDidUpdate: function componentDidUpdate() {

            this.onClose();
        },
        conditionsCheckFunc: function conditionsCheckFunc() {
            var div = document.getElementById("poll-privacy-information");
            if (div.style.display == "none") {
                div.style.display = "block";
            } else {
                div.style.display = "none";
            }
        },
        submitChatQueries: function submitChatQueries() {
            var self = this;
            var request = {
                "answers": [{
                    "answerId": $('[name="yesno"]:checked').val(),
                    "answer": ""
                }, {
                    "answerId": $('[name="smiley"]:checked').val(),
                    "answer": ""
                }, {
                    "answerId":$("#chatTextArea").attr("data-optionId"),
                    "answer": $("#chatTextArea").val()
                }]
            };
            axios.post(window.chatPath + '/sellabot/execute/feedback/insert', request).then(function (response) {
                $("#first_page").hide();
                $("#poll-privacy-information").hide();
                $("#second_page").show();
                
            }.bind(this)).catch(function (error) {
                // console.log(error);
            });
        },
        getProperties: function getProperties() {
            window.pollDelay = 5000;
            axios.post(window.chatPath + '/sellabot/execute/page/properties', { code: "FE_PAGE_PROPS" }).then(function (response) {

                if (response.data && response.data.props && response.data.props.POLL_DELAY_SEC) {
                    window.pollDelay = parseInt(response.data.props.POLL_DELAY_SEC) * 1000;
                    window.sessionDelay =  parseInt(response.data.props.SESSION_DELAY_MIN) * 1000;
                }
            }.bind(this)).catch(function (error) {
                // console.log(error);
            });
        },
        getUserInfo: function getUserInfo() {
            window.pollDelay = 5000;
            axios.post(window.chatPath + '/sellabot/execute/user/info').then(function (response) {

                if (response.data) {
                    this.state.name = response.data.nome;
                    this.state.sender = response.data.nickName;
                    this.state.isAnonymous = response.data.isAnonymous;
                    this.state.isShowButton = response.data.isShowButton;
                    this.state.categoria = response.data.categoria;
                    this.state.cognome = response.data.cognome;
                    this.state.email = response.data.email;
                    this.state.channelId = response.data.channelId;
                    this.state.isMobile = response.data.isMobile;
                    this.state.cnctrToken = response.data.cnctrToken;
                    this.state.onlineMessages = response.data.onlineMessages;
                    if(this.state.onlineMessages){
                    	this.setState({showModal:true});
                    }
                }
            }.bind(this)).catch(function (error) {
                // console.log(error);
            });
        },
        getHpPageInfo: function getHpPageInfo() {
            var hbPageInfo = '';
            var hbPageInfoObj = window.opener ? window.opener.hbPageInfo : '';
            if (hbPageInfoObj && hbPageInfoObj.currentPageName) {
                hbPageInfo = hbPageInfoObj.currentPageName;
                if (hbPageInfoObj.currentTabName) {
                    hbPageInfo = hbPageInfo + ';' + hbPageInfoObj.currentTabName;
                    if (hbPageInfoObj.currentSubTabName) {
                        hbPageInfo = hbPageInfo + ';' + hbPageInfoObj.currentSubTabName;
                    }
                }
            }
            return hbPageInfo;
        },
        closeModal:function closeModal(){
        	this.setState({showModal:false});
        },
        render: function render() {
        	var onlineMessages =  this.state.onlineMessages;
        	var showModal = this.state.showModal;
            if (!this.state.showQuestion) {
                return React.createElement(
                    'div',
                    { className: '' },
                    showModal ?
		        		 React.createElement(
		                         'div',
		                         { className: 'modal'},
		                         React.createElement(
		                                 'div',
		                                 { className: 'modal-inner'},
		                                 React.createElement(
		                                         'span',
		                                         { className: 'modal-close', onClick:this.closeModal }
		                                  ),
		                                  React.createElement(
		                                          'div',
		                                          { className: 'modal-content'},
		                                          React.createElement(
		                                                  'p',
		                                                  null,
		                                                  onlineMessages
		                                           ),
		                                           React.createElement(
		                                                   'button',
		                                                   { className: 'blue-btn' , id:"closeModal" , onClick:this.closeModal },
		                                                   "Close"
		                                            )   
		                                   ) 
		                         )
		                         
		                 )
	                :"",
                    React.createElement(
                        'div',
                        { className: 'header-wrap row' },
                        React.createElement(
                            'div',
                            { className: 'chat-icon-left col-sm-6 col-xs-6' },
                            React.createElement('img', { src: window.location.origin + "/sellabot/images/logo-sellait@2x.png", className: 'chat-header-logo', alt: 'Logo Sella.it' })
                        ),
                        React.createElement(
                            'div',
                            { className: 'chat-icon-right col-sm-6 col-xs-6 pull-right' },
                            (navigator.userAgent.toLowerCase().indexOf("mobi")<0 && navigator.userAgent.toLowerCase().indexOf("android")<0)?React.createElement('img', { src: window.location.origin + "/sellabot/images/newstyle/iconmonstr-printer-3-240.png", className: 'printer-close-icon', alt: 'Logo Sella.it', onClick: this.printOutFunc }):'',
                            React.createElement('img', { src: window.location.origin + "/sellabot/images/newstyle/close.png", className: 'printer-close-icon', alt: 'Close', onClick: this.chuidiHandleClick })
                        )
                    ),
                    React.createElement(
                        'div',
                        { className: 'chat-body' },
                        this.state.messagelist && this.state.messagelist.length > 0 ? React.createElement(ChatBoxContainer, { messagelist: this.state.messagelist, name: this.state.name, doOperatorRedirect: this.doOperatorRedirect, operatorAvail: this.state.operatorAvail, setlastMessage: this.setlastMessage, isAnonymous: this.state.isAnonymous,
                            isShowButton: this.state.isShowButton, isMobile: this.state.isMobile, cnctrToken: this.state.cnctrToken }) : null
                    ),
                    React.createElement(InviaInputField, { events: { messagePush: this.messagePush, onTyping: this.onTyping, messageConnect: this.messageConnect } })
                );
            } else {
                return React.createElement(
                    'div',
                    { className: 'poll-container' },
                    React.createElement(
                            'p',
                            { className: 'poll-privacy-note poll-hide', id: 'poll-privacy-information', style: { display: "block" } },
                            React.createElement(
                                    'div',
                                    { className: 'titleCenter'},
                                    'Prima di salutarci, La invitiamo a rispondere a queste brevi domande per permetterci di migliorare costantemente la qualità del servizio fornito'
                            ),
                            React.createElement('br', null),
                            React.createElement(
                                'strong',
                                null,
                                'Informativa Privacy ai sensi dell’art. 13 del Regolamento UE 2016/679'
                            ),
                            React.createElement('br', null),
							"Banca Sella S.p.A., con sede in Biella, Piazza Gaudenzio Sella n°1, in qualit\xE0  di Titolare del trattamento dei dati, La informa, ai sensi dell\'art. 13 del Regolamento UE 2016/679 che i dati da Lei forniti saranno trattati nel rispetto della citata normativa, mediante strumenti manuali, informatici e telematici per finalit\xE0 di rilevazione del grado di soddisfazione della clientela sulla qualit\xE0 dei servizi resi e sull\'attivit\xE0 svolta dalla Banca e dal Gruppo Sella ed elaborazione di studi e ricerche di mercato e potranno essere comunicati alle societ\xE0 appartenenti al Gruppo Sella ovvero controllate o collegate, che svolgano per suo conto trattamenti di dati per le medesime finalit\xE0, e societ\xE0  terze nominate responsabili esterne del trattamento.",
							React.createElement('br', null),
							"Per l\'esercizio dei diritti di cui agli articoli dal 15 al 22 del Regolamento, potr\xE0  scrivere a Banca Sella S.p.A. ai seguenti indirizzi di posta elettronica ",
							React.createElement(
                                    'a',
                                    { href: 'mailto:privacy@sella.it'},
                                    'privacy@sella.it'
                                ),
							" e ",
							React.createElement(
                                'a',
                                { href: 'mailto:dpo@sella.it'},
                                'dpo@sella.it'
                            ),
                            React.createElement('br', null),
                            "La informiamo altres\xEC che, sulla base del grado di soddisfazione da Lei espresso, al fine di fornirLe adeguato supporto, potrebbe seguire un ulteriore contatto.",
                            React.createElement('br', null)
                            
                        ),
                    React.createElement(
                        'div',
                        { id: 'first_page' },
                        this.state.questionlist.map(function (question) {
                            return React.createElement(
                                'div',
                                null,
                                question.questionType == "3" ? React.createElement(SimelyComp, { ques: question }) : null,
                                question.questionType == "2" ? React.createElement(FutureChatComp, { ques: question }) : null,
                                question.questionType == "1" ? React.createElement(CommentBoxComp, { ques: question }) : null
                            );
                        }),
     //                   React.createElement(
     //                       'p',
     //                       { className: 'poll-privacy-note' },
     //                       'Partecipando al sondaggio acconsenti al trattamento dei dati per la finalit\xE0 di seguito riportate.',
     //                       React.createElement(
     //                           'span',
     //                           { className: 'poll-privacy-toggle', onClick: this.conditionsCheckFunc },
     //                           '\xA0Leggi l\'informativa privacy.'
     //                       )
     //                   ),
                        
                        React.createElement(
                            'button',
                            { type: 'submit', name: 'submitPoll', id: 'submitPoll', className: 'poll-button', onClick: this.submitChatQueries },
                            'INVIA'
                        )
                    ),
                    React.createElement(
                        'div',
                        { id: 'second_page', style: { display: "none" } },
                        React.createElement(
                            'div',
                            { className: 'poll-content' },
                            React.createElement(
                                'div',
                                { className: 'poll-thanks-check' },
                                React.createElement(
                                    'p',
                                    { className: 'poll-thanks-check-text' },
                                    'GRAZIE PER LA COLLABORAZIONE',
                                    React.createElement('br', null),
                                    React.createElement(
                                        'span',
                                        null,
                                        ' La tua opinione \xE8 molto importante per permetterci di migliorare la qualit\xE0 del nostro servizio.'
                                    )
                                )
                            )
                        )
                    )
                );
            }
        }

    });

    return function () {
        return ReactDOM.render(React.createElement(ChatBotComp, null), document.getElementById('chatcontainer'));
    };
});