package it.sella.sb.filter;

import java.io.IOException;

import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import it.sella.crossauthentication.identity_federation.servlet.IdentityAssertionFilter;
import it.sella.sb.hb.dto.SbUserDetail;
import it.sella.sb.util.SBCONSTANT;

public class SBCrossAuthFilter extends IdentityAssertionFilter {
	
	private static final Logger LOGGER = Logger.getLogger(SBCrossAuthFilter.class);

    public SBCrossAuthFilter() {
        LOGGER.debug("SBCrossAuthFilter constructor created");
    }

	public void destroy() {
		LOGGER.debug("SBCrossAuthFilter destroy called");
	}

	public void doFilter(final ServletRequest request, final ServletResponse response, final FilterChain chain) throws IOException, ServletException {
		try{
			LOGGER.debug("<------ SBCrossAuthFilter doFilter start ------>");
			final HttpServletRequest httpServletRequest = (HttpServletRequest) request;
	        final String currentURL = httpServletRequest.getRequestURI();
	        final HttpSession session = httpServletRequest.getSession(); 
	        
	        if(currentURL != null && currentURL.indexOf("chatinit")>-1){
	        	String channel = httpServletRequest.getParameter(SBCONSTANT.CHANNEL.VALUE); 
	        	if(channel!=null && channel.indexOf("_free")>-1 && !channel.equalsIgnoreCase("Sella_sito_free_authenticated")){
	        		session.setAttribute(SBCONSTANT.ANONYMOUS.VALUE, Boolean.TRUE);
	            }else{
	            	session.setAttribute(SBCONSTANT.ANONYMOUS.VALUE, Boolean.FALSE);
	            }
	        }
	        Boolean isAnonymous= Boolean.FALSE; 
	        if(session!=null && session.getAttribute(SBCONSTANT.ANONYMOUS.VALUE)!=null && ((Boolean)session.getAttribute(SBCONSTANT.ANONYMOUS.VALUE))){
	        	isAnonymous= Boolean.TRUE; 
	        }
	        
	        if ((currentURL != null && currentURL.indexOf("/inbound/res")>-1) || (isAnonymous)){
	        	LOGGER.debug("Cross auth skip for url : "+currentURL+" -- "+isAnonymous);
	        	chain.doFilter(request, response);
	        } else {
	        	LOGGER.debug("else Cross auth skip for url : ");
	        	super.doFilter(request, response, chain);
	        }
	        LOGGER.debug("<------ SBCrossAuthFilter doFilter end ------>");
		}catch (Exception e) {
			 LOGGER.error("<------Exception SBCrossAuthFilter doFilter() ------>"+e.getMessage(),e);
		}
	}

	public void init(FilterConfig fConfig) throws ServletException {
		LOGGER.debug("SBIdentityAssertionFilter init initiated");
	}

}
