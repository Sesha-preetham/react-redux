package it.sella.sb.controller.history;

import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import it.sella.sb.common.exception.SBCommonException;
import it.sella.sb.core.facade.ChatHistoryFacade;
import it.sella.sb.hb.dto.SbUserDetail;
import it.sella.sb.im.dto.response.ChatHistoryResponse;
import it.sella.sb.util.SBCONSTANT;

@RestController
public class ChatHistoryController {

	@Autowired
	private ChatHistoryFacade chatHistoryFacade;
	
	private static final Logger LOGGER = Logger.getLogger(ChatHistoryFacade.class);

	@RequestMapping(value = "/user/chat/history", method = {RequestMethod.POST})
	public @ResponseBody ChatHistoryResponse chatHistory(final HttpSession session) {
		LOGGER.debug("Inside ChatHistoryController  chatHistory -->");
		/*final IMRequest imRequest = new IMRequest();
		imRequest.setChatid((String)session.getAttribute(SBCONSTANT.CHATID.VALUE));
		imRequest.setChaturl((String)session.getAttribute(SBCONSTANT.CHATURL.VALUE));*/
		final SbUserDetail userDetail = (SbUserDetail)session.getAttribute(SBCONSTANT.USERDETAIL.VALUE);
		if(userDetail == null) {
			LOGGER.debug("IMController syncEventData sella bot not initialized");
			throw new SBCommonException("IMController syncEventData sella bot not initialized", SBCommonException.SB_NOT_INITIALIZED);
		}
		/*final ChatHistoryResponse response = getChatHistoryFacade().getChatHistory(imRequest,userDetail);*/
		final ChatHistoryResponse response = new ChatHistoryResponse();
		final String chatId = (String)session.getAttribute(SBCONSTANT.CHATID.VALUE);
		response.setChatId(chatId);
		LOGGER.debug("<-- Transfer to agent for user : "+userDetail.getUserId()+" chat id : "+chatId);
		return response;
	}

	protected ChatHistoryFacade getChatHistoryFacade() {
		return chatHistoryFacade;
	}
}
