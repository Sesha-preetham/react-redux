package it.sella.sb.controller.feedback;

import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import it.sella.sb.core.facade.FeedbackFacade;
import it.sella.sb.feedback.dto.FeedBackQuestionResponse;
import it.sella.sb.feedback.dto.FeedBackRequest;
import it.sella.sb.hb.dto.SbUserDetail;
import it.sella.sb.im.response.BaseResponse;
import it.sella.sb.util.SBCONSTANT;

@RestController
public class FeedBackController {

	@Autowired
	private FeedbackFacade feedbackFacade;
	
	private static final Logger LOGGER = Logger.getLogger(FeedBackController.class);

	@RequestMapping(value = "/feedback/questions", method = {RequestMethod.POST})
	public @ResponseBody FeedBackQuestionResponse chatHistory(final HttpSession session) {
		LOGGER.debug("Inside feedback questions -->");
		final SbUserDetail hbUserDetail = (SbUserDetail)session.getAttribute(SBCONSTANT.USERDETAIL.VALUE);
		return getFeedbackFacade().getQuestions(hbUserDetail);
	}
	
	@RequestMapping(value = "/feedback/insert", method = {RequestMethod.POST})
	public @ResponseBody BaseResponse chat(final @RequestBody FeedBackRequest request,final HttpSession session) {
		LOGGER.debug("Inside feedback insert -->");
		final SbUserDetail hbUserDetail = (SbUserDetail)session.getAttribute(SBCONSTANT.USERDETAIL.VALUE);
		hbUserDetail.setChatid((String)session.getAttribute(SBCONSTANT.CHATIDLOG.VALUE));
		return getFeedbackFacade().insertFeedback(request, hbUserDetail);
	}

	protected FeedbackFacade getFeedbackFacade() {
		return feedbackFacade;
	}

}
