package it.sella.sb.controller;


import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import it.sella.sb.common.exception.SBBaseThrowable;
import it.sella.sb.common.exception.SBCommonException;
import it.sella.sb.core.exception.SBCoreException;
import it.sella.sb.dao.exception.SBDaoException;
import it.sella.sb.external.exception.SBServiceException;
import it.sella.sb.im.response.BaseResponse;
import it.sella.sb.im.response.BaseResponse.BaseStatusEnum;

@ControllerAdvice
public class SBExceptionHandler extends ResponseEntityExceptionHandler{
	private static final Logger LOGGER = Logger.getLogger(SBExceptionHandler.class);
	
	@ExceptionHandler(value=SBCommonException.class)
	public @ResponseBody BaseResponse handleSBCommonException(final HttpServletRequest req,final SBCommonException e) {
		BaseResponse br = new BaseResponse();
		br.setErrorMessageCode(e.getCode());
		br.setStatus(BaseStatusEnum.EXCEPTION);
		if(LOGGER.isDebugEnabled()) {
			LOGGER.debug("SBCommonException for" + 
					" RequestURI:" + req.getRequestURI() + 
					" Exception Message:" + e.getMessage() + 
					" Exception code:" + e.getCode() );
			LOGGER.debug("SBCommonException caused by: ", e);
		}
		return br;
	}
	
	@ExceptionHandler(value=SBCoreException.class)
	public @ResponseBody BaseResponse handleSBCoreException(final HttpServletRequest req,final SBCoreException e) {
		BaseResponse br = new BaseResponse();
		br.setErrorMessageCode(e.getCode());
		br.setStatus(BaseStatusEnum.EXCEPTION);
		if(LOGGER.isDebugEnabled()) {
			LOGGER.debug("HB SBCoreException error for" + 
					" RequestURI:" + req.getRequestURI() + 
					" Exception Message:" + e.getMessage() + 
					" Exception code:" + e.getCode());
			LOGGER.debug("SBCoreException error caused by: ", e);
		}
		return br;
	}
	
	
	@ExceptionHandler(value=SBDaoException.class)
	public @ResponseBody BaseResponse handleSBDaoException(final HttpServletRequest req,final SBDaoException e) {
		BaseResponse br = new BaseResponse();
		br.setErrorMessageCode(e.getCode());
		br.setStatus(BaseStatusEnum.EXCEPTION);
		if(LOGGER.isDebugEnabled()) {
			LOGGER.debug("SB SBDaoException error for" + 
					" RequestURI:" + req.getRequestURI() + 
					" Exception Message:" + e.getMessage() + 
					" Exception code:" + e.getCode());
			LOGGER.debug("SBDaoException error caused by: ", e);
		}
		return br;
	}
	
	@ExceptionHandler(value=SBServiceException.class)
	public @ResponseBody BaseResponse handleSBServiceException(final HttpServletRequest req,final SBServiceException e) {
		BaseResponse br = new BaseResponse();
		br.setErrorMessageCode(e.getCode());
		br.setStatus(BaseStatusEnum.EXCEPTION);
		if(LOGGER.isDebugEnabled()) {
			LOGGER.debug("SB SBServiceException error for" + 
					" RequestURI:" + req.getRequestURI() + 
					" Exception Message:" + e.getMessage() + 
					" Exception code:" + e.getCode());
			LOGGER.debug("SBServiceException error caused by: ", e);
		}
		return br;
	}
	
	@ExceptionHandler(value=Exception.class)
	public @ResponseBody BaseResponse handleException(final HttpServletRequest req,final Exception e) {
		BaseResponse br = new BaseResponse();
		br.setErrorMessageCode(SBBaseThrowable.SB_GEN_001);
		br.setStatus(BaseStatusEnum.EXCEPTION);
		if(LOGGER.isDebugEnabled()) {
			LOGGER.debug("Exception for" + 
					" RequestURI:" + req.getRequestURI() + 
					" Exception Message:" + e.getMessage() + 
					" Exception code:" + SBBaseThrowable.SB_GEN_001 );
			LOGGER.debug("Exception caused by: ", e);
		}
		return br;
	}
	

	
}
