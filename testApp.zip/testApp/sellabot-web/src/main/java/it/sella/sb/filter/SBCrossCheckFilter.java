package it.sella.sb.filter;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import it.sella.sb.common.util.StringUtility;
import it.sella.sb.core.factory.CrossAuthFactory;
import it.sella.sb.hb.dto.SbUserDetail;
import it.sella.sb.util.SBCONSTANT;

@Component("sbCrossCheckFilter")
public class SBCrossCheckFilter extends BaseFilter implements Filter
{
	
	private static final Logger LOGGER = Logger.getLogger(SBCrossCheckFilter.class);
	
	@Autowired
	private CrossAuthFactory crossAuthFactory;
	
	@Value("${logout-url}")
	private String logoutUrl;

	@Override
	public void destroy() 
	{
		LOGGER.info("###Destorying SBCrossCheckFilter###");
	}

	@Override
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException 
	{
		LOGGER.debug("<------ SBCrossCheckFilter doFilter start ------>");
		final HttpServletRequest hreq = (HttpServletRequest) request;
		final HttpServletResponse hres = (HttpServletResponse) response;
        final SbUserDetail sbUser= (SbUserDetail)hreq.getSession().getAttribute(SBCONSTANT.USERDETAIL.VALUE);
        final String currentURL = hreq.getRequestURI();
        final HttpSession session = ((HttpServletRequest)request).getSession();
        
        Boolean isAnonymous= Boolean.FALSE; 
        if(session!=null && session.getAttribute(SBCONSTANT.ANONYMOUS.VALUE)!=null && ((Boolean)session.getAttribute(SBCONSTANT.ANONYMOUS.VALUE))){
        	isAnonymous= Boolean.TRUE; 
        }
        
        if ((currentURL != null && currentURL.indexOf("/inbound/res")>-1) || isAnonymous){
        	LOGGER.debug("SB Cross Check Filter skip for url : "+currentURL+" -- "+isAnonymous);
        } else if (sbUser != null) {
        	String crossUser =  getCrossAuthFactory().getFederationInformation().getUserCode();
        	LOGGER.info("IbCode from cross --> "+crossUser);
            String sessionUser = sbUser.getUserId();
            LOGGER.info("IbCode from session --> "+sessionUser);
        	if(!StringUtility.isEmpty(crossUser) &&  !crossUser.equals(sessionUser)) {
        		hreq.getSession().invalidate();
        		LOGGER.info("forward to Url --> "+logoutUrl);
                hres.sendRedirect(logoutUrl);
                return;
            }
        }
        chain.doFilter(request, response);
        LOGGER.debug("<------ SBCrossCheckFilter doFilter end ------>");
	}

	@Override
	public void init(FilterConfig arg0) throws ServletException {
		LOGGER.info("###Initializing SBCrossCheckFilter###");
	}
	
	protected CrossAuthFactory getCrossAuthFactory() {
		return crossAuthFactory;
	}
	
}
