package it.sella.sb.filter;

import it.sella.sb.common.exception.SBBaseThrowable;
import it.sella.sb.util.SBCONSTANT;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Component;

@Component("sbProtectionFilter")
public class SBProtectionFilter extends BaseFilter implements Filter
{
	
	private static final Logger LOGGER = Logger.getLogger(SBProtectionFilter.class);

	@Override
	public void destroy() 
	{
		LOGGER.info("###Destorying SBProtectionFilter###");
	}

	@Override
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException 
	{
		LOGGER.debug("<------ SBProtectionFilter doFilter start ------>");
		final HttpServletRequest hreq = (HttpServletRequest) request;
        final HttpServletResponse hres = (HttpServletResponse) response;
		
        /*hres.addHeader("Cache-Control","no-cache, no-store, must-validate");//HTTP 1.1
        hres.addHeader("Pragma", "no-cache");//HTTP 1.0
        hres.setDateHeader("Expires", 0);//prevents caching at the proxy server
        */        
        //IE compatibility for last version usage
        hres.addHeader("X-UA-Compatible","IE=edge");		
		hres.addHeader( "X-FRAME-OPTIONS", "SAMEORIGIN" );
		
		LOGGER.info("###FILTEREXECUTION### Path " + hreq.getRequestURL()+" Starting execution");
		long startTime = System.currentTimeMillis();
		try		
		{
			if (!isRequestOK(hreq))
			{
				LOGGER.error("Request is not OK expecting a login authentication, session invalid..!!");
				LOGGER.debug("Request is not OK expecting a login authentication request uri:" + hreq.getRequestURI());
				hres.sendError(HttpServletResponse.SC_FORBIDDEN);
			}
			else
			{		 				
				try 
				{
					chain.doFilter(request, response);
				} catch (SBBaseThrowable e) {
					LOGGER.error("###SBBaseThrowable Exception###" ,e);
					writeErrorResponse(hres,e);
				} catch (Exception e) {
					LOGGER.error("###UNEXPECTED ERROR###" ,e);
					writeErrorResponse(hres);
				}				
			}
			LOGGER.debug("<------ SBProtectionFilter doFilter end ------>");
		} 
		catch (Exception e) 
		{
			LOGGER.error("###UNEXPECTED ERROR###" ,e);
			writeErrorResponse(hres);
		}
		finally
		{
			LOGGER.info("###FILTEREXECUTION### Path " + hreq.getRequestURL()+" -- Execution Time @" + (System.currentTimeMillis()-startTime)+"@ MS");
		}
	}
	
	private boolean isRequestOK(HttpServletRequest hreq)
	{
		final HttpSession session = hreq.getSession();
		
		Boolean isAnonymous= Boolean.FALSE; 
	    if(session!=null && session.getAttribute(SBCONSTANT.ANONYMOUS.VALUE)!=null && ((Boolean)session.getAttribute(SBCONSTANT.ANONYMOUS.VALUE))){
	    	isAnonymous= Boolean.TRUE; 
	    }
	        
		boolean toRet = true;
		final String currentURL = hreq.getRequestURI();
		if ((currentURL != null && currentURL.indexOf("/inbound/res")>-1) || isAnonymous){
        	LOGGER.debug("SB Protection Filter skip for url : "+currentURL);
        } else if (hreq.getSession().getAttribute(SBCONSTANT.USERDETAIL.VALUE) == null) { 
			if (hreq.getRequestURI()==null || ! ( hreq.getRequestURI().endsWith("/chatinit")))
			{
				toRet = false;
			} 
		}
		
		return toRet;
	}

	@Override
	public void init(FilterConfig arg0) throws ServletException {
		LOGGER.info("###Initializing SBProtectionFilter###");
	}
	
}
