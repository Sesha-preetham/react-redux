package it.sella.sb.filter;

import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import com.fasterxml.jackson.databind.ObjectMapper;

import it.sella.sb.common.exception.SBBaseThrowable;
import it.sella.sb.im.response.BaseResponse;
import it.sella.sb.im.response.BaseResponse.BaseStatusEnum;

public abstract class BaseFilter {
	
	private static final Logger LOGGER = Logger.getLogger(BaseFilter.class);
	
	public BaseFilter() {
		super();
	}

	protected void writeErrorResponse(HttpServletResponse response) throws ServletException {
		try {
			response.setContentType("application/json");
			PrintWriter respOut = response.getWriter();
			//TODO - check for the dependency on the ObjectMapper in the Filter.
			ObjectMapper objMapper = new ObjectMapper();
			BaseResponse br = new BaseResponse();
			br.setErrorMessageCode("SB_AUTH_ERR");
			br.setStatus(BaseStatusEnum.EXCEPTION);
			objMapper.writer().writeValue(respOut, br);
		} catch (Exception e) {
			LOGGER.error("UNEXPECTED CAN'T send the response", e);
			throw new ServletException(e);
		}
	}
	
	protected void writeErrorResponse(final HttpServletResponse response,final SBBaseThrowable t) throws ServletException {
		try {
			response.setContentType("application/json");
			PrintWriter respOut = response.getWriter();
			//TODO - check for the dependency on the ObjectMapper in the Filter.
			ObjectMapper objMapper = new ObjectMapper();
			BaseResponse br = new BaseResponse();
			br.setErrorMessageCode(t.getCode());
			br.setStatus(BaseStatusEnum.EXCEPTION);
			objMapper.writer().writeValue(respOut, br);
		} catch (Exception e) {
			LOGGER.error("UNEXPECTED CAN'T send the response", e);
			throw new ServletException(e);
		}
	}
	
	protected void writeErrorResponse(final HttpServletResponse response,final BaseResponse baseResponse) throws ServletException {
		try {
			response.setContentType("application/json");
			PrintWriter respOut = response.getWriter();
			//TODO - check for the dependency on the ObjectMapper in the Filter.
			ObjectMapper objMapper = new ObjectMapper();
			BaseResponse br = new BaseResponse();
			br.setErrorMessageCode(baseResponse.getErrorMessageCode());
			br.setStatus(BaseStatusEnum.valueOf(baseResponse.getStatus()));
			objMapper.writer().writeValue(respOut, br);
		} catch (Exception e) {
			LOGGER.error("UNEXPECTED CAN'T send the response", e);
			throw new ServletException(e);
		}
	}

}