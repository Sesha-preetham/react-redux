package it.sella.sb.controller.im;

import java.util.Map;

import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import it.sella.sb.anagrafe.dto.PersonalDetails;
import it.sella.sb.common.IPropertyDao;
import it.sella.sb.common.exception.SBBaseThrowable;
import it.sella.sb.common.exception.SBCommonException;
import it.sella.sb.common.util.JsonUtil;
import it.sella.sb.core.facade.ChatMessageFacade;
import it.sella.sb.core.facade.ChatTypingFacade;
import it.sella.sb.core.facade.EndChatFacade;
import it.sella.sb.core.facade.NewChatFacade;
import it.sella.sb.core.facade.PersonalDetailsFacade;
import it.sella.sb.core.hb.UserDetailBuilder;
import it.sella.sb.core.im.MessageHandler;
import it.sella.sb.hb.dto.HBUserDetail;
import it.sella.sb.hb.dto.SbUserDetail;
import it.sella.sb.im.dto.request.ChatMessageRequest;
import it.sella.sb.im.dto.request.ChatRequest;
import it.sella.sb.im.dto.request.ChatTypingRequest;
import it.sella.sb.im.dto.request.IMRequest;
import it.sella.sb.im.dto.request.PagePropsRequest;
import it.sella.sb.im.dto.response.IMResponse;
import it.sella.sb.im.dto.response.PagePropsResponse;
import it.sella.sb.im.response.BaseResponse;
import it.sella.sb.im.response.BaseResponse.BaseStatusEnum;
import it.sella.sb.poll.dto.PollResponse;
import it.sella.sb.util.SBCONSTANT;

@RestController
public class IMController {

	@Autowired
	private MessageHandler messageHandler;
	
	@Autowired
	private NewChatFacade newChatFacade;
	
	@Autowired
	private EndChatFacade endChatFacade;
	
	@Autowired
	private ChatTypingFacade chatTypingFacade;
	
	@Autowired
	private ChatMessageFacade chatMessageFacade;
	
	@Autowired
	private PersonalDetailsFacade personalDetailsFacade;
	
	@Autowired
	private UserDetailBuilder userDetailBuilder; 
	
	@Autowired
	private IPropertyDao iPropertyDao;
	private static final Logger LOGGER = Logger.getLogger(IMController.class);

	@RequestMapping(value = "/user/createchat", method = {RequestMethod.POST})
	public @ResponseBody void createchat( final HttpSession session) {
		LOGGER.debug("Create Chat-->"+session.getId());
	}

	@RequestMapping(value = "/user/syncalias", method = {RequestMethod.POST})
	public @ResponseBody BaseResponse syncEventData( final @RequestBody HBUserDetail hbUserDetail,final HttpSession httpSession) {
		final BaseResponse response = new BaseResponse();
		try {
			final SbUserDetail userDetail = (SbUserDetail)httpSession.getAttribute(SBCONSTANT.USERDETAIL.VALUE);
			if(userDetail == null) {
				LOGGER.debug("IMController syncEventData sella bot not initialized");
				throw new SBCommonException("IMController syncEventData sella bot not initialized", SBCommonException.SB_NOT_INITIALIZED);
			}
			getUserDetailBuilder().parse(hbUserDetail,userDetail);
		} catch (SBBaseThrowable e) {
			LOGGER.error("IMController syncEventData SBBaseThrowable error message : "+e.getMessage(),e);
			response.setStatus(BaseStatusEnum.EXCEPTION);
			response.setErrorMessageCode(e.getCode());
		} catch (Exception e) {
			LOGGER.error("IMController syncEventData Exception error message : "+e.getMessage(),e);
			response.setStatus(BaseStatusEnum.EXCEPTION);
			response.setErrorMessageCode(SBBaseThrowable.SB_ERR_9999);
		}
		return response;
	}
	
	@RequestMapping(value = "/user/info", method = {RequestMethod.POST})
	public @ResponseBody PersonalDetails info(final HttpSession session) {
		LOGGER.debug("IMController user info -->");
		final SbUserDetail userDetail = (SbUserDetail)session.getAttribute(SBCONSTANT.USERDETAIL.VALUE);
		personalDetailsFacade.retrieveOnlineMessages(userDetail);
		if(userDetail == null) {
			LOGGER.debug("IMController syncEventData sella bot not initialized");
			throw new SBCommonException("IMController syncEventData sella bot not initialized", SBCommonException.SB_NOT_INITIALIZED);
		}
		return userDetail.getPersonalDet();
	}

	@RequestMapping(value = "/user/chat", method = {RequestMethod.POST})
	public @ResponseBody IMResponse chat(final @RequestBody IMRequest imRequest,final HttpSession session) {
		LOGGER.debug("Inside chat -->");
		imRequest.setChatid((String)session.getAttribute(SBCONSTANT.CHATID.VALUE));
		final IMResponse imResponse = getMessageHandler().process(imRequest);
		return imResponse;
	}
	
	@RequestMapping(value = "/user/newchat", method = {RequestMethod.POST})
	public @ResponseBody IMResponse newChat(@RequestBody final ChatRequest request,final HttpSession session) {
		LOGGER.debug("Inside newChat -->");
		final IMRequest imRequest = new IMRequest();
		imRequest.setChatid((String)session.getAttribute(SBCONSTANT.CHATID.VALUE));
		final SbUserDetail userDetail = (SbUserDetail)session.getAttribute(SBCONSTANT.USERDETAIL.VALUE);
		final IMResponse imResponse = getNewChatFacade().newChat(imRequest,userDetail);
		if(BaseStatusEnum.OK.name().equalsIgnoreCase(imResponse.getStatus())) {
			LOGGER.debug("New chat initiated chat id : "+imResponse.getChatid());
			session.setAttribute(SBCONSTANT.CHATID.VALUE, imResponse.getChatid());
			session.setAttribute(SBCONSTANT.CHATURL.VALUE, imResponse.getChaturl());
		}
		return imResponse;
	}
	
	@RequestMapping(value = "/user/endchat", method = {RequestMethod.POST})
	public @ResponseBody IMResponse endChat(@RequestBody final ChatRequest request,final HttpSession session) {
		LOGGER.debug("Inside endChat -->");
		final IMRequest imRequest = new IMRequest();
		imRequest.setChatid((String)session.getAttribute(SBCONSTANT.CHATID.VALUE));
		imRequest.setChaturl((String)session.getAttribute(SBCONSTANT.CHATURL.VALUE));
		final SbUserDetail userDetail = (SbUserDetail)session.getAttribute(SBCONSTANT.USERDETAIL.VALUE);
		final IMResponse imResponse = getEndChatFacade().endChat(imRequest,userDetail);
		if(BaseStatusEnum.OK.name().equalsIgnoreCase(imResponse.getStatus())) {
			session.removeAttribute(SBCONSTANT.CHATID.VALUE);
			session.removeAttribute(SBCONSTANT.CHATURL.VALUE);
		}
		return imResponse;
	}
	
	@RequestMapping(value = "/user/chattyping", method = {RequestMethod.POST})
	public @ResponseBody IMResponse chatTyping(@RequestBody final ChatTypingRequest request,final HttpSession session) {
		LOGGER.debug("Inside chatTyping -->");
		final IMRequest imRequest = new IMRequest();
		imRequest.setChatid((String)session.getAttribute(SBCONSTANT.CHATID.VALUE));
		imRequest.setChaturl((String)session.getAttribute(SBCONSTANT.CHATURL.VALUE));
		final IMResponse imResponse = getChatTypingFacade().chatTyping(imRequest,request);
		return imResponse;
	}
	
	@RequestMapping(value = "/user/chatmessage", method = {RequestMethod.POST})
	public @ResponseBody IMResponse chatMessage(@RequestBody final ChatMessageRequest request,final HttpSession session) {
		LOGGER.debug("Inside chatTyping -->");
		final IMRequest imRequest = new IMRequest();
		imRequest.setChatid((String)session.getAttribute(SBCONSTANT.CHATID.VALUE));
		imRequest.setChaturl((String)session.getAttribute(SBCONSTANT.CHATURL.VALUE));
		final SbUserDetail userDetail = (SbUserDetail) session.getAttribute(SBCONSTANT.USERDETAIL.VALUE);
		final IMResponse imResponse = getChatMessageFacade().chatMessage(imRequest,request,userDetail);
		return imResponse;
	}
	
	@RequestMapping(value = "/user/poll", method = {RequestMethod.POST})
	public @ResponseBody PollResponse pool(@RequestBody final IMRequest imRequest,final HttpSession session) {
		LOGGER.debug("Inside poll -->");
		PollResponse response = new PollResponse();
		final String chatid = (String)session.getAttribute(SBCONSTANT.CHATID.VALUE);
		final Boolean pollInProgress = (Boolean)session.getAttribute("PollInProgress");
		if(pollInProgress!=null && pollInProgress) {
			LOGGER.debug("<-- Poll already In progress -- >");
			response.setStatus(BaseStatusEnum.EXCEPTION);
			response.setErrorMessageCode(SBBaseThrowable.SB_SERVICE_IN_PROGRESS);
		} else {
			session.setAttribute("PollInProgress", Boolean.TRUE);
			response = getMessageHandler().readMessage(chatid,session);
			session.removeAttribute("PollInProgress");
		}
		return response;
	}
	
	@RequestMapping(value = "/inbound/res", method = {RequestMethod.POST})
	public void chatresult(final @RequestBody String value) {
		LOGGER.debug("Inside chatresult String -->"+value);
		try {
			final IMRequest imRequest = JsonUtil.convertToObject(value, IMRequest.class); 
			LOGGER.debug("Inside chatresult -->"+imRequest);
			LOGGER.debug("Inside chatresult Action-->"+imRequest.getAction());
			LOGGER.debug("Inside chatresult Chatid-->"+imRequest.getChatid());
			LOGGER.debug("Inside chatresult Idevent-->"+imRequest.getIdevent());
			imRequest.setSender(SBCONSTANT.BOT.VALUE);
			getMessageHandler().preserveMessage(imRequest,value,null);
		} catch (Exception e) {
			LOGGER.error("IMController chatresult Exception message : "+e.getMessage(),e );
		}
	}
	
	@RequestMapping(value = "/page/properties", method = {RequestMethod.POST})
	public @ResponseBody PagePropsResponse getPageProps( final @RequestBody PagePropsRequest request,final HttpSession httpSession) {
		final PagePropsResponse response = new PagePropsResponse();
		try {
			final SbUserDetail userDetail = (SbUserDetail)httpSession.getAttribute(SBCONSTANT.USERDETAIL.VALUE);
			if(userDetail == null) {
				LOGGER.debug("IMController syncEventData sella bot not initialized");
				throw new SBCommonException("IMController syncEventData sella bot not initialized", SBCommonException.SB_NOT_INITIALIZED);
			}
			Map<String, String> props = iPropertyDao.getPropertiesByCodice(request.getCode(), userDetail.getBank() != null ? userDetail.getBank().getBankCode() : "");
			response.getProps().putAll(props);
		} catch (SBBaseThrowable e) {
			LOGGER.error("IMController getPageProps SBBaseThrowable error message : "+e.getMessage(),e);
			response.setStatus(BaseStatusEnum.EXCEPTION);
			response.setErrorMessageCode(e.getCode());
		} catch (Exception e) {
			LOGGER.error("IMController getPageProps Exception error message : "+e.getMessage(),e);
			response.setStatus(BaseStatusEnum.EXCEPTION);
			response.setErrorMessageCode(SBBaseThrowable.SB_ERR_9999);
		}
		return response;
	}
	
	protected MessageHandler getMessageHandler() {
		return messageHandler;
	}

	protected UserDetailBuilder getUserDetailBuilder() {
		return userDetailBuilder;
	}

	protected NewChatFacade getNewChatFacade() {
		return newChatFacade;
	}

	protected EndChatFacade getEndChatFacade() {
		return endChatFacade;
	}

	protected ChatTypingFacade getChatTypingFacade() {
		return chatTypingFacade;
	}

	protected ChatMessageFacade getChatMessageFacade() {
		return chatMessageFacade;
	}

	protected PersonalDetailsFacade getPersonalDetailsFacade() {
		return personalDetailsFacade;
	}

}
