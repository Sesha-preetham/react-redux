package it.sella.sb.controller;

import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import it.sella.sb.im.response.BaseResponse;

@RestController
public class SellaBotController {

	private static final Logger LOGGER = Logger.getLogger(SellaBotController.class);

	@RequestMapping(value = "/ping", method = {RequestMethod.GET,RequestMethod.POST})
	public @ResponseBody BaseResponse ping(final HttpSession session) {
		LOGGER.debug("SellaBotController ping -->");
		return new BaseResponse();
	}

}
