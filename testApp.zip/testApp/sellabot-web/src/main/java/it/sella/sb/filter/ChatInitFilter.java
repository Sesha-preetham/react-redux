package it.sella.sb.filter;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import javax.annotation.PostConstruct;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import it.sella.sb.anagrafe.dto.PersonalDetails;
import it.sella.sb.common.IPropertyDao;
import it.sella.sb.common.util.DateUtility;
import it.sella.sb.common.util.StringUtility;
import it.sella.sb.core.exception.SBCoreException;
import it.sella.sb.core.facade.AlghoFacade;
import it.sella.sb.core.facade.PersonalDetailsFacade;
import it.sella.sb.core.factory.CrossAuthFactory;
import it.sella.sb.hb.dto.Bank;
import it.sella.sb.hb.dto.SbUserDetail;
import it.sella.sb.util.SBCONSTANT;

@Component("chatInitFilter")
public class ChatInitFilter implements Filter {

	private static final Logger LOGGER = Logger.getLogger(ChatInitFilter.class);
	
	@Autowired
	private AlghoFacade alghoFacade;

	@Autowired
	private CrossAuthFactory crossAuthFactory;

	@Autowired
	private PersonalDetailsFacade personalDetailsFacade;
	@Value("${channel}")
	private String channels;
	static List<String> channelList;
	@Value("${categoria}")
	private String categoria;
	static List<String> categoriaList;
	
	@Value("${AppName}")
	private String appname;
	@Value("${AppName_Mobile}")
	private String appname_Mobile;
	@Value("${AppName_SME}")
	private String appname_SME;
	@Value("${AppName_BSE_EMAIL}")
	private String appname_Email;
	
	@Autowired
	private IPropertyDao propertyDao;


	public ChatInitFilter() {
		LOGGER.debug("ChatInitFilter constructor created");
	}

	@Override
	public void destroy() {
		LOGGER.debug("ChatInitFilter destroy called");
	}

	@PostConstruct
	public void initialize(){
		if(channelList==null){
			channelList = Arrays.asList(channels.split(","));
		}
		if(categoriaList==null){
			categoriaList = Arrays.asList(categoria.split(","));
		}
	}

	@Override
	public void doFilter(final ServletRequest request, final ServletResponse response, final FilterChain chain) throws IOException, ServletException {
		try{
			LOGGER.debug("<------ ChatInitFilter doFilter start ------>");
			final HttpServletRequest httpServletRequest = (HttpServletRequest) request;
			final HttpServletResponse httpServletResponse = (HttpServletResponse) response;
			final HttpSession session = httpServletRequest.getSession();

			Boolean isAnonymous= Boolean.FALSE;
			if((session!=null) && (session.getAttribute(SBCONSTANT.ANONYMOUS.VALUE)!=null) && ((Boolean)session.getAttribute(SBCONSTANT.ANONYMOUS.VALUE))){
				isAnonymous= Boolean.TRUE;
			}

			final SbUserDetail userDetail = new SbUserDetail();
			if(!isAnonymous){
				/*if(session.getAttribute("cnctr-ssocookie")!=null){
					final String token = ((ConnectedUser) session.getAttribute("cnctr-ssocookie")).getSsotoken();
					final FederationInformation fi = new FederationInformation();
					fi.setUserToken(token);
					userDetail.setFederationInformation(fi);

					final String cnctrToken = ((HttpServletRequest)request).getHeader("x-cnctr-oauth-token");
					if(cnctrToken!=null) {
						userDetail.setCnctrToken(cnctrToken); //Not Used
					}
					LOGGER.debug("cnctrToken -->"+cnctrToken);

					anagrafeService.validateSSOToken(userDetail);
				}else {*/

				userDetail.setFederationInformation(getCrossAuthFactory().getFederationInformation());
				userDetail.setPersonalDet(getPersonalDetailsFacade().getPersonalDetails(userDetail));

				final String cnctrToken = (String)session.getAttribute("x-cnctr-oauth-token");
				if(cnctrToken!=null) {
					userDetail.getPersonalDet().setCnctrToken(cnctrToken);
				}
				//}

				LOGGER.debug("userDetail -->"+userDetail.getFederationInformation());
				if(userDetail.getFederationInformation()!=null) {
					LOGGER.debug("userDetail.getFederationInformation -->"+userDetail.getFederationInformation().getAbi()+"--"+userDetail.getFederationInformation().getIdSoggetto());
				}
				userDetail.setIsAnonymous(Boolean.FALSE);
				userDetail.getPersonalDet().setIsAnonymous(Boolean.FALSE);
				userDetail.getPersonalDet().setIsShowButton(Boolean.TRUE);//To verify Sella_sito_free_authenticated
			}else{
				//Get user Details from parameter for Free chat
				final String nome = httpServletRequest.getParameter(SBCONSTANT.NOME.VALUE);
				final String cogNome = httpServletRequest.getParameter(SBCONSTANT.COGNOME.VALUE);
				final String email = httpServletRequest.getParameter(SBCONSTANT.EMAIL.VALUE);

				final PersonalDetails personalDetails = new PersonalDetails();
				personalDetails.setIsAnonymous(Boolean.TRUE);
				personalDetails.setIsShowButton(Boolean.FALSE);
				LOGGER.debug("Nome, cognome and email from Parameter --> "+nome+" -- "+cogNome+" -- "+email);
				if(!StringUtility.isEmpty(nome) && !StringUtility.isEmpty(cogNome)){
					personalDetails.setNome(nome);
					personalDetails.setCognome(cogNome);
					personalDetails.setEmail(email);
				}
				userDetail.setPersonalDet(personalDetails);
			}

			LOGGER.debug("ChatInitFilter  getting personal details for user --> "+userDetail.getUserId());
			final String uuid = UUID.randomUUID().toString();
			LOGGER.debug("Random UUID -->"+uuid);
			userDetail.setUuId(uuid);
			userDetail.setIpAddress(getIpFromRequest(httpServletRequest));
			userDetail.setUserAgent( getUserAgent(httpServletRequest));
			userDetail.setChannelId(getChannelId(httpServletRequest));
			userDetail.setLogTime(DateUtility.getStringFromDate(new Date(), DateUtility.DATE_TIME_FORMAT_6));
			userDetail.setBancaId(userDetail.getIsAnonymous() ? SBCONSTANT.ABI_ANONYMOUS_USER.VALUE : userDetail.getFederationInformation().getAbi()); /////
			userDetail.setIsAnonymous(isAnonymous);
			userDetail.setCategoria(getCategoria(httpServletRequest));
			
			//this is to check the appname details based on channel
			String tempAppName = this.appname;
			if(StringUtility.isMobileChannel(userDetail.getChannelId())) {
				tempAppName = this.appname_Mobile;
			}else if(StringUtility.isSME(userDetail.getChannelId())) {
				tempAppName = this.appname_SME;
			}else if(StringUtility.isEmail(userDetail.getChannelId())){
				tempAppName = this.appname_Email;
			}
			userDetail.setAppName(tempAppName);
			LOGGER.info("ChatInitFilter AppName  >>>> "+tempAppName);
			
			List<String> intentCodeList=new ArrayList<String>();
			if(StringUtility.isSME(userDetail.getChannelId())){
				LOGGER.info("ChatInitFilter SME chat >>>> ");
				Bank bank = userDetail.getBank();
				intentCodeList = propertyDao.getParamValue(bank!=null ? bank.getBankCode() : "", tempAppName);
			}
			if(intentCodeList.size()==1 && intentCodeList.get(0).equals("*")){
				userDetail.setBlockAllIntents(true);
			}else{
				userDetail.setBlockParticularIntent(intentCodeList);
			}
			LOGGER.info("ChatInitFilter SME intentCodeList >>>> "+intentCodeList);
			final PersonalDetails personalDetails = userDetail.getPersonalDet();
			personalDetails.setNickName((personalDetails.getNome().substring(0, 1)+personalDetails.getCognome().substring(0, 1)).toUpperCase());
			personalDetails.setCategoria(userDetail.getCategoria());
			personalDetails.setChannelId(userDetail.getChannelId());
			personalDetails.setIsMobile(StringUtility.isMobileChannel(userDetail.getChannelId()));
			personalDetails.setIsSME(StringUtility.isSME(userDetail.getChannelId()));

			String redirectPage = "/sellabot/index.jsp";
			String useAlghoProp = propertyDao.getPropertyValue(SBCONSTANT.USE_ALGHO.VALUE, (userDetail.getBank() != null) ? userDetail.getBank().getBankCode() : "", SBCONSTANT.ACTIVE.VALUE);
			String useAlghoByChannel = propertyDao.getPropertyValue(SBCONSTANT.USE_ALGHO.VALUE, (userDetail.getBank() != null) ? userDetail.getBank().getBankCode() : "", userDetail.getChannelId());
			userDetail.setUseAlgho(SBCONSTANT.Y.VALUE.equalsIgnoreCase(useAlghoProp) || SBCONSTANT.Y.VALUE.equalsIgnoreCase(useAlghoByChannel));
			if(userDetail.getUseAlgho()){
				String redirectPageFromDb = propertyDao.getPropertyValue(SBCONSTANT.CONFIG.VALUE, (userDetail.getBank() != null) ? userDetail.getBank().getBankCode() : "", SBCONSTANT.REDIRECT_PAGE.VALUE );
				userDetail.setContext(alghoFacade.getContext(userDetail));
				userDetail.setAlghoUserId(alghoFacade.getUserId(userDetail));
				redirectPage = StringUtility.isEmpty(redirectPageFromDb)?"/sellabot/index_bot.jsp":redirectPageFromDb;
			}
			httpServletRequest.getSession().setAttribute(SBCONSTANT.USERDETAIL.VALUE, userDetail);
			LOGGER.debug("ChatInitFilter doFilter redirect to : " + redirectPage);

			httpServletResponse.sendRedirect(redirectPage);
			LOGGER.debug("<------ ChatInitFilter doFilter end ------>");
		}catch (Exception e) {
			LOGGER.error("<------ Exception ChatInitFilter doFilter() ------>"+e.getMessage(),e);
		}
	}

	@Override
	public void init(FilterConfig fConfig) throws ServletException {
		LOGGER.debug("SBIdentityAssertionFilter init initiated");
	}

	protected CrossAuthFactory getCrossAuthFactory() {
		return crossAuthFactory;
	}

	protected PersonalDetailsFacade getPersonalDetailsFacade() {
		return personalDetailsFacade;
	}

	private String getIpFromRequest(final HttpServletRequest request) {
		String ipAddress = request.getHeader("X-Forwarded-For");
		if (ipAddress == null) {
			ipAddress = request.getRemoteAddr();
		}
		ipAddress=ipAddress.split(",")[0];
		return ipAddress;
	}

	private String getChannelId(final HttpServletRequest request) {
		String channelId = request.getParameter(SBCONSTANT.CHANNEL.VALUE);
		//remove this default value after modifying in homebanking
		channelId = channelId!=null?channelId:"Sella_sito_free";
		if(!channelList.contains(channelId)){
			LOGGER.debug("Invalid Channel Id:"+channelId);
			throw new SBCoreException("Invalid Channel Id: "+channelId,SBCoreException.SB_AUTH_ERROR);
		}
		LOGGER.debug("Channel Id:"+channelId);
		return channelId;
	}

	private String getUserAgent(HttpServletRequest request){
		String userAgent = request.getHeader("USER-AGENT");
		if (userAgent==null){
			userAgent=request.getHeader("User-Agent");
		}
		return userAgent;
	}

	private String getCategoria(HttpServletRequest request){
		String categoria = request.getParameter("categoria");
		//remove this default value after modifying in homebanking
		categoria = categoria!=null?categoria:"Generico_CHAT";
		if(!categoriaList.contains(categoria)){
			LOGGER.debug("Invalid Categoria :"+categoria);
			throw new SBCoreException("Invalid Categoria: "+categoria,SBCoreException.SB_AUTH_ERROR);
		}
		LOGGER.debug("Categoria :"+categoria);
		return categoria;
	}

}
