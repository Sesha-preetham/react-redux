package it.sella.sb.filter;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Component;

@Component("logoutFilter")
public class LogoutFilter implements Filter{
	private static final Logger LOGGER = Logger.getLogger(LogoutFilter.class);
	
	@Override
	public void destroy() {
	}

	@Override
	public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain) throws IOException, ServletException {
	    final HttpServletRequest request = (HttpServletRequest) servletRequest;
	    final HttpServletResponse response = (HttpServletResponse) servletResponse;
	    LOGGER.debug("LogoutFilter : sessionId : " + request.getSession().getId());
	    doInValidate(request);
	    response.getWriter().write("{\"status\":\"OK\"}");
	}

	@Override
	public void init(FilterConfig arg0) throws ServletException {
	}
	
	private void doInValidate(final HttpServletRequest req) {
		req.getSession().invalidate();
		LOGGER.debug("LogoutFilter : Session Invalidation is Done");
	}

}
