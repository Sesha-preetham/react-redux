package it.sella.sb.filter;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;

import it.sella.ssoclient.openam.filter.ConnectorFilter;

/**
 * Servlet Filter implementation class ChatConnectorFilter
 */
public class ChatConnectorFilter extends ConnectorFilter {
	
	private static final Logger LOGGER = Logger.getLogger(ChatConnectorFilter.class);

	/**
	 * @see ConnectorFilter#ConnectorFilter()
	 */
	public ChatConnectorFilter() {
		super();
	}

	/**
	 * @see Filter#destroy()
	 */
	@Override
	public void destroy() {
	}

	/**
	 * @see Filter#doFilter(ServletRequest, ServletResponse, FilterChain)
	 */
	@Override
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		try {
			LOGGER.debug("<------ ChatConnectorFilter doFilter start ------>");
			if(((HttpServletRequest)request).getHeader("x-cnctr-oauth-token")!=null){
				LOGGER.debug("<------ ChatConnectorFilter doFilter set the x-cnctr-oauth-token  ------>");
				((HttpServletRequest)request).getSession().setAttribute("x-cnctr-oauth-token", ((HttpServletRequest)request).getHeader("x-cnctr-oauth-token"));
				super.doFilter(request, response, chain);
			}else{
				LOGGER.debug("<------ else ChatConnectorFilter doFilter() ------>");
				chain.doFilter(request, response);
			}
			LOGGER.debug("<------ ChatConnectorFilter doFilter end ------>");
		} catch (Exception e) {
			LOGGER.error("<------ Exception ChatConnectorFilter doFilter() ------>"+e.getMessage(),e);
		}
	}

	/**
	 * @see Filter#init(FilterConfig)
	 */
	@Override
	public void init(FilterConfig fConfig) throws ServletException {
		super.init(fConfig);
	}

}
