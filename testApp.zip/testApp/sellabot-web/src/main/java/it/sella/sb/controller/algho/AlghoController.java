package it.sella.sb.controller.algho;

import java.io.IOException;

import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import it.sella.sb.algho.dto.BotConfigResponse;
import it.sella.sb.algho.dto.BotLinkRequest;
import it.sella.sb.algho.dto.BotMessageRequest;
import it.sella.sb.algho.dto.BotStartRequest;
import it.sella.sb.core.facade.AlghoFacade;
import it.sella.sb.hb.dto.SbUserDetail;
import it.sella.sb.im.response.BaseResponse;
import it.sella.sb.util.SBCONSTANT;

@RestController
public class AlghoController {
	
	private static final Logger LOGGER = Logger.getLogger(AlghoController.class);


	@Autowired
	private AlghoFacade alghoFacade;
	
	
	@RequestMapping(value = "/bot/config", method = {RequestMethod.POST})
	public @ResponseBody BotConfigResponse getBotConfig(final HttpSession session) {
		LOGGER.debug("Inside getBotConfig -->");
		final SbUserDetail hbUserDetail = (SbUserDetail)session.getAttribute(SBCONSTANT.USERDETAIL.VALUE);
		return alghoFacade.getBotConfig(hbUserDetail);
	}
	
	
	@RequestMapping(value = "/bot/start", method = {RequestMethod.POST})
	public @ResponseBody BaseResponse botStart(final HttpSession session, @RequestBody BotStartRequest request) {
		LOGGER.debug("Inside botStart -->");
		final SbUserDetail hbUserDetail = (SbUserDetail)session.getAttribute(SBCONSTANT.USERDETAIL.VALUE);
		return alghoFacade.botStart(hbUserDetail, request, session);
	}
	
	@RequestMapping(value = "/bot/message", method = {RequestMethod.POST})
	public @ResponseBody BaseResponse botMessage(final HttpSession session, @RequestBody BotMessageRequest request) {
		LOGGER.debug("Inside botMessage -->");
		final SbUserDetail hbUserDetail = (SbUserDetail)session.getAttribute(SBCONSTANT.USERDETAIL.VALUE);
		return alghoFacade.botMessage(hbUserDetail, request);
	}
	
	@RequestMapping(value = "/bot/hblink", method = {RequestMethod.GET})
	public void botLink( final HttpServletResponse response , final HttpSession session, BotLinkRequest request) {
		LOGGER.debug("Inside botHBLink -->");
		final SbUserDetail hbUserDetail = (SbUserDetail)session.getAttribute(SBCONSTANT.USERDETAIL.VALUE);
		final String redirectLink = alghoFacade.botHbLink(hbUserDetail, request);
		try {
			response.sendRedirect(redirectLink);
		} catch (IOException e) {
			LOGGER.debug("IOException  botLink --> ", e);
		}
	}
	
}
