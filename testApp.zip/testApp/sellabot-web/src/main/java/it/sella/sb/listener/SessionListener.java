package it.sella.sb.listener;

import javax.servlet.http.HttpSessionEvent;
import javax.servlet.http.HttpSessionListener;

import org.apache.log4j.Logger;

import it.sella.sb.listener.util.SessionUtil;

public class SessionListener implements HttpSessionListener {

	private static final Logger LOGGER = Logger.getLogger(SessionListener.class);

	@Override
	public void sessionCreated(HttpSessionEvent paramHttpSessionEvent) {
		LOGGER.debug("SessionCreated -->"+paramHttpSessionEvent.getSession().getId());
	}

	@Override
	public void sessionDestroyed(HttpSessionEvent paramHttpSessionEvent) {
		SessionUtil.activeSessionMap.remove(paramHttpSessionEvent.getSession().getId());
		LOGGER.debug("SessionDestroyed -->"+paramHttpSessionEvent.getSession().getId());
	}

}
