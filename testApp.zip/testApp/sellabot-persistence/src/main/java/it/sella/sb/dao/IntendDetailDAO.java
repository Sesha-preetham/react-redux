package it.sella.sb.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Types;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import it.sella.sb.dao.datasource.SBDataSource;
import it.sella.sb.dao.exception.SBDaoException;
import it.sella.sb.hb.dto.SbUserDetail;
import it.sella.sb.poll.IIntendDetailDao;
import it.sella.sb.poll.dto.IntendDetail;

@Component
public class IntendDetailDAO extends SBDataSource implements IIntendDetailDao{
	
	private static final Logger LOGGER = Logger.getLogger(IntendDetailDAO.class);
	
	@Value("${GET_INTEND_DETAIL}")
	private String GET_INTEND_DETAIL;
	
	@Override
	public IntendDetail getIntendDetail(final String intendCode,final SbUserDetail sbUser) {
		final IntendDetail detail = new IntendDetail(); 
		try(Connection con = jdbcTemplate.getDataSource().getConnection();
				CallableStatement cs = con.prepareCall(GET_INTEND_DETAIL);){
			cs.setString(1, "");
			cs.setString(2, sbUser != null && sbUser.getBank() != null ? sbUser.getBank().getBankCode() : "" );
			cs.setString(3, "");
			cs.setString(4, intendCode);
			cs.registerOutParameter(5, Types.VARCHAR);
			cs.registerOutParameter(6, Types.VARCHAR);
			cs.registerOutParameter(7, Types.VARCHAR);
			cs.registerOutParameter(8, Types.VARCHAR);
			cs.registerOutParameter(9, Types.VARCHAR);
			cs.registerOutParameter(10, Types.VARCHAR);
			cs.execute();
			detail.setMenu(cs.getString(5));
			detail.setTab(cs.getString(6));
			detail.setSubTab(cs.getString(7));
			detail.setUrl(cs.getString(8));
			detail.setLink(cs.getString(9));
			detail.setLable(cs.getString(10));
		} catch (SQLException e) {
			LOGGER.error("SQLException while getting intend details for intend code : "+intendCode+" Error Message : "+e.getMessage(), e);
			throw new SBDaoException(e.getMessage(),SBDaoException.SB_DBA_001, e);
		} catch (Exception e) {
			LOGGER.error("Exception while getting intend details for intend code : "+intendCode+" Error Message : "+e.getMessage(), e);
			throw new SBDaoException(e.getMessage(),SBDaoException.SB_ERR_9999, e);
		}
		return detail;
	}

}
