package it.sella.sb.dao.datasource;

import javax.annotation.Resource;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.support.SQLErrorCodeSQLExceptionTranslator;
import org.springframework.transaction.PlatformTransactionManager;

import it.sella.sb.datasource.ISBDataSource;

public class SBDataSource extends DataSource implements ISBDataSource{

	public JdbcTemplate jdbcTemplate;
	public PlatformTransactionManager transactionManager;

	@Resource(name="oraBEDataSource")
	@Override
	public void setDataSource(final  javax.sql.DataSource dataSource) {
		this.jdbcTemplate = new JdbcTemplate(dataSource);
		this.jdbcTemplate.setExceptionTranslator(this.errorCodeSQLExceptionTranslator);
	}

	@Override
	public void setErrorCodeSQLExceptionTranslator(final SQLErrorCodeSQLExceptionTranslator errorCodeSQLExceptionTranslator){
		this.errorCodeSQLExceptionTranslator = errorCodeSQLExceptionTranslator;
	}

	@Override
	public void setTransactionManager(final PlatformTransactionManager transactionManager) {
		this.transactionManager = transactionManager;
	}

	@Override
	public JdbcTemplate getJdbcTemplate() {
		return this.jdbcTemplate;
	}

}
