package it.sella.sb.algho.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import it.sella.sb.algho.IConversationDAO;
import it.sella.sb.algho.dto.ConversationDTO;
import it.sella.sb.dao.datasource.SBDataSource;
import it.sella.sb.dao.exception.SBDaoException;

@Component
public class ConversationDAO extends SBDataSource implements IConversationDAO{
	
	private static final Logger LOGGER = Logger.getLogger(ConversationDAO.class);

	@Value("${INSERT_CONVERSATION}")
	private String INSERT_CONVERSATION;

	@Override
	public void insertConversation(final ConversationDTO dto) {
		LOGGER.info("Inserting ConversationDTO "+ dto);
		try(Connection con = jdbcTemplate.getDataSource().getConnection();
				PreparedStatement ps = con.prepareStatement(INSERT_CONVERSATION);){
			ps.setLong(1, dto.getConversationId());
			ps.setString(2, dto.getBotId());
			ps.setString(3, dto.getUserId());
			ps.setString(4, dto.getChannel());
			ps.setString(5, dto.getContext());
			ps.setString(6, dto.getCode());
			ps.setString(7, dto.getName());
			ps.setString(8, dto.getSurname());
			ps.setString(9, dto.getEmail());
			ps.setString(10, dto.getBank());
			ps.setString( 11, dto.getSoggetto());
			ps.executeUpdate();
		} catch (SQLException e) {
			LOGGER.error("SQLException while inserting conversation for code : "+dto.getConversationId()+" Error Message : "+e.getMessage(), e);
			throw new SBDaoException(e.getMessage(),SBDaoException.SB_DBA_001, e);
		} catch (Exception e) {
			LOGGER.error("Exception while inserting userid for code : "+dto.getConversationId()+" Error Message : "+e.getMessage(), e);
			throw new SBDaoException(e.getMessage(),SBDaoException.SB_ERR_9999, e);
		}
		return;
		
	}

}
