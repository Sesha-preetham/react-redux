package it.sella.sb.dao.common;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import it.sella.sb.common.IServiceStatusCheckDAO;
import it.sella.sb.dao.datasource.SBDataSource;
import it.sella.sb.dao.exception.SBDaoException;
import it.sella.sb.util.SBCONSTANT;
import oracle.jdbc.OracleTypes;

@Component
public class ServiceStatusCheckDAO extends SBDataSource implements IServiceStatusCheckDAO {
	
	private static final Logger LOGGER = Logger.getLogger(ServiceStatusCheckDAO.class);
	
	
	@Value("${GET_SERVICE_STATUS}")
	private String GET_SERVICE_STATUS;
	
	@Value("${GET_SERVICE_STATUS_ON_DATE}")
	private String GET_SERVICE_STATUS_ON_DATE;
	
	@Value("${GET_IS_OVERTIME}")
	private String GET_IS_OVERTIME;
	
	public boolean checkServiceOpen(final String serviceName, final String bankCode) throws SBDaoException 
	{
		
		if (!serviceName.equals("ND")) //This will help in case of "no service to check"
		{
			checkServiceClosedForAll(serviceName, bankCode);
			checkServiceClosedOnDate(serviceName, bankCode);
		}
		//In this way, during service closing i'll read every time the status and the cache will be updated only 
		//when the service will be reopened
		return true;
	}
	
	
	private void checkServiceClosedForAll(final String serviceName, final String bankCode) {
		final String serviceStatus = getServiceStatus(serviceName, bankCode);
		boolean isServiceOpen = serviceStatus != null && SERVICE_STATUS_OPEN.equalsIgnoreCase(serviceStatus.trim());
		if(!isServiceOpen){
			LOGGER.debug("service status isServiceOpenForAll CLOSED:" + serviceStatus + ": for the servicename:" + serviceName + ":for the bank " + bankCode);
			throw new SBDaoException("service status isServiceOpenForAll CLOSED:" + serviceStatus + ": for the servicename:" + serviceName + ":for the bank " + bankCode, "ERRDB993");
		}
	}
	
	private void checkServiceClosedOnDate(final String serviceName, final String bankCode) {
		final String serviceStatus = getServiceStatusOnDate(serviceName, bankCode);
		boolean isServiceOpenOnDate = serviceStatus != null && SERVICE_STATUS_OPENED.equalsIgnoreCase(serviceStatus.trim());
		if(!isServiceOpenOnDate){
			LOGGER.debug("service status isServiceOpenOnDate CLOSED:" + serviceStatus + ": for the servicename:" + serviceName + ":for the bank " + bankCode + "But Expected the status to be" +SERVICE_STATUS_OPENED );
			throw new SBDaoException("service status isServiceOpenOnDate CLOSED:" + serviceStatus + ": for the servicename:" + serviceName + ":for the bank " + bankCode + "But Expected the status to be" +SERVICE_STATUS_OPENED , "ERRDB992");
		}
	}
	
	private String getServiceStatus(final String serviceName, final String bankCode) {
		String serviceStatus = null;
		if (LOGGER.isDebugEnabled()){
			LOGGER.debug("Query: " + GET_SERVICE_STATUS + " ["+serviceName+","+bankCode+"]");
		}
		try(Connection connection = jdbcTemplate.getDataSource().getConnection();
		    PreparedStatement ps = connection.prepareStatement(GET_SERVICE_STATUS)){
			ps.setString(1, serviceName);
			ps.setString(2, bankCode);
			try(ResultSet rs = ps.executeQuery();){
				if(rs.next()){
					serviceStatus = rs.getString(1);
				}
			}
			if(serviceStatus == null){
				String msg = "GETSERVICESTATUS ASSUMED CLOSED!!! CHECK THE CONFIG FOR SERVICE :[" + serviceName + "] bankCode:[" +bankCode +  "]";
				LOGGER.warn(msg);
				serviceStatus = SERVICE_STATUS_CLOSED;
			}
		} catch (Exception e) {
			LOGGER.error("ERROR ON GETSERVICESTATUSONDATE FOR SERVICE :[" + serviceName + "] bankCode:[" +bankCode +  "] msg:" + e.getMessage(),e);
			throw new SBDaoException("ERROR ON GETSERVICESTATUSONDATE FOR SERVICE :[" + serviceName + "] bankCode:[" +bankCode +  "] msg:" + e.getMessage(),"ERRDB990",e);
		}
		return serviceStatus;
	}

	public String getServiceStatusOnDate(final String serviceName, final String bankCode){
		return getServiceStatusOnDate(serviceName, bankCode, "IB") ;
	}
	
	public String getServiceStatusOnDate(final String serviceName, final String bankCode, final String platform){
		String serviceStatus = null;
		if (LOGGER.isDebugEnabled()){
			LOGGER.debug("Query: " + GET_SERVICE_STATUS_ON_DATE + " ["+platform+","+serviceName+","+bankCode+"]");
		}
		try(Connection connection = jdbcTemplate.getDataSource().getConnection();
			CallableStatement cs = connection.prepareCall(GET_SERVICE_STATUS_ON_DATE)){
			cs.registerOutParameter(1, OracleTypes.VARCHAR);
			cs.setString(2, platform); 
            cs.setString(3, serviceName);
            cs.setString(4, bankCode);
            cs.execute();
            serviceStatus = cs.getString(1);
		} catch (Exception e) {
			LOGGER.error("ERROR ON GETSERVICESTATUSONDATE FOR SERVICE :[" + serviceName + "] bankCode:[" +bankCode +  "] msg:" + e.getMessage(),e);
			throw new SBDaoException("ERROR ON GETSERVICESTATUSONDATE FOR SERVICE :[" + serviceName + "] bankCode:[" +bankCode +  "] msg:" + e.getMessage(),"ERRDB990",e);
		}
		if(serviceStatus == null){
			String msg = "ERROR ON GETSERVICESTATUSONDATE CHECK THE CONFIG FOR SERVICE :[" + serviceName + "] bankCode:[" +bankCode +  "]";
			LOGGER.warn(msg);
			serviceStatus = SERVICE_STATUS_OPENED;
		}
		return serviceStatus;
	}


	@Override
	public boolean isOverTime(String bankCode) {
		boolean isOverTime = false;
		try(Connection con = jdbcTemplate.getDataSource().getConnection();
				PreparedStatement ps = con.prepareStatement(GET_IS_OVERTIME);
			){
			ps.setString(1, bankCode);
			try(ResultSet rs = ps.executeQuery()){
				while(rs.next()){
					isOverTime = SBCONSTANT.TRUE.VALUE.equalsIgnoreCase(rs.getString(1));
				}
			}
		} catch (SQLException e) {
			LOGGER.error("SQLException while isOverTime Error Message : "+e.getMessage(), e);
			throw new SBDaoException(e.getMessage(),SBDaoException.SB_DBA_001, e);
		} catch (Exception e) {
			LOGGER.error("Exception while isOverTime Error Message : "+e.getMessage(), e);
			throw new SBDaoException(e.getMessage(),SBDaoException.SB_ERR_9999, e);
		}
		return isOverTime;
		
	}
}
