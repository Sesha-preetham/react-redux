package it.sella.sb.dao.feedback;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import it.sella.sb.dao.datasource.SBDataSource;
import it.sella.sb.dao.exception.SBDaoException;
import it.sella.sb.feedback.IFeedBackDao;
import it.sella.sb.feedback.dto.Answer;
import it.sella.sb.feedback.dto.FeedBackRequest;
import it.sella.sb.feedback.dto.Option;
import it.sella.sb.feedback.dto.Question;
import it.sella.sb.hb.dto.SbUserDetail;
import it.sella.sb.im.response.BaseResponse;

@Component
public class FeedBackDao extends SBDataSource implements IFeedBackDao{
	
	private static final Logger LOGGER = Logger.getLogger(FeedBackDao.class);
	
	@Value("${GET_FEEDBACK_QUESTIONS}")
	private String GET_FEEDBACK_QUESTIONS;
	
	@Value("${INSERT_FEEDBACK}")
	private String INSERT_FEEDBACK;
	
	@Override
	public List<Question> getQuestions(final SbUserDetail sbUser) {
		final Map<String, Question> map = new HashMap<String, Question>(); 
		try(Connection con = jdbcTemplate.getDataSource().getConnection();
				PreparedStatement ps = con.prepareCall(GET_FEEDBACK_QUESTIONS);
				ResultSet rs = ps.executeQuery()){
			while(rs.next()){
				final String questionId = rs.getString(1);
				if(map.containsKey(questionId)){
					final Option opt = new Option();
					opt.setOptionId(rs.getString(4));
					opt.setOptionDesc(rs.getString(5));
					opt.setOther(rs.getString(6));
					map.get(questionId).getOptions().add(opt);
				} else {
					final Question question = new Question();
					question.setQuestionId(questionId);
					question.setQuestionDesc(rs.getString(2));
					question.setQuestionType(rs.getString(3));
					question.setQuestionOrder(rs.getInt(7));
					final Option opt = new Option();
					opt.setOptionId(rs.getString(4));
					opt.setOptionDesc(rs.getString(5));
					opt.setOther(rs.getString(6));
					question.getOptions().add(opt);
					map.put(questionId, question);
				}
			}
		} catch (SQLException e) {
			LOGGER.error("SQLException while FeedBackDao getQuestions Error Message : "+e.getMessage(), e);
			throw new SBDaoException(e.getMessage(),SBDaoException.SB_DBA_001, e);
		} catch (Exception e) {
			LOGGER.error("Exception while FeedBackDao getQuestions Error Message : "+e.getMessage(), e);
			throw new SBDaoException(e.getMessage(),SBDaoException.SB_ERR_9999, e);
		}
		List<Question> response = new ArrayList<Question>(map.values());
		Collections.sort(response);
		return response;
	}
	
	@Override
	public BaseResponse insertFeedback(final FeedBackRequest request,final SbUserDetail sbUser) {
		final BaseResponse response = new BaseResponse();
		try(Connection con = jdbcTemplate.getDataSource().getConnection();)
		{
			
			
			String userId = sbUser.getUserId()!=null && sbUser.getUserId().length()<=8?sbUser.getUserId():"";
			String chatId = sbUser.getChatid()!=null ?sbUser.getChatid():"";
			String emailId = (sbUser.getPersonalDet()!=null && sbUser.getPersonalDet().getEmail()!=null) ? sbUser.getPersonalDet().getEmail() : "";
			String appName = sbUser.getAppName()!=null ? sbUser.getAppName():"";;
			for (Answer answer : request.getAnswers()) {
				try(PreparedStatement ps = con.prepareCall(INSERT_FEEDBACK);)
				{
					
					ps.setString(1, userId);
					ps.setString(2, answer.getAnswerId());
					ps.setString(3, answer.getAnswer());
					ps.setString(4, chatId);
					ps.setString(5, emailId);
					ps.setString(6, appName);
					ps.execute();
				}
			}
		} catch (SQLException e) {
			LOGGER.error("SQLException while FeedBackDao insertFeedback Error Message : "+e.getMessage(), e);
			throw new SBDaoException(e.getMessage(),SBDaoException.SB_DBA_001, e);
		} catch (Exception e) {
			LOGGER.error("Exception while FeedBackDao insertFeedback Error Message : "+e.getMessage(), e);
			throw new SBDaoException(e.getMessage(),SBDaoException.SB_ERR_9999, e);
		}
		return response;
	}

}
