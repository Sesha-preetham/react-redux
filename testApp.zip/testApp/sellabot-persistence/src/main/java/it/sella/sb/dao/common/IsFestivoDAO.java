package it.sella.sb.dao.common;


import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import it.sella.sb.common.IIsFestivoDAO;
import it.sella.sb.dao.datasource.SBDataSource;
import it.sella.sb.dao.exception.SBDaoException;

@Component
public class IsFestivoDAO extends SBDataSource implements IIsFestivoDAO {
	
	private static final Logger LOGGER = Logger.getLogger(IsFestivoDAO.class);
	
	@Value("${FESTIVAL_CHECK}")
	private String FESTIVAL_CHECK;
	
	public boolean isFestivo(final Date checkDate) {
		try(Connection c = jdbcTemplate.getDataSource().getConnection();
	        		CallableStatement cs = c.prepareCall(FESTIVAL_CHECK);)
        {    	
        	LOGGER.debug("isFestivo " + " - Date :"+checkDate);
			cs.registerOutParameter(1, Types.INTEGER);
			final java.sql.Date sqlDate = new java.sql.Date(checkDate.getTime());
            cs.setDate(2, sqlDate);	            
            cs.execute();	            
            return cs.getInt(1)==0 ? false : true;
        } catch (final SQLException ex) {
			LOGGER.error("###IsFestivoDAO isFestivo# Problem",ex);
			throw new SBDaoException(ex.getMessage(),SBDaoException.SB_DBA_001, ex);
		} catch (final Exception ex) {
			LOGGER.error("###IsFestivoDAO isFestivo# Problem",ex);
			throw new SBDaoException(ex.getMessage(),SBDaoException.SB_ERR_9999, ex);
		} 
     }
	
	public List<Date> getBetweenDates(Date fromDate, Date toDate, boolean removeHoliday) {
        LOGGER.debug("fromDate: " + fromDate + "  toDate: " + toDate);
        List<Date> betweenDates = new ArrayList<Date>();
        Calendar currDate = Calendar.getInstance();
        currDate.setTime(fromDate);
        Calendar lastDate = Calendar.getInstance();
        lastDate.setTime(toDate);
        try{
            while( !currDate.after(lastDate) ) {
                if(!removeHoliday){
                    betweenDates.add(currDate.getTime());
                }
                else{                	
                	if(!isFestivo(currDate.getTime())) {
                		//not festivo
                		betweenDates.add(currDate.getTime());
                    }                    
                }
                currDate.add(Calendar.DATE, 1);
            }
        }catch(Exception ex){
            LOGGER.error("Error during isFestivo DAO call.",ex);
        } 
        return betweenDates;
    }

}

