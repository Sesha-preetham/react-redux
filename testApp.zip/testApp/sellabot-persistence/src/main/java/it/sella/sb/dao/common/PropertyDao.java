package it.sella.sb.dao.common;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.Cache;
import org.springframework.cache.CacheManager;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Component;

import it.sella.sb.common.IPropertyDao;
import it.sella.sb.common.util.StringUtility;
import it.sella.sb.dao.datasource.SBDataSource;
import it.sella.sb.dao.exception.SBDaoException;

@Component
public class PropertyDao extends SBDataSource implements IPropertyDao {

	private static final Logger LOGGER = Logger.getLogger(PropertyDao.class);

	@Value("${QUERY_PROPERTY}")
	private String QUERY_PROPERTY;
	
	@Value("${INTENTCODE_QUERY}")
	private String INTENTCODE_QUERY;

	@Autowired
	CacheManager cacheManager;

	@Override
	@Cacheable(value="sb.propertiesByCodice", key="#codice+#banca")
	public Map<String,String> getPropertiesByCodice(final String codice, final String banca) {
		try(Connection c = jdbcTemplate.getDataSource().getConnection();PreparedStatement ps = c.prepareStatement(QUERY_PROPERTY);) {
			final HashMap<String, String> propertiesByCodice = new HashMap<String, String>();
			ps.setString(1, codice);
			ps.setString(2, (!StringUtility.isEmpty(banca) ? banca : "*"));
			try(ResultSet rs = ps.executeQuery()) {
				while (rs.next()) {
					propertiesByCodice.put(rs.getString("BOT_TRI_PARAMETER"),rs.getString("BOT_TRI_VALUE"));
				}
			}
			return propertiesByCodice;
		} catch (final SQLException e) {
			LOGGER.error("### error in fetch property table query:"+ QUERY_PROPERTY +" codice:" + codice+" banca:" + banca, e);
			throw new SBDaoException(e.getMessage(),SBDaoException.SB_DBA_001, e);

		} catch (final Exception e) {
			LOGGER.error("### error in fetch property table query:"+ QUERY_PROPERTY +" codice:" + codice +" banca:" + banca , e);
			throw new SBDaoException(e.getMessage(),SBDaoException.SB_ERR_9999, e);
		} 
	}

	@Override
	public String getPropertyValue(final String codice, final String banca, final String key) {
		final Cache propertiesByCodiceCache = cacheManager.getCache("sb.propertiesByCodice");
		Map<String,String> propertiesFromCache = getPropertiesFromCache(propertiesByCodiceCache,codice, banca);
		if(propertiesFromCache == null) {
			LOGGER.debug("populating cache for codice:" + codice + "banca:" + banca + "key: " + key);
			final Map<String,String> newPropertiesByCodice = getPropertiesByCodice(codice, banca);
			propertiesByCodiceCache.put(codice + banca, newPropertiesByCodice);
			propertiesFromCache = newPropertiesByCodice;
		}
		return propertiesFromCache.get(key);
	}

	@SuppressWarnings("unchecked")
	private Map<String,String> getPropertiesFromCache(final Cache propertiesByCodiceCache, final String codice, final String banca) {
		HashMap<String,String> properties = null;
		if(propertiesByCodiceCache != null) {
			properties = propertiesByCodiceCache.get(codice + banca,HashMap.class);
		}
		return properties;
	}
	
	@Override
	public List<String> getParamValue(final String banca, final String channel) {
		LOGGER.info(" Inside PropertyDao getParamValue() channel >>>> "+channel); 
		String intentCode =null;
		List<String> intentCodeList = new ArrayList<String>();
		try(Connection c = jdbcTemplate.getDataSource().getConnection();
				PreparedStatement ps = c.prepareStatement(INTENTCODE_QUERY);) {
			ps.setString(1, channel);
			ps.setString(2, (!StringUtility.isEmpty(banca) ? banca : "*"));
			try(ResultSet rs = ps.executeQuery()) {
				while (rs.next()) {
					intentCode = rs.getString("BOT_TRI_VALUE");
				}
			}
			if(!StringUtility.isEmpty(intentCode)){
				intentCodeList.addAll(Arrays.asList(intentCode.split(",")));
			}
			LOGGER.info(" Inside PropertyDao getParamValue() intentCodeList >>>> "+intentCodeList); 
		} catch (final SQLException e) {
			LOGGER.error("### error in fetch property table query:"+ QUERY_PROPERTY +" banca:" + banca, e);
			throw new SBDaoException(e.getMessage(),SBDaoException.SB_DBA_001, e);

		} catch (final Exception e) {
			LOGGER.error("### error in fetch property table query:"+ QUERY_PROPERTY +" banca:" + banca , e);
			throw new SBDaoException(e.getMessage(),SBDaoException.SB_ERR_9999, e);
		} 
		return intentCodeList;
	}
	
}
