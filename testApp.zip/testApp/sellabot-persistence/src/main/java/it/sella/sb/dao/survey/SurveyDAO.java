package it.sella.sb.dao.survey;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import it.sella.sb.dao.datasource.SBDataSource;
import it.sella.sb.dao.exception.SBDaoException;
import it.sella.sb.survey.AnswerDTO;
import it.sella.sb.survey.AnswerResponseDTO;
import it.sella.sb.survey.QuestionDTO;
import it.sella.sb.survey.SurveyDTO;
import it.sella.sb.survey.SurveyRequestDTO;
import it.sella.sb.util.SBCONSTANT;
import it.sella.sb.util.SQL;

@Component
public class SurveyDAO extends SBDataSource {

	private static final Logger LOGGER = Logger.getLogger(SurveyDAO.class);

	@Value("${GET_CUSTOMER_SURVEY_DETAILS}")
	private String GET_CUSTOMER_SURVEY_DETAILS;
	
	@Value("${GET_INITIAL_QUE_DETAILS}")
	private String GET_INITIAL_QUE_DETAILS;
	
	@Value("${GET_CONTINUE_QUE_DETAILS}")
	private String GET_CONTINUE_QUE_DETAILS;
	
	@Value("${INSERT_BOT_SMS_TRACE}")
	private String INSERT_BOT_SMS_TRACE;
	
	@Value("${GET_QUESTION_TYPE}")
	private String GET_QUESTION_TYPE;
	
	@Value("${GET_END_QUESTION_DETAILS}")
	private String GET_END_QUESTION_DETAILS;
	
	public SurveyDTO getCustomerSurveyDetails(final String smsKey) {
		LOGGER.info("Inside SurveyDAO getCustomerSurveyDetails() smsKey ---> "+smsKey);
		SurveyDTO survey = new SurveyDTO();
		try (Connection c = jdbcTemplate.getDataSource().getConnection();
				PreparedStatement ps = c.prepareStatement(GET_CUSTOMER_SURVEY_DETAILS);) {
			ps.setString(1, smsKey);
			try (ResultSet rs = ps.executeQuery()) {
				while (rs.next()) {
					survey.setId(rs.getLong(SQL.COLUMN.ID.VALUE));
					survey.setContactNumber(rs.getString(SQL.COLUMN.PHONE.VALUE));
					survey.setSmsKey(rs.getString(SQL.COLUMN.SMS_KEY.VALUE));
					survey.setState(rs.getString(SQL.COLUMN.STATE.VALUE));
					survey.setSurveyId(rs.getLong(SQL.COLUMN.SUR_ID.VALUE));
				}
			}
			LOGGER.info("Exit SurveyDAO getCustomerSurveyDetails() surveyId ---> "+survey.getSurveyId());
			return survey;
		} catch (final SQLException e) {
			LOGGER.error("### error in fetch property table query:" + GET_CUSTOMER_SURVEY_DETAILS + " key:" + smsKey, e);
			throw new SBDaoException(e.getMessage(), SBDaoException.SB_DBA_001, e);

		} catch (final Exception e) {
			LOGGER.error("### error in fetch property table query:" + GET_CUSTOMER_SURVEY_DETAILS + " key:" + smsKey, e);
			throw new SBDaoException(e.getMessage(), SBDaoException.SB_ERR_9999, e);
		}
	}
	
	public void updateSurveyDetails(final String keyToUpdate, final Long surveyId, final Boolean dateUpdate, final String consent) {
		LOGGER.info("Inside SurveyDAO updateSurveyDetails() keyToUpdate ---> "+keyToUpdate);
		LOGGER.info("Inside SurveyDAO updateSurveyDetails() surveyId ---> "+surveyId);
		StringBuffer QUERY = new StringBuffer();
		if(dateUpdate){
			QUERY.append("update weblogic_dba.BOT_SMS_TR set "+keyToUpdate+"= sysdate ");
			if(SBCONSTANT.SUR_COMPL.VALUE.equalsIgnoreCase(keyToUpdate)){
				QUERY.append(",STATE='COMPLETED' ");
			}
			QUERY.append("where id = "+surveyId);
		}else{
			QUERY.append("update weblogic_dba.BOT_SMS_TR set "+keyToUpdate+"='"+consent+"' where id = "+surveyId);
		}
		try (Connection c = jdbcTemplate.getDataSource().getConnection();
				PreparedStatement ps = c.prepareStatement(QUERY.toString());) {
			ps.executeUpdate();
			LOGGER.info(" SurveyDetails Updated successfully!! ");
		} catch (final SQLException e) {
			LOGGER.error("### error in query:" + QUERY, e);
			throw new SBDaoException(e.getMessage(), SBDaoException.SB_DBA_001, e);

		} catch (final Exception e) {
			LOGGER.error("### error in query:" + QUERY, e);
			throw new SBDaoException(e.getMessage(), SBDaoException.SB_ERR_9999, e);
		}
	}
	
	public String getNextQuestionType(final Long questionId, final Long answerId) {
		LOGGER.info("Inside SurveyDAO getNextQuestionType() [ answerId - "+answerId+" ], [ questionId - "+questionId+" ]");
		String nextQuestionType="";
		try (Connection c = jdbcTemplate.getDataSource().getConnection();
				PreparedStatement ps = c.prepareStatement(GET_QUESTION_TYPE);) {
			ps.setLong(1, questionId);
			ps.setLong(2, answerId);
			try (ResultSet rs = ps.executeQuery()) {
				while (rs.next()) {
					nextQuestionType=rs.getString(SQL.COLUMN.ATYPE.VALUE);
				}
			}
			LOGGER.info("Exit SurveyDAO getNextQuestionType() nextQuestionType ---> " + nextQuestionType);
			return nextQuestionType;
		} catch (final SQLException e) {
			LOGGER.error("### error in query:" + GET_QUESTION_TYPE , e);
			throw new SBDaoException(e.getMessage(), SBDaoException.SB_DBA_001, e);

		} catch (final Exception e) {
			LOGGER.error("### error in query:" + GET_QUESTION_TYPE, e);
			throw new SBDaoException(e.getMessage(), SBDaoException.SB_ERR_9999, e);
		}
	}
	
	public AnswerResponseDTO answer(final SurveyRequestDTO request) {
		LOGGER.info("Inside SurveyDAO answer() surveyId ---> "+request.getSurveyId());
		LOGGER.info("Inside SurveyDAO answer() type ---> "+request.getType());
		AnswerResponseDTO answerResponseDTO = new AnswerResponseDTO();
		String QUERY="";
		if(SBCONSTANT.INITIAL.VALUE.equalsIgnoreCase(request.getType())){
			QUERY = GET_INITIAL_QUE_DETAILS.replace(":survId", request.getSurveyId()+"");
		}else if(SBCONSTANT.CONTINUE.VALUE.equalsIgnoreCase(request.getType())){
			QUERY = GET_CONTINUE_QUE_DETAILS.replace(":queId", request.getQuesId()+"");
			QUERY = QUERY.replace(":ansId", request.getAnswer().getId()+"");
		}
		LOGGER.info("Inside SurveyDAO answer() QUERY ---> "+QUERY);
		QuestionDTO questionDTO = new QuestionDTO();
		List<AnswerDTO> answers = new ArrayList<>();
		try (Connection c = jdbcTemplate.getDataSource().getConnection();
				PreparedStatement ps = c.prepareStatement(QUERY);) {
			try (ResultSet rs = ps.executeQuery()) {
				while (rs.next()) {
					AnswerDTO answerDTO = new AnswerDTO();
					//question details
					Long questionId = rs.getLong(SQL.COLUMN.QID.VALUE);
					String qText = rs.getString(SQL.COLUMN.QTEXT.VALUE);
					//answer details for above question
					Long aId = rs.getLong(SQL.COLUMN.AID.VALUE);
					String aCode = rs.getString(SQL.COLUMN.ACODE.VALUE);
					String aLabel = rs.getString(SQL.COLUMN.ALABEL.VALUE);
					String aType = rs.getString(SQL.COLUMN.ATYPE.VALUE);
					
					questionDTO.setId(questionId);
					questionDTO.setQuestion(qText);
					questionDTO.setType(aType);
					answerDTO.setId(aId);
					
					answerDTO.setLabelcode(aLabel);
					answerDTO.setValue(aCode);
					answers.add(answerDTO);
				}
				questionDTO.setAnswers(answers);
				answerResponseDTO.setNextSurvey(questionDTO);
			}
			LOGGER.info("Exit SurveyDAO answer() surveyId ---> ");
			return answerResponseDTO;
		} catch (final SQLException e) {
			LOGGER.error("### error in query:" + QUERY + " key:" + request.getSurveyId(), e);
			throw new SBDaoException(e.getMessage(), SBDaoException.SB_DBA_001, e);

		} catch (final Exception e) {
			LOGGER.error("### error in table query:" + QUERY + " key:" + request.getSurveyId(), e);
			throw new SBDaoException(e.getMessage(), SBDaoException.SB_ERR_9999, e);
		}
	}
	
	public AnswerResponseDTO getEndQuestionDetails(final Long questionId, final Long answerId) {
		LOGGER.info("Inside SurveyDAO getEndQuestionDetails() [ answerId - "+answerId+" ], [ questionId - "+questionId+" ]");
		AnswerResponseDTO answerResponseDTO = new AnswerResponseDTO();
		QuestionDTO questionDTO = new QuestionDTO();
		try (Connection c = jdbcTemplate.getDataSource().getConnection();
				PreparedStatement ps = c.prepareStatement(GET_END_QUESTION_DETAILS);) {
			ps.setLong(1, questionId);
			ps.setLong(2, answerId);
			try (ResultSet rs = ps.executeQuery()) {
				while (rs.next()) {
					//question details
					Long nxtQueId = rs.getLong(SQL.COLUMN.QID.VALUE);
					String qText = rs.getString(SQL.COLUMN.QTEXT.VALUE);
					//answer details for above question
					String aType = rs.getString(SQL.COLUMN.ATYPE.VALUE);
					questionDTO.setId(nxtQueId);
					questionDTO.setQuestion(qText);
					questionDTO.setType(aType);
				}
				questionDTO.setAnswers(new ArrayList<AnswerDTO>());
				answerResponseDTO.setNextSurvey(questionDTO);
			}
			LOGGER.info("Exit SurveyDAO getEndQuestionDetails() ");
			return answerResponseDTO;
		} catch (final SQLException e) {
			LOGGER.error("### error in query:" + GET_END_QUESTION_DETAILS, e);
			throw new SBDaoException(e.getMessage(), SBDaoException.SB_DBA_001, e);

		} catch (final Exception e) {
			LOGGER.error("### error in table query:" + GET_END_QUESTION_DETAILS, e);
			throw new SBDaoException(e.getMessage(), SBDaoException.SB_ERR_9999, e);
		}
	}
	
	public void botSMSTrace(final SurveyRequestDTO request, final SurveyDTO surveyDTO) {
		LOGGER.info("Inside SurveyDAO botSMSTrace() smsKey ---> "+request);
		try (Connection c = jdbcTemplate.getDataSource().getConnection();
				PreparedStatement ps = c.prepareStatement(INSERT_BOT_SMS_TRACE);) {
			ps.setLong(1, request.getQuesId());
			ps.setLong(2, request.getSurveyId());
			ps.setString(3, request.getAnswer().getValue());
			ps.setString(4, surveyDTO.getSmsKey());
			ps.setString(5, surveyDTO.getContactNumber());
			ps.executeUpdate();
			LOGGER.info("Exit SurveyDAO botSMSTrace() surveyId ---> "+request.getSurveyId());
		} catch (final SQLException e) {
			LOGGER.error("### error in query:" + INSERT_BOT_SMS_TRACE + " key:" + surveyDTO.getSmsKey(), e);
			throw new SBDaoException(e.getMessage(), SBDaoException.SB_DBA_001, e);

		} catch (final Exception e) {
			LOGGER.error("### error in query:" + INSERT_BOT_SMS_TRACE + " key:" + surveyDTO.getSmsKey(), e);
			throw new SBDaoException(e.getMessage(), SBDaoException.SB_ERR_9999, e);
		}
	}

}
