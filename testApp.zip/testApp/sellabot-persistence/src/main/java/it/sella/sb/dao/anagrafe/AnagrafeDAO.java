package it.sella.sb.dao.anagrafe;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Types;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import it.sella.sb.anagrafe.IAnagrafeDAO;
import it.sella.sb.dao.datasource.SBDataSource;
import it.sella.sb.dao.exception.SBDaoException;

@Component
public class AnagrafeDAO extends SBDataSource implements IAnagrafeDAO {
	
	private static final Logger LOGGER = Logger.getLogger(AnagrafeDAO.class);

	@Value("${GET_ID_SOGGETTO}")
	private String GET_ID_SOGGETTO;

	public long getSubjectIdByIbcode(final String ibcode)
	{
		try(Connection con = jdbcTemplate.getDataSource().getConnection();
			CallableStatement cs = con.prepareCall(GET_ID_SOGGETTO);)
		{
			cs.setString(1,ibcode);
			cs.registerOutParameter(2, Types.BIGINT);
			cs.registerOutParameter(3, Types.VARCHAR);
			cs.execute();
			String result = cs.getString(3);
			if (result == null || result.trim().length()==0) {
				return cs.getLong(2);
			} else {
				throw new SBDaoException(result, SBDaoException.SB_GEN_001);
			}
		} catch (SQLException e) {
			LOGGER.error("SQLException while getting idSogg for userCode"+ibcode+" Error Message : "+e.getMessage(), e);
			throw new SBDaoException(e.getMessage(),SBDaoException.SB_DBA_001, e);
		} catch (Exception e) {
			LOGGER.error("Exception while getting idSogg for userCode"+ibcode+" Error Message : "+e.getMessage(), e);
			throw new SBDaoException(e.getMessage(),SBDaoException.SB_ERR_9999, e);
		}
	}

}
