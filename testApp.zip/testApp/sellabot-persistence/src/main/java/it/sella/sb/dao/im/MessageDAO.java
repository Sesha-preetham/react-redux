package it.sella.sb.dao.im;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.RowCallbackHandler;
import org.springframework.stereotype.Component;

import it.sella.sb.anagrafe.dto.MessageDetails;
import it.sella.sb.common.util.StringUtility;
import it.sella.sb.core.facade.UtilityBank;
import it.sella.sb.dao.datasource.SBDataSource;
import it.sella.sb.dao.exception.SBDaoException;
import it.sella.sb.hb.dto.SbUserDetail;
import it.sella.sb.im.IMessageDAO;
import it.sella.sb.im.dto.request.IMRequest;
import it.sella.sb.util.SBCONSTANT.EVENTDATA;
import oracle.jdbc.OracleTypes;

@Component
public class MessageDAO extends SBDataSource implements IMessageDAO {
	
	private static final Logger LOGGER = Logger.getLogger(MessageDAO.class);
	
	@Value("${INSERT_MESSAGE}")
	private String INSERT_MESSAGE;
	
	@Value("${READ_MESSAGE}")
	private String READ_MESSAGE;
	
	@Value("${UPDATE_MESSAGE}")
	private String UPDATE_MESSAGE;
	
	@Value("${RETRIEVE_ONLINE_MESSAGES}")
	private String RETRIEVE_ONLINE_MESSAGES;
	
	@Value("${SECTIONCODE_TO_RETRIVE_MSGS}")
	private String SECTIONCODE_TO_RETRIVE_MSGS;
	
	@Value("${INSERT_MESSAGE_WITH_TIMESTAMP}")
	private String INSERT_MESSAGE_WITH_TIMESTAMP;
	
	@Override
	public void preserveMessage(final IMRequest imRequest,final String imRequestString,final String history,final SbUserDetail userDet) {
		try {
			String messageToStore = "";
			if(imRequest.getEventdata() != null ) {
				String message = "";
				String answer = "";
				for (final Map<String, String> eventData : imRequest.getEventdata()) {
					if(eventData.get(EVENTDATA.NAME.VALUE).equals(EVENTDATA.MESSAGE.VALUE)){
						message = (String)eventData.get(EVENTDATA.VAL.VALUE);
						LOGGER.debug("Message found for chat id : "+imRequest.getChatid()+" message : "+message);
					}
					if(eventData.get(EVENTDATA.NAME.VALUE).equals(EVENTDATA.ANSWER.VALUE)){
						answer = (String)eventData.get(EVENTDATA.VAL.VALUE);
						LOGGER.debug("Answer found for chat id : "+imRequest.getChatid()+" answer : "+answer);
					}
					if( !StringUtility.isEmpty(message) || !StringUtility.isEmpty(answer) ) {
						break;
					}
				}
				messageToStore = !StringUtility.isEmpty(message) ? message : answer;
			}
			LOGGER.debug("MessageToStore for chat id : "+imRequest.getChatid()+" messageToStore : "+messageToStore);
			final Object[] params = new Object[]{imRequest.getChatid(),userDet != null ? userDet.getIdSogg() : null,
					imRequest.getSender(),imRequestString,messageToStore};
			this.jdbcTemplate.update(INSERT_MESSAGE,params);
		} catch (DataAccessException e) {
			LOGGER.error("DataAccessException MessageDAO preserveMessage Error Message : "+e.getMessage(), e);
			throw new SBDaoException(e.getMessage(),SBDaoException.SB_DBA_001, e);
		} catch (Exception e) {
			LOGGER.error("Exception MessageDAO preserveMessage Error Message : "+e.getMessage(), e);
			throw new SBDaoException(e.getMessage(),SBDaoException.SB_ERR_9999, e);
		}
	}

	@Override
	public List<String> readMessage(String chatid) {
		try {
			final Object[] params = new Object[]{chatid};
			final List<String> list = new ArrayList<String>();
			final List<String> rowIds = new ArrayList<String>();
			this.jdbcTemplate.query(READ_MESSAGE,params, new RowCallbackHandler()
			{
				@Override
				public void processRow(final ResultSet rs) throws SQLException {
					final String msgTxt = rs.getString(1); 
					rowIds.add(rs.getString(2));
					if(msgTxt!=null){
						list.add(msgTxt);
					}
					
				}
			});
			if(!rowIds.isEmpty()) {
				updateStatus(rowIds);
			}
			return list;
		} catch (DataAccessException e) {
			LOGGER.error("DataAccessException MessageDAO preserveMessage Error Message : "+e.getMessage(), e);
			throw new SBDaoException(e.getMessage(),SBDaoException.SB_DBA_001, e);
		} catch (Exception e) {
			LOGGER.error("Exception MessageDAO preserveMessage Error Message : "+e.getMessage(), e);
			throw new SBDaoException(e.getMessage(),SBDaoException.SB_ERR_9999, e);
		}
	}

	private void updateStatus(final List<String> rowIds) {
		final String rowId = rowIds.get(0);
		final Object[] params = new Object[]{rowId};
		this.jdbcTemplate.update(UPDATE_MESSAGE,params);
	}

	@Override
	public MessageDetails retrieveOnlineMessages(final SbUserDetail userDetail) {
		String userCode = "";
		String abiCode = "";
		String channel = "";
		if(userDetail.getFederationInformation() != null){
			userCode = userDetail.getFederationInformation().getUserCode();
		    abiCode = userDetail.getFederationInformation().getAbi();
			channel = userDetail.getPersonalDet().getChannelId().startsWith("Sella_app") ? "CHATAPP" : "CHAT";
		}else{
			abiCode = userDetail.getBancaId();
			channel = userDetail.getPersonalDet().getChannelId().startsWith("Sella_app") ? "CHATAPPFREE" : "CHATFREE";
		}
		LOGGER.info(" MessageDAO retrieveOnlineMessages() [ ' userCode - " + userCode + " ' ] , [ ' abiCode - " + abiCode + " ' ] , [ ' channel - " + channel + " ' ] ");
		
		final MessageDetails messageBO = new MessageDetails();
		try(Connection con = jdbcTemplate.getDataSource().getConnection();
				CallableStatement getMessageDetailsCall = con.prepareCall(RETRIEVE_ONLINE_MESSAGES);) {
			getMessageDetailsCall.registerOutParameter(1, OracleTypes.CURSOR);
			getMessageDetailsCall.setString(2, userCode);
			getMessageDetailsCall.setString(3, UtilityBank.getBankCode(abiCode));
			getMessageDetailsCall.setString(4, SECTIONCODE_TO_RETRIVE_MSGS);
			getMessageDetailsCall.setString(5, channel);
			getMessageDetailsCall.executeQuery();
			ResultSet cursorRS = (ResultSet) getMessageDetailsCall.getObject(1);
			while(cursorRS.next()){
				messageBO.setmId(cursorRS.getString(1));
				messageBO.setmTitle(cursorRS.getString(2));
				messageBO.setmMessage(cursorRS.getString(3));
				messageBO.setmMessageShort(cursorRS.getString(4));
				messageBO.setmPosition(cursorRS.getString(5));
				messageBO.setmMakeSections(cursorRS.getString(6));
			}
		} catch (DataAccessException e) {
			LOGGER.error("DataAccessException MessageDAO retrieveOnlineMessages() Error Message : "+e.getMessage(), e);
			throw new SBDaoException(e.getMessage(),SBDaoException.SB_DBA_001, e);
		} catch (Exception e) {
			LOGGER.error("Exception MessageDAO retrieveOnlineMessages() Error Message : "+e.getMessage(), e);
			throw new SBDaoException(e.getMessage(),SBDaoException.SB_ERR_9999, e);
		}
		LOGGER.info(" MessageDAO retrieveOnlineMessages()  message >>> " + messageBO);
		return messageBO;
	}

	@Override
	public void preserveAlghoMessage(final String chatId, final String soggetto, final String source, final String message, final String answer, final Long timestamp) {
		try {
			LOGGER.debug("MessageDAO preserveAlghoMessage for chat id : "+chatId+" messageToStore : "+message);
			final Object[] params = new Object[]{chatId,soggetto,source,message,answer, new java.sql.Timestamp(timestamp)};
			this.jdbcTemplate.update(INSERT_MESSAGE_WITH_TIMESTAMP,params);
		} catch (DataAccessException e) {
			LOGGER.error("DataAccessException MessageDAO preserveAlghoMessage Error Message : "+e.getMessage(), e);
			throw new SBDaoException(e.getMessage(),SBDaoException.SB_DBA_001, e);
		} catch (Exception e) {
			LOGGER.error("Exception MessageDAO preserveAlghoMessage Error Message : "+e.getMessage(), e);
			throw new SBDaoException(e.getMessage(),SBDaoException.SB_ERR_9999, e);
		}
	}


}
