package it.sella.sb.dao.exception;

import it.sella.sb.common.exception.SBBaseThrowable;


@SuppressWarnings("serial")
public class SBDaoException extends SBBaseThrowable {
	
	public static final String SB_DBA_001 = "DB_ERROR";
	
	public SBDaoException(String msg,String code) {
		super(msg,code);
	}

	public SBDaoException(String msg,String code, Throwable t) {
		super(msg, code, t);
	}
	
	public SBDaoException(final String msg,final String code,final String[] params) {
		super(msg,code,params);
	}
	

}
