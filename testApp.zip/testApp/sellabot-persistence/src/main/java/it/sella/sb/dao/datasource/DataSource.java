package it.sella.sb.dao.datasource;

import javax.annotation.Resource;

import org.springframework.jdbc.support.SQLErrorCodeSQLExceptionTranslator;

public class DataSource {

	@Resource(name = "sberrorcodestranslator")
	public SQLErrorCodeSQLExceptionTranslator errorCodeSQLExceptionTranslator;


}
