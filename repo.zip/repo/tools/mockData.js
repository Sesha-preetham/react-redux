const empDetails = [
  {
    id: 1,
    ename: "Sethu",
    slug: "react-auth0-authentication-security",
    phone: 9840112345,
    address: "No:1 First Cross, Anna nagar, Chennai"
  },
  {
    id: 2,
    ename: "Sreekanth",
    slug: "react-big-picture",
    phone: 9840112345,
    address: "No:2 First Cross, Anna nagar, Chennai"
  },
  {
    id: 3,
    ename: "Sakthi",
    slug: "react-creating-reusable-components",
    phone: 9840112345,
    address: "No:3 First Cross, Anna nagar, Chennai"
  },
  {
    id: 4,
    ename: "Sesha",
    slug: "javascript-development-environment",
    phone: 9840112345,
    address: "No:4 First Cross, Anna nagar, Chennai"
  },
];

const authors = [
  { id: 1, ename: "Cory House" },
  { id: 2, ename: "Scott Allen" },
  { id: 3, ename: "Dan Wahlin" }
];

const newEmployee = {
  id: null,
  ename: "",
  phone: null,
  address: ""
};

// Using CommonJS style export so we can consume via Node (without using Babel-node)
module.exports = {
  newEmployee,
  empDetails,
  authors
};
