import React from "react";
import { connect } from "react-redux";
import * as searchActions from "../../redux/actions/searchActions";
import PropTypes from "prop-types";
import { bindActionCreators } from "redux";
import DisplayEmpDetails from "./DisplayEmpDetails";
import SearchEmpDetails from "./SearchEmpDetails";

class SearchApp extends React.Component {
  
  componentDidMount(){

    const { empDetails, actions } = this.props;

    if(empDetails.length ===0){
      actions.loadEmployee().catch(error => {
      alert("Loading employees failed" + error);
    });
  }

  }

  render() {
    return (
      <>  
      <div className="row">
      <div className="col-xs-6 col-md-4">
        <SearchEmpDetails />
      </div>
      <div className="col-xs-12 col-md-8">
        <DisplayEmpDetails empDetails={this.props.empDetails} />
    </div>
    </div>  
     </>
    );
  }
}

SearchApp.propTypes = {
  empDetails: PropTypes.array.isRequired,
  actions: PropTypes.object.isRequired
};

function mapStateToProps(state) {
  return {
    empDetails: state.empDetails
  };
}

function mapDispatchToProps(dispatch) {
  return {
    actions: bindActionCreators(searchActions, dispatch)
  };
}

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(SearchApp);
