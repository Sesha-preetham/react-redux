import React from "react";
import PropTypes from "prop-types";

const DisplayEmpDetails = ({ empDetails }) => (

  <div className="card h-500 border-primary" style={{height: "470px"}}>
  <div className="card-header">Details</div>
  <div className="card-body">
    <table className="table">
    <thead>
      <tr>
        <th>ID</th>
        <th>Name</th>
        <th>Phone</th>
        <th>Edit</th>
      </tr>
    </thead>
    <tbody>
      {empDetails.map(employee => {
        
        return (
          <tr key={employee.id}>
            <td>{employee.id}</td>
            <td>{employee.ename}</td>
            <td>{employee.phone}</td>
            <td>
             <a
                className="btn btn-primary"
                onClick={()=> { alert("clicked edit")}}
              >
                Edit
              </a>
            </td>
          </tr>
        );
      })}
    </tbody>
  </table>
 </div>
 </div>
);



DisplayEmpDetails.propTypes = {
    empDetails: PropTypes.array.isRequired
};

export default DisplayEmpDetails;
