import React, { useEffect, useState } from "react";
import { connect } from "react-redux";
import * as searchActions from "../../redux/actions/searchActions";
import PropTypes from "prop-types";
import SearchForm from "./SearchForm";
import { newEmployee } from "../../../tools/mockData";


function SearchEmpDetails({ empDetails , loadEmployee,...props} ) {

    const [newemployee , setNewemployee] = useState({...props.newemployee});
    const [errors , setErrors] = useState({});

    useEffect(() => {
        if(empDetails.length ===0){
            loadEmployee().catch(error => {
            alert("Loading employees failed" + error);
          });
        }
    },[]);

    function onChange  (event) {
      const { name, value } = event.target;
      setNewemployee(prevEmployee =>({
        ...prevEmployee,
        [name]: name === "ID" ? parseInt(value,10) : value
      }));
    }

    return (
      <>  
     <div className="card h-470 border-primary" style={{height: "470px"}}>
     <div className="card-header">Search</div>
     <div className="card-body">
        <SearchForm employee={newemployee} errors={errors} onChange={onChange} />
      </div>
      </div>
     </>
    );  
}

SearchEmpDetails.propTypes = {
  newemployee: PropTypes.object.isRequired,
  empDetails: PropTypes.array.isRequired,
  loadEmployee: PropTypes.func.isRequired
};

function mapStateToProps(state) {
  return {
    newemployee: newEmployee,
    empDetails: state.empDetails
  };
}

const mapDispatchToProps = {
    loadEmployee: searchActions.loadEmployee
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(SearchEmpDetails);
