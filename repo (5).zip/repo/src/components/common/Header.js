import React from "react";
import { NavLink } from "react-router-dom";


const Header = () => {
  const activeStyle = { color: "#F15B2A" };
  return (
   
    <div className="navbar" style={{backgroundColor:"#414a4c", borderRadius:"10px"}} >
    <nav>
      <NavLink to="/" activeStyle={activeStyle} exact>
        Home
      </NavLink>
      {" | "}
      <NavLink to="/search" activeStyle={activeStyle}>
        Search
      </NavLink>
    </nav>
    </div>
    
  );
};

export default Header;
