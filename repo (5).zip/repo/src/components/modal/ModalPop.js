import React, { useState } from "react";
import PropTypes from "prop-types";
import { Modal } from "react-bootstrap";

function ModalPop({employeedetail, setIsOpen}) {
    const [show, setShow] = useState(true);
  
    const handleClose = () => {
      setShow(false);
      setIsOpen(false);
    };
  
    return (
      <>  
        <Modal
          show={show}
          onHide={handleClose}
          backdrop="static"
          keyboard={false}
        >
          <Modal.Header closeButton>
            <Modal.Title>Employee Complete Details</Modal.Title>
          </Modal.Header>
          <Modal.Body>
          <form>
          <label>Name: {employeedetail.ename}</label><br />
          <label>EMPID: {employeedetail.empid}</label><br />
          <label>DOJ: {employeedetail.DOJ}</label><br />
          <label>Phone: {employeedetail.phone}</label><br />
          <label>Email: {employeedetail.email}</label><br />
          <label>Address: {employeedetail.address}</label><br />
          </form>
          </Modal.Body>
          <Modal.Footer>
            <div className="btn btn-primary" variant="secondary" onClick={handleClose}>
              Close
            </div>
          </Modal.Footer>
        </Modal>
      </>
    );
  }
  
  ModalPop.propTypes = {
    employeedetail: PropTypes.object,
    setIsOpen:PropTypes.func
};
export default ModalPop