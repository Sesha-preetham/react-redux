import React from "react";
import { Link } from "react-router-dom";

const HomePage = () => (
  <div className="jumbotron" style={{backgroundColor:"#07BB9C"}}>
    <h1 style={{color:"white"}}>Search Employee</h1>
    <p>A Demo app to Search and View employee details</p>
    <Link to="search" className="btn btn-primary btn-lg">
      Learn more
    </Link>
  </div>
);

export default HomePage;
