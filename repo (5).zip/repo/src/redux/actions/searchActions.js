import * as types from "./actionTypes";
import * as employeeApi from "../../api/employeeApi";


export function loadEmployeeSuccess(empDetails){
  return{ type: types.LOAD_EMPLOYEE_SUCCESS, empDetails};
}

export function searchEmployeeSuccess(empDetails){
  return{ type: types.SEARCH_EMPLOYEE_SUCCESS, empDetails};
}

export function loadEmployee(){
  return function(dispatch){
    return employeeApi.getEmployee().then(empDetails => {
      dispatch(loadEmployeeSuccess(empDetails));
    }).catch(error => {
      throw error;
    })
  }
}

export function searchEmployee(employeeId){
  return function(dispatch){
    return employeeApi.searchEmployee(employeeId).then(empDetails => {
      //console.log(empDetails);
      dispatch(searchEmployeeSuccess(empDetails));
    }).catch(error => {
      throw error;
    })
  }
}

