import React from "react";
import { Container, Form } from "react-bootstrap";

const Sample = () => {
  return (
    <Container>
      <Form.Control size="sm" name="foo" placeholder="Smaller Input" />
    </Container>
  );
};

export default Sample;