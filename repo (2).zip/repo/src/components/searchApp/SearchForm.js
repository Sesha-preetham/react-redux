import React from "react";
import PropTypes from "prop-types";
import TextInput from "../common/TextInput";
//import SelectInput from "../common/SelectInput";

const SearchForm = ({
  employee,
  onSave,
  onChange,
  saving = false,
  errors = {}
}) => {
  return (
    <form onSubmit={onSave}>
      {errors.onSave && (
        <div className="alert alert-danger" role="alert">
          {errors.onSave}
        </div>
      )}
      <TextInput
        name="id"
        label="id"
        value={employee.id}
        onChange={onChange}
        error={errors.id}
      />

      <TextInput
        name="ename"
        label="ename"
        value={employee.ename}
        onChange={onChange}
        error={errors.ename}
      />

      <TextInput
        name="phone"
        label="phone"
        value={employee.phone}
        onChange={onChange}
        error={errors.phone}
      />

      <TextInput
        name="address"
        label="address"
        value={employee.address}
        onChange={onChange}
        error={errors.address}
      />

      <button type="submit" disabled={saving} className="btn btn-primary">
        {saving ? "Searching..." : "Search"}
      </button>
    </form>
  );
};

SearchForm.propTypes = {
  employee: PropTypes.object.isRequired,
  errors: PropTypes.object,
  onSave: PropTypes.func.isRequired,
  onChange: PropTypes.func.isRequired,
  saving: PropTypes.bool
};

export default SearchForm;
