import React,{useState} from "react";
import PropTypes from "prop-types";
import ModalPop from "../modal/ModalPop";

const DisplayEmpDetails = ({ empDetails }) => {

  const [isOpen, setIsOpen] = useState(false);
  const [employeedetail, setEmployeedetail] = useState();

const handleClick = (employee) => {
     setIsOpen(true);
     setEmployeedetail(employee);      
  }
  
return (
  <div className="card h-500 border-primary" style={{height: "470px"}}>
  <div className="card-header">Details</div>
  <div className="card-body">
    <table className="table">
    <thead>
      <tr>
        <th>ID</th>
        <th>Name</th>
        <th>Phone</th>
        <th>Address</th>
        <th>Information</th>
      </tr>
    </thead>
    <tbody>
      {empDetails.map(employee => {
        
        return (
          <tr key={employee.id}>
            <td>{employee.id}</td>
            <td>{employee.ename}</td>
            <td>{employee.phone}</td>
            <td>{employee.address}</td>
            <td>
             <a
                className="btn btn-primary"
                onClick={() => handleClick(employee)}
              >
                Info
              </a>
            </td>
          </tr>
        );
      })}
    </tbody>
  </table>
 </div>
 {isOpen && <ModalPop employeedetail={employeedetail} setIsOpen={setIsOpen}/>}
 </div>
);

    }

DisplayEmpDetails.propTypes = {
    empDetails: PropTypes.array.isRequired
};

export default DisplayEmpDetails;
