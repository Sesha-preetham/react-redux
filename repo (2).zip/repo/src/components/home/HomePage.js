import React from "react";
import { Link } from "react-router-dom";

const HomePage = () => (
  <div className="jumbotron">
    <h1>Search Employee</h1>
    <p>A Demo app to Search, Add and Edit Employee details</p>
    <Link to="search" className="btn btn-primary btn-lg">
      Learn more
    </Link>
  </div>
);

export default HomePage;
