import * as types from "./actionTypes";
import * as employeeApi from "../../api/employeeApi";

export function searchEmployee(employee) {
  return { type: types.SEARCH_EMPLOYEE, employee };
}

export function loadEmployeeSuccess(empDetails){
  return{ type: types.LOAD_EMPLOYEE_SUCCESS, empDetails};
}

export function loadEmployee(){
  return function(dispatch){
    return employeeApi.getEmployee().then(empDetails => {
      dispatch(loadEmployeeSuccess(empDetails));
    }).catch(error => {
      throw error;
    })

  }

}

export function findEmployee(filterRequest){
  return{ type: types.FIND_EMPLOYEE, filterRequest};
}
