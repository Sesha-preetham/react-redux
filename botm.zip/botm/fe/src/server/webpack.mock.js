var webpack = require("webpack");
var path = require("path");

const { CleanWebpackPlugin } = require("clean-webpack-plugin");
const UglifyJsPlugin = require("uglifyjs-webpack-plugin");

module.exports = {
  entry: __dirname + "/src/express-server.js",
  plugins: [new CleanWebpackPlugin()],
  mode: "production",
  target: "node",
  output: {
    filename: "express-server-build.js",
    path: path.resolve("./server/build")
  },
  /*optimization: {
     minimizer: [
      new UglifyJsPlugin({
        uglifyOptions: {
           warnings: false,
          output: {
            comments: false // remove comments
          },
          compress: {
            drop_console: true,
            drop_debugger: true,
          }
        },
        parallel: true,
        cache: false,
        extractComments: false,
        sourceMap: false
      })
    ]
  },*/
  module: {
    rules: [
      {
        test: /\.js$/,
        exclude: /node-modules/,
        use: {
          loader: "babel-loader",
          /*options: {
            presets: ["@babel/preset-env"],
            plugins: ["@babel/plugin-proposal-class-properties"],
          },*/
        },
      },
    ],
  },
  resolve: {
    extensions: [".js"],
    modules: ["node_modules/", path.resolve(__dirname, "./src/")],
  }
};
