const usersUrlsWithPath = [
    {
      postUrl: "/barratelefonicabe-web/service/users/userme",
      path: "server/services/users/userme.json"
    }
  ];
  
  export default usersUrlsWithPath;
  