const anagraficaUrlsWithPath = [
    {
      getUrl: '/barratelefonicabe-web/service/anagrafica/clientsearchtype',
      path: "server/services/anagrafica/clientsearchtype.json"
    },
    {
      getUrl: "/barratelefonicabe-web/service/anagrafica/clientsearch",
      queries: [
        {
          query: '?type=idSoggetto&value=111111&abicode=03268',
          path: "server/services/anagrafica/clientsearch.json"
        }
      ],
      path: "server/services/anagrafica/clientsearch.json"
    },
    {
      getUrl: '/barratelefonicabe-web/service/anagrafica/carte',
      queries: [
        {
          query: '?idSoggetto=111111&abicode=03268',
          path: "server/services/anagrafica/cartesearch.json"
        }
      ],
      path: "server/services/anagrafica/cartesearch.json"
    }
  ];
  
export default anagraficaUrlsWithPath;