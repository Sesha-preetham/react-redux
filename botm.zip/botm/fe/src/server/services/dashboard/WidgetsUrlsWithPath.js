const widgetsUrlsWithPath = [
    {
      getUrl: "/barratelefonicabe-web/service/widgets",
      queries: [
        {
          query:"?main=Y",
          path: "server/services/dashboard/widgets/mainWidgets.json"
        },
        {
          query:"?default=Y",
          path: "server/services/dashboard/widgets/defaultWidgets.json"
        },
        {
          query:"?main=N&default=Y",
          path: "server/services/dashboard/widgets/defaultWidgets.json"
        }
      ],
      path: "server/services/dashboard/widgets/widgets.json"
    },
    {
      getUrl: "/barratelefonicabe-web/service/widgets/queues",
      queries: [
        {
          query:"?queueName=CHAT_SERCLI",
          path: "server/services/dashboard/widgets/CHAT_SERCLIWidgets.json"
        }
      ],
      path: "server/services/dashboard/widgets/CHAT_SERCLIWidgets.json"
    }
  ];
  
  export default widgetsUrlsWithPath;
  