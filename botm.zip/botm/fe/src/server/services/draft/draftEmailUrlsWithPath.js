const draftEmailUrlsWithPath = [
    {
      postUrl: "/barratelefonicabe-web/service/email/draftPrivato",
      path: "server/services/draft/privato.json"
    }
  ];
  
  export default draftEmailUrlsWithPath;