const usersUrlsWithPath = [
    {
      getUrl: "/barratelefonicabe-web/service/init",
      path: "server/services/init/init.json"
    },
    {
      getUrl: "/barratelefonicabe-web/service/visiblebanks",
      path: "server/services/init/visiblebanks.json"
    }
  ];
  
  export default usersUrlsWithPath;