import usersUrlsWithPath from "../services/users/UsersUrlsWithPath";
import initUrlsWithPath from "../services/init/InitUrlsWithPath";
import anagraficaUrlsWithPath from "../services/anagrafica/anagraficaUrlsWithPath";
import widgetsUrlsWithPath from "../services/dashboard/WidgetsUrlsWithPath";
import draftEmailUrlsWithPath from "../services/draft/draftEmailUrlsWithPath";

const serviceUrlsWithPath = [
  ...initUrlsWithPath,
  ...usersUrlsWithPath,
  ...anagraficaUrlsWithPath,
  ...widgetsUrlsWithPath,
  ...draftEmailUrlsWithPath
];


export const loadPostUrls = () => {
  let length = serviceUrlsWithPath.length;
  let returnPostServiceUrls = [];
  for (let i = 0; i < length; i++) {
    if(serviceUrlsWithPath[i].postUrl){
      returnPostServiceUrls.push(serviceUrlsWithPath[i].postUrl);
    }
  }
  return returnPostServiceUrls;
};

export const loadGetUrls = () => {
  let length = serviceUrlsWithPath.length;
  let returnGetServiceUrls = [];
  for (let i = 0; i < length; i++) {
    if(serviceUrlsWithPath[i].getUrl){
      returnGetServiceUrls.push(serviceUrlsWithPath[i].getUrl);
    }
  }
  return returnGetServiceUrls;
};

export const findPathByPostUrl = (postUrl) => {
  let index = serviceUrlsWithPath.findIndex((postServiceUrl) => {
    return postServiceUrl.postUrl ===  "/"+postUrl;
  });
  return serviceUrlsWithPath[index].path;
};

export const findPathByGetUrl = (urlWithQuery) => {
  let path = undefined;
  serviceUrlsWithPath.forEach(url => {
    if(url.queries){
      for(let i = 0; i<url.queries.length; i++){
        console.log(url.getUrl + url.queries[i].query);
        if("/"+urlWithQuery === url.getUrl + url.queries[i].query){
          path=url.queries[i].path;
        }
      }
    }
    if(path === undefined){
      if("/"+urlWithQuery === url.getUrl){
        path = url.path;
      }
    }
  })
  console.log('path---> ' + path);
  return path;
}
