import express from "express";
import bodyParser from "body-parser";
import fs from "fs";
import { loadPostUrls, loadGetUrls, findPathByPostUrl, findPathByGetUrl } from "./express-urls";

const app = express();
const postServiceUrls = loadPostUrls();
const getServiceUrls = loadGetUrls();
app.use((req, res, next) => {
  res.header("Access-Control-Allow-Origin", "*");
  res.header(
    "Access-Control-Allow-Headers",
    "Origin, X-Requested-With, Content-Type, Accept"
  );
  next();
});
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

app.post(postServiceUrls, (req, res) => {
  let servicePath = req.originalUrl;
  servicePath = servicePath.substring(1, servicePath.length);
  let path = findPathByPostUrl(servicePath);
  console.log(
    "--------------- ExpressJS servicePath: POST METHOD " + servicePath
  );
  readFile(path, (err, data) => {
    res.send(data);
    console.log(err);
  });
});

app.get( getServiceUrls , (req, res) => {
  let servicePath = req.originalUrl;
  servicePath = servicePath.substring(1, servicePath.length);
  console.log(
    "--------------- ExpressJS servicePath: GET METHOD " + servicePath
  );
  let path = findPathByGetUrl(servicePath);
  readFile(path, (err, data) => {
    res.send(data);
    console.log(err);
  });
});

let readFile = (file, cbk) => {
  fs.readFile(file, (err, data) => {
    if (err) {
      cbk(err);
      return;
    }
    try {
      cbk(null, data);
    } catch (exception) {
      cbk(exception);
    }
  });
};




app.listen(8090, () => {
  console.log("----------------- ExpressJS Started on PORT 8090");
});
