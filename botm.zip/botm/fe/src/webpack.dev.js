const { merge } = require("webpack-merge");
const common = require("./webpack.common");
var mock = require("./server/build/express-server-build");

var HTMLWebpackPlugin = require("html-webpack-plugin");
var HTMLWebpackPluginConfig = new HTMLWebpackPlugin({
  template: __dirname + "/app/index.html",
  filename: "index.html",
  inject: "body"
});

module.exports = merge(common, {
  mode: "development",
  devtool: "inline-source-map",
  devServer: {
    host: "localhost",
    port: 8082,
    open: true
  },
  plugins: [HTMLWebpackPluginConfig],
  module: {
    rules: [
      {
        test: /\.(png|jp(e*)g|svg|gif|woff|woff2|eot|ttf)$/,
        use: [
          {
            loader: "url-loader"
          }
        ]
      },
      {
        test: /\.(css|styl)$/,
        use: [
          {
            loader: "style-loader"
          },
          {
            loader: "css-loader"
          },
          {
            loader: "stylus-loader"
          }
        ]
      }
    ]
  }
});
