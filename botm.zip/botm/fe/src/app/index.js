import "@babel/polyfill";
import React from "react";
import ReactDOM from "react-dom";
import { Provider } from "react-redux";
import configureStore from "./scripts/store/configureStore";
import bootstrap from "bootstrap";

import "./style/stylus/barra.styl";

import App from "./scripts/App.js";

ReactDOM.render(
    <Provider store={configureStore()}>
        <App />
    </Provider>,
    document.getElementById("app")
);