import it from "./dictionary-it";
import en from "./dictionary-en";

export default {
  it,
  en
};