const dictionary = {
    "DASHBOARD.PAGE.HEADER": "Benvenuto",

    /* Spinner IDs */
    "spinner.main": "main_spinner",
    "spinner.modal": "modalSpinner",
    "spinner.dashboard": "dashBoardSpinner",

    /* Alert Notification IDs */
    "alert.mainApp.messageContainer": "mainAppMessageContainer",
    "alert.content.area.message.container": "contentAreaMessageContainer",
    "alert.modal": "alertModalContainer",
    "alert.content.area.dashboard.anagrafica": "alertDashboardAnagrafica"

}

export default dictionary;
