const dictionary = {
  "DASHBOARD.PAGE.HEADER": "Welcome"
};

export default dictionary;
