import Common from "./Common";
import { updateAlertMessageByUniqueIdCall } from "../Service/common/AlertMessageService";

class ErrorHandler {
  static onSuccessException(
    onSuccessExceptionData,
    spinnerId,
    alertContainerId
  ) {
    Common.removeSpinner(spinnerId);
    updateAlertMessageByUniqueIdCall({
      uniqueID: alertContainerId,
      showAlert: true,
      alertType: "warning",
      alertContent:
        onSuccessExceptionData.response.errorMessageCode in window.BTDictionary
          ? window.BTDictionary[
              onSuccessExceptionData.response.errorMessageCode
            ]
          : onSuccessExceptionData.response.errorMessageCode +
            " : " +
            onSuccessExceptionData.response.errorMessage
    });
  }

  static errorData(errorData, spinnerId, alertContainerId) {
    Common.removeSpinner(spinnerId);
    updateAlertMessageByUniqueIdCall({
      uniqueID: alertContainerId,
      showAlert: true,
      alertType: "danger",
      alertContent:
        errorData.code in window.BTDictionary
          ? window.BTDictionary[errorData.code]
          : "HTTP Error " + errorData.code + " : " + errorData.msg
    });
  }
}

export default ErrorHandler;
