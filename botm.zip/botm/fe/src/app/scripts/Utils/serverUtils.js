import axios from "axios";


const defaultHttpSuccessHandler = (
  response,
  onSuccess,
  onSuccessException,
  requestData
) => {
    if (response.data) {
        if (response.data.status === "OK") {
            var successData = {
                requestData: requestData,
                response: response.data
            };
            if (onSuccess) {
                onSuccess(successData);
            } else {
                console.error("onSuccess function is undefined!");
            }
        } else {
            var onSuccessExceptionData = {
                requestData: requestData,
                response: response.data
            };
            if (onSuccessException) {
                onSuccessException(onSuccessExceptionData);
            } else {
                console.error("onSuccessException function is undefined!");
            }
        }
    }
}

const defaultHttpErrorHandler = (error, onError, requestData) => {
    var errorData = {
      code: "999",
      msg: "Unknown Technical Error",
      requestData: requestData
    };
    if (error) {
      if (error.response) {
        errorData.code = error.response.status;
        if (errorData.code === 403) {
          /* Open a modal to re-route to login modal 
          sessionRouteToLoginCall({
            show: true
          });
          */
        } else {
          errorData.msg = error.response.statusText;
          if (onError) {
            onError(errorData);
          } else {
            console.error("errorData function is undefined!");
          }
        }
      } else {
        if (onError) {
          onError(errorData);
        } else {
          console.error("errorData function is undefined!");
        }
      }
    }
};

export const doPost = async (
    url,
    onSuccess,
    onSuccessException, 
    onError,
    requestData,
    addiontionalHeaders
  ) => {
    let data = requestData ? requestData : {};
    let headers = addiontionalHeaders ? { "Content-type": "application/json; charset=utf-8" , ...addiontionalHeaders}:{ "Content-type": "application/json; charset=utf-8"} ;
    try {
      let response = await axios.post(url, data, headers);
      if (response && response.status === 200) {
        defaultHttpSuccessHandler(response, onSuccess, onSuccessException, data);
      } else {
        defaultHttpErrorHandler(response, onError, data);
      }
    } catch (error) {
      defaultHttpErrorHandler(error, onError, data);
    }
};


export const doGet = async (
    url,
    onSuccess,
    onSuccessException, 
    onError,
    requestData,
    addiontionalHeaders
  ) => {
    let data = requestData ? { params: requestData} : undefined;
    let headers = addiontionalHeaders ? { "Content-type": "application/json; charset=utf-8" , ...addiontionalHeaders}:{ "Content-type": "application/json; charset=utf-8"} ;
    try {
      let response = (data)?await axios.get(url, data, headers):await axios.get(url, headers);
      if (response && response.status === 200) {
        defaultHttpSuccessHandler(response, onSuccess, onSuccessException, data);
      } else {
        defaultHttpErrorHandler(response, onError, data);
      }
    } catch (error) {
      defaultHttpErrorHandler(error, onError, data);
    }
};