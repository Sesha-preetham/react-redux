import moment from "moment";

class Common {
  static drawSpinner(objectId, fullscreen, forceDraw) {
    let height = $("#" + objectId).height();
    let classes = "loader-container";

    if (!fullscreen) {
      classes += " loader-section";
      //  if (height < 200 && !$("#" + objectId).hasClass('no-minheight'))
      // 	classes += ' loader-section-minheight'
      if ($("#" + objectId).hasClass("no-minheight"))
        classes += " no-minheight";
    }
    if ($("#" + objectId + " .loader").length == 0 || forceDraw) {
      $("#" + objectId).prepend(
        '<div class="' +
          classes +
          '">' +
          '<div class="loader">' +
          '<div class="jawn"></div>' +
          "</div>" +
          "</div>"
      );
    }
  }

  static removeSpinner(objectId, fullscreen) {
    var classes = ".loader-container";
    if (!fullscreen) {
      classes += ".loader-section";
    }
    $("#" + objectId + " " + classes).remove();
  }

  static getUniqueValueFromArray(array, key) {
    var groupByValues = [];
    array.forEach(function(item) {
      if (typeof item[key] != "undefined") {
        groupByValues.push(item[key]);
      }
    });
    function onlyUnique(value, index, self) {
      return self.indexOf(value) === index;
    }
    return groupByValues.filter(onlyUnique);
  }

  static getIndexedGroup(array, key) {
    var groupByIndex = {};
    array.forEach(function(item) {
      groupByIndex[item[key]] = item;
    });
    return groupByIndex;
  }

  static dateDiff(fromdate, todate) {
    var a = moment(fromdate, "D/M/YYYY");
    var b = moment(todate, "D/M/YYYY");
    return b.diff(a, "days");
  }

  static isIE() {
    if (
      navigator.appName == "Microsoft Internet Explorer" ||
      !!(
        navigator.userAgent.match(/Trident/) ||
        navigator.userAgent.match(/rv:11/)
      ) ||
      (typeof $.browser !== "undefined" && $.browser.msie == 1)
    ) {
      return true;
    } else {
      return false;
    }
  }
}

export default Common;
