import React, { useEffect } from "react";
import {Container, Row, Col} from "react-bootstrap";
import UserInfoContainer from "./modules/user-info/UserInfoContainer";
import {
     initCall,
     initGetVisibleBanks
} from "./service/init/InitServerService";
import pureCloudClient from "./client/PureCloudClient";
import { getUserMe } from "./service/purecloud/PureCloudUserService";
import InteractionsBarContainer from "./modules/interactions-bar/InteractionsBarContainer";
import DashboardContainer from "./modules/dashboard/DashboardContainer";
import AlertMessageContainer from "./modules/common/components/AlertMessageContainer";

import { useSelector } from "react-redux";


function App(){
    
    const pcTokenIsAvailable = useSelector(state => state.initReducer.pcTokenAvailable);

    useEffect( () => {
        init();
    });

    const alertConfiguration ={
        uniqueID: window.BTDictionary["alert.mainApp.messageContainer"]
    };

    useEffect( () => {
        pureCloudClient.init(window.localStorage.getItem('pc-token'));
        getUserMe();
    }, [pcTokenIsAvailable]);

    async function init(){
        try{
            initCall().then(responseData => {
                // do something
            });
        } catch(e){
            console.log(e)
        }
        await initGetVisibleBanks();
    }

    return (
        <div id="app_container">
            <Container fluid={true} className='full-height'>
                <AlertMessageContainer configuration={alertConfiguration} />
                <Row className='full-height'>
                    <Col xs={2} sm={2} md={2} id='userInfoParentContainer' className='full-height' >
                        <UserInfoContainer />
                    </Col>
                    <Col xs={10} sm={10} md={10} className='full-height'  >
                            <Row id='interactionBarRowContainer'>
                                <Col xs={12} sm={12} md={12} id='interactionBarParentContainer' className='full-height'>
                                    <InteractionsBarContainer />
                                </Col>
                            </Row>
                            <Row id='dashboardRowContainer'>
                                <Col xs={12} sm={12} md={12} id='dashboardParentContainer' className=' full-height no-padding'>
                                    <DashboardContainer />
                                </Col>                            
                            </Row>
                    </Col>
                </Row>
            </Container>
        </div>
        
    );
}

export default App;