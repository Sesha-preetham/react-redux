import {
    addInteractionToBar,
    setCurrentInteractionToBar,
    updateInteractionToBar,
    removeInteractionToBar,
    getInteractionDetailsFromBar,
    storeWidgetsStateOnInteractionBar,
    moveWidgetsStateFromInteractionBar
} from "../service/interaction-bar/InteractionBarService";

import {
    getDashboardWidgetsByQueue
} from "../service/dashboard/DashboardWidgetServerService";

import {
    userInfoRouterStatusData,
    userInfoStatusData
} from "../service/user-info/UserInfoService";

import {
    setPureCloudTokenAvailable
} from "../service/init/InitService";

import {
    dashboardWidgetAddCall
} from "../service/dashboard/DashboardWidgetService";

import {
    postLogoutServerCall
} from "../service/common/LogoutUserServerService";

const platformClient = require('platformClient');

let pureCloudClient = {};

let client = platformClient.ApiClient.instance;

// TODO: remove below apis
var usersApi ;
var notificationsApi ;
var analyticsApi;
var routingApi;
let embeddableFrameworkToken = null;

client.setEnvironment(platformClient.PureCloudRegionHosts.eu_central_1);

pureCloudClient.init = function (accessToken){
    client.setAccessToken(accessToken);
    usersApi = new platformClient.UsersApi();
    notificationsApi = new platformClient.NotificationsApi();
    analyticsApi = new platformClient.AnalyticsApi();
    routingApi = new platformClient.RoutingApi();
}


window.addEventListener("message", function(event){
    try{
        var message = JSON.parse(event.data);
        console.log('Message from framework!!!!!!!!!!!!!');
        console.log(message);
        if(message && message.type == "getAuthToken"){
            //TODO: remove above if
            console.log('Message from framework ---- getAuthToken....');
            embeddableFrameworkToken = message.data.token;
            setPureCloudTokenAvailable(embeddableFrameworkToken);
            // !!!! Do not store token on localStorage
            window.localStorage.setItem('pc-token',embeddableFrameworkToken);
        }else if(message && message.type == "interactionSubscription"){
            console.log("interactionSubscription event..........");
            let data= message.data;
            if(data.category==='add'){
                //new interaction
                if(data.interaction){
                    addInteractionToBar(data.interaction);
                }
            }else if(data.category==='change'){
                updateInteractionToBar(data.interaction.new);
            }else if(data.category==='connect'){
                console.log('connect....');
                setCurrentInteractionToBar(data.interaction.id);
                updateInteractionToBar(data.interaction);
                let queueName = data.interaction.queueName;
                    if(queueName){
                        getDashboardWidgetsByQueue({
                            queueName: queueName
                        }).then(widgets => {
                            widgets.forEach(w => {
                                dashboardWidgetAddCall({
                                    uniqueID: w.code,
                                    widgetConfig: w.widgetConfig
                                });
                            });
                        });
                }
            }else if(data.category==='disconnect'){
                console.log("disconnect interaction!!!")
            }else if(data.category==='deallocate'){
                //when interaction disappear from the framework
                console.log("deallocate interaction!!!");
                removeInteractionToBar(data.interaction);
            }
        }else if(message && message.type == "userActionSubscription"){
            console.log("userActionSubscription event..........");
            let userSubscriptionData= message.data;
            if(userSubscriptionData && userSubscriptionData.category==="routingStatus"){
                userInfoRouterStatusData(userSubscriptionData.data);
            }else if(userSubscriptionData && userSubscriptionData.category==="status"){
                userInfoStatusData(userSubscriptionData.data.status);
            }else if(userSubscriptionData && userSubscriptionData.category==="logout"){
                //TODO: logout from barra application!
                postLogoutServerCall();
            }
        }else if(message && message.type === 'notificationSubscription'){
            console.log('notificationSubscription event......');
            let notificationSubscriptionData = message.data;
            if(notificationSubscriptionData && notificationSubscriptionData.category==='interactionSelection'){
                let currentInteraction = notificationSubscriptionData.data.interactionId;
                if(currentInteraction && currentInteraction !== ''){
                    storeWidgetsStateOnInteractionBar();
                    setCurrentInteractionToBar(currentInteraction);
                    moveWidgetsStateFromInteractionBar(currentInteraction);
                }
            }
        }
    }catch {
        //ignore if you can not parse the payload into JSON
    }
    
})

pureCloudClient.getUsersApi = function(){
    return usersApi;
}

pureCloudClient.getNotificationsApi = function(){
    return notificationsApi;
}

pureCloudClient.getAnalyticsApi = function(){
    return analyticsApi;
}

pureCloudClient.getRoutingApi = function(){
    return routingApi;
}

export default pureCloudClient;

