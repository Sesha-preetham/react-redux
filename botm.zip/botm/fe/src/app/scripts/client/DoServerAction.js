import { doPost, doGet } from "../Utils/serverUtils.js";


export const DoPostServerAction = async (url , onSuccess, onSuccessException, onError, reqData, additionalHeaders) =>{
    await doPost(url, onSuccess, onError, onSuccessException, reqData, additionalHeaders);
}

export const DoGetServerAction = async (url , onSuccess, onSuccessException, onError, reqData, additionalHeaders) =>{
    await doGet(url, onSuccess, onError, onSuccessException, reqData, additionalHeaders);
}
