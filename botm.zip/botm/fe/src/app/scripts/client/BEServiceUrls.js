
const initUrls = {
  logout: "/barratelefonicabe-web/logout",
  init: "/barratelefonicabe-web/service/init",
  initVisibleBanks: "/barratelefonicabe-web/service/visiblebanks"
}

const anagraficaUrls = {
  anagraficaGetClientDataBySearchType: "/barratelefonicabe-web/service/anagrafica/clientsearch",
  anagraficaGetClientSearchTypes: "/barratelefonicabe-web/service/anagrafica/clientsearchtype",
  anagraficaGetCarte: "/barratelefonicabe-web/service/anagrafica/carte"
}

const widgetsUrls = {
  getDashboardWidgets: "/barratelefonicabe-web/service/widgets",
  getDashboardWidgetsByQueueName: "/barratelefonicabe-web/service/widgets/queues"
}

const interactionTraceUrls = {
  insertInteraction: "/barratelefonicabe-web/service/interaction/{interId}/trace/insertinteraction"
}

const concatUrlBaseWithRestUrls = (urlBase, urlsObject) => {
    let immutableUrlsObject = { ...urlsObject };
    for (let url in immutableUrlsObject) {
      immutableUrlsObject[url] = urlBase + immutableUrlsObject[url];
    }
    return immutableUrlsObject;
};
  

const BEUrls = (urlBase) => {
    const urlsListObject = {
        ...initUrls,
        ...anagraficaUrls,
        ...widgetsUrls
    };
    return {
      ...concatUrlBaseWithRestUrls(urlBase, urlsListObject)
    };
  };
  
  export default BEUrls;