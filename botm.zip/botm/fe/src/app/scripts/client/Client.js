import BEUrls from "./BEServiceUrls";


const isDev = false;
const urlBase = isDev ? "http://localhost:8090" : ""; // FOR MOCK AND BACK ENVIRONMENT HOST NAME
const beServiceUrls = BEUrls(urlBase);

export const isReduxDebug = isDev ? true : false; // FOR CHROME DEBUGGING ONLY IF REDUX DEVTOOLS PLUGIN IS ADDED TO CHROME

export const pcEmbeddableFrameworkUrl = isDev ? "https://apps.mypurecloud.de/crm/index.html?crm=framework-local-secure":"https://apps.mypurecloud.de/crm/embeddableFramework.html";

export function serviceUrls() {
    return beServiceUrls;
}