import { combineReducers } from "redux";
import UserInfoReducer from "./reducers/UserInfoReducer";
import alertReducer from "./reducers/AlertMessageReducer";
import InitReducer from "./reducers/InitReducer";
import InteractionBarReducer from "./reducers/InteractionBarReducer";
import AnagraficaReducer from "./reducers/AnagraficaReducer";
import DashboardWidgetReducer from "./reducers/DashboardWidgetReducer";


const reducerCombined = combineReducers({
    alertReducer: alertReducer,
    initReducer: InitReducer,
    userInfoReducer: UserInfoReducer,
    interactionBarReducer: InteractionBarReducer,
    anagraficaReducer: AnagraficaReducer,
    dashboardWidgetsReducer: DashboardWidgetReducer,
});

export default reducerCombined;
