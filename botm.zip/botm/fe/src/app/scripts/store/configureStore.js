import { createStore, applyMiddleware } from 'redux'
import thunk from 'redux-thunk'
import combinedReducers from './index'
import { isReduxDebug } from '../client/Client.js';

let store = '';
let composeEnhancers;

if (isReduxDebug) {
    composeEnhancers = window.__REDUX_DEVTOOLS_EXTENSION_COMPOSE__ || compose; // added for Chrome Redux dev tools
}

const configureStore = () => {
    if(!store && isReduxDebug) {
        store = createStore(combinedReducers, composeEnhancers(applyMiddleware(thunk)))
    } else if (!store && !isReduxDebug){
        store = createStore(combinedReducers, applyMiddleware(thunk))
    }
    return store
}


export default configureStore