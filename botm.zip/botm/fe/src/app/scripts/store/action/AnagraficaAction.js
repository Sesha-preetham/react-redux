import {
    LOAD_BASECLIENT_DATA,
    LOAD_CARTECLIENT_DATA
} from "../action-type/AnagraficaActionType";

import {
    UPDATE_CURRENTINTERACTION_WIDGET_STATE_BAR
} from "../action-type/InteractionBarActionType";

export function loadBaseClientDataAction(anagraficaBaseWidgetData) {
    return dispatch => {
        dispatch({
            type:LOAD_BASECLIENT_DATA,
            anagraficaBaseWidgetData
        });
        dispatch({
            type: UPDATE_CURRENTINTERACTION_WIDGET_STATE_BAR,
            anagraficaBaseWidget: {
                anagraficaBaseWidgetData: anagraficaBaseWidgetData
            }
        })
    };
}

export function loadCarteClientDataAction(carteWidgetData){
    return dispatch => {
        dispatch({
            type:LOAD_CARTECLIENT_DATA,
            carteWidgetData
        });
        dispatch({
            type: UPDATE_CURRENTINTERACTION_WIDGET_STATE_BAR,
            carteWidget: {
                carteWidgetData: carteWidgetData
            }
        })
    };
}