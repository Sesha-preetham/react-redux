

import { 
    BAR_ADD_INTERACTION,
    BAR_REMOVE_INTERACTION,
    BAR_CURRENT_INTERACTION,
    BAR_UPDATE_INTERACTION,
    BAR_STORE_INTERACTION_WIDGETS_STATE
 } from "../action-type/InteractionBarActionType.js";

export function addInteractionAction(interaction) {
    return dispatch => {
        dispatch({
            type:BAR_ADD_INTERACTION,
            interaction
        });
    };
}

export function removeInteractionAction(interaction) {
    return dispatch => {
        dispatch({
            type:BAR_REMOVE_INTERACTION,
            interaction
        });
    };
}

export function updateInteractionAction(interaction) {
    return dispatch => {
        dispatch({
            type:BAR_UPDATE_INTERACTION,
            interaction
        });
    };
}

export function setCurrentInteractionToBarAction(interactionId){
    return dispatch => {
        dispatch({
            type:BAR_CURRENT_INTERACTION,
            interactionId
        });
    }
}

export function storeWidgetsStateOnInteractionBarAction(interactionId, needToStoreObject){
    return dispatch => {
        dispatch({
            type:BAR_STORE_INTERACTION_WIDGETS_STATE,
            interactionId,
            needToStoreObject
        });
    }
}

