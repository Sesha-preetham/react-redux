import {
    LOAD_INIT_CALL,
    LOAD_VISIBLE_BANKS,
    PC_TOKEN_AVAILABLE
} from "../action-type/InitActionType.js";

export function initCallDataAction(initData) {
    return dispatch => {
        dispatch({
            type:LOAD_INIT_CALL,
            initData
        });
    };
}

export function initVisibleBanksDataAction(visibleBanks) {
    return dispatch => {
        dispatch({
            type:LOAD_VISIBLE_BANKS,
            visibleBanks
        });
    };
}

export function setPureCloudTokenAvailableAction(isAvailable){
    return dispatch => {
        dispatch({
            type:PC_TOKEN_AVAILABLE,
            isAvailable
        });
    };
}


