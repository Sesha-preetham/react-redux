import {
    DASHBOARD_MAINWIDGET_INIT,
    DASHBOARD_MAINWIDGET_SHOW,
    DASHBOARD_MAINWIDGET_HIDE,
    DASHBOARD_MAINWIDGET_ADD,
    DASHBOARD_MAINWIDGET_REMOVE,
    DASHBOARD_WIDGET_ADD,
    DASHBOARD_WIDGET_LOAD_STATES
} from "../action-type/DashboardWidgetActionType";


export function dashboardMainWidgetInitDataAction(dashboardMainWidgets) {
    return dispatch => {
        dispatch({
            type:DASHBOARD_MAINWIDGET_INIT,
            dashboardMainWidgets
        });
    };
}

export function dashboardMainWidgetShowDataAction(dashboardMainWidgetUniqueID) {
    return dispatch => {
        dispatch({
            type:DASHBOARD_MAINWIDGET_SHOW,
            dashboardMainWidgetUniqueID
        });
    };
}

export function dashboardMainWidgetHideDataAction(dashboardMainWidgetUniqueID) {
    return dispatch => {
        dispatch({
            type:DASHBOARD_MAINWIDGET_HIDE,
            dashboardMainWidgetUniqueID
        });
    };
}

export function dashboardMainWidgetAddDataAction(dashboardMainWidget) {
    return dispatch => {
        dispatch({
            type:DASHBOARD_MAINWIDGET_ADD,
            dashboardMainWidget
        });
    };
}

export function dashboardMainWidgetRemoveDataAction(dashboardMainWidgetUniqueID) {
    return dispatch => {
        dispatch({
            type:DASHBOARD_MAINWIDGET_REMOVE,
            dashboardMainWidgetUniqueID
        });
    };
}

export function dashboardWidgetAddDataAction(dashboardWidget){
    return dispatch => {
        dispatch({
            type:DASHBOARD_WIDGET_ADD,
            dashboardWidget
        });
    };
}

export function dashboardLoadWidgetsStateAction(dashboardWidgetsStates){
    return dispatch => {
        dispatch({
            type:DASHBOARD_WIDGET_LOAD_STATES,
            dashboardWidgetsStates
        });
    };
}