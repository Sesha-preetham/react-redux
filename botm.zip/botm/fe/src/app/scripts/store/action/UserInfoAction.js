import { 
    LOAD_USERINFO_ME,
    CHANGE_ROUTINGSTATUS,
    CHANGE_USERSTATUS
 } from "../action-type/UserInfoActionType.js";


export function userInfoStatusAction(status) {
    return dispatch => {
        dispatch({
            type:CHANGE_USERSTATUS,
            status
        });
    };
}

export function userInfoMeDataAction(userMe) {
    return dispatch => {
        dispatch({
            type:LOAD_USERINFO_ME,
            userMe
        });
    };
}


export function userInfoRouterStatusAction(routingStatus) {
    return dispatch => {
        dispatch({
            type:CHANGE_ROUTINGSTATUS,
            routingStatus
        });
    };
}
