import {
  LOAD_NEW_ALERT_MESSAGE,
  UPDATE_ALERT_MESSAGE_BY_UNIQUEID,
  DELETE_ALERT_MESSAGE_BY_UNIQUEID
} from "../action-type/AlertMessageActionType";

export function loadNewAlertMessageAction(newAlertMessage) {
  return dispatch => {
    dispatch({
      type: LOAD_NEW_ALERT_MESSAGE,
      newAlertMessage
    });
  };
}

export function updateAlertMessageByUniqueIdAction(updateAlertMessage) {
  return dispatch => {
    dispatch({
      type: UPDATE_ALERT_MESSAGE_BY_UNIQUEID,
      updateAlertMessage
    });
  };
}

export function deleteAlertMessageByUniqueIdAction(deleteAlertMessage) {
  return dispatch => {
    dispatch({
      type: DELETE_ALERT_MESSAGE_BY_UNIQUEID,
      deleteAlertMessage
    });
  };
}
