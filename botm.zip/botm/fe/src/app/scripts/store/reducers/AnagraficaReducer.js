
import {
    LOAD_BASECLIENT_DATA,
    LOAD_CARTECLIENT_DATA
} from "../action-type/AnagraficaActionType.js";


export default function AnagraficaReducer(state = initialState, action) {

    switch (action.type) {
        case LOAD_BASECLIENT_DATA:
            return {
                ...state,
                anagraficaBaseWidget:{
                    ...state.anagraficaBaseWidget,
                    anagraficaBaseWidgetData: action.anagraficaBaseWidgetData
                }
            };
        case LOAD_CARTECLIENT_DATA:
            return {
                ...state,
                carteWidget:{
                    ...state.carteWidget,
                    carteWidgetData: action.carteWidgetData
                }
            }
        default:
            return state;
    }
}

const initialState = {
    anagraficaBaseWidget: {
        moveOperation: LOAD_BASECLIENT_DATA,
        anagraficaBaseWidgetData:{}
    },
    carteWidget:{
        moveOperation: LOAD_CARTECLIENT_DATA,
        carteWidgetData: []
    }
}