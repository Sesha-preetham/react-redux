import {
  LOAD_NEW_ALERT_MESSAGE,
  UPDATE_ALERT_MESSAGE_BY_UNIQUEID,
  DELETE_ALERT_MESSAGE_BY_UNIQUEID
} from "../action-type/AlertMessageActionType";

export default function(state = initialState, action) {
  let immutableAlertMessage = { ...state }.alertMessages;
  let newAlertElementStructure = {
    uniqueID: "",
    showAlert: false,
    alertType: "info",
    alertContent: ""
  };
  switch (action.type) {
    case LOAD_NEW_ALERT_MESSAGE:
      let pushIfNotExistIndex = immutableAlertMessage.findIndex(
        alertMessage => {
          return alertMessage.uniqueID === action.newAlertMessage.uniqueID;
        }
      );
      if (pushIfNotExistIndex === -1) {
        immutableAlertMessage.push({
          ...newAlertElementStructure,
          uniqueID: action.newAlertMessage.uniqueID
        });
        return {
          ...state,
          alertMessages: immutableAlertMessage
        };
      }
      return {
        ...state
      };
    case UPDATE_ALERT_MESSAGE_BY_UNIQUEID:
      let updateIndex = immutableAlertMessage.findIndex(alertMessage => {
        return alertMessage.uniqueID === action.updateAlertMessage.uniqueID;
      });
      if (updateIndex !== -1) {
        let availAlertMessage = immutableAlertMessage[updateIndex];
        availAlertMessage.showAlert = action.updateAlertMessage.showAlert;
        availAlertMessage.alertType = action.updateAlertMessage.alertType;
        availAlertMessage.alertContent = action.updateAlertMessage.alertContent;
        return {
          ...state,
          alertMessages: immutableAlertMessage
        };
      }
      return {
        ...state
      };
    case DELETE_ALERT_MESSAGE_BY_UNIQUEID:
      let deleteIndex = immutableAlertMessage.findIndex(alertMessage => {
        return alertMessage.uniqueID === action.deleteAlertMessage.uniqueID;
      });
      if (updateIndex !== -1) {
        immutableAlertMessage.splice(deleteIndex, 1);
        return {
          ...state,
          alertMessages: immutableAlertMessage
        };
      }
      return {
        ...state
      };
    default:
      return state;
  }
}

const initialState = {
  alertMessages: []
};
