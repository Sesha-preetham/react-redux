import dictionaries from "../../Utils/dictionary/index";

import {
    LOAD_INIT_CALL,
    LOAD_VISIBLE_BANKS,
    PC_TOKEN_AVAILABLE
} from "../action-type/InitActionType.js";


export default function InitReducer(state = initialState, action) {
    window.locale = "it";
    window.BTDictionary = dictionaries["it"];
    switch (action.type) {
        case LOAD_INIT_CALL:
            return {
                ...state,
                initData: action.initData
            };
        case LOAD_VISIBLE_BANKS:
            return {
                ...state,
                visibleBanks: action.visibleBanks
            };
        case PC_TOKEN_AVAILABLE:
            return {
                ...state,
                pcTokenAvailable: action.isAvailable
            };
        default:
            return state;
    }
}

const initialState = {
    initData:{},
    visibleBanks:[],
    pcTokenAvailable: false
}