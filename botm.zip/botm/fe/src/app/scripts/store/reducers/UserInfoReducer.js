import {
    LOAD_USERINFO_ME,
    CHANGE_ROUTINGSTATUS,
    CHANGE_USERSTATUS
} from "../action-type/UserInfoActionType.js";


export default function UserInfoReducer(state = initialState, action) {
    let userStatusOld;
    switch (action.type) {
        case LOAD_USERINFO_ME:
            return {
                ...state,
                userMe: action.userMe
            };
        case CHANGE_ROUTINGSTATUS:
            userStatusOld= {...state.userStatus};
            return {
                ...state,
                userStatus: {
                    ...userStatusOld,
                    routingStatus: action.routingStatus
                }
            };
        case CHANGE_USERSTATUS:
            userStatusOld = {...state.userStatus};
            return {
                ...state,
                userStatus: {
                    ...userStatusOld,
                    status: action.status
                }
            };
        default:
            return state;
    }
}

const initialState = {
    userMe:{},
    userStatus: {
        routingStatus: null,
        status: null
    }
}