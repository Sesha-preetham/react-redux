import {
    BAR_ADD_INTERACTION,
    BAR_REMOVE_INTERACTION,
    BAR_UPDATE_INTERACTION,
    BAR_CURRENT_INTERACTION,
    BAR_STORE_INTERACTION_WIDGETS_STATE,
    UPDATE_CURRENTINTERACTION_WIDGET_STATE_BAR
} from "../action-type/InteractionBarActionType";


export default function InteractionBarReducer(state = initialState, action) {

    switch (action.type) {
        case BAR_ADD_INTERACTION:
            return {
                ...state,
                interactions: addInteraction(state,action.interaction)
            };
        case BAR_REMOVE_INTERACTION:
            return {
                ...state,
                interactions: removeInteraction(state,action.interaction)
            };
        case BAR_CURRENT_INTERACTION:
            return {
                ...state,
                currentInteractionId: action.interactionId
            }
        case BAR_UPDATE_INTERACTION:
            return {
                ...state,
                interactions: updateInteraction(state,action.interaction)
            }
        case BAR_STORE_INTERACTION_WIDGETS_STATE:
            let obj={}
            obj[action.interactionId] = action.needToStoreObject;
            return {
                ...state,
                ...obj
            }
        case UPDATE_CURRENTINTERACTION_WIDGET_STATE_BAR:
            return updateCurrentInteractionWidgetState(state,action)
        default:
            return state;
    }
}

function addInteraction(state,interaction){
    let ints = [...state.interactions];
    ints.push(interaction);
    return ints;
}

function removeInteraction(state,interaction){
    let ints = [...state.interactions];
    let interactionIndex = ints.findIndex(i => {return (interaction && interaction.id && i.id === interaction.id)});
    if(interactionIndex !== -1){
        ints.splice(interactionIndex,1);
    }
    return ints;
}

function updateInteraction(state,interaction){
    let ints = [...state.interactions];
    let interactionIndex = ints.findIndex(i => {return (interaction && interaction.id && i.id === interaction.id)});
    if(interactionIndex !== -1){
        ints.splice(interactionIndex,1,interaction);
    }
    return ints;
}

function updateCurrentInteractionWidgetState(state, action){
    let currentIteraction = state.currentInteractionId;
    const { type, ...toUpdate } =action;
    let widgetStateKey = Object.keys(toUpdate);
    if(currentIteraction && state[currentIteraction]){
        return {
            ...state,
            [currentIteraction]: {
                ...state[currentIteraction],
                [widgetStateKey]: {
                    ...state[currentIteraction][widgetStateKey],
                    ...toUpdate[widgetStateKey]
                }
            }
        }
    }
    return state
}

const initialState = {
    currentInteractionId: undefined,
    interactions: []
}