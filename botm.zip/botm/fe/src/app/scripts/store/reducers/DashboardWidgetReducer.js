import {
    DASHBOARD_MAINWIDGET_INIT,
    DASHBOARD_MAINWIDGET_SHOW,
    DASHBOARD_MAINWIDGET_HIDE,
    DASHBOARD_MAINWIDGET_ADD,
    DASHBOARD_MAINWIDGET_REMOVE,
    DASHBOARD_WIDGET_ADD,
    DASHBOARD_WIDGET_LOAD_STATES
} from "../action-type/DashboardWidgetActionType.js";


export default function DashboardWidgetReducer(state = initialState, action) {

    switch (action.type) {
        case DASHBOARD_MAINWIDGET_INIT:
            return {
                ...state,
                dashboardMainWidgets: action.dashboardMainWidgets
            };
        case DASHBOARD_MAINWIDGET_SHOW:
            return dashboardMainWidgetShow(state,action.dashboardMainWidgetUniqueID,true)
        case DASHBOARD_MAINWIDGET_HIDE:
                return dashboardMainWidgetShow(state,action.dashboardMainWidgetUniqueID,false)
        case DASHBOARD_WIDGET_ADD:
            return dashboardAddWidget(state,action.dashboardWidget);
        case DASHBOARD_WIDGET_LOAD_STATES:
            return {
                ...state,
                dashboardWidgets: action.dashboardWidgetsStates.dashboardWidgetReducer.dashboardWidgets
            }
        default:
            return state;
    }
}

function dashboardAddWidget(currentState, widget){
    let exists = false;
    currentState.dashboardWidgets.forEach(el => {
        if(el.uniqueID === widget.uniqueID){
            exists=true;
        }
    });
    if(!exists){
        let dashboardWidgetsNew = [...currentState.dashboardWidgets];
        dashboardWidgetsNew.push(widget);
        return {
            ...currentState,
            dashboardWidgets: [
                ...dashboardWidgetsNew
            ]
        }
    }
    return currentState;
}
function dashboardMainWidgetShow(currentState, uniqueID, show){
    let dashboardMainWidgetsNew = [];
    currentState.dashboardMainWidgets.map(el => {
        if(el.uniqueID === uniqueID){
            el.showWidget=show;
        }
        dashboardMainWidgetsNew.push(el);
    })
    return {
        ...currentState,
        dashboardMainWidgets: dashboardMainWidgetsNew
    };
}
/*
{
    dashboardMainWidgets: [
        {
            uniqueID: 'widget1ID',
            showWidget: true
        }
    ]
}
*/

const initialState = {
    dashboardMainWidgets: [],
    dashboardWidgets: []
}