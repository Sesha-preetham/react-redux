import {
  loadNewAlertMessageAction,
  updateAlertMessageByUniqueIdAction,
  deleteAlertMessageByUniqueIdAction
} from "../../store/action/AlertMessageAction";

import Store from "../../store/configureStore";

let store = Store();

export const loadNewAlertMessageCall = successData => {
  store.dispatch(loadNewAlertMessageAction(successData));
};

export const updateAlertMessageByUniqueIdCall = successData => {
  store.dispatch(updateAlertMessageByUniqueIdAction(successData));
};

export const deleteAlertMessageByUniqueIdCall = successData => {
  store.dispatch(deleteAlertMessageByUniqueIdAction(successData));
};
