import { serviceUrls } from "../../client/Client.js";
import { DoPostServerAction
 } from "../../client/DoServerAction.js";
import ErrorHandler from "../../Utils/ErrorHandler";
import Common from "../../Utils/Common";


export const postLogoutServerCall = async () => {
    let succData1 = [];
    let spinnerId = window.BTDictionary["spinner.dashboard"];
    let alertContainerId = window.BTDictionary["alert.content.area.dashboard.anagrafica"];
    Common.drawSpinner(spinnerId);
    await DoPostServerAction(
        serviceUrls().logout,
        successData => {
            let res = successData.response;
            if(res && res.response){
                succData1 = res.response;
            }
            Common.removeSpinner(spinnerId);
        },
        errorData => {
          ErrorHandler.errorData(errorData, spinnerId, alertContainerId);
        },
        onSuccessExceptionData => {
          ErrorHandler.onSuccessException(
            onSuccessExceptionData,
            spinnerId,
            alertContainerId
          );
        }
      );
      return succData1;
}

