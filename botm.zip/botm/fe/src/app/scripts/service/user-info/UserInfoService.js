
import  {
    userInfoMeDataAction,
    userInfoRouterStatusAction,
    userInfoStatusAction
} from "../../store/action/UserInfoAction";
import Store from "../../store/configureStore";

const store = Store();



export function userInfoData(data){
    store.dispatch(userInfoMeDataAction(data));
}

export function userInfoRouterStatusData(data){
    store.dispatch(userInfoRouterStatusAction(data));
}

export function userInfoStatusData(data){
    store.dispatch(userInfoStatusAction(data));
}
