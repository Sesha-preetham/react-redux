import {
    initCallDataAction,
    initVisibleBanksDataAction,
    setPureCloudTokenAvailableAction
 } from "../../store/action/InitAction";

import Store from "../../store/configureStore";

const store = Store();

export function initCallData(data){
    store.dispatch(initCallDataAction(data));
}

export function initVisibleBanksData(data){
    store.dispatch(initVisibleBanksDataAction(data));
}

export function setPureCloudTokenAvailable(data){
    store.dispatch(setPureCloudTokenAvailableAction(data));
}