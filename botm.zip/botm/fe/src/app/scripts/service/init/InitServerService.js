import { serviceUrls } from "../../client/Client.js";
import { DoPostServerAction, DoGetServerAction } from "../../client/DoServerAction.js";
import { initCallData,
  initVisibleBanksData
} from "./InitService";
import ErrorHandler from "../../Utils/ErrorHandler";
import Common from "../../Utils/Common";

export const initCall = async () => {
    let succData1 = {};
    let spinnerId = window.BTDictionary["spinner.main"];
    let alertContainerId = window.BTDictionary["alert.mainApp.messageContainer"];
    Common.drawSpinner(spinnerId);
    await DoGetServerAction(
        serviceUrls().init,
        successData => {
            let res = successData.response;
            if(res && res.response){
                succData1 = res.response;
                initCallData(res.response);
            }
            Common.removeSpinner(spinnerId);
        },
        errorData => {
          ErrorHandler.errorData(errorData, spinnerId, alertContainerId);
        },
        onSuccessExceptionData => {
          ErrorHandler.onSuccessException(
            onSuccessExceptionData,
            spinnerId,
            alertContainerId
          );
        }
      );
      return succData1;
}

export const initGetVisibleBanks = async (reqData) => {
  let succData1 = {};
  let spinnerId = window.BTDictionary["spinner.main"];
  let alertContainerId = window.BTDictionary["alert.mainApp.messageContainer"];
  Common.drawSpinner(spinnerId);
  await DoGetServerAction(
      serviceUrls().initVisibleBanks,
      successData => {
          let res = successData.response;
          if(res && res.response){
              succData1 = res.response;
              initVisibleBanksData(res.response);
          }
          Common.removeSpinner(spinnerId);
      },
      errorData => {
        ErrorHandler.errorData(errorData, spinnerId, alertContainerId);
      },
      onSuccessExceptionData => {
        ErrorHandler.onSuccessException(
          onSuccessExceptionData,
          spinnerId,
          alertContainerId
        );
      },
      reqData
    );
    return succData1;
}