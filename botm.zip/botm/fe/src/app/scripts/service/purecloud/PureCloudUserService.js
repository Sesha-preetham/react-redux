import pureCloudClient from "../../client/PureCloudClient";
import {
    userInfoData
} from "../user-info/UserInfoService";

export async function getUserMe(){
    var userApi  = pureCloudClient.getUsersApi();
    let opts = { 
        'expand': ["employerInfo"],
    };
    if(userApi && userApi.getUsersMe){
        userApi.getUsersMe(opts).then(res => {
            userInfoData(res);
        })
    }
}