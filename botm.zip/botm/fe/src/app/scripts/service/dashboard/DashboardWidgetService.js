import {
    dashboardMainWidgetInitDataAction,
    dashboardMainWidgetShowDataAction,
    dashboardMainWidgetHideDataAction,
    dashboardMainWidgetAddDataAction,
    dashboardMainWidgetRemoveDataAction,
    dashboardWidgetAddDataAction
} from "../../store/action/DashboardWidgetAction";

import Store from "../../store/configureStore";

const store = Store();

export function dashboardMainWidgetInitCall(data){
    store.dispatch(dashboardMainWidgetInitDataAction(data));
}
export function dashboardMainWidgetShowCall(data){
    store.dispatch(dashboardMainWidgetShowDataAction(data));
}
export function dashboardMainWidgetHideCall(data){
    store.dispatch(dashboardMainWidgetHideDataAction(data));
}
export function dashboardMainWidgetAddCall(data){
    store.dispatch(dashboardMainWidgetAddDataAction(data));
}
export function dashboardMainWidgetRemoveCall(data){
    store.dispatch(dashboardMainWidgetRemoveDataAction(data));
}
export function dashboardWidgetAddCall(data){
    store.dispatch(dashboardWidgetAddDataAction(data));
}

