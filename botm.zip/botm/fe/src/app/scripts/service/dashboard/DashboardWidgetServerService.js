import { serviceUrls } from "../../client/Client.js";
import { DoGetServerAction } from "../../client/DoServerAction.js";
import ErrorHandler from "../../Utils/ErrorHandler";
import Common from "../../Utils/Common";



export const getDashboardMainWidgets = async (reqData) => {
    let succData1 = [];
    let spinnerId = window.BTDictionary["spinner.main"];
    let alertContainerId = window.BTDictionary["alert.mainApp.messageContainer"];
    Common.drawSpinner(spinnerId);
    await DoGetServerAction(
        serviceUrls().getDashboardWidgets,
        successData => {
            let res = successData.response;
            if(res && res.response){
                succData1 = res.response;
            }
            Common.removeSpinner(spinnerId);
        },
        errorData => {
          ErrorHandler.errorData(errorData, spinnerId, alertContainerId);
        },
        onSuccessExceptionData => {
          ErrorHandler.onSuccessException(
            onSuccessExceptionData,
            spinnerId,
            alertContainerId
          );
        },
        (reqData)?{
          ...reqData,
          main: 'Y'
        }:
        {
          main: 'Y'
        }
      );
      return succData1;
}

export const getDashboardWidgetsByQueue = async (reqData, drawSpinner) => {
  let succData1 = [];
  let spinnerId = window.BTDictionary["spinner.main"];
  let alertContainerId = window.BTDictionary["alert.mainApp.messageContainer"];
  let url = serviceUrls().getDashboardWidgetsByQueueName;
  if(drawSpinner !== false){
    Common.drawSpinner(spinnerId);
  }
  await DoGetServerAction(
      url,
      successData => {
          let res = successData.response;
          if(res && res.response){
              succData1 = res.response;
          }
          if(drawSpinner !== false){
            Common.removeSpinner(spinnerId);
          }
      },
      errorData => {
        ErrorHandler.errorData(errorData, spinnerId, alertContainerId);
      },
      onSuccessExceptionData => {
        ErrorHandler.onSuccessException(
          onSuccessExceptionData,
          spinnerId,
          alertContainerId
        );
      },
      reqData
    );
    return succData1;
}

export const getDashboardDefaultWidget = async (reqData, drawSpinner) => {
  let succData1 = [];
  let spinnerId = window.BTDictionary["spinner.main"];
  let alertContainerId = window.BTDictionary["alert.mainApp.messageContainer"];
  if(drawSpinner !== false){
    Common.drawSpinner(spinnerId);
  }
  await DoGetServerAction(
      serviceUrls().getDashboardWidgets,
      successData => {
          let res = successData.response;
          if(res && res.response){
              succData1 = res.response;
          }
          if(drawSpinner !== false){
            Common.removeSpinner(spinnerId);
          }
      },
      errorData => {
        ErrorHandler.errorData(errorData, spinnerId, alertContainerId);
      },
      onSuccessExceptionData => {
        ErrorHandler.onSuccessException(
          onSuccessExceptionData,
          spinnerId,
          alertContainerId
        );
      },
      (reqData)?{
        ...reqData,
        default: 'Y'
      }:
      {
        default: 'Y'
      }
    );
    return succData1;
}
