
import {
    loadBaseClientDataAction,
    loadCarteClientDataAction
} from "../../../store/action/AnagraficaAction";

import Store from "../../../store/configureStore";

const store = Store();

export function loadBaseClientData(data){
    store.dispatch(loadBaseClientDataAction(data));
}

export function loadCarteClientData(data){
    store.dispatch(loadCarteClientDataAction(data));
}
