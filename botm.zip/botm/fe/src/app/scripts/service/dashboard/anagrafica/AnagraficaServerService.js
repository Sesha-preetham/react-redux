import { serviceUrls } from "../../../client/Client.js";
import { DoPostServerAction,
         DoGetServerAction
 } from "../../../client/DoServerAction.js";
import ErrorHandler from "../../../Utils/ErrorHandler";
import Common from "../../../Utils/Common";

import { 
  loadBaseClientData,
  loadCarteClientData
} from "./AnagraficaService";

export const getAnagraficaSearchType= async (reqData) => {
  let succData1 = [];
  let spinnerId = window.BTDictionary["spinner.dashboard"];
  let alertContainerId = window.BTDictionary["alert.content.area.dashboard.anagrafica"];
  Common.drawSpinner(spinnerId);
  await DoGetServerAction(
      serviceUrls().anagraficaGetClientSearchTypes,
      successData => {
          let res = successData.response;
          if(res && res.response){
              succData1 = res.response;
          }
          Common.removeSpinner(spinnerId);
      },
      errorData => {
        ErrorHandler.errorData(errorData, spinnerId, alertContainerId);
      },
      onSuccessExceptionData => {
        ErrorHandler.onSuccessException(
          onSuccessExceptionData,
          spinnerId,
          alertContainerId
        );
      },
      reqData
    );
    return succData1;
}

export const anagraficaGetClientDataBySearchType= async (reqData) => {
    let succData1 = {};
    let spinnerId = window.BTDictionary["spinner.dashboard"];
    let alertContainerId = window.BTDictionary["alert.content.area.dashboard.anagrafica"];
    Common.drawSpinner(spinnerId);
    await DoGetServerAction(
        serviceUrls().anagraficaGetClientDataBySearchType,
        successData => {
            let res = successData.response;
            if(res && res.response){
                succData1 = res.response;
                loadBaseClientData(succData1);
            }
            Common.removeSpinner(spinnerId);
        },
        errorData => {
          ErrorHandler.errorData(errorData, spinnerId, alertContainerId);
        },
        onSuccessExceptionData => {
          ErrorHandler.onSuccessException(
            onSuccessExceptionData,
            spinnerId,
            alertContainerId
          );
        },
        reqData
      );
      return succData1;
}

export const anagraficaGetCarte= async (reqData) => {
  let succData1 = {};
  let spinnerId = window.BTDictionary["spinner.dashboard"];
  let alertContainerId = window.BTDictionary["alert.content.area.dashboard.anagrafica"];
  Common.drawSpinner(spinnerId);
  await DoGetServerAction(
      serviceUrls().anagraficaGetCarte,
      successData => {
          let res = successData.response;
          if(res && res.response){
              succData1 = res.response;
              loadCarteClientData(succData1);
          }
          Common.removeSpinner(spinnerId);
      },
      errorData => {
        ErrorHandler.errorData(errorData, spinnerId, alertContainerId);
      },
      onSuccessExceptionData => {
        ErrorHandler.onSuccessException(
          onSuccessExceptionData,
          spinnerId,
          alertContainerId
        );
      },
      reqData
    );
    return succData1;
}