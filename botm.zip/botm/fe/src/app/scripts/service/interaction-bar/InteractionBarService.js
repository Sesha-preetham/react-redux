
import  {
    addInteractionAction,
    removeInteractionAction,
    updateInteractionAction,
    setCurrentInteractionToBarAction,
    storeWidgetsStateOnInteractionBarAction,
} from "../../store/action/InteractionBarAction";

import {
    dashboardLoadWidgetsStateAction
} from "../../store/action/DashboardWidgetAction";

import Store from "../../store/configureStore";

const store = Store();


export function addInteractionToBar(data){
    store.dispatch(addInteractionAction(data));
}

export function updateInteractionToBar(data){
    store.dispatch(updateInteractionAction(data));
}

export function removeInteractionToBar(data){
    store.dispatch(removeInteractionAction(data));
}

export function setCurrentInteractionToBar(interactionId){
    store.dispatch(setCurrentInteractionToBarAction(interactionId))
}

export function storeWidgetsStateOnInteractionBar(){
    let storeState = store.getState();
    let currentInteractionId = storeState.interactionBarReducer.currentInteractionId;
    if(currentInteractionId){
        let storeThem = {
            ...storeState.anagraficaReducer,
            dashboardWidgetsReducer: {
                dashboardWidgets: [ ...storeState.dashboardWidgetsReducer.dashboardWidgets]
            }
        }
        store.dispatch(storeWidgetsStateOnInteractionBarAction(currentInteractionId,storeThem))
    }
}

export function moveWidgetsStateFromInteractionBar(interactionId){
    let storedInfo = store.getState().interactionBarReducer[interactionId];
    if(storedInfo){
        for(let key in storedInfo){
            if(storedInfo[key].moveOperation !== undefined){
                const { moveOperation, ...toDispath } = storedInfo[key];
                store.dispatch( dispatch => {
                    dispatch({
                        type: storedInfo[key].moveOperation,
                        ...toDispath
                    });
                })
            }
        }
    }
}

export function getInteractionDetailsFromBar(interactionId){
    let interactionBarReducer = store.getState().interactionBarReducer;
    for(let i=0;i<interactionBarReducer.interactions.length; i++ ){
        let interaction = interactionBarReducer.interactions[i];
        if(interaction.id===interactionId){
            return {
                ...interaction
            }
        }
    }
    return undefined;
}


