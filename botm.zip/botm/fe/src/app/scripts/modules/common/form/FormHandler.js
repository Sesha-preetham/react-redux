class FormHandler {


    //// REMOVING LOGIC OF theField passing as "this" for functional components

    fieldList = []; //of field object

    /*
      {
        field:{
            getValue: func,
            isValid: func,
            uniqueID: string,
            isVisible: func,
            isReadOnly: func,
            setVisible: func

        },
        validationResult: func
       }


    */
  
    constructor(onReplaceAndAdd = false) {
      // BUG FIX FOR NEW FIELDS WITH SAME UNIQUE ID REMOVE AND ADD AGAIN BY SANTHEEP
      const isReplaceAndAdd = onReplaceAndAdd;
      this.getIsReplaceAndAdd = () => {
        return isReplaceAndAdd;
      };
    }
  
    removeFields = () => {
      this.fieldList = [];
    };
  
    getFields = () => {
      let toRetArray = [];
      for (let i = 0; i < this.fieldList.length; i++) {
        let field = this.fieldList[i];
        toRetArray.push({
          uniqueID: field.configuration.uniqueID,
          getCurrentValue: field.theField.getValue,
          isValid: field.theField.isValid,
          field: field.theField
        });
      }
      return toRetArray;
    };
  
    addField = (field) => {
      if (
        field === undefined ||
        field.isValid === undefined 
      ) {
        console.warn(
          "[FormHandler]Mandatory parameter on addField not provided!"
        );
        throw "[FormHandler]Mandatory parameter on addField not provided!";
      }
      if (
        field.uniqueID &&
        this.getField(field.uniqueID) === undefined
      ) {
        this.fieldList.push({
          theField: field,
          validationResult: undefined
        });
      } else {
        console.warn(
          "[FormHandler]field alreeady present in the form! " +
          field.uniqueID
        );
        // BUG FIX FOR NEW FIELDS WITH SAME UNIQUE ID REMOVE AND ADD AGAIN BY SANTHEEP
        if (this.getIsReplaceAndAdd()) {
          this.removeField(field.uniqueID);
          this.addField(field);
        }
      }
    };
  
    removeField = uniqueID => {
      let field = this.getField(uniqueID);
      if (field !== undefined) {
        for (let i in this.fieldList) {
          if (uniqueID === this.fieldList[i].theField.uniqueID) {
            this.fieldList.splice(i, 1);
          }
        }
      }
    };
  
    validationResult = e => {
      let field = this.getField(e.uniqueID);
      if (field === undefined) {
        console.warn("[FormHandler]Field " + e.uniqueID + " not registered!");
        throw "[FormHandler]Field " + e.uniqueID + " not registered!";
      }
      field.validationResult = e;
    };
  
    cleanCachedField = uniqueID => {
      let field = this.getField(uniqueID);
      if (field === undefined) {
        console.warn("[FormHandler]Field " + uniqueID + " not registered!");
        throw "[FormHandler]Field " + uniqueID + " not registered!";
      }
      field.validationResult = undefined;
    };
  
    shouldValidate = field => {
      return (
        (field.theField &&
          field.theField.ignoreElement) ||
        (field.theField.isVisible() && !field.theField.isReadonly())
      );
    };
  
    isFormValid = () => {
      let toRet = true;
      for (let i = 0; i < this.fieldList.length; i++) {
        let field = this.fieldList[i];
        if (field.validationResult !== undefined) {
          if (
            this.shouldValidate(field) &&
            !field.validationResult.valid &&
            toRet
          ) {
            toRet = false;
          }
        } else {
          if (this.shouldValidate(field) && !field.theField.isValid() && toRet) {
            toRet = false;
          }
        }
      }
      return toRet;
    };
  
    getField = uniqueID => {
      for (let i = 0; i < this.fieldList.length; i++) {
        let field = this.fieldList[i];
        if (field.theField.uniqueID == uniqueID) {
          return field;
        }
      }
      return undefined;
    };
  
    setVisible = (uniqueID, bVisible) => {
      try {
        let field = this.getField(uniqueID);
        field.theField.setVisible(bVisible);
      } catch (err) {
        console.log("setVisible " + err);
      }
    };
  
    getValue = uniqueID => {
      try {
        let field = this.getField(uniqueID);
        return field.theField.getValue();
      } catch (err) {
        console.log("getValue " + err);
      }
    };
  
    replaceAll = (s, from, to) => {
      while (s.indexOf(from) != -1) {
        s = s.replace(from, to);
      }
      return s;
    };
  
    getFormSet = () => {
      let reqData = {};
      let list = this.fieldList;
      for (let i in list) {
        let field = list[i];
        if (field.validationResult !== undefined) {
          if (field.theField.isVisible()) {
            let key = field.validationResult.uniqueID;
            if (reqData[key] != field.validationResult.currentValue) {
              let value = field.validationResult.currentValue;
              reqData[key] = value;
            }
          }
        } else {
          if (field.theField && field.theField.props) {
            if (field.theField.isVisible()) {
              if (field.theField.props.configuration) {
                let conf = field.theField.props.configuration;
                reqData[conf.uniqueID] = field.theField.getValue();
              }
            }
          }
        }
      }
      return reqData;
    };
  
    fillFormSet = form => {
      let inputList = form.fieldList;
      for (let i in inputList) {
        let field = inputList[i];
        if (field.validationResult !== undefined) {
          let key = field.configuration.uniqueID;
          let value = field.validationResult.currentValue;
          if (key) {
            let shouldUpdate = this.getField(key);
            if (
              shouldUpdate.configuration.validation &&
              shouldUpdate.configuration.validation.type &&
              "Currency" === shouldUpdate.configuration.validation.type
            ) {
              let myValue = shouldUpdate.theField.formatAmount(value);
              myValue = this.replaceAll(myValue, ".", "");
              shouldUpdate.theField.setValue(myValue);
            } else {
              shouldUpdate.theField.setValue(value);
            }
          }
        }
      }
    };
  
    getJsonNewPreferences = funct => {
      let retObj = this.getFormSet();
      retObj["funct"] = funct;
      return retObj;
    };
  }
  
  export default FormHandler;