import React, {useState} from "react";
import { useSelector} from "react-redux";

function WidgetWrapper(props){

    const [internalObject] = useState({
        uniqueID: props.configuration.uniqueID,
        onlyChild: props.configuration.onlyChild
    });
    
    const widgetsState = useSelector(state => state.dashboardWidgetsReducer.dashboardWidgets);
    
    function needToShow(){
        let uniqueID = internalObject.uniqueID;
        let needToShow;
        for (let i = 0; i < widgetsState.length; i++) {
            if(widgetsState[i].uniqueID === uniqueID && widgetsState[i]){
                needToShow = true;
                break;
            }else{
                needToShow = false;
            }
        }
        return needToShow
    }

    function getWidgetConfig(){
        let uniqueID = internalObject.uniqueID;
        let widgetConfig;
        for (let i = 0; i < widgetsState.length; i++) {
            if(widgetsState[i].uniqueID === uniqueID ){
                widgetConfig = widgetsState[i].widgetConfig;
                break;
            }
        }
        return widgetConfig;
    }

    if(internalObject.onlyChild === true){
        if(needToShow()){
            return props.children(getWidgetConfig())
        }else{
            return null;
        }
    }else{
        return(
            <div id={internalObject.uniqueID} className={'widget-wrapper widget-wrapper-'+internalObject.uniqueID + ((needToShow())?'':' hide')}>
                {props.children(getWidgetConfig())}
            </div>
        )
    }
    
}

export default WidgetWrapper;