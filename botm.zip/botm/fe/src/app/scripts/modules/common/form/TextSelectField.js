import React, {useEffect, useState, useRef } from "react";
import PropTypes from "prop-types";
import FormHandler from "./FormHandler";
import { useAsyncReference } from "../hooks/customHooks";


function TextSelectField(props){
    
    let configuration = props.configuration;

    const [internalObject, setInternalObject] = useState({
            uniqueID: props.configuration.uniqueID,
            form: props.configuration.form,
            options: props.configuration.options,
            isVisible: props.configuration.isVisible,
            isReadOnly: props.configuration.isReadOnly,
            isDisabled: props.configuration.isDisabled,
            textValueType: (props.configuration.textValueType)?props.configuration.textValueType:'text'
    });

    const [selectedOption, setSelectedOption] = useAsyncReference();
    //const [textValue, setTextValue] = useState(props.configuration.defaulTextValue);

    const [textValue, setTextValue ] = useAsyncReference(props.configuration.defaulTextValue);

    console.log('TextSelectField textValue ---> ' + textValue);

    let getValue = () => { //callback function for form
        // get selected option + text
        let returnValue={};
        returnValue["selectValue"] = getSelectedOptionValue();
        returnValue["textValue"] = getTextValue();
        return returnValue;
    };

    function getSelectedOptionValue(){
        return selectedOption.current;
    }
    
    function getTextValue() {
        return textValue.current;
    }
    
    // handle menu click effect
    useEffect(() => {
        let uniqueID = internalObject.uniqueID;
        function handleMenuItemClick(e){
            console.log("handliiing menuiteeeeem click!!!!!!");
            $(e.currentTarget.parentElement).children('li').each( (i,li) => {
                $(li.children[0]).removeClass('selected');
            })
            $(e.currentTarget.children[0]).addClass('selected');
            setSelectedOptionWrapper();
        }

        $('#'+uniqueID+' .dropdown-item').on('click', handleMenuItemClick);
        return () => { $('#'+uniqueID+' .dropdown-item').off('click', handleMenuItemClick);}
    }, [internalObject.options]);

    //init form
    useEffect(() => {
        let form = internalObject.form;
        let toUseObject = {};
        toUseObject['getValue'] = getValue;
        toUseObject['isValid'] = isValid;
        toUseObject['uniqueID'] = internalObject.uniqueID;
        toUseObject['isVisible'] = isVisible;
        toUseObject['isReadOnly'] = isReadOnly;
        toUseObject['isDisabled'] = isDisabled;
        toUseObject['setVisible'] = setVisible;
        toUseObject['reloadOptions'] = reloadOptions; 
        form.addField(toUseObject);
    }, []);

    function reloadOptions (options){
        let obj = {...internalObject}
        obj.options=options;
       
        setInternalObject(obj);
        let defOption;
        options.map(el => {
            if(el.isDefault===true){
                defOption = el;
            }
        });
        setSelectedOption(defOption);
    }

    function isValid(){

    }

    function isVisible (){
        if(internalObject.isVisible){
            return internalObject.isVisible;
        }else{
            return false;
        }
    }

    function isDisabled() {
        if (internalObject.isDisabled) {
          return internalObject.isDisabled;
        } else {
          return false;
        }
    };

    function isReadOnly (){
        if(internalObject.isReadOnly){
            return internalObject.isReadOnly;
        }else{
            return false;
        }
    }

    function setVisible(isVisible){
        setInternalObject({
            ...internalObject,
            isVisible: isVisible
        })
    }

    function setSelectedOptionWrapper(){
        let selectedEl = $('#'+internalObject.uniqueID+' .dropdown-item > a.selected')[0];
        let selectedOption;
        if(selectedEl){
            let selectedOptionId = selectedEl.attributes['data-id'].value;
            selectedOption = internalObject.options.find( (el, index, allEls ) => (el.id === selectedOptionId) );
        }
        setSelectedOption(selectedOption);
    }

    function onChangeText(event){
        setTextValue(event.currentTarget.value);
    }

    function onKeyPress(event){
        if(event.key === "Enter" && configuration.onKeyEnter){
            configuration.onKeyEnter(event);
        }
    }

    function getTypeBaseOnOption(){
        let type;
        if(selectedOption && selectedOption.type){
            type = selectedOption.type;
        }else{
            type='text'
        }
        return type;
    }

    return (
        <div id={internalObject.uniqueID} className={" dropdown textselect-field-container " + "textselect-field-container-"+internalObject.uniqueID}>
            <div  >
                <input 
                    data-rtid={"textselect-text-field-"+configuration.uniqueID}
                    className={" textselect-text-field"}
                    onKeyPress={onKeyPress}
                    type={getTypeBaseOnOption()}
                    value={internalObject.textValue}
                    onChange={onChangeText}
                />
                
            </div >
            <a className="dropdown-toggle textselect-select-icon" 
                href="#"
                data-toggle="dropdown"  
                id={"dropdownMenuButton-"+internalObject.uniqueID} 
                role="button" 
                aria-haspopup="true"
                aria-expanded="false"
            />
            <ul className="bt-dropdown-menu dropdown-menu" aria-labelledby={"dropdownMenuButton-"+internalObject.uniqueID}>
                {internalObject.options.map((option, i) => {
                    return (
                        <li className={"bt-dropdown-item dropdown-item " + option.class}  >
                            <a  data-id={option.id}
                                className={ '' + ((option.isDefault)?'selected':'')
                                        }
                                 href="#">
                                <i className="glyphicon glyphicon-ok"></i>
                                <span>{option.description}</span>
                            </a>
                        </li>
                    );
                })}
            </ul>
        </div>
    );
}


TextSelectField.propTypes = {
    configuration: PropTypes.shape({
      uniqueID: PropTypes.string.isRequired,

      form: PropTypes.instanceOf(FormHandler),
      defaulTextValue: PropTypes.string,
      textTypeOnSelectedOption: PropTypes.bool,
      defaultOptionId: PropTypes.string,
      isReadOnly: PropTypes.bool,
      isVisible: PropTypes.bool,
      isDisabled: PropTypes.bool,
      options: PropTypes.arrayOf({
          id: PropTypes.string,
          description: PropTypes.string,
          class: PropTypes.string,
          type: PropTypes.string,
          isDefault: PropTypes.bool
      }),
      onKeyEnter: PropTypes.func
    }).isRequired
};


export default TextSelectField;