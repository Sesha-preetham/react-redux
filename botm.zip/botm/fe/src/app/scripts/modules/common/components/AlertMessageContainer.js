import React, {useEffect, useState} from "react";
import PropTypes from "prop-types";
import { Container, Row, Col, Alert } from "react-bootstrap";
import { useSelector } from "react-redux";

import {
  updateAlertMessageByUniqueIdCall,
  loadNewAlertMessageCall,
  deleteAlertMessageByUniqueIdCall
} from "../../../service/common/AlertMessageService";

const wait = (delay, ...args) =>
  new Promise(resolve => setTimeout(resolve, delay, ...args));


function AlertMessageContainer(props){

    const configuration = props.configuration;
    const [mounted, setMounted ] = useState(false);
    const alertState = useSelector( state => state.alertReducer);

    useEffect(() => {
        loadNewAlertMessageCall({
            uniqueID: configuration.uniqueID
        });
        setMounted(true);
        return () => {
            let alertData = getAlertDataByUniqueId();
            deleteAlertMessageByUniqueIdCall({
                uniqueID: alertData.uniqueID
            });
        }
    }, []);

    useEffect(() => {
        let alertData = getAlertDataByUniqueId();
        if (alertData.showAlert) {
            alertTimeout();
        }
    })


    async function alertTimeout () {
        await wait(10000);
        updateAlertMessageByUniqueIdCall({
          uniqueID: configuration.uniqueID,
          showAlert: false,
          alertType: "info",
          alertContent: ""
        });
    };

    function getAlertDataByUniqueId () {
        let alertDataArray = alertState.alertMessages;
        let alertDataIndex = alertDataArray.findIndex(alertMessage => {
          return alertMessage.uniqueID === configuration.uniqueID;
        });
        return alertDataArray[alertDataIndex];
    };

    function handleDismiss () {
        let alertData = getAlertDataByUniqueId();
        if (alertData.showAlert) {
          updateAlertMessageByUniqueIdCall({
            uniqueID: configuration.uniqueID,
            showAlert: false,
            alertType: "info",
            alertContent: ""
          });
        }
    };

    if(mounted){
        let alertData = getAlertDataByUniqueId();
        if (alertData.showAlert) {
            return (
                <Alert
                    id={alertData.uniqueID}
                    bsPrefix={'alert-'+alertData.alertType}
                    className="bt-MessageContainer alert"
                    onDismiss={handleDismiss}
                >
                    <Container fluid={true}>
                        <Row className="show-grid">
                            <Col
                                xs={12}
                                sm={12}
                                md={12}
                            >
                            <div className="bt-MessageContent">
                                {alertData.alertContent}
                            </div>
                            </Col>
                        </Row>
                    </Container>
                </Alert>
            );
        }else{
            return null;
        }
    }else{
        return null;
    }
}

AlertMessageContainer.propTypes = {
    configuration: PropTypes.shape({
      uniqueID: PropTypes.string.isRequired
    })
};

export default AlertMessageContainer;