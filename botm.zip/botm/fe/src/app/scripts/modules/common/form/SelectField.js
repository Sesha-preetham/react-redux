import React from "react";
import PropTypes from "prop-types";
import selectpicker from "bootstrap-select";

import Utils from "../../../Utils/Common";
import FormHandler from "./FormHandler";

class SelectField extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      internalObject: {}
    };
  }

  getOption = currentValue => {
    let options = this.state.internalObject.options;
    let uniqueID = this.state.internalObject.uniqueID;
    let optionIndex = options.findIndex(option => {
      return option.id === currentValue;
    });
    if (optionIndex !== -1) {
      return options[optionIndex];
    }
    console.warn("[SelectField] " + uniqueID + " option not available for current value " + currentValue + " !");
    throw "[SelectField] " + uniqueID + " option not available for current value " + currentValue + " !";
  };

  setReadonly = b => {
    var obj = this.state.internalObject;
    obj.readonly = b;
    if (b) {
      obj.valid = true;
      this.doThrowSetValue();
    } else {
      obj.valid = null;
      this.state.internalObject.form.cleanCachedField(
        this.state.internalObject.uniqueID
      );
    }
    this.updateInternalObject(obj);
  };

  isReadonly = () => {
    if (this.state.internalObject.readonly) {
      return this.state.internalObject.readonly;
    } else {
      return false;
    }
  };

  setSuppressEvent = isSuppress => {
    var obj = this.state.internalObject;
    obj.isSupress = isSuppress || false;
    this.updateInternalObject(obj);
  };

  isSuppressEvent = () => {
    var obj = this.state.internalObject;
    var isSupress = obj.isSupress || false;
    return isSupress;
  };

  setVisible = b => {
    var obj = this.state.internalObject;
    obj.visible = b;
    if (!b) {
      obj.valid = true;
      this.doThrowSetValue();
    } else {
      obj.valid = null;
      this.state.internalObject.form.cleanCachedField(
        this.state.internalObject.uniqueID
      );
    }
    this.updateInternalObject(obj);
  };

  isVisible = () => {
    if (this.state.internalObject.visible) {
      return this.state.internalObject.visible;
    } else {
      return false;
    }
  };

  getValue = () => {
    return this.state.internalObject.value;
  };

  getDescription = () => {
    return $(
      $(
        "select[name=" +
          this.state.internalObject.uniqueID +
          "]  option:selected"
      ).attr("data-content")
    ).text();
  };

  setValue = value => {
    var obj = this.state.internalObject;
    if (value !== obj.value) {
      $("select[name=" + this.state.internalObject.uniqueID + "]").val(value);
      $("#" + this.state.internalObject.uniqueID).selectpicker("refresh");
      this.internalValidate(value, true);
    }
  };

  doThrowSetValue = () => {
    var refreshObject = {
      uniqueID: this.state.internalObject.uniqueID,
      currentValue: this.state.internalObject.value,
      valid: this.state.internalObject.valid
    };
    if (
      this.state.internalObject.setValue !== undefined &&
      !this.isSuppressEvent()
    )
      this.state.internalObject.setValue(refreshObject);

    if (this.state.internalObject.form !== undefined)
      this.state.internalObject.form.validationResult(refreshObject);
  };

  isValid = () => {
    this.internalValidate(this.state.internalObject.value, true);
    return this.state.internalObject.valid;
  };

  shouldValidate = e => {
    var validation = this.state.internalObject.validation;
    return validation && this.isVisible() && !this.isReadonly();
  };

  internalValidate = (value, forceMessage) => {
    var internalObject = this.state.internalObject;
    var validation = internalObject.validation;
    var doForceRepaint = false;
    if (this.shouldValidate()) {
      var valid =
        !internalObject.readonly &&
        internalObject.visible &&
        validation.externalCheck(value);
      if (!valid) {
        // MODIFIED DICTIONARY LOGIC BY SANTHEEP
        validation.textError = "Not Valid";
      }
      //If 2 status are the same i don't need to full update everything
      doForceRepaint = this.state.internalObject.valid !== valid;
      this.state.internalObject.valid = valid;
    }

    this.state.internalObject.value = value;
    this.state.internalObject.forceMessage = forceMessage;
    if (doForceRepaint) {
      this.updateInternalObject(this.state.internalObject);
    }
    this.doThrowSetValue(); // Callback to the parent

    return this.state.internalObject;
  };

  onChange = e => {
    var obj = this.state.internalObject;
    if (e.target.value !== obj.value) {
      this.internalValidate(e.target.value, true);
    }
  };

  updateInternalObject = newObj => {
    this.setState({ internalObject: newObj });
  };

  componentWillUnmount() {
    this.unbindSelectPicker();
  }

  shouldComponentUpdate() {
    this.unbindSelectPicker();
    return true;
  }

  componentDidUpdate() {
    this.bindSelectPicker();
  }

  componentDidMount() {
    this.bindSelectPicker();
    //FIXME - bs.changed event not firing on setting default value so manually called didMount, we have to check the selector behvaiour - Arul
    var internalObject = this.state.internalObject;
    if (internalObject.defaultConfigValue) {
      this.setValue(internalObject.defaultConfigValue);
      internalObject.defaultConfigValue = "";
    }
  }

  unbindSelectPicker = () => {
    var internalObject = this.state.internalObject;
    $("div." + internalObject.uniqueID).unbind("changed.bs.select");
    $("." + internalObject.uniqueID).selectpicker("destroy");
  };

  bindSelectPicker = () => {
    var internalObject = this.state.internalObject;
    if (internalObject.visible) {
      if (internalObject.readonly) {
        $("." + internalObject.uniqueID).attr("disabled", "true");
      } else {
        $("." + internalObject.uniqueID).removeAttr("disabled");
      }
      if (internalObject.value) {
        $("." + internalObject.uniqueID).selectpicker(
          "val",
          internalObject.value
        );
      } else {
        $("." + internalObject.uniqueID).selectpicker();
      }

      $("div." + internalObject.uniqueID).on(
        "changed.bs.select",
        this.onChange
      );
    }
  };

  reloadOptions = options => {
    var obj = this.state.internalObject;
    obj.options = [];
    this.updateInternalObject(obj);

    var items = [];
    //var allItems = [];
    var addDefault = true;
    for (var i = 0; i < options.length; i++) {
      var item = options[i];

      if (!item.id || !item.description) {
        console.warn(
          "[SelectField]Mandatory parameters not provided on item " + i + "!"
        );
        throw "[SelectField]Mandatory parameters not provided on item " +
          i +
          "!";
      }
      if (!item.class) {
        item["class"] = "selectpicker-option";
      }

      if (item.defaultItem) {
        obj["value"] = item.id;
        addDefault = false;
      } else {
        item["defaultItem"] = false;
      }

      items.push(item);
    }

    if (addDefault && items.length > 0) {
      items[0].defaultItem = true;
      obj["value"] = items[0].id;
    }

    obj.options = items;
    this.updateInternalObject(obj);
  };

  reset = () => {
    var obj = this.state.internalObject;
    obj.options = [];
    this.updateInternalObject(obj);
  };

  setLabelKey = labelKey => {
    var obj = this.state.internalObject;
    obj.label = labelKey;
    this.updateInternalObject(obj);
  };

  setError = error => {
    //add error like standard error manager (append error at the end of name of field)
    var obj = this.state.internalObject;
    obj.forceMessage = true;
    obj.validation.textError = error;
    obj.valid = false;
    this.setState({
      internalObject: obj
    });
  };

  setErrorText = error => {
    //Overryde text label with error
    var obj = this.state.internalObject;
    if ($("#" + obj.uniqueID + "TITLE_CONTAINER"))
      $("#" + obj.uniqueID + "TITLE_CONTAINER").addClass("error");
    if (document.getElementById(this.state.internalObject.uniqueID + "TITLE"))
      document.getElementById(
        this.state.internalObject.uniqueID + "TITLE"
      ).innerHTML = error;
  };

  componentWillMount() {
    var internalObject = this.props.configuration;
    var toUseObject = {};

    // MODIFIED DICTIONARY LOGIC BY SANTHEEP
    toUseObject["label"] = internalObject.labelKey
      ? internalObject.labelKey
      : "";
    toUseObject["placeholder"] = internalObject.placeHolderKey
      ? internalObject.placeHolderKey
      : "";

    toUseObject["uniqueID"] = internalObject.uniqueID;

    toUseObject["validation"] = {};
    if (!internalObject.validation) {
      toUseObject.validation["externalCheck"] = function(value) {
        return true;
      };
    } else {
      toUseObject.validation["externalCheck"] =
        internalObject.validation.externalCheck === undefined
          ? function(value) {
              return true;
            }
          : internalObject.validation.externalCheck;
    }

    toUseObject["readonly"] = false;
    if (internalObject.readonly !== undefined) {
      toUseObject["readonly"] = internalObject.readonly;
    }

    toUseObject["visible"] = true;
    if (internalObject.visible !== undefined) {
      toUseObject["visible"] = internalObject.visible;
    }

    toUseObject["groupByAttr"] = internalObject.groupByAttr || null;
    toUseObject["groupByFn"] = internalObject.groupByFn || null;
    toUseObject["isGroupingAvailable"] =
      internalObject.groupByFn || internalObject.groupByAttr ? true : false;

    var items = [];
    //var allItems = [];
    var addDefault = true;
    for (var i = 0; i < internalObject.options.length; i++) {
      var item = internalObject.options[i];

      if (!item.id || !item.description) {
        console.warn(
          "[SelectField]Mandatory parameters not provided on item " + i + "!"
        );
        throw "[SelectField]Mandatory parameters not provided on item " +
          i +
          "!";
      }
      if (!item.class) {
        item["class"] = "selectpicker-option";
      }

      if (item.defaultItem) {
        if (toUseObject.value === undefined) {
          toUseObject["value"] = item.id;
        }

        addDefault = false;
      } else {
        item["defaultItem"] = false;
      }
      items.push(item);
    }

    /*for (i = 0; i<items.length; i++)
        {
            allItems.push(items[i]);
        }*/

    if (addDefault && items.length > 0) {
      items[0].defaultItem = true;
      if (toUseObject.value === undefined) {
        toUseObject["value"] = items[0].id; //FIX
      }
    }
    toUseObject["options"] = items;
    toUseObject["setValue"] = internalObject.setValue;
    toUseObject["minimal"] =
      internalObject.minimal !== undefined ? internalObject.minimal : false;
    //ANDREA: set da true a false
    toUseObject["searchEnabled"] = internalObject.searchEnabled || false;
    toUseObject["width"] =
      internalObject.width === undefined ? "100%" : internalObject.width;
    // MODIFIED ERROR UNDEFINED WHILE LABEL IS NOT GIVEN BY SANTHEEP
    toUseObject.validation["textError"] = "";
    toUseObject["valid"] = null;
    toUseObject["forceMessage"] = true;
    toUseObject["additionalClass"] = internalObject.additionalClass
      ? " " + internalObject.additionalClass
      : "";

    if (internalObject.form !== undefined) {
      if (internalObject.form.addField === undefined) {
        console.warn("[SelectField]Form parameter is not a Form!");
        throw "[SelectField]Form parameter is not a Form!";
      }
      toUseObject["form"] = internalObject.form;
      //internalObject.form.addField(this, toUseObject);
      // below method added for new FormHandler where I don't same all the object.
      toUseObject["getValue"] = this.getValue;
      toUseObject["isValid"] = this.isValid;
      toUseObject["reloadOptions"] = this.reloadOptions;
      internalObject.form.addField(toUseObject);
    }

    //if default value was set through config.defaultConfigValue we need select it as default
    if (internalObject.defaultConfigValue) {
      toUseObject["defaultConfigValue"] = internalObject.defaultConfigValue;
    }

    this.setState({ internalObject: toUseObject });
  }

  render() {
    var obj = this.state.internalObject;
    var fieldOption = {};
    fieldOption["id"] = obj.uniqueID;
    fieldOption["name"] = obj.uniqueID;
    // if (obj.readonly)
    {
      fieldOption["readOnly"] = obj.readonly || false;
    }
    if (obj.placeholder) {
      fieldOption["title"] =
        "<div class='selectpicker-option placeholder'>" +
        obj.placeholder +
        "</div>";
    }

    if (obj.defaultConfigValue) {
      fieldOption["defaultValue"] = obj.defaultConfigValue;
    }
    // MODIFIED DICTIONARY LOGIC BY SANTHEEP
    var placeHolder = this.props.configuration.placeHolderKey
      ? this.props.configuration.placeHolderKey
      : "";
    // MODIFIED DICTIONARY LOGIC BY SANTHEEP
    var noItemFound = "There are no results for {0}";

    if (obj.visible) {
      if (obj.minimal && !obj.isGroupingAvailable) {
        return (
          <select
            className={"selectpicker flag-select " + obj.uniqueID}
            data-width={obj.width}
            data-size="6"
            data-rtid={obj.uniqueID}
            data-live-search={obj.searchEnabled}
            data-none-selected-text=""
            data-none-results-text={noItemFound}
            data-live-search-placeholder={placeHolder}
            {...fieldOption}
          >
            {obj.options.map(
              function(option, i) {
                var item =
                  "<div class='" +
                  option.class +
                  "'>" +
                  option.description +
                  "</div>";
                return (
                  <option
                    data-rtid={option.id}
                    key={option.id}
                    value={option.id}
                    data-content={item}
                  />
                );
              }.bind(this)
            )}
          </select>
        );
      } else if (obj.isGroupingAvailable) {
        var data = obj.options;
        var groupBy = obj.groupByAttr;
        var groupByFn = obj.groupByFn;
        if (groupByFn) {
          groupBy = groupByFn(data);
        }
        var groupById = groupBy.id ? groupBy.id : "";
        var groupByDesc = groupBy.desc ? groupBy.desc : "";
        var grouping = Utils.getUniqueValueFromArray(data, groupBy.id);
        var indexedGroup = Utils.getIndexedGroup(data, groupBy.id);

        //  var groupingDesc = Utils.getUniqueValueFromArray(data, groupBy.desc);
        return (
          <select
            className={"selectpicker flag-select " + obj.uniqueID}
            data-width={obj.width}
            data-size="6"
            data-rtid={obj.uniqueID}
            data-live-search={obj.searchEnabled}
            data-none-selected-text=""
            data-none-results-text={noItemFound}
            data-live-search-placeholder={placeHolder}
            {...fieldOption}
          >
            {grouping.map(function(group, i) {
              var indexedVal = indexedGroup[group] || {};
              return (
                <optgroup label={indexedVal[groupByDesc]}>
                  ;
                  {data.map(function(options) {
                    if (options[groupById] == grouping[i]) {
                      var item =
                        "<div class='" +
                        options.class +
                        "'>" +
                        options.description +
                        "</div>";
                      //if placeholder is present it must be disabled/hidden
                      if (options.id == "-1") {
                        return (
                          <option
                            data-rtid={options.id}
                            selected
                            disabled
                            data-hidden="true"
                            key={options.id}
                            value={options.id}
                            data-content={item}
                          />
                        );
                      } else {
                        return (
                          <option
                            data-rtid={options.id}
                            key={options.id}
                            value={options.id}
                            data-content={item}
                          />
                        );
                      }
                    }
                  })}
                </optgroup>
              );
            })}
          </select>
        );
      } else {
        // MODIFIED DICTIONARY LOGIC BY SANTHEEP
        var label = $.trim(
          obj.valid === false && obj.forceMessage
            ? "The field " + obj.label + " " + obj.validation.textError
            : obj.label + (obj.validation.mandatory === true ? "" : "")
        );
        return (
          <div
            data-rtid={obj.uniqueID + "TITLE_CONTAINER"}
            id={obj.uniqueID + "TITLE_CONTAINER"}
            className={
              "inputfield-container " +
              (obj.valid === false && obj.forceMessage ? "error" : "") +
              obj.additionalClass
            }
          >
            <div className="title-field" id={obj.uniqueID + "TITLE"}>
              {label}
            </div>
            <select
              className={"selectpicker flag-select " + obj.uniqueID}
              data-live-search={obj.searchEnabled}
              data-width={obj.width}
              data-size="6"
              data-none-selected-text=""
              data-rtid={obj.uniqueID}
              data-none-results-text={noItemFound}
              data-live-search-placeholder={placeHolder}
              {...fieldOption}
            >
              {obj.options.map(
                function(option, i) {
                  var item =
                    "<div class='" +
                    option.class +
                    "'>" +
                    option.description +
                    "</div>";
                  //if placeholder is present it must be disabled/hidden
                  if (option.id == "-1") {
                    return (
                      <option
                        data-rtid={option.id}
                        selected
                        disabled
                        data-hidden="true"
                        key={option.id}
                        value={option.id}
                        data-content={item}
                      />
                    );
                  } else {
                    return (
                      <option
                        data-rtid={option.id}
                        key={option.id}
                        value={option.id}
                        data-content={item}
                      />
                    );
                  }
                }.bind(this)
              )}
            </select>
          </div>
        );
      }
    } else {
      return <div id={obj.uniqueID} />;
    }
  }
}

SelectField.propTypes = {
  configuration: PropTypes.shape({
    labelKey: PropTypes.string,
    placeHolderKey: PropTypes.string,
    form: PropTypes.instanceOf(FormHandler),
    defaultConfigValue: PropTypes.string,
    searchEnabled: PropTypes.bool,
    readonly: PropTypes.bool,
    visible: PropTypes.bool,
    minimal: PropTypes.bool,
    width: PropTypes.string,
    options: PropTypes.arrayOf(
      PropTypes.shape({
        id: PropTypes.string.isRequired,
        description: PropTypes.string.isRequired,
        class: PropTypes.string,
        defaultItem: PropTypes.bool
      })
    ).isRequired,
    validation: PropTypes.shape({
      externalCheck: PropTypes.func
    }),
    setValue: PropTypes.func
  }).isRequired
};

export default SelectField;
