import React, {useEffect, useState} from "react";
import PropTypes from "prop-types";
import FormHandler from "./FormHandler";

import { useAsyncReference } from "../hooks/customHooks";


function TextField(props){

    const [value, setValue] = useAsyncReference();
    const [internalObject, setInternalObject] = useState(props.configuration);

    const objConfig = props.configuration;

    //init form
    useEffect(() => {
        let toUseObject = {};
        let form = objConfig.form;
        toUseObject['getValue'] = getValue;
        toUseObject['setValue'] = (value) => {
            setValue(value);
        }
        toUseObject['isValid'] = isValid;
        toUseObject['uniqueID'] = objConfig.uniqueID;
        toUseObject['isVisible'] = isVisible;
        toUseObject['isReadOnly'] = isReadOnly;
        toUseObject['isDisabled'] = isDisabled;
        toUseObject['setVisible'] = setVisible;
        form.addField(toUseObject);
        if(objConfig.value){
            setValue(objConfig.value);
        }
    },[]);

    function getValue (){
        return value.current;
    }

    function isValid (){

    }

    function isVisible (){
        if(internalObject.isVisible){
            return internalObject.isVisible;
        }else{
            return false;
        }
    }

    function isDisabled() {
        if (internalObject.isDisabled) {
          return internalObject.isDisabled;
        } else {
          return false;
        }
    };

    function isReadOnly (){
        if(internalObject.isReadOnly){
            return internalObject.isReadOnly;
        }else{
            return false;
        }
    }

    function setVisible(){

    }

    function onBlur(event){

    }
    function onFocus(event){

    }
    function onKeyUp(event){

    }

    function onChange(event){
        let val = event.currentTargetState.value;
        setValue(val);
    }

    function getFieldOptions(){
        let obj = internalObject;
        let fieldOption = {};
        fieldOption["id"] = obj.uniqueID;
        fieldOption["name"] = obj.uniqueID;
        if (obj.isReadOnly) {
        fieldOption["readOnly"] = obj.readonly;
        }
        if (obj.isDisabled) {
        fieldOption["disabled"] = "disabled";
        }

        if (obj.validation && obj.validation.maxLen && obj.validation.maxLen !== -1) {
            fieldOption["maxLength"] = obj.validation.maxLen;
        }
        return fieldOption;
    }
    
    return(
        <div id={objConfig.uniqueID+'TEXTFIELD_CONTAINER'} className='bt-text-field-container'>
            {(objConfig.labelKey)?
                <div id={objConfig.uniqueID+'TEXTFIELD_LABEL_CONTAINER'}>
                    <span className='bt-text-field-label'>
                        {objConfig.labelKey} 
                    </span>
                </div>
            :null}
            <input 
                data-rtid={objConfig.uniqueID}
                type={objConfig.type} 
                value={value.current}
                placeholder={objConfig.placeHolderKey} 
                className='bt-text-field'
                onBlur={onBlur}
                onChange={onChange}
                onFocus={onFocus}
                onKeyUp={onKeyUp}
                {...getFieldOptions()}
            >
                {props.children}
            </input>
        </div>
    )

}

TextField.propTypes = {
    configuration: PropTypes.shape({
      labelKey: PropTypes.string,
      placeHolderKey: PropTypes.string,
      uniqueID: PropTypes.string.isRequired,
      form: PropTypes.instanceOf(FormHandler),
      isReadOnly: PropTypes.bool,
      isVisible: PropTypes.bool,
      isDisabled: PropTypes.bool,
      additionalValidation: PropTypes.func,
      validation: PropTypes.shape({
        mandatory: PropTypes.bool,
        minLen: PropTypes.number,
        maxLen: PropTypes.number,
        type: PropTypes.string
      }),
      value: PropTypes.oneOfType([
        PropTypes.string,
        PropTypes.number,
        PropTypes.bool
      ]),
      setValue: PropTypes.func,
      callBackOnBlur: PropTypes.func,
      callBackOnKeyUp: PropTypes.func
    }).isRequired
};


export default TextField;