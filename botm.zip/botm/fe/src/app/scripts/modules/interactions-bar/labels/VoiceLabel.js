import React from "react";
import {Envelope} from 'react-bootstrap-icons';

function VoiceLabel(props){

    let isSelected = props.isSelected;
    let isSelectedClass= (isSelected)?'selected':'';

    function handleOnClick(e){
        console.log(e + " interactionID -----> " + props.interaction.id);
    }
    

    return(
        <div id={'voiceMailLabelContainer-'+props.interaction.id} className={ "interaction-label-container " + isSelectedClass} onClick={e => handleOnClick(e)}>
            <div className='voiceMail-interaction-label-icon interaction-label-icon'>
                <Envelope className="voice-interaction-icon interaction-icon" />
                <span className="interaction-label">
                    VOCE {props.interaction.id}
                </span>
            </div>
        </div>
    )

}


export default VoiceLabel;