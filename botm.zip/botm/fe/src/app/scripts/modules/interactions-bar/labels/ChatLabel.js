import React from "react";
import {ChatFill} from 'react-bootstrap-icons';

function ChatLabel(props){

    let isSelected = props.isSelected;
    let isSelectedClass= (isSelected)?'selected':'';

    function handleOnClick(e){
        console.log(e + " interactionID -----> " + props.interaction.id);
    }
    

    return(
        <div id={'chatLabelContainer-'+props.interaction.id} className={ "interaction-label-container " + isSelectedClass} onClick={e => handleOnClick(e)}>
            <div className='chat-interaction-label-icon interaction-label-icon'>
                <ChatFill className="chat-interaction-icon interaction-icon" />
                <span className="interaction-label">
                    CHAT {props.interaction.name}
                </span>
            </div>
        </div>
    )

}

export default ChatLabel;