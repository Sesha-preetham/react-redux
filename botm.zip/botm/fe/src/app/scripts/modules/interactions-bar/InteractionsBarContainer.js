import React from "react";
import { Container,Row,Col } from "react-bootstrap";
import { useSelector } from "react-redux";
import EmailLabel from "./labels/EmailLabel";
import VoiceLabel from "./labels/VoiceLabel";
import ChatLabel from "./labels/ChatLabel";


function InteractionsBarContainer(){

    const interactionBarState = useSelector(state => state.interactionBarReducer);

    function InteractionLabelsContainer(){

        function renderLabel(el){
            console.log(el);
            let isSelected =(interactionBarState.currentInteractionId === el.id)?true:false;
            return(
                <Col  xs={2} sm={2} md={2} className='full-height'>
                    {renderInteractionLabel(el, isSelected)}
                </Col>
            )
        }

        function renderInteractionLabel(el, isSelected){
            if(el.isEmail){
                return (
                    <EmailLabel interaction={el} isSelected={isSelected} />
                )
            }else if(el.isChat){
                return(
                    <ChatLabel interaction={el} isSelected={isSelected} />
                )
            }else if(el.isMessage){
                
            }else{
                //voice
                return(
                    <VoiceLabel interaction={el} isSelected={isSelected} />
                )
            }
        }
        return(
            <Row className='full-height'>
                { (interactionBarState.interactions)?
                    interactionBarState.interactions.map(renderLabel):''}
            </Row>
        );
    }

    return (
        <Container id="interactionBar-container" className='full-height' fluid={true}>
                <InteractionLabelsContainer />
        </Container>
    );
}

export default InteractionsBarContainer;

