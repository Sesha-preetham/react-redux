import React from "react";
import {Envelope} from 'react-bootstrap-icons';

function EmailLabel(props){

    let isSelected = props.isSelected;
    let isSelectedClass= (isSelected)?'selected':'';

    function handleOnClick(e){
        console.log(e + " interactionID -----> " + props.interaction.id);
    }
    
    return(
        <div id={'emailLabelContainer-'+props.interaction.id} className={ "interaction-label-container " + isSelectedClass} onClick={e => handleOnClick(e)}>
            <div className='mail-interaction-label-icon interaction-label-icon'>
                <Envelope className="mail-interaction-icon interaction-icon" />
                <span className="interaction-label">
                    MAIL {props.interaction.displayAddress}
                </span>
            </div>
        </div>
    )

}

export default EmailLabel;