import React, { useState } from "react";
import { Container, Row, Col } from "react-bootstrap";
import PrivatoAziendaDispatcher from "./privato-azienda/PrivatoAziendaDispatcher";
import AlertMessageContainer from "../../common/components/AlertMessageContainer";
import DashboardSectionTitle from "../common/DashboardSectionTitle";
import {
    PrivatoAziendaSelector
 } from "./privato-azienda/PrivatoAziendaSelector";
 import ClientSearchBox from "./client-search/ClientSearchBox";
import FormHandler from "../../common/form/FormHandler";
import WidgetWrapper from "../../common/widgets/WidgetWrapper";

function AnagraficaContainer(){

    const [ privatoAzienda, setPrivatoAzienda] = useState('PRIVATO');
    const [ anagraficaClientSearchForm ] = useState(new FormHandler());
    const titleConfiguration = {
        id:'anagraficaTitleContainer',
        mainTitle: 'Anagrafica Cliente',
        form: anagraficaClientSearchForm,
        leftChild: <PrivatoAziendaSelector configuration={{
                        form: anagraficaClientSearchForm,
                        handlePrivato: () => {
                            setPrivatoAzienda('PRIVATO');
                        },
                        handleAzienda: () => {
                            setPrivatoAzienda('AZIENDA');
                        },
                        privatoAzienda: privatoAzienda
                    }}/>,
        rigthChild: <ClientSearchBox configuration={{
            form: anagraficaClientSearchForm
        }}/>
    }

    const alertConfiguration = {
        uniqueID: window.BTDictionary["alert.content.area.dashboard.anagrafica"]
    }
    return(
        <Container id="dashboard-anagrafica-container" className="anagrafica-container barra-dashboard-section-container pBottom30">
            <Row>
               <DashboardSectionTitle configuration={titleConfiguration} />
            </Row>
            <Row>
                <AlertMessageContainer configuration={alertConfiguration} />
                <WidgetWrapper configuration={{
                        uniqueID: "anagraficaButtonsWidget",
                        onlyChild: true
                }}>{ widgetConfig => (
                    <Col xs={1} md={1} lg={1} >
                        <button className='anagrafica-left-button anagrafica-left-button-authentication'>Autenticazione</button>
                    </Col>
                )}
                </WidgetWrapper>
                <Col xs={11} md={11} lg={11} >
                    <PrivatoAziendaDispatcher privatoAzienda={privatoAzienda} />
                </Col>
            </Row>
        </Container>
    );
}

export default AnagraficaContainer;