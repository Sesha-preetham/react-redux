import React, { useEffect} from "react";
import {Container, Row, Col, Nav} from "react-bootstrap";

import DashboardMainWidgetWrapper from "./common/DashboardMainWidgetWrapper";
import AnagraficaContainer from "./anagrafica/AnagraficaContainer";
import ConsuntivazioneContainer from "./consuntivazione/ConsuntivazioneContainer";
import ConversationContainer from "./conversation/ConversationContainer";
import ContactHistoryContainer from "./contact-history/ContactHistoryContainer";

import {
    dashboardMainWidgetInitCall,
    dashboardMainWidgetShowCall,
    dashboardMainWidgetHideCall,
    dashboardWidgetAddCall
} from "../../service/dashboard/DashboardWidgetService";
import {
    getDashboardMainWidgets,
    getDashboardDefaultWidget
} from "../../service/dashboard/DashboardWidgetServerService";

import { useSelector } from "react-redux";



function DashBoardContainer(){

    const dashboardWidgets = useSelector(state => state.dashboardWidgetsReducer.dashboardMainWidgets ) ;

    useEffect(() => {
        //load main dashboard widget from db
        getDashboardMainWidgets().then( widgets =>{
            let mainWidget = [];
            widgets.forEach(el => {
                mainWidget.push({
                    uniqueID: el.code,
                    ...el.widgetConfig
                });
            });
            dashboardMainWidgetInitCall(mainWidget);
        });
        getDashboardDefaultWidget({
            main:'N'
        }).then( widgets => {
            if(widgets){
                widgets.forEach(w => {
                    dashboardWidgetAddCall({
                        uniqueID: w.code,
                        widgetConfig: w.widgetConfig
                    });
                });
            }
        });
    },[]);

    function onSelectItem (key, event){
        console.log('dashboard item selected ' + key + " e " + event);
        let parentEl = event.currentTarget.parentElement;
        if($(parentEl).hasClass('selected')){
            $(parentEl).removeClass('selected');
            dashboardMainWidgetHideCall(key);
        }else{
            $(parentEl).addClass('selected');
            dashboardMainWidgetShowCall(key);
        }

    } 
    return(
        <Container fluid={true} className="dashboard-container full-height" id="dashboardContainer" >
            <div id={window.BTDictionary["spinner.dashboard"]} />
            <Row className='full-height'>
                <Col xs={1} md={1} lg={1} id="dashboardMenuContainer" className='no-padding full-height'>
                    <React.Fragment>
                        <Nav className='sidebar' id="dashboardMenuSideBar" onSelect={ (sKey,event) => onSelectItem(sKey,event)}>
                            
                                {dashboardWidgets.map(el => {
                                    return(
                                        <Nav.Item className={'dashboard-menu-item' + ((el.showWidget)?' selected':'')}>
                                            <Nav.Link eventKey={el.uniqueID} className='dashboard-menu-link'>
                                                <img className='dashboard-menu-icon' src={'data:image/svg+xml;utf8,'+el.icon} />
                                            </Nav.Link>
                                            {
                                                (el.showWidget)?
                                                    <a href={'#'+el.uniqueID} className='dashboard-menu-icon-arrow'>
                                                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-caret-right-fill" viewBox="0 0 16 16">
                                                            <path d="M12.14 8.753l-5.482 4.796c-.646.566-1.658.106-1.658-.753V3.204a1 1 0 0 1 1.659-.753l5.48 4.796a1 1 0 0 1 0 1.506z"/>
                                                        </svg>
                                                    </a>:null
                                            }
                                            
                                    </Nav.Item>
                                    )
                                })}
                        </Nav>
                    </React.Fragment>
                </Col>
                <Col xs={11} md={11} lg={11} id="dashboardContentContainer" className='full-height no-padding'>
                    <DashboardMainWidgetWrapper uniqueID='anagraficaWidget'>
                        <AnagraficaContainer />
                    </DashboardMainWidgetWrapper>
                    <DashboardMainWidgetWrapper uniqueID='conversationWidget'>
                        <ConversationContainer />
                    </DashboardMainWidgetWrapper>
                    <DashboardMainWidgetWrapper uniqueID='contactHistoryWidget'>
                        <ContactHistoryContainer />
                    </DashboardMainWidgetWrapper>
                    <DashboardMainWidgetWrapper uniqueID='consuntivazioneWidget'>
                        <ConsuntivazioneContainer/>
                    </DashboardMainWidgetWrapper>
                </Col>
            </Row>
        </Container>
    );
}
export default DashBoardContainer;