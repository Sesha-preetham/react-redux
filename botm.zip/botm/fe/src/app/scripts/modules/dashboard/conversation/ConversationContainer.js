import React, { useEffect } from "react";
import { Container, Row, Col } from "react-bootstrap";
import DashboardSectionTitle from "../common/DashboardSectionTitle";

function ConversationContainer(){
    const ref = React.createRef();
    const titleConfiguration = {
        mainTitle: 'Conversazione',
        id: 'conversationTitleContainer',
    }

    /*useEffect(() => {
        
        //call function after load
        handleResizeStartup();
        // Add event listener
        window.addEventListener("resize", handleResizeStartup);
        // Remove event listener on cleanup
        return () => window.removeEventListener("resize", handleResizeStartup);
    }, []);


    useEffect(() => {
        
        const element = ref.current;
        element.addEventListener('resize', handleResize);
        function checkResize(mutations) {
            const el = mutations[0].target;
            const w = el.clientWidth;
            const h = el.clientHeight;

            const isChange = mutations
                .map((m) => `${m.oldValue}`)
                .some((prev) => prev.indexOf(`width: ${w}px`) === -1 || prev.indexOf(`height: ${h}px`) === -1);

            if (!isChange) { return; }
            const event = new CustomEvent('resize', { detail: { width: w, height: h } });
            el.dispatchEvent(event);
        }
        const observer = new MutationObserver(checkResize);
        observer.observe(element, { attributes: true, attributeOldValue: true, attributeFilter: ['style'] });

        return () => element.removeEventListener("resize", handleResize);
    }, []);

    function handleResizeStartup() {
        getSoftPhoneH(true);
    }

    function handleResize(){
        getSoftPhoneH(false);
    }*/


    //<iframe id="softphone" allow="camera *; microphone *" src="https://apps.mypurecloud.de/crm/index.html?crm=framework-local-secure"></iframe>
    //https://apps.mypurecloud.de/crm/embeddableFramework.html
    return(
        <Container  fluid={true} id='conversationContainer' className='conversation-container barra-dashboard-section-container'>
                <Row>
                    <DashboardSectionTitle configuration={titleConfiguration} />
                </Row>
                <Row id="purecloud-interaction-container">
                    <Col>
                        <iframe ref={ref} id="purecloud-interaction" allow="camera *; microphone *; autoplay *" src="https://apps.mypurecloud.de/crm/interaction.html"></iframe>
                    </Col>
                </Row>
        </Container>
    );
}

function getSoftPhoneH(starup){     
    let totH=(starup===true)?($('#app_container').innerHeight()-50)/2:$('#conversationContainer').innerHeight();
    console.log('#app_container: ' +totH);
    console.log('#conversationTitleContainer: ' + $("#conversationTitleContainer").innerHeight());
    $('#purecloud-interaction').height(totH-$("#conversationTitleContainer").innerHeight()-7); //-14 border
}

export default ConversationContainer;