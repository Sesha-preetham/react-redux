
import React, {useEffect, useState} from "react";
import { Container, Row, Col } from "react-bootstrap";
import WidgetWrapper from "../../../common/widgets/WidgetWrapper";
import TextField from "../../../common/form/TextField";
import FormHandler from "../../../common/form/FormHandler";
import { useSelector } from "react-redux";
import { Front } from "react-bootstrap-icons";


function AnagraficaBaseWidget(props){

    const configuration = props.configuration; 
    const widgetConfig = props.widgetConfig;

    const[ form] = useState(new FormHandler());

    const [internalObject] = useState({
        uniqueID: props.configuration.uniqueID,
        form: form
    });

    const baseAnagraficaState = useSelector( state => state.anagraficaReducer.anagraficaBaseWidget.anagraficaBaseWidgetData);


    useEffect(()=> {
        console.log(baseAnagraficaState);
        let baseValue = {};
        if(baseAnagraficaState){
            if(baseAnagraficaState.length > 1){
                //show modal with multiple customer selection
            }else{
                baseValue =  baseAnagraficaState[0];
            }
            if(baseValue){
                if(baseValue.name && baseValue.surname){
                    form.getField('nomeCognomeField').theField.setValue(baseValue.name + ' ' + baseValue.surname);
                }
                if(baseValue.idSoggetto ){
                    form.getField('idSoggettoField').theField.setValue(baseValue.idSoggetto);
                }
                if(baseValue.nationality ){
                    form.getField('nazionalitaField').theField.setValue(baseValue.nationality);
                }
                if(baseValue.ottoCifre ){
                    form.getField('ottoCifreField').theField.setValue(baseValue.ottoCifre);
                }
                if(baseValue.username ){
                    form.getField('usernameField').theField.setValue(baseValue.username);
                }
                if(baseValue.sesso ){
                    form.getField('sessoField').theField.setValue(baseValue.sesso);
                }
                if(baseValue.codiceFiscale ){
                    form.getField('codFiscaleField').theField.setValue(baseValue.codiceFiscale);
                }
                if(baseValue.luogoNascita ){
                    form.getField('luogoNascitaField').theField.setValue(baseValue.luogoNascita);
                }
                if(baseValue.dataNascita ){
                    form.getField('dataNascitaField').theField.setValue(baseValue.dataNascita);
                }
                if(baseValue.email ){
                    form.getField('emailField').theField.setValue(baseValue.email);
                }
                
            }else{
                form.getField('nomeCognomeField').theField.setValue('');
                form.getField('idSoggettoField').theField.setValue('');
                form.getField('nazionalitaField').theField.setValue('');
                form.getField('ottoCifreField').theField.setValue('');
                form.getField('usernameField').theField.setValue('');
                form.getField('sessoField').theField.setValue('');
                form.getField('codFiscaleField').theField.setValue('');
                form.getField('luogoNascitaField').theField.setValue('');
                form.getField('dataNascitaField').theField.setValue('');
                form.getField('emailField').theField.setValue('');
            }
        }
    },[baseAnagraficaState]);

    const anagraficaWidgetConfiguration = {
        uniqueID: configuration.uniqueID
    }

    const commonTextBoxConfiguration = {
        form: internalObject.form,
        isVisible: true
    }

    const nomeCognomeTextConfig = {
        uniqueID: "nomeCognomeField",
        isDisabled: true,
        ...commonTextBoxConfiguration
    }

    const idSoggettoTextConfig = {
        uniqueID: "idSoggettoField",
        isDisabled: true,
        ...commonTextBoxConfiguration
    }
    const nazionalitaTextConfig ={
        uniqueID: "nazionalitaField",
        isDisabled: true,
        ...commonTextBoxConfiguration
    }

    const codiceClienteConfig = {
        uniqueID: "codClienteField",
        isDisabled: true,
        ...commonTextBoxConfiguration
    }

    const ottoCifreConfig = {
        uniqueID: "ottoCifreField",
        isDisabled: true,
        ...commonTextBoxConfiguration
    }

    const codFiscaleField ={
        uniqueID: "codFiscaleField",
        isDisabled: true,
        ...commonTextBoxConfiguration
    }

    const userNameConfig = {
        uniqueID: "usernameField",
        isDisabled: true,
        ...commonTextBoxConfiguration
    }

    const luogoNascitaConfig = {
        uniqueID: "luogoNascitaField",
        isDisabled: true,
        ...commonTextBoxConfiguration
    }
    const sessoConfig = {
        uniqueID: "sessoField",
        isDisabled: true,
        ...commonTextBoxConfiguration
    }
    const statoCodiceConfig = {
        uniqueID: "statoCodiceField",
        isDisabled: true,
        ...commonTextBoxConfiguration
    }
    const dataNascitaConfig = {
        uniqueID: "dataNascitaField",
        isDisabled: true,
        ...commonTextBoxConfiguration
    }

    const emailConfig = {
        uniqueID: "emailField",
        isDisabled: true,
        ...commonTextBoxConfiguration
    }

    const provinciaConfig = {
        uniqueID: "provinciaField",
        isDisabled: true,
        ...commonTextBoxConfiguration
    }

    const documentiConfig = {
        uniqueID: "documentiField",
        isDisabled: true,
        ...commonTextBoxConfiguration
    }

    return(
        <Container fluid={true}>
            <Row className=" mTop5">
                <Col xs={4} sm={4} md={4} className="no-padding">
                    <Col xs={6} sm={6} md={6} className="bt-label-style text-right">
                        <span>Nome e Cognome: </span>
                    </Col>
                    <Col xs={6} sm={6} md={6} className="bt-label-text-style text-right">
                        <TextField configuration={nomeCognomeTextConfig} />
                    </Col>
                </Col>
                <Col xs={4} sm={4} md={4} className="no-padding">
                    <Col xs={6} sm={6} md={6} className="bt-label-style text-right">
                        <span>IDSoggetto:</span>
                    </Col>
                    <Col xs={6} sm={6} md={6} className="bt-label-text-style text-right">
                        <TextField configuration={idSoggettoTextConfig} />
                    </Col>
                </Col>
                <Col xs={4} sm={4} md={4} className="no-padding">
                    <Col xs={6} sm={6} md={6} className="bt-label-style text-right">
                        <span>Nazionalità:</span>
                    </Col>
                    <Col xs={6} sm={6} md={6} className="bt-label-text-style text-right">
                        <TextField configuration={nazionalitaTextConfig} />
                    </Col>
                </Col>
            </Row>
            <Row className=" mTop5">
                <Col xs={4} sm={4} md={4} className="no-padding">
                    <Col xs={6} sm={6} md={6} className="bt-label-style text-right">
                        <span>Codice Cliente:</span>
                    </Col>
                    <Col xs={6} sm={6} md={6} className="bt-label-text-style text-right">
                        <TextField configuration={codiceClienteConfig}/>
                    </Col>
                </Col>
                <Col xs={4} sm={4} md={4} className="no-padding">
                    <Col xs={6} sm={6} md={6} className="bt-label-style text-right">
                        <span>8 Cifre: </span>
                    </Col>
                    <Col xs={6} sm={6} md={6} className="bt-label-text-style text-right">
                        <TextField configuration={ottoCifreConfig} />
                    </Col>
                </Col>
                <Col xs={4} sm={4} md={4} className="no-padding">
                    <Col xs={6} sm={6} md={6} className="bt-label-style text-right">
                        <span>Codice Fiscale:</span>
                    </Col>
                    <Col xs={6} sm={6} md={6} className="bt-label-text-style text-right">
                        <TextField configuration={codFiscaleField} />
                    </Col>
                </Col>
            </Row>
            <Row className=" mTop5">
                <Col xs={4} sm={4} md={4} className="no-padding">
                    <Col xs={6} sm={6} md={6} className="bt-label-style text-right">
                        <span>Username:</span>
                    </Col>
                    <Col xs={6} sm={6} md={6} className="bt-label-text-style text-right">
                        <TextField configuration={userNameConfig}/>
                    </Col>
                </Col>
                <Col xs={4} sm={4} md={4} className="no-padding">
                    <Col xs={6} sm={6} md={6} className="bt-label-style text-right">
                        <span>Luogo di Nascita: </span>
                    </Col>
                    <Col xs={6} sm={6} md={6} className="bt-label-text-style text-right">
                        <TextField configuration={luogoNascitaConfig} />
                    </Col>
                </Col>
                <Col xs={4} sm={4} md={4} className="no-padding">
                    <Col xs={6} sm={6} md={6} className="bt-label-style text-right">
                        <span>Sesso:</span>
                    </Col>
                    <Col xs={6} sm={6} md={6} className="bt-label-text-style text-right">
                        <TextField configuration={sessoConfig} />
                    </Col>
                </Col>
            </Row>
            <Row className=" mTop5">
                <Col xs={4} sm={4} md={4} className="no-padding">
                    <Col xs={6} sm={6} md={6} className="bt-label-style text-right">
                        <span>Stato Codice:</span>
                    </Col>
                    <Col xs={6} sm={6} md={6} className="bt-label-text-style text-right">
                        <TextField configuration={statoCodiceConfig}/>
                    </Col>
                </Col>
                <Col xs={4} sm={4} md={4} className="no-padding">
                    <Col xs={6} sm={6} md={6} className="bt-label-style text-right">
                        <span>Data di Nascita: </span>
                    </Col>
                    <Col xs={6} sm={6} md={6} className="bt-label-text-style text-right">
                        <TextField configuration={dataNascitaConfig} />
                    </Col>
                </Col>
                <Col xs={4} sm={4} md={4} className="no-padding">
                    <Col xs={6} sm={6} md={6} className="bt-label-style text-right">
                        <span>Email:</span>
                    </Col>
                    <Col xs={6} sm={6} md={6} className="bt-label-text-style text-right">
                        <TextField configuration={emailConfig} />
                    </Col>
                </Col>
            </Row>
            <Row className=" mTop5">
                <Col xs={4} sm={4} md={4} className="no-padding">
                    <Col xs={6} sm={6} md={6} className="bt-label-style text-right">
                        <span>Provincia:</span>
                    </Col>
                    <Col xs={6} sm={6} md={6} className="bt-label-text-style text-right">
                        <TextField configuration={provinciaConfig}/>
                    </Col>
                </Col>
                <Col xs={4} sm={4} md={4} className="no-padding">
                    <Col xs={6} sm={6} md={6} className="bt-label-style text-right">
                        <span>Documenti:</span>
                    </Col>
                    <Col xs={6} sm={6} md={6} className="bt-label-text-style text-right">
                        <TextField configuration={documentiConfig} />
                    </Col>
                </Col>
            </Row>
        </Container>
    );


}

export default AnagraficaBaseWidget;