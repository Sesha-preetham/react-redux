import React, {useState} from "react";
import { Rnd } from "react-rnd";

export class DashboardRndWrapper extends React.Component{

    constructor(props){
        super(props);
        let configuration = props.configuration;
        this.state={
            uniqueID: configuration.uniqueID,
            rndRefs: configuration.rndRefs,
            rndWrapperRefs: configuration.rndWrapperRefs,
            x:configuration.position.x,
            y:configuration.position.y,
            width: configuration.size.width,
            height: configuration.size.height,
            parentContainer: configuration.parentContainer,
            maxParentWidth: 0
        }
        this.updatePosition = this.updatePosition.bind(this);
        this.updateSize = this.updateSize.bind(this);
        this.handleResizeCallBack = this.handleResizeCallBack.bind(this);
    }

    componentDidMount(){
        const{parentContainer} = this.state;
        let maxParentWidth = $(parentContainer).innerWidth();
        this.setState({
            maxParentWidth:maxParentWidth
        });
    }

    handleResizeCallBack (event, dir, refToElement, delta, position) {
        const {configuration} = this.props;
        const {rndWrapperRefs}= configuration;
        const {x,y,height,width, uniqueID} = this.state;
        let cb = configuration.onResize;

        console.log(' handleResizeCallBack ' + event + ' ' + dir + ' ' + refToElement + ' ' + delta + ' ' + position);
        let currentResizeID = refToElement.id;
        if(currentResizeID === uniqueID){
            if(delta.height < 0 || delta.width <0){ // no reducing operation allow
                return;
            }
            for( const key in rndWrapperRefs){
                //dispatch the resize to other wrappers
                if(currentResizeID !== key){
                    rndWrapperRefs[key].handleResizeCallBack(event, dir, refToElement, delta, position);
                }
            }
        }else{
            //currentRndWrapper.state.x;
            //currentRndWrapper.state.y;
            let currentRndWrapper = rndWrapperRefs[currentResizeID];
            let currentRndWrapperW = currentRndWrapper.state.width;
            let currentRndWrapperH = currentRndWrapper.state.height;
            let currentRndWrapperX = position.x; 
            let currentRndWrapperY = position.y; 
            if(delta.height !==0 || delta.width!==0){
                // need to take the top-left corner and the bottom-right corner
                //{x1,y1} : top-left - {y1,y2} : bottom-right
                let x1; let x2; let y1; let y2;
                if( dir === 'bottomRight'){
                    x1= currentRndWrapperX;
                    y1= currentRndWrapperY;
                    x2= currentRndWrapperX+currentRndWrapperW+delta.width;
                    y2=currentRndWrapperY+currentRndWrapperH+delta.height;
                }else if(dir === 'bottomLeft' ){
                    x1= currentRndWrapperX;
                    y1= currentRndWrapperY;
                    x2= currentRndWrapperX+currentRndWrapperW+delta.width;
                    y2=currentRndWrapperY+currentRndWrapperH+delta.height;
                }else if(dir==='topLeft'){
                    x1= currentRndWrapperX;
                    y1= currentRndWrapperY;
                    x2= currentRndWrapperX+currentRndWrapperW+delta.width;
                    y2= currentRndWrapperY+currentRndWrapperH+delta.height;
                }else if(dir==='topRight'){
                    x1= currentRndWrapperX;
                    y1= currentRndWrapperY;
                    x2= currentRndWrapperX+currentRndWrapperW+delta.width;
                    y2= currentRndWrapperY+currentRndWrapperH+delta.height;
                }
                let r1={ x1: x1, y1: y1,
                    x2: x2, y2: y2};
                let r2={ x1: x, y1: y,
                        x2: x+width, y2: y+height};
                let newX=x; let newY=y; let newW=width; let newH=height;
                if(this.isOverlapping(r1,r2)){
                    console.log(configuration.uniqueID + ' OVERLAPIIIIING');
                    //if(r1.x2 > r2.x1 && r1.y2 > r2.y1){ // left to right - top
                    if(dir==='bottomRight'){
                        if(r1.x1!==r2.x1){
                            newX = x+(r1.x2-r2.x1);
                            //newW = width-(r1.x2-r2.x1);
                            newW=r2.x2-newX;
                            if(r1.y1!==r2.y1){ 
                                newY=y+(r1.y2-r2.y1);
                                newH=height-(r1.y2-r2.y1);
                            }else{
                                newH=r1.y2-r1.y1;
                            }
                        }else{
                            newW = width+(r1.x2-r2.x2);
                            newY=r1.y2;
                            newH= height-(r1.y2-r2.y1);
                        }
                    }else if(dir==='bottomLeft'){
                        if(Math.round(r2.x2) < Math.round(r1.x2) && r2.x1 < r1.x1){ //sx
                            newW = width-(r2.x2-r1.x1);
                            if(r2.y1 === r1.y1){
                                newH=height+(r1.y2-r2.y2);
                            }else{
                                newY=r1.y2;
                                newH=height-(r1.y2-r2.y1);
                            }
                        }else{
                            //newX=x-(r2.x1-r1.x1);
                            newX=r1.x1;
                            //newW = width+(r2.x1-r1.x1);
                            //newW=r1.x2-r1.x1;
                            newW=currentRndWrapperW+delta.width;
                            newY=r1.y2;
                            //newH=height-(r1.y2-r1.y1);
                            newH=r2.y2-newY;
                        }
                    }else if(dir==='topLeft'){
                        if(r2.x2 < r1.x2 && r1.x1 > r2.x1){
                            newW = width-(r2.x2-r1.x1);
                            if(r2.y1 < r1.y1 && r2.y2 >= r1.y1){
                                newH=height-(r2.y2-r1.y1);
                            }else{
                                newY=r1.y1;
                                newH=height+(r2.y1-r1.y1);
                            }
                        }else{
                            newX=x-(r2.x1-r1.x1);
                            newW = width+(r2.x1-r1.x1);
                            newH=r1.y1;
                        }
                    }else if(dir==='topRight'){
                        if(r1.x1!==r2.x1){
                            newX = x+(r1.x2-r2.x1);
                            newW = width-(r1.x2-r2.x1);
                            if(r2.y2 < r1.y2){
                                newH= height-(r2.y2-r1.y1);
                            }else{
                                newY=r1.y1;
                                newH=r1.y2-r1.y1;
                            }
                        }else{
                            newW = width+(r1.x2-r2.x2);
                            newH= height-(r2.y2-r1.y1); 
                        }
                    }
                    
                }
                this.updatePosition({
                    x: newX,
                    y: newY
                });
                this.updateSize({
                    width: newW,
                    height: newH
                });
            }
        }

        if(cb){
            cb(event, dir, refToElement, delta, position);
        }
        
    }

    isOverlapping = (r1, r2) =>{
        if(r1.x1 > r2.x2 || r1.x2 < r2.x1){ // no horizontal overlapping
            return false;
        }
        if(r1.y1 > r2.y2 || r1.y2 < r2.y1){ // no vertical overlapping
            return false;
        }
        return true;
    }

    isOverlappingY = (r1, r2) =>{
        if( (r1.y2 > r2.y1 ) || (r1.y1 < r2.y2)){
            return true;
        }
        return false;
    }
    isOverlappingX = (r1, r2) =>{
        if( (r1.x2 > r2.x1 ) || (r1.x1 < r2.x2)){
            return true;
        }
        return false;
    }
    
    updatePosition(position) {
        //const {rndRefs, rndRefKey} = this.state;
        //rndRefs[rndRefKey].updatePosition(position);
        this.setState(position);
    }

    updateSize(size) {
        //const {rndRefs, rndRefKey} = this.state;
        //rndRefs[rndRefKey].updateSize(size);
        this.setState(size);
    }

    render(){
        const {rndRefs, uniqueID, width, height, x, y } = this.state;
        const {configuration } = this.props;
        return(
            <Rnd
                id={uniqueID}
                ref={c => { rndRefs[uniqueID] = c; }}
                size={{
                    width: width,
                    height: height
                }}
                position={{
                    x: x,
                    y: y   
                }}
                onResizeStop={(e, direction, ref, delta, position) => {
                    const {width, height} = this.state;
                    if(delta.height < 0 || delta.width <0){ // no reducing operation allow
                        return;
                    }
                    this.setState({
                        x: position.x,
                        y: position.y,
                        width: width+delta.width,
                        height: height+delta.height
                    })
                }}
                enableResizing={configuration.enableResizing}
                resizeHandleClasses={configuration.resizeHandleClasses}
                disableDragging={configuration.disableDragging}
                bounds={configuration.bounds}
                onResize={this.handleResizeCallBack}
            >
            {this.props.children} 
            </Rnd>
        )
    }

}


/*export function DashboardRndWrapper(props){

    let configuration = props.configuration;

    const [x, setX] = useState(configuration.x);
    const [y, setY] = useState(configuration.y);
    const [width, setWidth] = useState(configuration.width);
    const [height, setHeight] = useState(configuration.height);

    const updatePosition = (position) => {
        setX(position.x);
        setY(position.y);
    }

    const updateSize = (size) => {
        setWidth(size.width);
        setHeight(size.height);
    }

    const handleResizeCallBack = (event, dir, refToElement, delta, position) => {
        let cb = configuration.onResize;
        if(cb){
            cb(event, dir, refToElement, delta, position);
        }
    }

    return(
        <Rnd
            id={configuration.uniqueID}
            ref={c => { configuration.rndRefs[configuration.uniqueID] = c; }}
            size={{
                width: width,
                height: height
            }}
            position={{
                x: x,
                y: y   
            }}
            onResizeStop={(e, direction, ref, delta, position) => {
                setX(position.x);
                setY(position.y);
                setWidth(width+delta.width);
                setHeight(height+delta.height);
            }}
            enableResizing={configuration.enableResizing}
            resizeHandleClasses={configuration.resizeHandleClasses}
            disableDragging={configuration.disableDragging}
            bounds={configuration.bounds}
            onResize={handleResizeCallBack}
        >
        {props.children} 
        </Rnd>
    )
}*/