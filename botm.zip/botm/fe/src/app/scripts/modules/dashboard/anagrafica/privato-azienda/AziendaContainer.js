import React from "react";
import { Container, Row, Col } from "react-bootstrap";

function AziendaContainer(props){


    return(
        <Container fluid={true}>
            <Row>
                <Col>

                </Col>
                <Col>

                </Col>
                <Col>
                    
                </Col>
            </Row>
        </Container>
    );
}

export default AziendaContainer;