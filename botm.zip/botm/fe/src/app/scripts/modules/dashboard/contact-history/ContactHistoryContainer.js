import React from "react";
import { Container, Row, Col } from "react-bootstrap";
import DashboardSectionTitle from "../common/DashboardSectionTitle";

function ContactHistoryContainer(){

    const titleConfiguration = {
        mainTitle: 'Contact History',
        id:'contactHistoryTitleContainer'
    }

    return(
        <Container fluid={true} className='contact-history-container barra-dashboard-section-container'>
            <Row>
                <DashboardSectionTitle configuration={titleConfiguration} />
            </Row>

        </Container>
    );
}

export default ContactHistoryContainer;