import React from "react"
import {useSelector} from "react-redux";

function DashboardMainWidgetWrapper(props){

    const dashboardWidgets = useSelector(state => state.dashboardWidgetsReducer.dashboardMainWidgets ) ;

    function needToShow(){
        let uniqueID = props.uniqueID;
        let needToShow;
        for (let i = 0; i < dashboardWidgets.length; i++) {
            if(dashboardWidgets[i].uniqueID === uniqueID && dashboardWidgets[i].showWidget){
                needToShow = true;
                break;
            }else{
                needToShow = false;
            }
        }
        return needToShow
    }
    return(
        <div id={props.uniqueID} className={'' + ((needToShow())?'':' hide')}>
            {props.children}
        </div>
    )
    

}

export default DashboardMainWidgetWrapper;

