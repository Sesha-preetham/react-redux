import React from 'react'

export function PrivatoAziendaSelector(props){

    let configuration = props.configuration;

    const baseBtnClass ="btn bt-btn btn-clientType";
    const handlePrivato = configuration.handlePrivato;
    const handleAzienda = configuration.handleAzienda;
    const privatoAzienda = configuration.privatoAzienda;

    return(
        <div id="privatoAziendaSelectorContainer">
            <button type="button" className={(privatoAzienda ==='PRIVATO')?baseBtnClass+" btn-clientTypeSelected":baseBtnClass} onClick={handlePrivato} > Privato </button>
            <button type="button" className={(privatoAzienda ==='AZIENDA')?baseBtnClass+" btn-clientTypeSelected":baseBtnClass} onClick={handleAzienda} > Azienda </button>
        </div>
    );
}

