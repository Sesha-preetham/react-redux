import React from "react";
import { Container, Row, Col} from "react-bootstrap";
import DashboardChildWidgetButton from "./DashboardChildWidgetButton";

function DashboardSectionTitle( props ){
    let configuration = props.configuration;
    let id= (configuration && configuration.id) ? configuration.id:'';
    return(
        <Container fluid={true} className='dashboard-section-title-container' id={id}>
            <Row>
                <Col xs={4} sm={4} md={4} className="dashboard-section-left"> 
                    {(configuration.leftChild)?configuration.leftChild:null}
                </Col>
                <Col xs={4} sm={4} md={4} className="dashboard-section-title"> 
                    <span className="dashboard-section-title">{(configuration.mainTitle)?configuration.mainTitle:''}</span>
                </Col>
                <Col xs={3} sm={3} md={3} className="dashboard-section-right"> 
                    {(configuration.rigthChild)?configuration.rigthChild:null}
                </Col>
                <Col xs={1} sm={1} md={1} className="dashboard-section-right no-padding"> 
                    <DashboardChildWidgetButton />
                </Col>
            </Row>
        </Container>
    );

}

export default DashboardSectionTitle;