import React from "react";
import { Container, Row, Col} from "react-bootstrap";
import DashboardSectionTitle from "../common/DashboardSectionTitle";

function ConsuntivazioneContainer(){

    const titleConfiguration = {
        mainTitle: 'Motivo del contatto',
        id:'consuntivazioneTitleContainer'
    }
    return(
        <Container fluid={true} className='consuntivazione-container barra-dashboard-section-container'>
             <Row>
                <DashboardSectionTitle configuration={titleConfiguration} />
             </Row>
             <Container>
             <Row>
                 <Col><span>Select tag:</span></Col> 
                 <Col><select id="pet-select">
                        <option value="">--Please choose an option--</option>
                        <option value="dog">Dog</option>
                        <option value="cat">Cat</option>
                        <option value="hamster">Hamster</option>
                        <option value="parrot">Parrot</option>
                        <option value="spider">Spider</option>
                        <option value="goldfish">Goldfish</option>
                    </select></Col>
             </Row>
             <Row>
                 <Col><span>Interaction tags:</span></Col> 
                 <Col><input></input></Col>
             </Row>
             <Row>
                 <Col><span>Da Ricontattare: </span><input type="radio" /></Col> 
             </Row>
             </Container>
        </Container>
    );
}

export default ConsuntivazioneContainer;