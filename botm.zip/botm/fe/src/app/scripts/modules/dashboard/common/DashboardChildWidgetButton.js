import React from "react";
import { Container, Row, Col} from "react-bootstrap";

function DashboardChildWidgetButton( props ){
   
    return(
        <button>+</button>
    );

}

export default DashboardChildWidgetButton;