import React, {useState, useEffect} from "react";
import { Container, Row, Col } from "react-bootstrap";
import FormHandler from "../../../common/form/FormHandler";
import TextSelectField from "../../../common/form/TextSelectField";
import SelectField from "../../../common/form/SelectField";
import { useSelector } from "react-redux";
import { getAnagraficaSearchType, 
    anagraficaGetClientDataBySearchType,
    anagraficaGetCarte
} from "../../../../service/dashboard/anagrafica/AnagraficaServerService";


function ClientSearchBox(props){

    const [internalObject, setInternalObject ] = useState((props.configuration)?props.configuration:{});

    const [ form, setForm] = useState((props.configuration.form)?props.configuration.form:new FormHandler());

    const visibleBanks = useSelector( state => state.initReducer.visibleBanks);

    useEffect( () => {
        if(visibleBanks){
            form.getField('clientSeachBankField').theField.reloadOptions(remapBanksValuesForSelect(visibleBanks));
            /*loadSearchTypes({
                abicode: visibleBanks[0].abicode
            });*/
        }
    }, [visibleBanks]);

   useEffect( () => {
        loadSearchTypes();
    }, []);

    async function loadSearchTypes () {
        getAnagraficaSearchType().then(response =>{
            form.getField('clientSeachTextSelectField').theField.reloadOptions(remapSearchTypeValuesForSelect(response));
        });      
    }

    

    const clientSearchTextSelectFieldConfig={
        uniqueID: 'clientSeachTextSelectField',
        form: form,
        defaultOptionId: null,
        textTypeOnSelectedOption: true,
        isVisible: true,
        isReadOnly: false,
        isDisabled: false,
        options: [],
        onKeyEnter: handleSubmit
    };

    /*
     {
                id: '0',
                description: "IdSoggetto",
                type: 'number',
                class: ''
            },
            {
                id: '1',
                description: "CodiceCliente",
                type: 'number',
                class: ''
            }
    */

    const clientSearchBankFieldConfig={
        uniqueID: 'clientSeachBankField',
        form: form,
        readonly: false,
        visible: true,
        searchEnabled: false,
        width:"100%",
        additionalClasses: 'show-tick',
        options: [],
        setValue: handleChangeBank
    }

    function handleChangeBank(currentOptionObj){
        console.log(currentOptionObj);
        if(currentOptionObj && currentOptionObj.currentValue){
            let abiCode = currentOptionObj.currentValue.split('||')[1];
            /*loadSearchTypes({
                abicode: abiCode
            });*/
        }
    }

    function remapBanksValuesForSelect(values){
        let res = [];
        values.map(el => {
            res.push({
                id: ''+el.id + '||' + el.abicode,
                description: el.bankCode,
                class:''
            })
        });
        return res;
    }

    function remapSearchTypeValuesForSelect(values){
        let res = [];
        values.map(el => {
            res.push({
                id: ''+el.id+'||'+el.code,
                description: el.description,
                class:'',
                type: el.type,
                isDefault: el.isDefault?el.isDefault:false
            })
        });
        return res;
    }

    function handleSubmit(event ){
        let value = form.getField('clientSeachTextSelectField').theField.getValue();
        let abiCode = form.getField('clientSeachBankField').theField.getValue();
        abiCode = (abiCode)?abiCode.split('||')[1]:undefined;
        let typeCode = (value.selectValue && value.selectValue.id)?value.selectValue.id.split('||')[1]:undefined;
        let request = {
            type: typeCode,
            value: value.textValue,
            abicode: abiCode
        };
        let responseData = getClientData(request);

    }

    async function getClientData(request){
        let response;
        response = await anagraficaGetClientDataBySearchType(request);
        let abiCode = request.abicode;
        if(response && response[0].idSoggetto){
            let carteRequest = {
                idSoggetto: response[0].idSoggetto,
                abicode: abiCode
            };
            anagraficaGetCarte(carteRequest);
        }
        return response;
    }

    return(
        <Container fluid={true} className=" client-search-box-container">
            <Row>
            <Col xs={8} sm={8} md={8} className={'no-padding'}>
                <TextSelectField configuration={clientSearchTextSelectFieldConfig}/>
            </Col>
            <Col xs={4} sm={4} md={4} className={'no-padding'}>
                <SelectField configuration={clientSearchBankFieldConfig} />
            </Col>
            </Row>
        </Container>
    );
}
/*

<Row>
    <Col xs={10} sm={10} md={10} className="no-right-padding">
        <TextField configuration={clientSearchTextFieldConfig}/>
    </Col>
    <Col xs={2} sm={2} md={2} className="no-padding">
        <SelectField configuration={clientSearchTypeFieldCondig} />
    </Col>
</Row>

*/

export default ClientSearchBox;