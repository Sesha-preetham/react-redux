import React, {useState } from "react";
import { Container, Row, Col } from "react-bootstrap";
import FormHandler from "../../../common/form/FormHandler";
import WidgetWrapper from "../../../common/widgets/WidgetWrapper";
import AnagraficaBaseWidget from "../widgets/AnagraficaBaseWidget";
import CarteWidget from "../widgets/CarteWidget";

function PrivatoContainer(props){

    const [internalObject, setInternalObject ] = useState({
        form: new FormHandler()
    });
    const anagraficaBaseWidgetConfiguration = {
        uniqueID: "anagraficaPrivatoBaseWidget",
        form: internalObject.form
    };
    const carteWidgetConfiguration = {
        uniqueID: "carteAnagraficaWidget",
        form: internalObject.form
    };

    return(
        <Container fluid={true}>
            <Row>
                <WidgetWrapper configuration={{
                    uniqueID: "anagraficaPrivatoBaseWidget"
                }}>
                    { (widgetConfig) => (
                        <AnagraficaBaseWidget 
                            configuration={anagraficaBaseWidgetConfiguration} 
                            widgetConfig={widgetConfig } />
                    )}
                </WidgetWrapper>
            </Row>
            <Row>
                <Col xs={6} mg={6} lg={6} >
                    <WidgetWrapper configuration={{
                        uniqueID: "carteAnagraficaWidget"
                    }}>
                        { (widgetConfig) => (
                            <CarteWidget 
                                configuration={carteWidgetConfiguration}
                                widgetConfig={widgetConfig}
                            />
                        )}
                    </WidgetWrapper>
                </Col>
            </Row>
        </Container>
    );
}

export default PrivatoContainer;