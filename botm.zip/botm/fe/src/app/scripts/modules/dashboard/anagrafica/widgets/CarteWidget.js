
import React, {useEffect, useState} from "react";
import { Container, Row, Table } from "react-bootstrap";
import WidgetWrapper from "../../../common/widgets/WidgetWrapper";
import FormHandler from "../../../common/form/FormHandler";
import { useSelector } from "react-redux";

function CarteWidget(props){

    const widgetConfig = props.widgetConfig;
    const[ form, setForm] = useState(new FormHandler());

    const [internalObject] = useState({
        uniqueID: props.configuration.uniqueID,
        form: form
    });

    const carteAnagraficaState = useSelector( state => state.anagraficaReducer.carteWidget.carteWidgetData);

    useEffect(()=> {
        console.log(carteAnagraficaState);
    });

    const carteWidgetConfiguration = {
        uniqueID: props.configuration.uniqueID
    };

    function renderCarteTable(){
        if(carteAnagraficaState ){
            return(
                carteAnagraficaState.map(el=>{
                    return (<tr>
                        <td>{el.carta}</td>
                        <td>{el.type}</td>
                    </tr>)
                })
            );
        }
        return <tr></tr>
    }

    return(
        <Container fluid={true}>
            <Row>
                <table class="table">
                    <thead> 
                        <tr>
                            <th scope="col">Carte</th>
                        </tr>
                    </thead>
                    <tbody>
                        {renderCarteTable()}
                    </tbody>
                </table>
            </Row>
        </Container>
    );


}

export default CarteWidget;