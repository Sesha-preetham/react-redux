import React, {useState, useEffect} from "react";
import {Container, Row, Col} from "react-bootstrap";
import { Rnd } from "react-rnd";
import { DashboardRndWrapper } from "./common/DashboardRndWrapper";
import AnagraficaContainer from "./anagrafica/AnagraficaContainer";
import ConsuntivazioneContainer from "./consuntivazione/ConsuntivazioneContainer";
import ConversationContainer from "./conversation/ConversationContainer";
import ContactHistoryContainer from "./contact-history/ContactHistoryContainer";


function DashBoardContainer(){

    const [ totWidth, setTotWidth] = useState($("#dashboardParentContainer").innerWidth());
    //const [ totWidth, setTotWidth] = useState($("#dashboardParentContainer").width());
    
    //const [ totHeight, setTotHeight] = useState((Math.max($(document).height(), $(window).height()))-50);
    const [ totHeight, setTotHeight] = useState($("#app_container").innerHeight());
    const [ parentWidth, setParentWidth] = useState($("#dashboardParentContainer").innerWidth());
    const [ parentHeight, setParentHeight] = useState($("#app_container").innerHeight()-$("#interactionBarParentContainer").innerHeight());

    let dashBoardRnds = {};
    let dashBoardRndWrappers = {};

    let anagraficaRndConfiguration={
        uniqueID:'anagraficaRnd',
        rndRefs: dashBoardRnds,
        rndWrapperRefs: dashBoardRndWrappers,
        size:{
            width: ($("#dashboardParentContainer").innerWidth())?($("#dashboardParentContainer").innerWidth())/2:'50%',
            height: (totHeight)?(totHeight)/2:350
        },
        position:{
            x: 0,
            y: 0  
        },
        resizeHandleClasses:{
            bottomRight:' dashboard-resize-icon dashboard-resize-bottom-right'
        },
        enableResizing:{
            bottomRight: true
        },
        disableDragging:true,
        bounds : '#dashboardParentContainer',
        parentContainer: '#dashboardParentContainer',
        onResize: handleResizeCallBack
    }

    let consuntivazioneRndConfiguration={
        rndRefs: dashBoardRnds,
        uniqueID: 'consuntivazioneRnd',
        rndWrapperRefs: dashBoardRndWrappers,
        size:{
            width: (totWidth)?(totWidth)/2:'50%',
            height: (totHeight)?(totHeight)/2:350
        },
        position:{
            x: ($("#dashboardParentContainer").innerWidth())?($("#dashboardParentContainer").innerWidth())/2:0,
            y: 0  
        },
        resizeHandleClasses:{
            bottomLeft:' dashboard-resize-icon dashboard-resize-bottom-left'
        },
        enableResizing:{
            bottomLeft: true
        },
        disableDragging: true,
        bounds: '#dashboardParentContainer',
        parentContainer: '#dashboardParentContainer',
        onResize: handleResizeCallBack
    };

    let conversationRndConfiguration={
        rndRefs: dashBoardRnds,
        uniqueID: 'conversationRnd',
        rndWrapperRefs: dashBoardRndWrappers,
        size:{
            width: (totWidth)?(totWidth)/2:'50%',
            height: (totHeight)?(totHeight)/2:350
        },
        position:{
            x: 0,
            y: (totHeight)?(totHeight)/2:0
        },
        resizeHandleClasses:{
            topRight:' dashboard-resize-icon dashboard-resize-top-right'
        },
        enableResizing:{
            topRight: true
        },
        disableDragging:true,
        bounds: '#dashboardParentContainer',
        parentContainer: '#dashboardParentContainer',
        onResize: handleResizeCallBack
    };

    let contactHistoryRndConfiguration = {
        rndRefs: dashBoardRnds,
        uniqueID: 'contactHistoryRnd',
        rndWrapperRefs: dashBoardRndWrappers,
        size:{
            width: (totWidth)?(totWidth)/2:'50%',
            height: (totHeight)?(totHeight)/2:350
        },
        position:{
            x: (totWidth)?(totWidth)/2:0,
            y: (totHeight)?(totHeight)/2:0
        },
        resizeHandleClasses:{
            topLeft:' dashboard-resize-icon dashboard-resize-top-left'
        },
        enableResizing:{
            topLeft: true
        },
        resizeHandleClasses:{
            topLeft:' dashboard-resize-icon dashboard-resize-top-left'
        },
        disableDragging:true,
        bounds: '#dashboardParentContainer',
        parentContainer: '#dashboardParentContainer',
        onResize: handleResizeCallBack
    }


    useEffect(() => {
        // Handler to call on window resize
        function handleResize() {
          updatePosition();
        }
        handleResize();
        // Add event listener
        window.addEventListener("resize", handleResize);
        
        // Remove event listener on cleanup
        return () => window.removeEventListener("resize", handleResize);
      }, []); // Empty array ensures that effect is only run on mount
    

    function updatePosition() {
        setTotWidth($("#dashboardParentContainer").innerWidth());
        $('#dashboardParentContainer').height($("#app_container").innerHeight()-$("#interactionBarParentContainer").innerHeight());
        setTotHeight($('#dashboardParentContainer').height());
        let parentWidth = $("#dashboardParentContainer").innerWidth();
        let parentHeight = $("#app_container").innerHeight()-$("#interactionBarParentContainer").innerHeight();
        setParentHeight(parentHeight);
        setParentWidth(parentWidth);
        if(parentHeight && parentHeight !== 0 && dashBoardRndWrappers){
            if(parentWidth && parentWidth !== 0 ){
                dashBoardRndWrappers.consuntivazioneRnd.updatePosition({ x: (parentWidth/2) , y:0});
                dashBoardRndWrappers.contactHistoryRnd.updatePosition({ x: (parentWidth/2), y: (parentHeight)/2});
            }
            dashBoardRndWrappers.anagraficaRnd.updatePosition({ x: 0, y:0 });
            dashBoardRndWrappers.conversationRnd.updatePosition({ x: 0, y: (parentHeight)/2 });
            for(const rdn in dashBoardRndWrappers){
                if(dashBoardRndWrappers[rdn]){
                    dashBoardRndWrappers[rdn].updateSize({
                        width:  (parentWidth)/2,
                        height: ((parentHeight)/2)
                    });
                }
            }
        }
    }


    function handleResizeCallBack(event, dir, refToElement, delta, position){
        let totH=$('#conversationContainer').innerHeight();
        console.log('#app_container: ' +totH);
        console.log('#conversationTitleContainer: ' + $("#conversationTitleContainer").innerHeight());
        $('#purecloud-interaction').height(totH-$("#conversationTitleContainer").innerHeight());
    }


    return(
        <Container fluid={true} className="dashboard-container" id="dashboardContainer">
            <div id={window.BTDictionary["spinner.dashboard"]} />
            <DashboardRndWrapper 
                ref={c => { dashBoardRndWrappers[anagraficaRndConfiguration.uniqueID] = c; }}
                configuration={anagraficaRndConfiguration} >
                <AnagraficaContainer />
            </DashboardRndWrapper>
            <DashboardRndWrapper 
                ref={c => { dashBoardRndWrappers[consuntivazioneRndConfiguration.uniqueID] = c; }}
                configuration={consuntivazioneRndConfiguration} >
                <ConsuntivazioneContainer />
            </DashboardRndWrapper>
            <DashboardRndWrapper 
                ref={c => { dashBoardRndWrappers[conversationRndConfiguration.uniqueID] = c; }}
                configuration={conversationRndConfiguration} >
                <ConversationContainer/>
            </DashboardRndWrapper>
            <DashboardRndWrapper
              ref={c => { dashBoardRndWrappers[contactHistoryRndConfiguration.uniqueID] = c; }}
              configuration={contactHistoryRndConfiguration} >
                <ContactHistoryContainer/>
            </DashboardRndWrapper>
        </Container>
    );
}
export default DashBoardContainer;