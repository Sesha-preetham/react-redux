import React from "react";
import { Container, Row, Col } from "react-bootstrap";
import PrivatoContainer from "./PrivatoContainer";
import AziendaContainer from "./AziendaContainer";

function PrivatoAziendaDispatcher(props){

        if(props.privatoAzienda === 'PRIVATO'){
            return(
                <Container fluid={true}>
                    <PrivatoContainer />
                </Container>
            );
        }else if(props.privatoAzienda === 'AZIENDA'){
            return(
                <Container fluid={true}>
                    <AziendaContainer />
                </Container>
            );
        }else{
            return(
                <div>
                    No widgets defined...
                </div>
            );
        }
    
}

export default PrivatoAziendaDispatcher;