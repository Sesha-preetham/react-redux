import React, {useState} from "react";
import { Container, Col, Row, Image, Accordion, Button, useAccordionToggle } from "react-bootstrap";
import { useSelector } from "react-redux";

import {ArrowDown, ArrowUp} from 'react-bootstrap-icons';

function UserInfoBox(){
    const userInfoMe = useSelector(state => state.userInfoReducer.userMe);

    const [activeKey, setActiveKey] = useState('0')


    function getName(){
        return (userInfoMe && userInfoMe.name)?userInfoMe.name:''
    }

    function getCode(){
        return ( userInfoMe && userInfoMe.employerInfo)?userInfoMe.employerInfo.employeeId:'';
    }

    return (
        <Container id="userinfobox-container" fluid={true}>
            <Accordion activeKey={activeKey}>
                <Row>
                    <div id="userinfobox-btn-container">
                        <ArrowToggleButton props={
                            {
                                onSelect: () => {
                                    let key = (activeKey=='0')?'1':'0';
                                    if(key=='1'){
                                        $('.barra-softphone-container').hide();
                                    }else{
                                        $('.barra-softphone-container').show();
                                    }
                                    setActiveKey(key);

                                }
                        }} />
                    </div>
                </Row>
                <Row>
                    <Accordion.Collapse eventKey="1">
                        <Container fluid={true} id="userinfobox-data-container">
                            <Row>
                                <div className="profile-label-title">Nome e Cognome</div>
                                <div className="profile-label"> {getName()}</div>
                            </Row>
                            <Row>
                                <div className="profile-label-title">Codice</div>
                                <div className="profile-label"> {getCode()}</div>
                            </Row>
                        </Container>
                    </Accordion.Collapse>
                </Row>
            </Accordion>
        </Container>
    );
}


function ArrowToggleButton(properties){

    const [position, setPosition] = useState('down');

    function handleSelect(){
        let pos = (position==='down')?'up':'down';
        setPosition(pos);
        let p = properties.props;
        let onSel = p.onSelect;
        onSel();
    }

    return(
            <button type="button" className="btn btn-default barra-arrow-button" onClick={handleSelect} >
                { (position === 'down')?
                    <ArrowDown />: <ArrowUp />
                }
            </button>
    )
}

export default UserInfoBox;