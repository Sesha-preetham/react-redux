import React, {useState} from "react";
import { Container, Col, Row } from "react-bootstrap";
import { useSelector } from "react-redux";

/*
  <i id="barra-profile-presence" className="barra-profile-presence">
            </i>
*/
function UserInfoPresence(){

    const userState = useSelector(state => state.userInfoReducer.userStatus);
    let presenceStates = {
        "AVAILABLE": "barra-profile-available",
        "AWAY": "barra-profile-await",
        "BUSY": "barra-profile-busy",
        "ON_QUEUE": "barra-profile-onqueue"
    };

    function UserPresence(){
        return(
            <div id="barra-profile-image" className={'barra-profile-image ' + renderClassBasedOnStatus()} />
        )
    }

    function renderClassBasedOnStatus(){
        console.log(userState);
        let cls = presenceStates[userState.status];
        return (cls)?cls:'';
    }

    return (
        <Container id="userinfopresence-container" fluid={true}>
            <Row>
                <Col id="barra-profile-container">
                    <UserPresence />
                    
                </Col>
            </Row>
        </Container>
    );
}

export default UserInfoPresence;