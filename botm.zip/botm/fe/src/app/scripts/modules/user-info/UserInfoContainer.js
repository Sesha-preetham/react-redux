import React, { useEffect } from "react";
import { Container, Col, Row } from "react-bootstrap";
import UserInfoBox from "./UserInfoBox.js";
import UserInfoPresence from "./UserInfoPresence.js";
import { pcEmbeddableFrameworkUrl } from "../../client/Client";

function UserInfoContainer(){

    useEffect(() => {
        function handleResize() {
            getSoftPhoneH();
        }
        //call function after load
        handleResize();
        // Add event listener
        window.addEventListener("resize", handleResize);
        // Remove event listener on cleanup
        return () => window.removeEventListener("resize", handleResize);
    }, []);

    return(
        <Container id="userInfoContainer" className={"user-info-container full-height"} fluid={true}>
            <UserInfoPresence />
            <Container id="userContainer" fluid={true}>
                <Row>
                    <UserInfoBox />
                </Row>
                <Row className='h90perc'>
                        <div className="softphone barra-softphone-container" >
                            <iframe id="softphone" allow="camera *; microphone *" src={ pcEmbeddableFrameworkUrl } ></iframe>
                        </div>
                </Row>
            </Container>
        </Container>
    );
}

 function getSoftPhoneH(){     
     let totH=$(window).height();
     console.log('totH: ' +totH);
     console.log('#userinfopresence-container: ' + $("#userinfopresence-container").height());
     console.log('#userinfobox-container: ' + $('#userinfobox-container').height());
     //$('#softphone').height(totH-$("#userinfopresence-container").height()-$('#userinfobox-container').height()-15); //-15 di top userContainer
 }

export default UserInfoContainer;