var webpack = require("webpack");
var path = require("path");

const { CleanWebpackPlugin } = require("clean-webpack-plugin");

var WebpackProviderPlugin = new webpack.ProvidePlugin({
  jQuery: "jquery",
  $: "jquery",
  "window.jQuery": "jquery"
});

//plugins: [ new CleanWebpackPlugin(),WebpackProviderPlugin], 

module.exports = {
  entry: __dirname + "/app/index.js",
  plugins: [ WebpackProviderPlugin],
  module: {
    rules: [
      {
        test: /\.js$/,
        exclude: /node-modules/,
        use: {
          loader: "babel-loader"
        },
      },
    ],
  },
  resolve: {
    extensions: [".js", ".jsx"],
    modules: ["node_modules/", path.resolve(__dirname, "./app/")],
    alias: {
      bootstrap: path.resolve(
        __dirname,
        "./app/scripts/libs/bootstrap/js/bootstrap.min"
      ),
      moment: path.resolve(
        __dirname, 
        "./app/scripts/libs/moment"
      ),
      "bootstrap-select": path.resolve(
        __dirname,
        "./app/scripts/libs/bootstrap-select.js"
      )
    }
  },
  externals: {
    'platformClient': 'commonjs2 platformClient',
  }
};
