var webpack = require("webpack");
var path = require("path");
const { merge } = require("webpack-merge");
const common = require("./webpack.common.js");

const UglifyJsPlugin = require("uglifyjs-webpack-plugin");
const MiniCssExtractPlugin = require('mini-css-extract-plugin');
const OptimizeCSSAssetsPlugin = require("optimize-css-assets-webpack-plugin");


module.exports = merge(common, {
    mode: "production",
    output: {
        filename: 'scripts/bundle.js',
        path: path.resolve("../../barratelefonicafe-web/src/main/webapp/dist")
    },
    optimization: {
      splitChunks: {
        chunks: "all",
        cacheGroups: {
          vendors: {
            filename: "scripts/vendor.js",
          },
        },
      },
      minimizer: [
        /*new UglifyJsPlugin({
          uglifyOptions: {
            warnings: false,
            output: {
              comments: false, // remove comments
            },
            compress: {
              drop_console: true,
              drop_debugger: true,
            },
          },
          parallel: true,
          cache: false,
          extractComments: false,
          sourceMap: false,
        }),*/
        new MiniCssExtractPlugin({
          filename: 'styles/style.css'
        }),
        new OptimizeCSSAssetsPlugin(),
      ],
    },
    module: {
      rules: [
        {
          test: /\.(png|jp(e*)g|svg|gif|woff|woff2|eot|ttf)$/,
          use: [
            {
              loader: "url-loader",
              options: {
                limit: 1000, // 1000 kb
                outputPath: "assets/btelimages/bundle",
                publicPath: "../assets/btelimages/bundle",
                name: "[hash].[ext]",
              },
            },
          ],
        },
        {
          test: /\.(css|styl)$/,
          use: [MiniCssExtractPlugin.loader, "css-loader", "stylus-loader"]
        }
      ]
    }
  });