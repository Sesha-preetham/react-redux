import "core-js/stable";

import React from "react";
import ReactDOM from "react-dom";

import "./css/bse/style.sass";
import "./css/bpa/bpa-style.sass";
import App from "./scripts/App";

ReactDOM.render(<App />, document.getElementById("barra-app-container"));
