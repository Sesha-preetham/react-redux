import { toast } from "react-toastify";
import { beServiceUrls } from "../Client/ClientProperties";
import { globalAlertId } from "../CommonComponents/AlertToast/AlertIdConstants";
import {
  setBanks,
  setChannelsAndCallTypes,
  setCities,
  setNations,
  setSystemPresences,
  setOrganizationPresences,
  setGrantedCustomFunction,
} from "../Store/commonSlice";
import {
  addNotificationTopics,
  setNotificationChannel,
} from "../Store/purecloudNotificationSlice";
import { exposedDispatch, exposedGetState } from "../Store/store";
import HttpClient from "./HttpClient";

export const reduceToOptions = (options = []) => {
  return (optionValueProperty = "", optionLabelProperty = "") => {
    if (!optionValueProperty || !optionLabelProperty) return [];
    return options.reduce((previousValue, currentValue) => {
      if (
        !currentValue[optionValueProperty] ||
        !currentValue[optionLabelProperty]
      )
        return previousValue;
      previousValue.push({
        value: currentValue[optionValueProperty],
        label: currentValue[optionLabelProperty],
        rlData: {
          ...currentValue,
        },
      });
      return previousValue;
    }, []);
  };
};

export const getBankByCode = (banks = []) => {
  return (code = "") => {
    let i = banks.findIndex((el) => el.bankCode === code);
    if (i !== -1) {
      return { ...banks[i] };
    }
    return {};
  };
};

export const getDefaultBank = (banks = []) => {
  return () => {
    let i = banks.findIndex((el) => el.default === true);
    if (i !== -1) {
      return { ...banks[i] };
    }
    return {};
  };
};

export const getBTChannelOfInteraction = (interaction = {}) => {
  let channel;
  const { channels = {} } = exposedGetState().common;
  if (interaction.id) {
    // if id is not present it means it's not an interaction
    if (interaction.isEmail) {
      channel = channels.email || window.BTFEDictionary["email"];
    } else if (interaction.isChat) {
      channel = channels.chat || window.BTFEDictionary["chat"];
    } else if (interaction.isMessage) {
      channel = channels.messages || window.BTFEDictionary["messages"];
    } else {
      channel = channels.voice || window.BTFEDictionary["voice"];
    }
  }
  return channel || "";
};

export const copyTextToClipboard = (value = "") => {
  if (!value) return;
  navigator.clipboard.writeText(value).then(() => {
    toast.success("Copiato negli appunti!!", { containerId: globalAlertId });
  });
};

export const getBaseErrorMessage = (type = "", baseResponse = {}) => {
  const { errorCode = "", errorMessage = "" } = baseResponse;
  return type + ": " + errorCode + " - " + errorMessage;
};

export const httpGetVisibleBanks = async (
  request = {},
  updateStore = false
) => {
  let httpClient = new HttpClient();
  httpClient.setUrl(beServiceUrls().visiblebanks);
  const dispatch = exposedDispatch;
  let visibleBanks = await httpClient.httpGet(request).then((response) => {
    const { status = "", response: visibleBanksResponse = [] } = response;
    if (status === "OK") {
      if (updateStore) {
        dispatch(setBanks({ banks: visibleBanksResponse }));
      }
      return reduceToOptions(visibleBanksResponse)("bankCode", "desctiption");
    }
    return [];
  });
  return visibleBanks;
};

export const httpGetSystemPresences = async (request = {}) => {
  let httpClient = new HttpClient();
  httpClient.setUrl(beServiceUrls().systemPresences);
  const dispatch = exposedDispatch;
  let systemPresences = await httpClient.httpGet(request).then((response) => {
    const { status = "", response: systemPresences = [] } = response;
    if (status === "OK") {
      dispatch(setSystemPresences({ systemPresences: systemPresences }));
      return systemPresences;
    }
    return [];
  });
  return systemPresences;
};

export const httpGetOrganizationPresences = async (request = {}) => {
  let httpClient = new HttpClient();
  httpClient.setUrl(beServiceUrls().organizationPresences);
  const dispatch = exposedDispatch;
  let systemPresences = await httpClient.httpGet(request).then((response) => {
    const { status = "", response: presences = [] } = response;
    if (status === "OK") {
      dispatch(setOrganizationPresences({ presences: presences }));
      return systemPresences;
    }
    return [];
  });
  return systemPresences;
};

export const httpPostNotificationChannel = async () => {
  let httpClient = new HttpClient();
  httpClient.setUrl(beServiceUrls().notificationChannelCreate);
  const dispatch = exposedDispatch;
  await httpClient.httpPost().then((response) => {
    const { webSocketChannel = {}, status } = response;
    if (status === "OK") {
      dispatch(setNotificationChannel({ channel: webSocketChannel }));
    }
  });
};

export const httpPostNotificationSubscribe = async (
  request = {
    topics: [],
  }
) => {
  let httpClient = new HttpClient();
  httpClient.setUrl(beServiceUrls().notificationSubscribe);
  let currentTopics = exposedGetState().purecloudNotification.topics;
  let newTopics = request.topics.filter((value = {}) => 
    currentTopics.findIndex((el) => el.id === value.id) === -1
  );
  let finalRequest = {
    ...request,
    topics: newTopics,
  };
  const dispatch = exposedDispatch;
  await httpClient.httpPost(finalRequest).then((response) => {
    const { status } = response;
    if (status === "OK") {
      dispatch(
        addNotificationTopics({
          topics: newTopics,
        })
      );
    }
  });
};

export const httpGetMemberQueues = async (queryRequest={}) => {
  let httpClient = new HttpClient();
  httpClient.setUrl(beServiceUrls().getMemberQueues);
  const dispatch = exposedDispatch;
  let res = await httpClient.httpGet(queryRequest).then((r) => {
    const { response = [], status } = r;
    if (status === "OK") {
      return response;
    }
    return [];
  });
  return res;
};

export const httpGetChannelsAndCallTypes = async (
  request = {},
  updateStore = false
) => {
  let httpClient = new HttpClient();
  httpClient.setUrl(beServiceUrls().channelsandcalltypes);
  const dispatch = exposedDispatch;
  let channelsandcalltypes = await httpClient
    .httpGet(request)
    .then((response) => {
      const { status = "", response: channelsCallTypesResponse = {} } =
        response;
      if (status === "OK") {
        if (updateStore) {
          dispatch(
            setChannelsAndCallTypes({
              channelsCallTypes: channelsCallTypesResponse,
            })
          );
        }
        return channelsCallTypesResponse;
      }
      return {};
    });
  return channelsandcalltypes;
};

export const httpGetClientSearchType = async (request = {}) => {
  let httpClient = new HttpClient();
  httpClient.setUrl(beServiceUrls().clientsearchtype);
  let visibleBanks = await httpClient.httpGet(request).then((response) => {
    const { status = "", response: visibleBanksResponse = [] } = response;
    if (status === "OK") {
      return reduceToOptions(visibleBanksResponse)("code", "description");
    }
    return [];
  });
  return visibleBanks;
};

export const httpGetAgents = async (request = {}, reduceOptions = false) => {
  let httpClient = new HttpClient();
  httpClient.setUrl(beServiceUrls().getAgents);
  let agentList = await httpClient.httpGet(request).then((response) => {
    const { status = "", response: agentResponse = [] } = response;
    if (status === "OK") {
      return [...agentResponse];
    }
    return [];
  });
  if (reduceOptions === true) {
    return reduceToOptions(agentList)("userCode", "name"); //CCCLOUD-178
  }
  return agentList;
};

export const httpPostErrorLog = async (request) => {
  let httpError = new HttpClient();
  httpError.setUrl(beServiceUrls().errorLog);
  await httpError
    .httpPost(request)
    .then((response) => {
      const { status = "" } = response;
      if (status !== "OK") {
        toast.warn("Warning: errorLog Service", { containerId: globalAlertId });
      }
    })
    .catch((err) => {
      toast.error("Error: errorLog Service", { containerId: globalAlertId });
    });
};

export const httpGetCities = async () => {
  let httpClient = new HttpClient();
  httpClient.setUrl(beServiceUrls().cities);
  await httpClient
    .httpGet()
    .then((response) => {
      const { status = "", cities = [] } = response;
      if (status === "OK") {
        const dispatch = exposedDispatch;
        dispatch(setCities({ cities }));
      } else {
        toast.warn("Warning: httpGetCities Service", {
          containerId: globalAlertId,
        });
      }
    })
    .catch((err) => {
      toast.error("Error: httpGetCities Service", {
        containerId: globalAlertId,
      });
    });
};

export const httpGetNations = async () => {
  let httpClient = new HttpClient();
  httpClient.setUrl(beServiceUrls().nations);
  await httpClient
    .httpGet()
    .then((response) => {
      const { status = "", nations = [] } = response;
      if (status === "OK") {
        const dispatch = exposedDispatch;
        dispatch(setNations({ nations }));
      } else {
        toast.warn("Warning: httpGetNations Service", {
          containerId: globalAlertId,
        });
      }
    })
    .catch((err) => {
      toast.error("Error: httpGetNations Service", {
        containerId: globalAlertId,
      });
    });
};

export const ChangeAutoFocus = (interactionId) => {
  document.getElementById("softphone").contentWindow.postMessage(
    JSON.stringify({
      type: "updateInteractionState",
      data: {
        action: "pickup",
        id: interactionId,
      },
    }),
    "*"
  );
};

export const httpGetCustomFunctionGranted = async () => {
  let httpClient = new HttpClient();
  httpClient.setUrl(beServiceUrls().customFunctionUserGranted);
  let res = await httpClient
    .httpGet()
    .then((response) => {
      const { status, grantsList = [] } = response;
      if (status === "OK") {
        const dispatch = exposedDispatch;
        dispatch(setGrantedCustomFunction({ grantsList }));
        res = grantsList || [];
      } else {
        toast.warn(
          getBaseErrorMessage(
            "Warning - Unable to load function granted",
            response
          ),
          {
            containerId: globalAlertId,
          }
        );
        res = [];
      }
      return res;
    })
    .catch((err) => {
      toast.error(
        getBaseErrorMessage("Error - Unable to load function granted", err),
        {
          containerId: globalAlertId,
        }
      );
      res = [];
    });
  return res;
};

export const isCustomFunctionAvailable = (customFunctionCode) => {
  if (!customFunctionCode) {
    return false;
  }
  const { grantedCustomFunction = [] } = exposedGetState().common;
  let cfIndex = grantedCustomFunction.findIndex(
    (el) => el.enabled === true && el.cfCode === customFunctionCode
  );
  console.log("isCustomFunctionAvailable ", customFunctionCode, cfIndex);
  return cfIndex === -1 ? false : true;
};

export const isAuthenticatedChat = (interaction = {}) => {
  const { attributes = {} } = interaction;
  return (
    getBTChannelOfInteraction(interaction) === "CHAT" &&
    attributes["context.verified:ibcode"] &&
    attributes["context.authenticated"] === "true"
  );
};

export const isFullAuthenticatedCall = (interaction = {}) => {
  const { attributes = {} } = interaction;
  return (
    getBTChannelOfInteraction(interaction) === "VOICE" &&
    attributes["auth3"] === "true" &&
    attributes["ibcode"]
  );
};

export const isPartialAuthenticatedCall = (interaction = {}) => {
  const { attributes = {} } = interaction;
  return (
    getBTChannelOfInteraction(interaction) === "VOICE" &&
    attributes["auth2"] === "true" &&
    attributes["auth3"] === "false" &&
    attributes["ibcode"]
  );
};

export const isTMLAvailable = (interaction = {}) => {
  const { attributes = {} } = interaction;
  return attributes["tml"];
};

export const isContactIDAvailable = (interaction = {}) => {
  const { attributes = {} } = interaction;
  return attributes["contactid"]
}

export const isNTCodeAvailable = (interaction = {}) => {
  const { attributes = {} } = interaction;
  return attributes["usernt"]

}

export const isIdSoggettoAvailable = (interaction = {}) => {
  const { attributes = {} } = interaction;
  return attributes["idsoggetto"]
}

export const isAbandonRecallConversation = (interaction = {}) => {
  const { attributes = {}} = interaction;
  return attributes["abandonrecallconversation"];
}

export const isSospesoConversation = (interaction = {}) => {
  const { attributes = {}} = interaction;
  return attributes["idsospeso"];
}

export const getChatChannel = (interaction = {}) => {
  const { attributes = {} } = interaction;
  return attributes["context.channel"]
}

export const addParticipantDataToInteraction = (interactionId = "noInteraction", attributes = {}) => {
  console.log("addParticipantDataToInteraction", interactionId, attributes);
  if(!interactionId || interactionId === "noInteraction" || !attributes){
    return;
  }
  document.getElementById("softphone").contentWindow.postMessage(
    JSON.stringify({
      type: "addAttribute",
      data: {
        interactionId: interactionId,
        attributes: attributes,
      },
    }),
    "*"
  );
}

/**
 * For request body see: https://developer.genesys.cloud/platform/embeddable-framework/actions/clickToDial
 * @param {*} request 
 */
export const placeCall = (request = {}) =>  {
  console.log("placeCall", request);
  document.getElementById("softphone").contentWindow.postMessage(
    JSON.stringify({
      type: "clickToDial",
      data: request,
    }),
    "*"
  );
}

export const sendUserNotifictionOnPEF = (data = {}) => {
  let { message, type = "info" } = data;
  if (!message) return;
  document.getElementById("softphone").contentWindow.postMessage(
    JSON.stringify({
      type: "sendCustomNotification",
      data: {
        message: message,
        type: type,
      },
    }),
    "*"
  );
}

export const sendContactSearchOnPEF = ( contactList = [] ) => {
  document.getElementById("softphone").contentWindow.postMessage(
    JSON.stringify({
      type: "sendContactSearch",
      data: contactList,
    }),
    "*"
  );
}

export const makeOutboundCallMethod = ( phn , idVal, queue) => {
  document.getElementById("softphone").contentWindow.postMessage(
    JSON.stringify({
    type: "clickToDial",
    data: {
    number: phn,
    type: "call",
    autoPlace:true,
    queueId: queue,
    attributes:{
    ContactId:idVal
    }
    },
    }),
    "*"
  );
}

export const getOrganizationPresencesById = (presences) => {
  return ( id ) => {
    if(!id || !presences) return {};
    return presences.find(el => el.id === id) || {};
  }
}
export const updateSystemPresence = ({setSystemStatus}) => {
  const { systemPresences = [] } = exposedGetState().common;
  let availableIndex = systemPresences.findIndex(el => el.name===setSystemStatus);
  if(availableIndex!==-1){
    const{id = "" } = systemPresences[availableIndex];
    document.getElementById("softphone").contentWindow.postMessage(
      JSON.stringify({ 
        type: "updateUserStatus", 
        data:{ id: id} 
      }),
      "*"
      );
  }
}

export const getNormalizedIbCode = (value) => {
  let regex = /\d/i
  if(!value || !regex.test(value)) return value;
  const ibCodeLength = 8;
  let newValue;
  if(value.length < ibCodeLength){
    for(let i=0;i<ibCodeLength-value.length; i++){
      newValue = "0" + value;
    }
  }else{
    newValue = value;
  }
  return newValue;
}

export const getAniFromInteraction = (interaction) => {
  const { ani: aniPEF, attributes = {} } = interaction;
  let validAni = "";
    if(!aniPEF.startsWith("+") && attributes["ani"]){
      validAni = attributes["ani"];
    }else{
      validAni = aniPEF;
    }
    return validAni;
}