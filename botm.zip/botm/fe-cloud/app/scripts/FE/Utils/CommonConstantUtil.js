export const autoWrapProspect = "PROSPECT";
export const autoWrapRecall = "RECALL";

export const transferAutoTraceEmailType = "Mail Trasferita";
export const transferAutoTraceChatType = "Chat Trasferita";
export const transferAutoTraceCallType = "Tel Trasferita";