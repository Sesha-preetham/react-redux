import itDictionary from "./dictionary-it";
import enDictionary from "./dictionary-en";
import common from "./dictionary-common";

const it = {
    ...itDictionary,
    ...common
};

const en = {
    ...enDictionary,
    ...common
}

export default {
    it,
    en
};