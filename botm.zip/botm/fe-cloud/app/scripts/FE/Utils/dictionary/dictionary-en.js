const dictionary = {
    connected: "CONNECTED",
    held: "HELD",
    disconnected: "DISCONNECTED",
    authenticationSuccess: "Client authenticated!",
    smsOtpSentSuccess: "Sms Sent!",
    changePinSuccess: "Pin updated!",
    contacting : "CONTACTING"
}

export default dictionary;