const dictionary = {
    connected: "CONNESSO",
    held: "IN ATTESA",
    disconnected: "DISCONNESSO",
    authenticationSuccess: "Cliente autenticato!",
    smsOtpSentSuccess: "Sms inviato!",
    changePinSuccess: "Pin aggiornato!",
    contacting : "CONTATTACI"
    
}

export default dictionary;