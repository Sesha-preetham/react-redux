const dictionary = {

    // BT channel constant
    voice: 'VOICE',
    email: 'EMAIL',
    chat: 'CHAT',
    messages: 'MESSAGES'
    
}

export default dictionary;