import axios from "axios";
import {setShowSessionExpires} from "../Store/commonSlice";
import {exposedDispatch} from "../Store/store"


class HttpClient {
  constructor(config = "") {
    this.config = config;
  }

  setUrl = (url = "") => {
    this.url = url;
  };

  getUrl = (url = "") => {
    this.url = url;
  };

  errorHandler = (axiosError) => {
    console.log("HttpClient",axiosError, axiosError.response);
    const { response = {} } = axiosError;
    const { status, data: serverBodyResponse = {} } = response;
    const dispatch = exposedDispatch;
    if(403 === status){
      dispatch(setShowSessionExpires({show: true}));
    }
    return serverBodyResponse;
  }


  httpGet = async (queryObj = {}, paramObj = {}) => {
    let paramObjEntries = Object.entries(paramObj);
    this.url = paramObjEntries.reduce((acc, [key, value]) => {
      console.log(this.url);
      if (value) {
        acc = acc.replace(":" + key, value);
      }
      return acc;
    }, this.url);
    let queryObjEntries = Object.entries(queryObj);
    let queryObjString = queryObjEntries.reduce(
      (acc, [key, value]) => {
        if (value) {
          acc = acc.concat(`${key}=${value}&`);
        }
        return acc;
      },
      queryObjEntries.length > 0 ? "?" : ""
    );
    queryObjString = queryObjString.substring(0, queryObjString.length - 1);
    let httpResponse = await axios
      .get(`${this.url}${queryObjString}`)
      .then((response) => {
        if (response && response.data) {
          return response.data;
        }
      })
      .catch((error) => {
        return this.errorHandler(error);
      });
    return httpResponse;
  };

  httpPost = async (bodyRequest = {}, paramObj = {}) => {
    let paramObjEntries = Object.entries(paramObj);
    this.url = paramObjEntries.reduce((acc, [key, value]) => {
      if (value) {
        acc = acc.replace(":" + key, value);
      }
      return acc;
    }, this.url);
    console.log(this.url);
    let httpResponse = await axios
      .post(this.url, bodyRequest)
      .then((response) => {
        if (response && response.data) {
          return response.data;
        }
      })
      .catch((error) => {
        return this.errorHandler(error);
      });
    return httpResponse;
  };

  httpGetFile = async (queryObj = {}, paramObj = {}) => {
    let paramObjEntries = Object.entries(paramObj);
    this.url = paramObjEntries.reduce((acc, [key, value]) => {
      console.log(this.url);
      if (value) {
        acc = acc.replace(":" + key, value);
      }
      return acc;
    }, this.url);
    let queryObjEntries = Object.entries(queryObj);
    let queryObjString = queryObjEntries.reduce(
      (acc, [key, value]) => {
        if (value) {
          acc = acc.concat(`${key}=${value}&`);
        }
        return acc;
      },
      queryObjEntries.length > 0 ? "?" : ""
    );
    queryObjString = queryObjString.substring(0, queryObjString.length - 1);
    let httpResponse = await axios
      .get(`${this.url}${queryObjString}`,{responseType:"blob",})  //Axios.get(url, {        responseType: "blob", })
      .then((response) => {
        return response
      })
      .catch((error) => {
        return this.errorHandler(error);
      });
    return httpResponse;
  };

  httpPostFile = async (bodyRequest , paramObj = {}) => {
    let paramObjEntries = Object.entries(paramObj);
    this.url = paramObjEntries.reduce((acc, [key, value]) => {
      if (value) {
        acc = acc.replace(":" + key, value);
      }
      return acc;
    }, this.url);
    console.log(this.url);
    let httpResponse = await axios
      .post(this.url, bodyRequest)
      .then((response) => {
        if (response && response.data) {
          return response.data;
        }
      })
      .catch((error) => {
        return this.errorHandler(error);
      });
    return httpResponse;
  };

  httpPut = async (bodyRequest = {}, paramObj = {}) => {
    let paramObjEntries = Object.entries(paramObj);
    this.url = paramObjEntries.reduce((acc, [key, value]) => {
      if (value) {
        acc = acc.replace(":" + key, value);
      }
      return acc;
    }, this.url);
    console.log(this.url);
    let httpResponse = await axios
      .put(this.url, bodyRequest)
      .then((response) => {
        if (response && response.data) {
          return response.data;
        }
      })
      .catch((error) => {
        return this.errorHandler(error);
      });
    return httpResponse;
  }
}



export default HttpClient;
