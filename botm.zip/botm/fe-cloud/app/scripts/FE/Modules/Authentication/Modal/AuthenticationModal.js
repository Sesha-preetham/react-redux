import React, { useState } from "react";
import MyModal from "../../../CommonComponents/Modal/MyModal";
//import AutenticazioneContainer from "../AutenticazioneContainer";
import AutenticazioneV2Container from "../AutenticazioneV2Container";
import AlertToast from "../../../CommonComponents/AlertToast/AlertToast";
import { authenticationAlertId } from "../../../CommonComponents/AlertToast/AlertIdConstants";
import FormFieldHandler from "../../../CommonComponents/Forms/FormFieldHandler";
import { withErrorBoundary } from "../../../CommonComponents/ErrorBoundary/withErrorBoudary";
import AutenticazioneV3Container from "../AutenticazioneV3Container";
import { useSelector } from "react-redux";

const AuthenticationModal = ({ configuration = {} } = props) => {
  const {
    showAuthenticationModal = false,
    valueToAuthenticate,
    handleOnHideAuthenticationModal = () => {},
  } = configuration;

  const [ formFields ] = useState(new FormFieldHandler(true));

  const { profile = {} } = useSelector(state => state.preference);
  const { authFlow } = profile;

  let handleOnhide = () => {
    handleOnHideAuthenticationModal();
  };

  let handleOnOpen = () => {
  };

  const authenticationModalConfig = {
    uniqueID: "authenticationModal",
    modalClass: "my-modal authentication-modal",
    dialogClassName: "modal-w",
    modalBodyClass: "my-modal-body modal-h",
    title: {
      content: "Autenticazione",
      class: "widget-title",
    },
    modalShow: showAuthenticationModal,
    modalHeaderShow: true,
    backdrop: {
      enable: true,
    },
    events: {
      onHide: () => {
        console.log("authenticationModal modal onHide");
        handleOnhide();
      },
      onEntered: () => {
        handleOnOpen();
        console.log("authenticationModal modal onEntered");
      },
      onExited: () => {
        console.log("authenticationModal modal onExited");
      },
    },
  };
  return (
    <MyModal configuration={authenticationModalConfig}>
      <AlertToast
        configuration={{
          unqiueID: authenticationAlertId,
          className: "inline-toast-container",
          transition: "flip",
        }}
      />
      {authFlow === "v3"?<AutenticazioneV3Container
        formFields={formFields}
        valueToAuthenticate={valueToAuthenticate}
      />:null}
      {authFlow === "v2"?<AutenticazioneV2Container
        formFields={formFields}
        valueToAuthenticate={valueToAuthenticate}
      />:null}
      
    </MyModal>
  );
};

export default withErrorBoundary(AuthenticationModal);
