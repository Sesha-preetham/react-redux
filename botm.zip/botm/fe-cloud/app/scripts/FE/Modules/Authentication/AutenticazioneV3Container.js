import React, { useCallback, useEffect, useMemo, useState } from "react";
import { createDispatchHook, useSelector } from "react-redux";
import { withErrorBoundary } from "../../CommonComponents/ErrorBoundary/withErrorBoudary";
import FormFieldHandler from "../../CommonComponents/Forms/FormFieldHandler";
import useAsyncReference from "../../CommonComponents/Hooks/useAsyncReference";
import MySpinner from "../../CommonComponents/Spinner/MySpinner";
import { authenticationSpinnerId } from "../../CommonComponents/Spinner/spinnerSlice";
import { exposedDispatch } from "../../Store/store";
import {
  addParticipantDataToInteraction,
  getNormalizedIbCode,
} from "../../Utils/CommonUtil";
import {
  getInteractionDetails,
  updateInteractionProperty,
} from "../Interaction/interactionSlice";
import {
  addAuthenticationValueByInteraction,
  getAuthenticationDataByInteractionAndValue,
  updateAuthenticationPropertiesByInteractionAndValue,
  updateAuthenticationPropertyByInteractionAndValue,
} from "./authenticationSlice";
import ChangePin from "./ChangePin";
import AuthenticationDropdown from "./Common/AuthenticationDropdown";
import { httpPostAuthV3Init, httpPostAuthV3Validate } from "./Service";
import { AuthProvider } from "./v2/AuthenticationContext";
import BirthDayKey from "./v2/BirthDayKey";
import IbCodeKey from "./v2/IbCodeKey";
import PinKey from "./v2/PinKey";
import PwdTwoChar from "./v2/PwdTwoChar";
import RsaTokenKey from "./v2/RsaTokenKey";
import SmsOtpKey from "./v2/SmsOtpKey";

const ibCodeKey = {
  key: "Ib Code",
  value: "",
};
const initialAuthState = {
  authKeys: [{ ...ibCodeKey }],
  flowToken: undefined,
  authInitDone: false,
  isNewCustomer: false,
};

const AutenticazioneV3Container = ({
  formFields = new FormFieldHandler(),
  valueToAuthenticate,
  isPartialAuthenticationFromIvr = false, // used on ExpandAuthenticationContainer since the redux state is updated later than rendering of this component
  onAuthenticationSuccess = () => {},
} = props) => {
  const [codice, setCodice] = useAsyncReference(valueToAuthenticate);

  const { authentication } = useSelector((state) => state.authentication);

  const [internalAuthState, setInternalAuthState] = useAsyncReference({
    ...initialAuthState,
    authKeys: isPartialAuthenticationFromIvr ? [] : [{ ...ibCodeKey }],
  });

  const { currentInteraction, interactions = [] } = useSelector(
    (state) => state.interaction
  );
  const { intxId, attributes = {} } =
    getInteractionDetails(interactions)(currentInteraction);

  const {
    authenticationState = "NOT_AUTHENTICATED",
    isNewCustomer = false,
    authKeys: authKeysRedux,
    authToken: authTokenRedux,
  } = getAuthenticationDataByInteractionAndValue(authentication)(
    currentInteraction,
    codice.current
  );

  const initCodice = (authKeyRequest = []) => {
    console.log(
      "Authv3 initCodice with form ibcode",
      internalAuthState,
      codice,
      formFields.getValue("Ib Code")
    );
    let ibCode = formFields.getValue("Ib Code");
    let normIbCode = getNormalizedIbCode(ibCode);
    console.log("Authv3 initCodice getNormalizedIbCode", normIbCode);
    setCodice(normIbCode);
  };

  const getComponentFromAuthKey = (authKey) => {
    console.log(
      "Authv3 getComponentFromAuthKey ",
      authKey,
      internalAuthState,
      codice
    );
    const { authInitDone } = internalAuthState;
    let { key = "" } = authKey || {};
    if (key && key.includes("PWD_CHARS")) {
      key = key.split(":")[0];
    }
    switch (key) {
      case "Ib Code":
        return (
          <IbCodeKey
            callClientSearch={
              !valueToAuthenticate || valueToAuthenticate === "" ? true : false
            }
            validateValue={initCodice}
            authKey={authKey}
          />
        );
      case "Pin":
        return <PinKey validateValue={validateValue} authKey={authKey} />;
      case "rsa-token":
        return <RsaTokenKey validateValue={validateValue} authKey={authKey} />;
      case "PWD_CHARS":
        return <PwdTwoChar validateValue={validateValue} authKey={authKey} />;
      case "AntiDOS":
        return <BirthDayKey validateValue={validateValue} authKey={authKey} />;
      case "Enter OTP":
        return <SmsOtpKey validateValue={validateValue} authKey={authKey} />;
      case "new-rsa-token":
        return (
          <RsaTokenKey
            uniqueID={"newTokenField"}
            validateValue={validateValue}
            authKey={authKey}
          />
        );
      case "next-rsa-token":
        return (
          <RsaTokenKey
            uniqueID={"nextTokenField"}
            validateValue={validateValue}
            authKey={authKey}
          />
        );
      default:
        return <div>{`Key: ${key} not handled `}</div>;
    }
  };

  const dispactAuthState = async (action) => {
    console.log("Authv3 dispactAuthState ", action);
    switch (action.type) {
      /* without useAsyncReference
      case "update":
        setInternalAuthState((prevState) => {
          const newState = { ...prevState, ...action.value };
          console.log("Authv3 dispactAuthState update ", newState);
          return newState;
        });
        break;
      case "reset":
        console.log("Authv3 dispactAuthState reset ");
        setInternalAuthState(initialAuthState);
        break;
      default:
        return;
      */
      case "update":
        setInternalAuthState({
          ...internalAuthState.current.current,
          ...action.value,
        });
        break;
      case "reset":
        console.log("Authv3 dispactAuthState reset ");
        setInternalAuthState(initialAuthState);
        break;
      default:
        return;
    }
  };

  const addAuthKeysIfNotExists = (originAuthKeys = [], newAuthKeys = []) => {
    let finalAuthKeys = [...originAuthKeys];
    for (let i = 0; i < newAuthKeys.length; i++) {
      const { key } = newAuthKeys[i];
      if (
        !key.includes("Submit OTP") &&
        originAuthKeys.findIndex((el) => el.key === key) === -1
      ) {
        finalAuthKeys.push(newAuthKeys[i]);
      }
    }
    return finalAuthKeys;
  };

  const initFlow = (additionalRequest = {}) => {
    console.log("Authv3 initFlow ", codice, internalAuthState);
    httpPostAuthV3Init({
      codice: codice.current,
      interactionId: currentInteraction,
      intxId: intxId,
      barraAuthToken: internalAuthState.current.authToken,
      ...additionalRequest,
    }).then((response) => {
      const { authKey = [], codice: codiceInit, authToken } = response;
      exposedDispatch(
        addAuthenticationValueByInteraction({
          interactionId: currentInteraction,
          authValue: codiceInit,
        })
      );
      let keys = updateValidatedAuthKeys(internalAuthState.current.authKeys, [
        { ...ibCodeKey, value: codiceInit },
      ]);
      keys = addAuthKeysIfNotExists(keys, authKey);
      dispactAuthState({
        type: "update",
        value: {
          authInitDone: true,
          authKeys: keys,
          authToken,
        },
      });
      formFields.getField("Ib Code").theField.setValue(codiceInit);
    });
  };

  const updateValidatedAuthKeys = (originAuthKeys = [], newAuthKeys = []) => {
    console.log(
      "Authv3 updateValidatedAuthKeys starts with: ",
      originAuthKeys,
      newAuthKeys
    );
    let finalAuthKeys = [...originAuthKeys];
    for (let i = 0; i < newAuthKeys.length; i++) {
      let keyIndex = finalAuthKeys.findIndex(
        (el) => el.key === newAuthKeys[i].key
      );
      if (keyIndex !== -1) {
        let newK = { ...finalAuthKeys[keyIndex], validated: true };
        finalAuthKeys.splice(keyIndex, 1, newK);
      }
    }
    console.log(
      "Authv3 updateValidatedAuthKeys wnd with finalAuthKeys: ",
      finalAuthKeys
    );
    return finalAuthKeys;
  };

  const refreshFlow = () => {
    console.log(
      "Authv3 refreshFlow ",
      internalAuthState,
      codice,
      currentInteraction,
      authenticationState
    );
    if (authenticationState.includes("PARTIAL_AUTHENTICATED")) {
      initFlow();
    } else {
      dispactAuthState({
        type: "reset",
      });
      initFlow();
    }
  };

  const validateValue = async (authKeyRequest = []) => {
    console.log("Authv3 validateValue ", codice, internalAuthState);
    const validateRequest = {
      codice: codice.current,
      authKey: authKeyRequest,
      interactionId: currentInteraction,
      intxId: intxId,
      barraAuthToken: internalAuthState.current.authToken,
    };
    let isSendSmsRequest = false;
    for (let i = 0; i < authKeyRequest.length; i++) {
      if (
        authKeyRequest[i].key.includes("Request OTP") &&
        authKeyRequest[i].value === "1"
      ) {
        isSendSmsRequest = true;
      }
    }
    httpPostAuthV3Validate(validateRequest).then((responseBody = {}) => {
      const { status, response = {} } = responseBody;
      if (status !== "OK") {
        refreshFlow();
        return responseBody;
      }
      if (isSendSmsRequest) {
        return responseBody;
      }
      const {
        authKey = [],
        authLevel = 0,
        codice: codiceFromResponse,
        authenticated = false,
        authToken,
      } = response;

      if (authenticated === true && authLevel === 10) {
        exposedDispatch(
          updateAuthenticationPropertyByInteractionAndValue({
            authValue: codiceFromResponse,
            interactionId: currentInteraction,
            property: "authenticationState",
            value: "AUTHENTICATED",
          })
        );
        onAuthenticationSuccess();
        return responseBody;
      }

      let newAuthKeys = addAuthKeysIfNotExists(
        internalAuthState.current.authKeys,
        authKey
      );
      newAuthKeys = updateValidatedAuthKeys(newAuthKeys, authKeyRequest);
      if (authenticated === true && authLevel === 3) {
        exposedDispatch(
          updateAuthenticationPropertyByInteractionAndValue({
            authValue: codiceFromResponse,
            interactionId: currentInteraction,
            property: "authenticationState",
            value: "PARTIAL_AUTHENTICATED",
          })
        );
        if (authToken) {
          let attributesToSet = {};
          try {
            attributesToSet["IBCode"] = `${codiceFromResponse}`;
            attributesToSet["BarraAuthToken"] = authToken;
            attributesToSet["Autenticazione Parziale"] =
              "dati aggiornati da barra";
            addParticipantDataToInteraction(
              currentInteraction,
              attributesToSet
            );
          } catch (e) {
            console.log(e);
          }
        }
      }
      dispactAuthState({
        type: "update",
        value: {
          authLevel: authLevel,
          authKeys: newAuthKeys,
          authToken: authToken,
        },
      });
    });
  };

  useEffect(() => {
    console.log(
      "Authv3 useEffect authenticationState ",
      authenticationState,
      authTokenRedux
    );
    if (
      authenticationState === "PARTIAL_AUTHENTICATED_IVR" ||
      authenticationState === "PARTIAL_AUTHENTICATED_TRASF"
    ) {
      initFlow({
        barraAuthToken: authTokenRedux,
      });
    }
  }, [authenticationState]);

  useEffect(() => {
    console.log(
      "Authv3 useEffect codice ",
      codice,
      authTokenRedux,
      authenticationState,
      internalAuthState,
      currentInteraction,
      attributes
    );
    if (authenticationState !== "AUTHENTICATED") {
      if (codice.current && codice.current !== "") {
        if (
          !authenticationState.includes("PARTIAL_AUTHENTICATED") &&
          !isPartialAuthenticationFromIvr
        ) {
          if (intxId) {
            initFlow();
          }
        } else {
          if (formFields.getField("Ib Code")) {
            formFields.getField("Ib Code").theField.setValue(codice.current);
          }
        }
      }
    }
    if (
      codice.current &&
      (!attributes["ibcode"] || attributes["ibcode"] === "")
    ) {
      // below action add the property on interaction state, used when there is mandatory authentication
      // and the ibcode participant data is not available and there are multiple interaction on barra
      // since on interaction selection the authentication component is re-build and we need to load authenticat data from redux
      exposedDispatch(
        updateInteractionProperty({
          id: currentInteraction,
          property: "expandAuthIbCode",
          value: codice.current,
        })
      );
    }
  }, [codice.current, intxId]);

  useEffect(() => {
    console.log(
      "Authv3 useEffect componentDidMount ",
      internalAuthState,
      codice,
      authTokenRedux,
      authenticationState,
      authKeysRedux
    );
    if (codice.current && codice.current !== "") {
      if (authTokenRedux) {
        dispactAuthState({
          type: "update",
          value: {
            authKeys: authKeysRedux || [],
            authToken: authTokenRedux,
          },
        });
      }
    }
  }, []);

  useEffect(() => {
    console.log(
      "Authv3 useEffect internalAuthState ",
      internalAuthState,
      currentInteraction,
      codice
    );
    exposedDispatch(
      updateAuthenticationPropertiesByInteractionAndValue({
        interactionId: currentInteraction,
        authValue: codice.current,
        value: {
          authKeys: internalAuthState.current.authKeys,
          authLevel: internalAuthState.current.authLevel,
          authToken: internalAuthState.current.authToken,
        },
      })
    );
  }, [internalAuthState.current]);

  if (authenticationState === "AUTHENTICATED") {
    return (
      <>
        <MySpinner uniqueID={authenticationSpinnerId} />
        <div className="authentication-container">
          <div className="row pb-2">
            <div className=" col-12 authentication-label-text">{`${codice.current} - ${window.BTFEDictionary["authenticationSuccess"]}`}</div>
          </div>
          {!isNewCustomer && (
            <AuthenticationDropdown title="Cambio Pin">
              <ChangePin
                formFields={formFields}
                codice={codice.current}
                currentInteraction={currentInteraction}
              />
            </AuthenticationDropdown>
          )}
        </div>
      </>
    );
  } else {
    return (
      <div className="authentication-container">
        <>
          <MySpinner uniqueID={authenticationSpinnerId} type={"global"} />
          <AuthProvider
            value={{
              codice: codice.current,
              formFields: formFields,
            }}
          >
            {(authenticationState === "PARTIAL_AUTHENTICATED_IVR" ||
              isPartialAuthenticationFromIvr) && (
              <div className=" col-12 authentication-label-text">
                Autenticazione parziale da IVR
              </div>
            )}
            {authenticationState === "PARTIAL_AUTHENTICATED_TRASF" && (
              <div className=" col-12 authentication-label-text">
                Autenticazione parziale - Trasferimento
              </div>
            )}
            {internalAuthState.current.authKeys.map((authKey) => {
              return (
                <div key={authKey.key}>{getComponentFromAuthKey(authKey)}</div>
              );
            })}
          </AuthProvider>
        </>
      </div>
    );
  }
};

export default withErrorBoundary(AutenticazioneV3Container);
