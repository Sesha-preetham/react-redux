import  React, { useContext, useEffect } from "react";
import { useSelector } from "react-redux";
import TextField from "../../../CommonComponents/Forms/TextField";
import { httpPostClientSearch } from "../../../Main/Header/UserSearch/Service";
import { getInteractionDetails } from "../../Interaction/interactionSlice";
import { getAuthenticationDataByInteractionAndValue } from "../authenticationSlice";
import AuthenticationLabelValue from "../Common/AuthenticationLabel";
import AuthContext from "./AuthenticationContext";
import { v4 as uuidv4 } from "uuid";


const IbCodeKey = ({
    callClientSearch = false,
    authKey = {},
    validateValue = () => {},
    id = uuidv4()
}) => {

    const {
        formFields,
        codice
    } = useContext(AuthContext);

    const { currentInteraction, interactions = [] } = useSelector(
        (state) => state.interaction
    );

    const { queueName = undefined, attributes = {}, intxId } =
    getInteractionDetails(interactions)(currentInteraction);

    const buildAuthKeyRequest = (value)  => {
      let localAuthKey = {...authKey};
      localAuthKey.value=value;
      console.log("Authv2 buildAuthKeyResponse: ", localAuthKey)
      return [localAuthKey]
    }

    const { validated = false, key = "Ib Code", value = "" } = authKey;

    useEffect(() => {
      if (validated && formFields.getField(key)) {
        formFields.getField(key).theField.setDisabled(true,false);
      }
    }, [validated]);


    const doClientSearch = async (valueToSearch) => {
        console.log(
          "AuthenticationContainer doClientSearch: ",
          valueToSearch,
          codice
        );
        if (valueToSearch) {
          const { x_servizio } = attributes;
          let request = {
            searchType: "codCliUsername",
            value: valueToSearch,
            interactionId: currentInteraction,
            queueName: queueName,
            service: x_servizio,
            intxId: intxId
          };
          await httpPostClientSearch(request);
        }
    };


    const ibCodeUsernameField = {
        uniqueID: key,
        form: formFields,
        value: value,
        setValue: (value) => {
          console.log("Authv2 ibCodeUsernameField ", id, value, callClientSearch);
          const { currentValue = "" } = value || {};
          let regex = /\d{8}/i;
          if (regex.test(currentValue)) {
            if(callClientSearch){
                doClientSearch(currentValue);
            }
            validateValue(buildAuthKeyRequest(currentValue));
          }
          //setCodice(currentValue);
        },
        callBackOnKeyUp: (event, obj) => {
          const { currentValue = "" } = obj;
          let regex = /\d{8}/i;
          if (event && event.keyCode == 13 && !regex.test(currentValue)) {
            console.log("Authv2 callBackOnKeyUp Event :" + currentValue, callClientSearch);
            if(callClientSearch){
                doClientSearch(currentValue);
            }
            validateValue(buildAuthKeyRequest(currentValue));
          }
        }
    };

    return (
        <AuthenticationLabelValue label="Codice cliente/Username">
            <TextField configuration={ibCodeUsernameField} />
        </AuthenticationLabelValue>
    )
}

export default IbCodeKey;