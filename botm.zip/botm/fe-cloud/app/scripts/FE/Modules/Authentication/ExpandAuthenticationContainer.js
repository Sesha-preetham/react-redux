import React, { useEffect, useState } from "react";
import { useSelector } from "react-redux";
import { authenticationAlertId } from "../../CommonComponents/AlertToast/AlertIdConstants";
import AlertToast from "../../CommonComponents/AlertToast/AlertToast";
import { withErrorBoundary } from "../../CommonComponents/ErrorBoundary/withErrorBoudary";
import FormFieldHandler from "../../CommonComponents/Forms/FormFieldHandler";
import { stackNavPop } from "../../Main/StackNavigation/stackNavigationSlice";
import { exposedDispatch } from "../../Store/store";
import {
  isFullAuthenticatedCall,
  isPartialAuthenticatedCall,
} from "../../Utils/CommonUtil";
import { getInteractionDetails } from "../Interaction/interactionSlice";
import ExpandedWidgetWrapper from "../Widgets/ExpandedWidgetWrapper";
import AutenticazioneV2Container from "./AutenticazioneV2Container";
import AutenticazioneV3Container from "./AutenticazioneV3Container";
import { getAuthenticationDataByInteractionAndValue } from "./authenticationSlice";

const ExpandAuthenticationContainer = (props = {}) => {
  const { elStack = {} } = props;
  const [formFields] = useState(new FormFieldHandler(true));

  const { currentInteraction = "noInteraction", interactions = [] } =
    useSelector((state) => state.interaction);

  const { authentication } = useSelector((state) => state.authentication);

  const { profile = {}} = useSelector(state => state.preference);

  const { authFlow } = profile;

  const interaction = getInteractionDetails(interactions)(currentInteraction);

  const {
    state,
    attributes = {},
    expandAuthIbCode,
    lastClientSearchFound = false,
  } = interaction || {};

  useEffect(() => {
    if (state === window.BTFEDictionary["disconnected"]) {
      exposedDispatch(stackNavPop());
    }
  }, [state]);

  const handleOnStackMounted = () => {
    console.log("ExpandAuthenticationContainer handleOnStackMounted ");
  };
  const handleOnStackUnMounted = () => {
    console.log("ExpandAuthenticationContainer handleOnStackUnMounted ");
  };

  const handleOnAuthenticationCompleted = () => {
    exposedDispatch(stackNavPop());
  };

  let toUseIbCode;
  if (attributes["ibcode"] && attributes["ibcode"] !== "") {
    toUseIbCode = attributes["ibcode"];
  } else if (expandAuthIbCode) {
    toUseIbCode = expandAuthIbCode;
  }

  const { authenticationState } = getAuthenticationDataByInteractionAndValue(
    authentication
  )(currentInteraction, toUseIbCode);

  if (
    isFullAuthenticatedCall(interaction) ||
    authenticationState === "AUTHENTICATED" ||
    lastClientSearchFound === true ||
    attributes["isagenttransfer"] === "true"
  ) {
    exposedDispatch(stackNavPop());
    return <div></div>;
  } else {
    return (
      <ExpandedWidgetWrapper
        className={
          "section-authentication authentication-expand-main-container"
        }
        elStack={elStack}
        events={{
          handleOnStackMounted: handleOnStackMounted,
          handleOnStackUnMounted: handleOnStackUnMounted,
        }}
      >
        <AlertToast
          configuration={{
            unqiueID: authenticationAlertId,
            className: "inline-toast-container",
            transition: "flip",
          }}
        />
        {authFlow === "v3"?<AutenticazioneV3Container
          valueToAuthenticate={toUseIbCode || undefined}
          formFields={formFields}
          onAuthenticationSuccess={handleOnAuthenticationCompleted}
          isPartialAuthenticationFromIvr={isPartialAuthenticatedCall(
            interaction
          )}
        />:null}
        {authFlow === "v2"?<AutenticazioneV2Container
          valueToAuthenticate={toUseIbCode || undefined}
          formFields={formFields}
          onAuthenticationSuccess={handleOnAuthenticationCompleted}
          isPartialAuthenticationFromIvr={isPartialAuthenticatedCall(
            interaction
          )}
        />:null}
      </ExpandedWidgetWrapper>
    );
  }
};

export default withErrorBoundary(ExpandAuthenticationContainer);
