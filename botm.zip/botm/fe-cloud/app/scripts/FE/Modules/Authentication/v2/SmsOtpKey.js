import React, { useContext, useEffect } from "react";
import { toast } from "react-toastify";
import { authenticationAlertId } from "../../../CommonComponents/AlertToast/AlertIdConstants";
import TextField from "../../../CommonComponents/Forms/TextField";
import { exposedDispatch } from "../../../Store/store";
import AuthenticationLabelValue from "../Common/AuthenticationLabel";
import AuthContext from "./AuthenticationContext";

const SmsOtpKey = ({
  colSize = "col-10",
  validateValue = () => {},
  authKey = {},
}) => {
  const { formFields } = useContext(AuthContext);

  const { key = "Enter OTP" , value = "", validated = false } = authKey;

  const smsValueFieldConfiguration = {
    uniqueID: key,
    form: formFields,
    value: value,
    setValue: (value) => {
      console.log("setValue smsField ", value);
    },
    callBackOnKeyUp: (event, obj) => {
      const { currentValue = "" } = obj;
      if (event && event.keyCode == 13 && currentValue.length === 6 && !validated) {
        console.log("callBackOnKeyUp Event :" + currentValue);
        validateValue(buildAuthKeyRequest(currentValue));
      }
    },
  };

  const requestSubmitOtpObject = {
    key: "Submit OTP : 0 Request OTP : 1 ",
    value: "0",
  };

  const buildAuthKeyRequest = (value) => {
    let localAuthKey = { ...authKey };
    localAuthKey.value = value;
    console.log("Authv2 SmsOtpKey buildAuthKeyResponse: ", localAuthKey);
    return [localAuthKey, requestSubmitOtpObject];
  };

  const handleSendSms = async () => {
    let localAuthKey = { ...authKey };
    let requestSendOtp = [localAuthKey, {
      ...requestSubmitOtpObject,
      value: "1"
    }];
    console.log("Authv2 SmsOtpKey handleSendSms: ", requestSendOtp);
    validateValue(requestSendOtp).then(response => {
      const { status } = response;
      if (status === "OK"){
        toast.success("Sms Inviato",{containerId: authenticationAlertId});
      }
    })
  };

  return (
    <div className="row justify-content-center">
      <div className={`${colSize} authentication-label-content`}>
        <div className="row justify-content-center">
          <div className="col-6 authentication-sendsms-container">
            <button
              type="button"
              className={`btn Rectangle-Button-Blue w-100`}
              onClick={handleSendSms}
            >
              Invia Sms
            </button>
          </div>
          <div className="col-4">
            <div className="authentication-label">Otp Sms</div>
            <div className="authentication-label-text">
              <TextField configuration={smsValueFieldConfiguration} />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SmsOtpKey;
