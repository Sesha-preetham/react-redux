import React, { useRef, useEffect, useState } from "react";
import { useSelector } from "react-redux";
import { exposedDispatch } from "../../Store/store";
import FormFieldHandler from "../../CommonComponents/Forms/FormFieldHandler";
import TextField from "../../CommonComponents/Forms/TextField";
import MySpinner from "../../CommonComponents/Spinner/MySpinner";
import { authenticationSpinnerId } from "../../CommonComponents/Spinner/spinnerSlice";
import { authenticationAlertId } from "../../CommonComponents/AlertToast/AlertIdConstants";
import { withErrorBoundary } from "../../CommonComponents/ErrorBoundary/withErrorBoudary";

import {
  getInteractionDetails,
  updateInteractionProperty,
} from "../Interaction/interactionSlice";
import { httpPostClientSearch } from "../../Main/Header/UserSearch/Service";
import { toast } from "react-toastify";
import AuthenticationLabelValue from "./Common/AuthenticationLabel";
import SmsField from "./Common/SmsField";
import AuthenticationDropdown from "./Common/AuthenticationDropdown";
import ChangePin from "./ChangePin";
import {
  addAuthenticationValueByInteraction,
  getAuthenticationDataByInteractionAndValue,
  updateAuthenticationPropertyByInteractionAndValue,
} from "./authenticationSlice";
import { httpPostAuthV2Init, httpPostAuthV2Validate } from "./Service";
import { AuthProvider } from "./v2/AuthenticationContext";
import IbCodeKey from "./v2/IbCodeKey";
import PinKey from "./v2/PinKey";
import RsaTokenKey from "./v2/RsaTokenKey";
import PwdTwoChar from "./v2/PwdTwoChar";
import BirthDayKey from "./v2/BirthDayKey";
import SmsOtpKey from "./v2/SmsOtpKey";
import { addParticipantDataToInteraction } from "../../Utils/CommonUtil";

const initialAuthState = {
  authStep: undefined,
  authKeys: [],
  flowToken: undefined,
  authInitDone: false,
  isNewCustomer: false,
};

function authStateReducer(state, action) {
  switch (action.type) {
    case "update":
      return {
        ...state,
        ...action.value,
      };
    case "reset":
      return {
        ...initialAuthState,
      };
    default:
      return {
        ...state,
      };
  }
}

const AutenticazioneV2Container = ({
  valueToAuthenticate,
  //formFields: parentFormFields = new FormFieldHandler(true),
  formFields = new FormFieldHandler(true),
  isPartialAuthenticationFromIvr = false,
  onAuthenticationSuccess = () => {},
} = props) => {
  //const [formFields] = useState(parentFormFields);

  const [codice, setCodice] = useState(valueToAuthenticate);
  const codiceRef = useRef(codice);

  const [internalAuthState, setInternalAuthState] = useState(initialAuthState);

  const internalAuthStateRef = useRef(internalAuthState);

  useEffect(() => {
    console.log("Authv2 internalAuthState change! ", internalAuthState);
    internalAuthStateRef.current = internalAuthState;
  }, [internalAuthState]);

  const { authentication } = useSelector((state) => state.authentication);

  const { currentInteraction, interactions = [] } = useSelector(
    (state) => state.interaction
  );

  const { intxId, attributes = {} } =
    getInteractionDetails(interactions)(currentInteraction);

  const {
    authenticationState = "NOT_AUTHENTICATED",
    isNewCustomer = false,
    flowToken: flowTokenRedux,
    authStep: authStepRedux,
    authKeys: authKeysRedux,
  } = getAuthenticationDataByInteractionAndValue(authentication)(
    currentInteraction,
    codice
  );

  const dispactAuthState = async (action) => {
    console.log("Authv2 dispactAuthState ", action);
    switch (action.type) {
      case "update":
        setInternalAuthState((prevState) => {
          const newState = { ...prevState, ...action.value };
          console.log("Authv2 dispactAuthState update ", newState);
          return newState;
        });
        break;
      case "reset":
        console.log("Authv2 dispactAuthState reset ");
        setInternalAuthState(initialAuthState);
        break;
      default:
        return;
    }
  };
  /*const [flowToken, setFlowToken] = useState(); //flowTokenRedux);
  const [authStep, setAuthStep] = useState(); //authStepRedux);
  const [authKeys, setAuthKeys] = useState([]); //authKeysRedux || []);
  const [authInitDone, setAuthInitDone] = useState(false);*/

  const authStateFromStep = ["VALIDATED", "PARTIAL_AUTHENTICATED"];

  /*const flowTokenRef = useRef(flowToken);
  const authStepRef = useRef(authStep);
  const authInitDoneRef = useRef(authInitDone);
  const authKeysRef = useRef(authKeys);*/

  const [authRetryCount, setAuthRetryCount] = useState(0);
  const authRetryCountRef = useRef(authRetryCount);
  useEffect(() => {
    authRetryCountRef.current = authRetryCount;
  }, [authRetryCount]);

  /*useEffect(() => {
    flowTokenRef.current = flowToken;
  }, [flowToken]);

  useEffect(() => {
    authStepRef.current = authStep;
  }, [authStep]);


  useEffect(() => {
    authInitDoneRef.current = authInitDone;
  }, [authInitDone]);

  */

  useEffect(async () => {
    //const authInitDone = authInitDoneRef.current;
    const { authInitDone } = internalAuthStateRef.current;
    console.log(
      "AuthV2 useffect codice :: ",
      codice,
      //authInitDoneRef.current,
      authInitDone,
      authenticationState
    );
    codiceRef.current = codice;
    if (
      authInitDone === false &&
      !authenticationState.includes("PARTIAL_AUTHENTICATED") &&
      isPartialAuthenticationFromIvr === false &&
      authenticationState !== "AUTHENTICATED"
    ) {
      let initRes = await initAuthentication();
      const { codice: codiceInit } = initRes || {};
      setCodice(codiceInit); //aggiunto per quando inserisci un codice < 8 cifre
      formFields.getField("Ib Code").theField.setValue(codiceInit);
    } else if (authenticationState === "PARTIAL_AUTHENTICATED") {
      console.log("AuthV2 useffect codice PARTIAL_AUTHENTICATED :: ", codice);
      if (formFields.getField("Ib Code")) {
        formFields.getField("Ib Code").theField.setValue(codice);
      }
    }
    if (codice && (!attributes["ibcode"] || attributes["ibcode"] === "")) {
      // below action add the property on interaction state, used when there is mandatory authentication
      // and the ibcode participant data is not available and there are multiple interaction on barra
      // since on interaction selection the authentication component is re-build and we need to load authenticat data from redux
      console.log(
        "AuthV2 useffect codice update interaction attributes :: ",
        codice,
        currentInteraction,
        attributes
      );
      exposedDispatch(
        updateInteractionProperty({
          id: currentInteraction,
          property: "expandAuthIbCode",
          value: codice,
        })
      );
    }
  }, [codice]);

  /*useEffect(() => {
    console.log("Authv2 store authKeys on redux", codice, authKeys);
    exposedDispatch(
      updateAuthenticationPropertyByInteractionAndValue({
        authValue: codice,
        interactionId: currentInteraction,
        property: "authKeys",
        value: authKeys,
      })
    );
    authKeysRef.current = authKeys;
  }, [authKeys]);*/
  useEffect(() => {
    console.log(
      "Authv2 store authKeys on redux",
      codice,
      internalAuthState.authKeys
    );
    if (!internalAuthState.authKeys) return;
    exposedDispatch(
      updateAuthenticationPropertyByInteractionAndValue({
        authValue: codice,
        interactionId: currentInteraction,
        property: "authKeys",
        value: internalAuthState.authKeys,
      })
    );
  }, [internalAuthState.authKeys]);

  const initAndValidateIbcode = async (authKeyRequest = []) => {
    //const authInitDone = authInitDoneRef.current;
    const { authInitDone } = internalAuthStateRef.current;
    if (authInitDone === true) {
      validateValue(authKeyRequest);
    } else {
      //let ibCode = formFields.getValue("ibCodeUsernameField");
      let ibCode = formFields.getValue("Ib Code");
      console.log("Authv2 initAndValidateIbcode ", ibCode, authInitDone);
      if (!ibCode) return;
      setCodice(ibCode);
    }
  };

  const validateValue = (authKeyRequest = []) => {
    /*console.log(
      "Authv2 validateValue: ",
      authStepRef.current,
      authStep,
      authKeys,
      authKeyRequest,
      authInitDoneRef.current,
      flowTokenRef.current,
      flowToken
    );*/
    //const authInitDone = authInitDoneRef.current;
    //const authStepRequest = authStepRef.current;
    //const flowTokenRequest = flowTokenRef.current;
    console.log("Authv2 validateValue: ", internalAuthStateRef.current);
    const {
      authInitDone,
      authStep: authStepRequest,
      flowToken: flowTokenRequest,
      isNewCustomer: isNewCustomerRequest,
    } = internalAuthStateRef.current;

    let isSendSmsRequest = false;
    for (let i = 0; i < authKeyRequest.length; i++) {
      if (
        authKeyRequest[i].key.includes("Request OTP") &&
        authKeyRequest[i].value === "1"
      ) {
        isSendSmsRequest = true;
      }
    }
    //da testare quando si chiude modal autenticazion e si riapre
    for (let i = 0; i < authKeyRequest.length; i++) {
      if (authKeyRequest[i].validated === true) {
        console.log("Authv2 validateValue: already validate.. go to next step");
        return;
      }
    }
    if (authInitDone === false) {
      return;
    }
    return httpPostAuthV2Validate({
      authStep: authStepRequest,
      authKey: getCleanAuthKeyRequestForValidate(authKeyRequest),
      //flowToken: flowToken,
      flowToken: flowTokenRequest,
      codice: codiceRef.current,
      isNewCustomer: isNewCustomerRequest,
      intxId,
    }).then((fullResponse = {}) => {
      const { status, response = {} } = fullResponse;
      console.log("Authv2 httpPostAuthV2Validate", fullResponse);
      if (status === "OK") {
        const {
          codice: codiceFromResponse,
          isNewCustomerFromResponse,
          authKey = [],
          authStep: newAuthStep,
          authenticated = false,
          flowToken: newFlowToken,
        } = response;
        if (isSendSmsRequest === true) {
          return fullResponse;
        }
        exposedDispatch(
          addAuthenticationValueByInteraction({
            interactionId: currentInteraction,
            authValue: codiceFromResponse,
          })
        );
        exposedDispatch(
          updateAuthenticationPropertyByInteractionAndValue({
            authValue: codiceFromResponse,
            interactionId: currentInteraction,
            property: "flowToken",
            value: newFlowToken,
          })
        );
        exposedDispatch(
          updateAuthenticationPropertyByInteractionAndValue({
            authValue: codiceFromResponse,
            interactionId: currentInteraction,
            property: "isNewCustomer",
            value: isNewCustomerRequest,
          })
        );
        if (!authenticated && authStateFromStep[authStepRequest]) {
          exposedDispatch(
            updateAuthenticationPropertyByInteractionAndValue({
              authValue: codiceFromResponse,
              interactionId: currentInteraction,
              property: "authenticationState",
              value: authStateFromStep[authStepRequest],
            })
          );
        } else if (authenticated) {
          exposedDispatch(
            updateAuthenticationPropertyByInteractionAndValue({
              authValue: codiceFromResponse,
              interactionId: currentInteraction,
              property: "authenticationState",
              value: "AUTHENTICATED",
            })
          );
          onAuthenticationSuccess();
        }
        exposedDispatch(
          updateAuthenticationPropertyByInteractionAndValue({
            authValue: codiceFromResponse,
            interactionId: currentInteraction,
            property: "authStep",
            value: newAuthStep,
          })
        );
        /*setAuthStep(newAuthStep);
        setFlowToken(newFlowToken);
        setCodice(codiceFromResponse);
        updateAuthKeysState(authKey, authKeyRequest);
        */
        if (!authenticated) {
          dispactAuthState({
            type: "update",
            value: {
              authStep: newAuthStep,
              flowToken: newFlowToken,
              authKeys: updateAuthKeys(authKey, authKeyRequest),
            },
          });
          if (authKey && newFlowToken) {
            let attributesToSet = {};
            try {
              attributesToSet["IBCode"] = `${codiceFromResponse}`;
              attributesToSet[
                "Auth_Challenge Ultimo"
              ] = `"authChallenges": ${JSON.stringify(authKey)}`;
              attributesToSet["AuthToken"] = newFlowToken;
              attributesToSet["Autenticazione Parziale"] =
                "dati aggiornati da barra";
              /*if(authStateFromStep[authStepRequest] === "PARTIAL_AUTHENTICATED"){
                attributesToSet["Auth2"] = "true";
              }*/
              addParticipantDataToInteraction(
                currentInteraction,
                attributesToSet
              );
            } catch (e) {
              console.log(e);
            }
          }
        }
        setCodice(codiceFromResponse);
      } else {
        refreshAuthentication();
      }
      return fullResponse;
    });
  };

  const getCleanAuthKeyRequestForValidate = (authKeysRequest = []) => {
    let newAuthKeys = [];
    authKeysRequest.forEach((el) => {
      let newEl = { ...el };
      ["validated"].forEach((propertyToDelete) => {
        if (propertyToDelete in newEl) {
          delete newEl[propertyToDelete];
        }
      });
      newAuthKeys.push(newEl);
    });
    return newAuthKeys;
  };

  const getKeyIndex = (authKeys = [], keyToSearch) => {
    let index = -1;
    if (!keyToSearch) return index;
    index = authKeys.findIndex((el) => {
      let { key = "" } = el;
      if (key && key.includes("PWD_CHARS")) {
        key = key.split(":")[0];
      }
      return key === keyToSearch;
    });
    console.log("Authv2 getKeyIndex ", authKeys, keyToSearch, index);
  };

  const getComponentFromAuthKey = (authKey = {}) => {
    //let authInitDone = authInitDoneRef.current;
    let { authInitDone } = internalAuthStateRef.current;
    let { key = "" } = authKey || {};
    console.log(
      "Authv2 getComponentFromAuthKey >> ",
      authKey,
      key,
      authInitDone,
      codice
    );
    if (key && key.includes("PWD_CHARS")) {
      key = key.split(":")[0];
    }
    switch (key) {
      case "Ib Code":
        return (
          <IbCodeKey
            callClientSearch={
              !valueToAuthenticate || valueToAuthenticate === "" ? true : false
            }
            validateValue={
              authInitDone === true ? validateValue : initAndValidateIbcode
            }
            authKey={authKey}
          />
        );
      case "Pin":
        return <PinKey validateValue={validateValue} authKey={authKey} />;
      case "rsa-token":
        return <RsaTokenKey validateValue={validateValue} authKey={authKey} />;
      case "PWD_CHARS":
        return <PwdTwoChar validateValue={validateValue} authKey={authKey} />;
      case "AntiDOS":
        return <BirthDayKey validateValue={validateValue} authKey={authKey} />;
      case "Enter OTP":
        return <SmsOtpKey validateValue={validateValue} authKey={authKey} />;
      case "new-rsa-token":
        return (
          <RsaTokenKey
            uniqueID={"newTokenField"}
            validateValue={validateValue}
            authKey={authKey}
          />
        );
      case "next-rsa-token":
        return(<RsaTokenKey
          uniqueID={"nextTokenField"}
          validateValue={validateValue}
          authKey={authKey}
        />);
      default:
        return <div>{`Key: ${key} not handled `}</div>;
    }
  };

  const updateAuthKeyStateValidated = (authKeys = [], authKey = []) => {
    let newAuthKeys = [...authKeys];
    authKey.forEach((el) => {
      const { key, value } = el;
      if (key) {
        for (let i = 0; i < newAuthKeys.length; i++) {
          let currObj = { ...newAuthKeys[i] };
          if (key === currObj.key) {
            currObj.validated = true;
            currObj.value = el.value;
            newAuthKeys[i] = currObj;
          }
        }
      }
    });
    return newAuthKeys;
  };

  const updateAuthKeysState = (authKeyResponse = [], authKeyValidated = []) => {
    let newAuthKeys = [...authKeysRef.current];
    console.log("Authv2 updateAuthKeysState current authKeys", newAuthKeys);
    authKeyResponse.forEach((keyResponse) => {
      const { key } = keyResponse;
      if (key && !key.includes("Submit OTP")) {
        if (
          authKeysRef.current.findIndex((el) => el.key === keyResponse.key) ===
          -1
        ) {
          newAuthKeys.push(keyResponse);
        }
      }
    });
    newAuthKeys = updateAuthKeyStateValidated(newAuthKeys, authKeyValidated);
    console.log("Authv2 updateAuthKeysState newAuthKeys", newAuthKeys);
    setAuthKeys(newAuthKeys);
  };

  const updateAuthKeys = (authKeyResponse, authKeyValidated = []) => {
    let newAuthKeys = [...internalAuthStateRef.current.authKeys];
    console.log("Authv2 updateAuthKeys current authKeys", newAuthKeys);
    authKeyResponse = authKeyResponse || [];
    authKeyResponse.forEach((keyResponse) => {
      const { key, value } = keyResponse;
      if (key && !key.includes("Submit OTP")) {
        let keyIndex = internalAuthStateRef.current.authKeys.findIndex(
          (el) => el.key === key
        );
        if (keyIndex === -1) {
          newAuthKeys.push(keyResponse);
        } else {
          newAuthKeys.splice(keyIndex, 1, keyResponse);
        }
      }
    });
    if (!haveSameKeys(authKeyResponse, authKeyValidated)) {
      newAuthKeys = updateAuthKeyStateValidated(newAuthKeys, authKeyValidated);
    }
    console.log("Authv2 updateAuthKeys newAuthKeys", newAuthKeys);
    return newAuthKeys;
  };

  const haveSameKeys = (authKeys1 = [], authKeys2 = []) => {
    if (authKeys1.length === authKeys2.length && authKeys1.length === 0)
      return true;
    for (let i = 0; i < authKeys1.length; i++) {
      const { key: key1 } = authKeys1[i] || {};
      let keyfound = false;
      for (let j = 0; j < authKeys2.length; j++) {
        const { key: key2 } = authKeys2[j] || {};
        if (key2 === key1) {
          keyfound = true;
          break;
        }
      }
      if (!keyfound) {
        return false;
      }
    }
    return true;
  };

  const refreshAuthentication = async () => {
    //let lAuthKeys = [...authKeysRef.current]; // save them to recall authentication...
    let lAuthKeys = [...internalAuthStateRef.current.authKeys];
    console.log(
      "Authv2 refreshAuthentication :: ",
      authenticationState,
      authRetryCountRef.current,
      formFields.getFields(),
      lAuthKeys
    );

    /*if (authRetryCountRef.current > 1) return;
    setAuthRetryCount((authRetryCount) => {
      return authRetryCount + 1;
    });*/

    //setAuthInitDone(false);
    //dispactAuthState({ type: "update", value: { authInitDone: false } });
    if (
      authenticationState === "PARTIAL_AUTHENTICATED_IVR" ||
      authenticationState === "PARTIAL_AUTHENTICATED_TRASF"
    ) {
      exposedDispatch(
        updateAuthenticationPropertyByInteractionAndValue({
          authValue: codice,
          interactionId: currentInteraction,
          property: "authenticationState",
          value: "NOT_AUTHENTICATED",
        })
      );
      /*
      setAuthKeys([]);
      setAuthStep(undefined);
      setFlowToken(undefined);
      */
      dispactAuthState({ type: "reset" });
      initAuthentication().then(() => {
        // trigger ibcode validate
        //formFields.getField("ibCodeUsernameField").theField.setValue(codice);
        formFields.getField("Ib Code").theField.setValue(codice);
      });
      return;
    }
    httpPostAuthV2Init({
      codice: codice,
      interactionId: currentInteraction,
      intxId,
    }).then(async (initResponse = {}) => {
      const {
        flowToken: flowTokenFromInit,
        isNewCustomer: isNewCustomerFromInit,
        authStep: authStepFromInit,
      } = initResponse || {};
      let flowTokenForRequest = flowTokenFromInit;
      let authStep = authStepFromInit;
      // lAuthKeys.length - 1 because we don't want to validate the value that cause the error.
      for (let i = 0; i < lAuthKeys.length - 1; i++) {
        console.log(
          "Authv2 refresh call validate for :: ",
          lAuthKeys[i],
          internalAuthStateRef.current
        );
        const validateResponse = await httpPostAuthV2Validate({
          authStep,
          authKey: getCleanAuthKeyRequestForValidate([lAuthKeys[i]]),
          flowToken: flowTokenForRequest,
          codice: codiceRef.current,
          isNewCustomer: isNewCustomerFromInit,
          intxId,
        });
        const { status, response = {} } = validateResponse || {};
        if (status === "OK") {
          console.log("Authv2 validate on refresh OK ", response);
          const { flowToken: flowTokenResponse } = response || {};
          flowTokenForRequest = flowTokenResponse;
          authStep++;
        } else {
          console.log("Authv2 validate on refresh KO ", validateResponse);
          break;
        }
        //await validateValue(getCleanAuthKeyRequestForValidate([lAuthKeys[i]]));
      }
      // clean the box with the key that failed
      let keyFailed = lAuthKeys[lAuthKeys.length - 1];
      if (formFields.getField(keyFailed.key)) {
        formFields.getField(keyFailed.key).theField.setValue("");
      }
      dispactAuthState({
        type: "update",
        value: {
          flowToken: flowTokenForRequest,
          authStep: authStep,
          authKeys: lAuthKeys,
          isNewCustomer: isNewCustomerFromInit,
        },
      });
    });

    /*initAuthentication().then(async (response) => {
      const { flowToken: flowTokenFromInit } = response || {};
      console.log(
        "Authv2 refreshAuthentication :: ", formFields.getFields(), authStepRef.current, lAuthKeys, flowTokenFromInit, flowToken
      );
      console.log(
        "Authv2 refreshAuthentication :: ",
        formFields.getFields(),
        internalAuthStateRef.current,
        flowTokenFromInit
      );
      for (let i = 0; i < lAuthKeys.length; i++) {
        if (i === lAuthKeys.length - 1) {
          // do not validate the step that failed...
          break;
        }
        await validateValue(getCleanAuthKeyRequestForValidate([lAuthKeys[i]]));
      }
    });*/
  };

  const initAuthentication = async (customData = {}) => {
    const { ibcode } = customData || {};
    let codeToValidate = codice ? codice : ibcode;
    /*console.log(
      "Authv2 initAuthentication :: ",
      codeToValidate,
      authInitDoneRef.current
    );*/
    console.log(
      "Authv2 initAuthentication :: ",
      codeToValidate,
      internalAuthStateRef.current
    );
    if (!codeToValidate || codeToValidate === "") return;
    let response = await httpPostAuthV2Init({
      codice: codeToValidate,
      interactionId: currentInteraction,
      intxId,
    });
    const {
      authStep,
      flowToken,
      authKey = [],
      codice: resIbCode,
      isNewCustomer,
    } = response;
    console.log("Authv2 httpPostAuthV2Init response: ", response);
    if (flowToken && authStep >= 0) {
      //setFlowToken(flowToken);
      //setAuthStep(authStep);
      //updateAuthKeysState(authKey);
      //setAuthInitDone(true);

      /* per provare con reducer...
      setFlowToken(flowToken);
      setAuthInitDone(true);
      setAuthStep(authStep);
      updateAuthKeysState(authKey);
      */
      dispactAuthState({
        type: "update",
        value: {
          flowToken,
          authStep,
          authInitDone: true,
          authKeys: updateAuthKeys(authKey),
          isNewCustomer,
        },
      });
    }
    return response;
  };

  useEffect(async () => {
    console.log("Authv2 useEffect authenticationState ", authenticationState);
    if (authenticationState === "PARTIAL_AUTHENTICATED_IVR" || authenticationState === "PARTIAL_AUTHENTICATED_TRASF" ) {
      await httpPostAuthV2Init({
        codice: codice,
        interactionId: currentInteraction,
        intxId,
        flowToken: flowTokenRedux,
      });
      dispactAuthState({
        type: "update",
        value: {
          authStep: 0,
          authInitDone: true,
          flowToken: flowTokenRedux,
          authKeys: authKeysRedux || [],
        },
      });
    }
  }, [authenticationState]);

  useEffect(async () => {
    if (
      !authenticationState.includes("PARTIAL_AUTHENTICATED") &&
      authenticationState !== "AUTHENTICATED"
    ) {
      if (codice && codice !== "") {
        console.log("Authv2 componentDidMount with codice :: ", codice);
        // logic of init moved on useEffect of codice
        //initAuthentication();
      } else {
        dispactAuthState({
          type: "update",
          value: {
            authStep: 0,
            authKeys: [
              {
                key: "Ib Code",
                value: "",
              },
            ],
          },
        });
        /*setAuthStep(0);
        setAuthKeys([
          {
            key: "Ib Code",
            value: "",
          },
        ]);*/
      }
    } else if (
      authenticationState === "PARTIAL_AUTHENTICATED_IVR" ||
      isPartialAuthenticationFromIvr || authenticationState === "PARTIAL_AUTHENTICATED_TRASF"
    ) {
      console.log(
        "Authv2 componentDidMount isPartialAuthenticationFromIvr... ",
        codice
      );
      /*await httpPostAuthV2Init({
        codice: codice,
        interactionId: currentInteraction,
        intxId,
        flowToken: flowTokenRedux,
      });
      //setAuthKeys(authKeysRedux);
      //setAuthStep(0);
      //setAuthInitDone(true);
      //setFlowToken(flowTokenRedux);
      dispactAuthState({
        type: "update",
        value: {
          authStep: 0,
          authInitDone: true,
          flowToken: flowTokenRedux,
          authKeys: authKeysRedux,
        },
      });*/
    } else {
      // if you are here it means that user closed and reopened the modal, load data from redux
      console.log(
        "Authv2 componentDidMount else ... ",
        codice,
        authenticationState
      );
      /*
      setAuthKeys(authKeysRedux);
      setAuthStep(authStepRedux);
      //await initAuthentication();
      setAuthInitDone(true);
      setFlowToken(flowTokenRedux);
      */
      dispactAuthState({
        type: "update",
        value: {
          authStep: authStepRedux,
          authInitDone: true,
          flowToken: flowTokenRedux,
          authKeys: authKeysRedux,
        },
      });
    }
    return () => {};
  }, []);

  console.log(
    "Authv2 return : ",
    codice,
    internalAuthState,
    authenticationState,
    authentication,
    currentInteraction
  );

  if (authenticationState === "AUTHENTICATED") {
    return (
      <>
        <MySpinner uniqueID={authenticationSpinnerId} />
        <div className="authentication-container">
          <div className="row pb-2">
            <div className=" col-12 authentication-label-text">{`${codice} - ${window.BTFEDictionary["authenticationSuccess"]}`}</div>
          </div>
          {!isNewCustomer && (
            <AuthenticationDropdown title="Cambio Pin">
              <ChangePin
                formFields={formFields}
                codice={codice}
                currentInteraction={currentInteraction}
              />
            </AuthenticationDropdown>
          )}
        </div>
      </>
    );
  } else {
    //console.log("Authv2 return : ", authStep, authKeys, codice, authInitDone);
    const authStep = internalAuthState.authStep;
    const authKeys = internalAuthState.authKeys;
    return (
      <div className="authentication-container">
        <>
          <MySpinner uniqueID={authenticationSpinnerId} type={"global"} />
          <AuthProvider
            value={{
              codice: codice,
              formFields: formFields,
              //flowToken: flowTokenRedux,
              //authStep: authStepRedux,
              //authKeys: authKeysRedux,
              //authKey: currentAuthKey,
            }}
          >
            {authenticationState === "PARTIAL_AUTHENTICATED_IVR" && (
              <div className=" col-12 authentication-label-text">
                Autenticazione parziale da IVR
              </div>
            )}
            {authenticationState === "PARTIAL_AUTHENTICATED_TRASF" && (
              <div className=" col-12 authentication-label-text">
                Autenticazione parziale - Trasferimento
              </div>
            )}
            {authStep >= 0 &&
              [...Array(authStep + 1)].map((e, index) => {
                return getComponentFromAuthKey(authKeys[index]);
              })}
          </AuthProvider>
        </>
      </div>
    );
  }
};

export default withErrorBoundary(AutenticazioneV2Container);
