import React from "react";
import TextField from "../../../CommonComponents/Forms/TextField";

const SmsField = (props) => {
  const {
    colSize = "col-10",
    handleSendSms = () => {},
    smsValueFieldConfiguration = {},
  } = props;

  return (
    <div className="row justify-content-center">
      <div className={`${colSize} authentication-label-content`}>
        <div className="row justify-content-center">
          <div className="col-6 authentication-sendsms-container">
            <button
              type="button"
              className={`btn Rectangle-Button-Blue w-100`}
              onClick={handleSendSms}
            >
              Invia Sms
            </button>
          </div>
          <div className="col-4">
            <div className="authentication-label">Otp Sms</div>
            <div className="authentication-label-text">
              <TextField configuration={smsValueFieldConfiguration} />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SmsField;
