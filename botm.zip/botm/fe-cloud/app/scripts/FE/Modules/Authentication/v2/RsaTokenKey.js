import React, { useContext, useEffect } from "react";
import TextField from "../../../CommonComponents/Forms/TextField";
import AuthenticationLabelValue from "../Common/AuthenticationLabel";
import AuthContext from "./AuthenticationContext";

const RsaTokenKey = ({ uniqueID = "tokenField" , validateValue = () => {}, authKey = {} }) => {
  const { formFields } = useContext(AuthContext);

  const { validated = false, key, value } = authKey;

  useEffect(() => {
    if (validated && formFields.getField(key)) {
      formFields.getField(key).theField.setDisabled(true,false);
    }
  }, [validated]);

  const buildAuthKeyRequest = (value) => {
    let localAuthKey = { ...authKey };
    localAuthKey.value = value;
    console.log("Authv2 PinKey buildAuthKeyResponse: ", localAuthKey);
    return [localAuthKey];
  };

  const tokenField = {
    uniqueID: key,
    form: formFields,
    value: value,
    validation: {
      maxLen: 6,
      type: "Numeric",
    },
    feedback: {
      enable: true,
      component: () => <>* 6 cifre</>,
    },
    setValue: (value) => {
      const { currentValue = "" } = value;
      console.log("Authv2 TokenField setValue ", currentValue);
      /*if (currentValue.length === 6 && !validated) {
        validateValue(buildAuthKeyRequest(currentValue));
      }*/
    },
    callBackOnKeyUp: (event, obj) => {
      const { currentValue = "" } = obj;
      if (currentValue.length === 6 && !validated && !(event && event.keyCode == 13)) {
        console.log("callBackOnKeyUp Event :" + obj.currentValue);
        validateValue(buildAuthKeyRequest(currentValue));
      }
    },
  };

  return (
    <AuthenticationLabelValue label="Token">
      <TextField configuration={tokenField} />
    </AuthenticationLabelValue>
  );
};

export default RsaTokenKey;
