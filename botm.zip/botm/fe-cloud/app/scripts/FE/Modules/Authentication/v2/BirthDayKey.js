import  React, { useContext, useEffect } from "react";
import { useSelector } from "react-redux";
import TextField from "../../../CommonComponents/Forms/TextField";
import { httpPostClientSearch } from "../../../Main/Header/UserSearch/Service";
import { getInteractionDetails } from "../../Interaction/interactionSlice";
import AuthenticationLabelValue from "../Common/AuthenticationLabel";
import AuthContext from "./AuthenticationContext";

const BirthDayKey = ({
    validateValue = () => {},
    authKey={}
}) => {

    const {
        formFields
    } = useContext(AuthContext);

    const {
        validated = false
    } = authKey;

    useEffect(()=> {
        if(validated && formFields.getField("birthdayField")){
            formFields.getField("birthdayField").theField.setDisabled(true);
            if(!formFields.getValue("birthdayField")){
                formFields.getField("birthdayField").theField.setValue("**/**/****");
            }
        }
    }, [validated]);

    const buildAuthKeyRequest = (value)  => {
        let localAuthKey = {...authKey};
        localAuthKey.value=value;
        console.log("Authv2 buildAuthKeyResponse: ", localAuthKey)
        return [localAuthKey]
    }

    const bithdayField = {
        uniqueID: "birthdayField",
        placeHolder: "DD/MM/YYYY",
        value: "",
        disabled: false,
        readonly: false,
        visible: true,
        form: formFields,
        callBackOnKeyUp: (event, obj) => {
          if (event && event.keyCode == 13) {
            console.log("Authv2 callBackOnKeyUp Event :" + obj.currentValue);
            validateValue(buildAuthKeyRequest(obj.currentValue));
          }
        },
    };

    return (
        <AuthenticationLabelValue label="Data nascita">
            <TextField configuration={bithdayField} />
        </AuthenticationLabelValue>
    )
}

export default BirthDayKey;