import React, { useRef, useEffect, useState } from "react";
import { useSelector } from "react-redux";
import { exposedDispatch } from "../../Store/store";
import FormFieldHandler from "../../CommonComponents/Forms/FormFieldHandler";
import TextField from "../../CommonComponents/Forms/TextField";
import MySpinner from "../../CommonComponents/Spinner/MySpinner";
import { authenticationSpinnerId } from "../../CommonComponents/Spinner/spinnerSlice";
import { authenticationAlertId } from "../../CommonComponents/AlertToast/AlertIdConstants";
import { withErrorBoundary } from "../../CommonComponents/ErrorBoundary/withErrorBoudary";

import {
  httpPostSendValidateSms,
  httpPostValidateCodice,
  httpPostValidatePin,
  httpPostValidatePwd,
  httpPostValidateToken,
  httpPostValidateTokenForNewAuth,
  httpPostSendOtpSms,
  httpPostValidateOtpSms,
} from "./Service";
import { getInteractionDetails } from "../Interaction/interactionSlice";
import { httpPostClientSearch } from "../../Main/Header/UserSearch/Service";
import { toast } from "react-toastify";
import AuthenticationLabelValue from "./Common/AuthenticationLabel";
import SmsField from "./Common/SmsField";
import AuthenticationDropdown from "./Common/AuthenticationDropdown";
import ChangePin from "./ChangePin";
import {
  addAuthenticationValueByInteraction,
  getAuthenticationDataByInteractionAndValue,
  updateAuthenticationPropertyByInteractionAndValue,
} from "./authenticationSlice";

const AutenticazioneContainer = ({
  valueToAuthenticate,
  formFields: parentFormFields = new FormFieldHandler(true),
} = props) => {
  const [formFields] = useState(parentFormFields);

  //const { anagrafica } = useSelector((state) => state.anagrafica);
  const { authentication } = useSelector((state) => state.authentication);

  const { currentInteraction, interactions = [] } = useSelector(
    (state) => state.interaction
  );

  const { queueName = undefined, attributes = {}, intxId } =
    getInteractionDetails(interactions)(currentInteraction);

  const [codice, setCodice] = useState(valueToAuthenticate);

  const doClientSearch = (valueToSearch) => {
    console.log(
      "AuthenticationContainer doClientSearch: ",
      valueToAuthenticate,
      codice
    );
    if (!valueToAuthenticate && valueToSearch && valueToSearch !== "") {
      const { x_servizio } = attributes;
      let request = {
        searchType: "codCliUsername",
        value: valueToSearch,
        interactionId: currentInteraction,
        queueName: queueName,
        service: x_servizio,
        intxId: intxId
      };
      httpPostClientSearch(request);
    }
  };

  const {
    authenticationState = "NOT_AUTHENTICATED",
    isNewCustomer = false,
    nextStep,
    pwdPosition1 = "",
    pwdPosition2 = "",
  } = getAuthenticationDataByInteractionAndValue(authentication)(
    currentInteraction,
    codice
  );

  // below is used to get updated value on ibCodeUsernameField setValue callback
  const currentAuthenticationStateRef = useRef();
  currentAuthenticationStateRef.current = authenticationState;

  useEffect(() => {
    console.log(
      "AuthenticationContainer useEffect: ",
      valueToAuthenticate,
      codice
    );
    if (valueToAuthenticate && authenticationState === "NOT_AUTHENTICATED") {
      formFields
        .getField("ibCodeUsernameField")
        .theField.setValue(valueToAuthenticate);
      //setCodice(valueToAuthenticate);
      validateIbCode(valueToAuthenticate);
    } else if (codice && authenticationState === "PARTIAL_AUTHENTICATED") {
      if (!isNewCustomer) {
        formFields.getField("pinField").theField.setValue("****");
        formFields.getField("pinField").theField.setDisabled(true);
      } else {
        formFields.getField("newAuthTokenField").theField.setValue("******");
        formFields.getField("newAuthTokenField").theField.setDisabled(true);
      }
    }
  }, []);

  useEffect(() => {
    if (
      authenticationState &&
      authenticationState !== "NOT_AUTHENTICATED" &&
      formFields.getField("ibCodeUsernameField")
    ) {
      formFields.getField("ibCodeUsernameField").theField.setDisabled(true);
    }
  }, [authenticationState]);

  const validateIbCode = (codiceCliente) => {
    let toUseInteraction =
      currentInteraction !== "noInteraction" ? currentInteraction : undefined;
    let ibCode =
      codiceCliente ||
      formFields.getField("ibCodeUsernameField").theField.getValue();
    //let ibCode = codice;
    if (!ibCode || ibCode === "") return;
    console.log("AuthenticationContainer validateIbCode: ", ibCode);
    httpPostValidateCodice({
      codice: ibCode,
      interactionId: toUseInteraction,
      intxId: intxId
    }).then((response = {}) => {
      const { status = "", response: validateCodiceResponse = {} } = response;
      if (status === "OK") {
        const { isNewCustomer = false, codice: normalizedIbCode } =
          validateCodiceResponse;
        ibCode = normalizedIbCode;
        console.log(
          "AuthenticationContainer validateIbCode internal: ",
          ibCode
        );
        setCodice(ibCode);
        exposedDispatch(
          addAuthenticationValueByInteraction({
            interactionId: currentInteraction,
            authValue: ibCode,
          })
        );
        exposedDispatch(
          updateAuthenticationPropertyByInteractionAndValue({
            authValue: ibCode,
            interactionId: currentInteraction,
            property: "isNewCustomer",
            value: isNewCustomer,
          })
        );
        exposedDispatch(
          updateAuthenticationPropertyByInteractionAndValue({
            authValue: ibCode,
            interactionId: currentInteraction,
            property: "authenticationState",
            value: "VALIDATED",
          })
        );
        formFields.getField("ibCodeUsernameField").theField.setValue(ibCode); // this is for showing normalized ibcode
      }
    });
  };

  const validatePin = () => {
    let toUseInteraction =
      currentInteraction !== "noInteraction" ? currentInteraction : undefined;
    let ibCode = formFields.getField("ibCodeUsernameField").theField.getValue();
    let pin = formFields.getField("pinField").theField.getValue();
    httpPostValidatePin({
      codice: ibCode,
      pin: pin,
      interactionId: toUseInteraction,
      intxId: intxId
    }).then((response = {}) => {
      const { status = "", response: validateResponse = {} } = response;
      if (status === "OK") {
        const {
          nextStep = "",
          position1 = "",
          position2 = "",
        } = validateResponse;
        exposedDispatch(
          updateAuthenticationPropertyByInteractionAndValue({
            authValue: ibCode,
            interactionId: currentInteraction,
            property: "authenticationState",
            value: "PARTIAL_AUTHENTICATED",
          })
        );
        exposedDispatch(
          updateAuthenticationPropertyByInteractionAndValue({
            authValue: ibCode,
            interactionId: currentInteraction,
            property: "nextStep",
            value: nextStep,
          })
        );
        exposedDispatch(
          updateAuthenticationPropertyByInteractionAndValue({
            authValue: ibCode,
            interactionId: currentInteraction,
            property: "pwdPosition1",
            value: position1,
          })
        );
        exposedDispatch(
          updateAuthenticationPropertyByInteractionAndValue({
            authValue: ibCode,
            interactionId: currentInteraction,
            property: "pwdPosition2",
            value: position2,
          })
        );
        formFields.getField("pinField").theField.setDisabled(true);
      }
    });
  };

  const validateToken = () => {
    let toUseInteraction =
      currentInteraction !== "noInteraction" ? currentInteraction : undefined;
    const ibCode = formFields
      .getField("ibCodeUsernameField")
      .theField.getValue();
    const token = formFields.getField("tokenField").theField.getValue();
    httpPostValidateToken({
      codice: ibCode,
      rsaToken: token,
      interactionId: toUseInteraction,
      intxId: intxId
    }).then((response) => {
      const { status = "", response: tokenResponse = {} } = response;
      const { validCredential = "" } = tokenResponse;
      if (status === "OK" && validCredential === "OK") {
        exposedDispatch(
          updateAuthenticationPropertyByInteractionAndValue({
            authValue: codice,
            interactionId: currentInteraction,
            property: "authenticationState",
            value: "AUTHENTICATED",
          })
        );
      }
    });
  };

  const sendSms = () => {
    let toUseInteraction =
      currentInteraction !== "noInteraction" ? currentInteraction : undefined;
    const ibCode = formFields
      .getField("ibCodeUsernameField")
      .theField.getValue();
    httpPostSendValidateSms({
      codice: ibCode,
      validateSmsOtp: "1",
      interactionId: toUseInteraction,
      intxId: intxId
    }).then((response) => {
      const { status = "", response: tokenResponse = {} } = response;
      if (status === "OK") {
        toast.success(window.BTFEDictionary["smsOtpSentSuccess"], {
          containerId: authenticationAlertId,
        });
      }
    });
  };

  const validateSms = () => {
    let toUseInteraction =
      currentInteraction !== "noInteraction" ? currentInteraction : undefined;
    const ibCode = formFields
      .getField("ibCodeUsernameField")
      .theField.getValue();
    const smsOtp = formFields.getField("smsField").theField.getValue();
    httpPostSendValidateSms({
      codice: ibCode,
      smsOtp: smsOtp,
      validateSmsOtp: "0",
      interactionId: toUseInteraction,
      intxId: intxId
    }).then((response) => {
      const { status = "", response: tokenResponse = {} } = response;
      const { validCredential = "" } = tokenResponse;
      if (status === "OK" && validCredential === "OK") {
        exposedDispatch(
          updateAuthenticationPropertyByInteractionAndValue({
            authValue: ibCode,
            interactionId: currentInteraction,
            property: "authenticationState",
            value: "AUTHENTICATED",
          })
        );
      }
    });
  };

  const sendSmsForNewAuth = () => {
    let toUseInteraction =
      currentInteraction !== "noInteraction" ? currentInteraction : undefined;
    const ibCode = formFields
      .getField("ibCodeUsernameField")
      .theField.getValue();
    httpPostSendOtpSms({
      codice: ibCode,
      interactionId: toUseInteraction,
      intxId: intxId
    }).then((response) => {
      const { status = "", response: tokenResponse = {} } = response;
      if (status === "OK") {
        toast.success(window.BTFEDictionary["smsOtpSentSuccess"], {
          containerId: authenticationAlertId,
        });
      }
    });
  };

  const validateSmsForNewAuth = () => {
    let toUseInteraction =
      currentInteraction !== "noInteraction" ? currentInteraction : undefined;
    const ibCode = formFields
      .getField("ibCodeUsernameField")
      .theField.getValue();
    const smsOtp = formFields
      .getField("smsFieldForNewAuth")
      .theField.getValue();
    httpPostValidateOtpSms({
      codice: ibCode,
      smsOtp: smsOtp,
      interactionId: toUseInteraction,
      intxId: intxId
    }).then((response) => {
      const { status = "", response: tokenResponse = {} } = response;
      const { validCredential = "", isSmsOtpValidated = false } = tokenResponse;
      if (
        status === "OK" &&
        validCredential === "OK" &&
        isSmsOtpValidated === true
      ) {
        exposedDispatch(
          updateAuthenticationPropertyByInteractionAndValue({
            authValue: ibCode,
            interactionId: currentInteraction,
            property: "authenticationState",
            value: "AUTHENTICATED",
          })
        );
      }
    });
  };

  const validatePassword = () => {
    let toUseInteraction =
      currentInteraction !== "noInteraction" ? currentInteraction : undefined;
    const ibCode = formFields
      .getField("ibCodeUsernameField")
      .theField.getValue();
    const pwd1 = formFields.getField("pwd1Field").theField.getValue();
    const pwd2 = formFields.getField("pwd2Field").theField.getValue();
    httpPostValidatePwd({
      codice: ibCode,
      c1: pwd1,
      c2: pwd2,
      interactionId: toUseInteraction,
      intxId: intxId
    }).then((response) => {
      const { status = "", response: validatePwdResponse = {} } = response;
      const { validCredential = "" } = validatePwdResponse;
      if (status === "OK" && validCredential === "OK") {
        exposedDispatch(
          updateAuthenticationPropertyByInteractionAndValue({
            authValue: ibCode,
            interactionId: currentInteraction,
            property: "authenticationState",
            value: "AUTHENTICATED",
          })
        );
      }
    });
  };

  const validateTokenForNewAuth = () => {
    let toUseInteraction =
      currentInteraction !== "noInteraction" ? currentInteraction : undefined;
    const ibCode = formFields
      .getField("ibCodeUsernameField")
      .theField.getValue();
    const token = formFields.getField("newAuthTokenField").theField.getValue();
    httpPostValidateTokenForNewAuth({
      codice: ibCode,
      otp: token,
      interactionId: toUseInteraction,
      intxId: intxId
    }).then((response) => {
      const { status = "", response: tokenResponse = {} } = response;
      const { validCredential = "" } = tokenResponse;
      if (status === "OK") {
        exposedDispatch(
          updateAuthenticationPropertyByInteractionAndValue({
            authValue: codice,
            interactionId: currentInteraction,
            property: "authenticationState",
            value: "PARTIAL_AUTHENTICATED",
          })
        );
      }
    });
  };

  const ibCodeUsernameField = {
    uniqueID: "ibCodeUsernameField",
    form: formFields,
    value: codice || "",
    setValue: (value) => {
      console.log("setValue ibCodeUsernameField ", value);
      const { currentValue = "" } = value || {};
      let regex = /\d{8}/i;
      if (
        currentValue !== valueToAuthenticate &&
        currentAuthenticationStateRef.current === "NOT_AUTHENTICATED" &&
        regex.test(currentValue)
      ) {
        doClientSearch(currentValue);
        validateIbCode(currentValue);
      }
      //setCodice(currentValue);
    },
    callBackOnKeyUp: (event, obj) => {
      if (event && event.keyCode == 13) {
        console.log("callBackOnKeyUp Event :" + obj.currentValue);
        doClientSearch(obj.currentValue);
        validateIbCode(obj.currentValue);
      }
    },
  };

  const pinField = {
    uniqueID: "pinField",
    form: formFields,
    value: "",
    additionalClass: "password",
    //controlType: "password",
    validation: {
      maxLen: 4,
      type: "Numeric",
    },
    feedback: {
      enable: true,
      component: () => <>* 4 cifre</>,
    },
    setValue: (value) => {
      const { currentValue = "" } = value;
      console.log("setValue pinField ", currentValue, formFields.getFields());
    },
    callBackOnKeyUp: (event, obj) => {
      const { currentValue = "" } = obj;
      if (
        (event && event.keyCode == 13 && currentValue.length === 4) ||
        currentValue.length === 4
      ) {
        console.log("callBackOnKeyUp Event :" + obj.currentValue);
        validatePin(currentValue);
      }
    },
  };

  const tokenField = {
    uniqueID: "tokenField",
    form: formFields,
    value: "",
    validation: {
      maxLen: 8,
      type: "Numeric",
    },
    feedback: {
      enable: true,
      component: () => <>* 8 cifre</>,
    },
    setValue: (value) => {
      console.log("setValue tokenField ", value);
    },
    callBackOnKeyUp: (event, obj) => {
      if (event && event.keyCode == 13) {
        console.log("callBackOnKeyUp Event :" + obj.currentValue);
        validateToken(obj.currentValue);
      }
    },
  };

  const newAuthTokenField = {
    uniqueID: "newAuthTokenField",
    form: formFields,
    value: "",
    validation: {
      maxLen: 8,
      type: "Numeric",
    },
    feedback: {
      enable: true,
      component: () => <>* 8 cifre</>,
    },
    setValue: (value) => {
      console.log("setValue tokenField ", value);
    },
    callBackOnKeyUp: (event, obj) => {
      if (event && event.keyCode == 13) {
        console.log("callBackOnKeyUp Event :" + obj.currentValue);
        validateTokenForNewAuth(obj.currentValue);
      }
    },
  };

  const smsFieldForNewAuth = {
    uniqueID: "smsFieldForNewAuth",
    form: formFields,
    value: "",
    setValue: (value) => {
      console.log("setValue smsField ", value);
    },
    callBackOnKeyUp: (event, obj) => {
      if (event && event.keyCode == 13) {
        console.log("callBackOnKeyUp Event :" + obj.currentValue);
        validateSmsForNewAuth(obj.currentValue);
      }
    },
  };

  const smsField = {
    uniqueID: "smsField",
    form: formFields,
    value: "",
    setValue: (value) => {
      console.log("setValue smsField ", value);
    },
    callBackOnKeyUp: (event, obj) => {
      if (event && event.keyCode == 13) {
        console.log("callBackOnKeyUp Event :" + obj.currentValue);
        validateSms(obj.currentValue);
      }
    },
  };

  const pwd1Field = {
    uniqueID: "pwd1Field",
    form: formFields,
    value: "",
    additionalClass: "password",
    //controlType: "password",
    validation: {
      maxLen: 1,
      type: "Alphanumeric",
    },
    setValue: (value) => {
      console.log("setValue pwd1Field ", value);
    },
    feedback: {
      enable: true,
      component: () => <>* 1 carattere alfanumerico</>,
    },
  };

  const pwd2Field = {
    uniqueID: "pwd2Field",
    form: formFields,
    value: "",
    additionalClass: "password",
    //controlType: "password",
    validation: {
      maxLen: 1,
      type: "Alphanumeric",
    },
    setValue: (value) => {
      console.log("setValue pwd2Field ", value);
      const { currentValue = "" } = value;
      if (currentValue !== "") {
        validatePassword(currentValue);
      }
    },
    callBackOnKeyUp: (event, obj) => {
      if (event && event.keyCode == 13) {
        console.log("callBackOnKeyUp Event :" + obj.currentValue);
        validatePassword(obj.currentValue);
      }
    },
    feedback: {
      enable: true,
      component: () => <>* 1 carattere alfanumerico</>,
    },
  };

  if (authenticationState === "AUTHENTICATED") {
    return (
      <>
        <MySpinner uniqueID={authenticationSpinnerId} />
        <div className="authentication-container">
          <div className="row pb-2">
            <div className=" col-12 authentication-label-text">{`${codice} - ${window.BTFEDictionary["authenticationSuccess"]}`}</div>
          </div>
          {!isNewCustomer && (
            <AuthenticationDropdown title="Cambio Pin">
              <ChangePin
                formFields={formFields}
                codice={codice}
                currentInteraction={currentInteraction}
              />
            </AuthenticationDropdown>
          )}
        </div>
      </>
    );
  } else if (!isNewCustomer) {
    return (
      <div className="authentication-container">
        <>
          <MySpinner uniqueID={authenticationSpinnerId} />
          <AuthenticationLabelValue label="Codice cliente">
            <TextField configuration={ibCodeUsernameField} />
          </AuthenticationLabelValue>
          {authenticationState !== "NOT_AUTHENTICATED" && (
            <AuthenticationLabelValue label="Pin">
              <TextField configuration={pinField} />
            </AuthenticationLabelValue>
          )}
          {authenticationState === "PARTIAL_AUTHENTICATED" &&
            ((nextStep === "TOKEN" && (
              <AuthenticationLabelValue label="Token">
                <TextField configuration={tokenField} />
              </AuthenticationLabelValue>
            )) ||
              (nextStep === "SMS" && (
                <SmsField
                  handleSendSms={sendSms}
                  smsValueFieldConfiguration={smsField}
                />
              )) ||
              (nextStep === "PWD" && (
                <AuthenticationLabelValue label="Password">
                  <div className="row justify-content-center">
                    <div className="col-6 ">
                      <div className="authentication-label">
                        {`Ch: ${pwdPosition1}`}{" "}
                      </div>
                      <div className="authentication-label-text">
                        <TextField configuration={pwd1Field} />
                      </div>
                    </div>
                    <div className="col-6">
                      <div className="authentication-label">{`Ch: ${pwdPosition2}`}</div>
                      <div className="authentication-label-text">
                        <TextField configuration={pwd2Field} />
                      </div>
                    </div>
                  </div>
                </AuthenticationLabelValue>
              )))}
        </>
      </div>
    );
  } else {
    return (
      <div className="authentication-container">
        <>
          <MySpinner uniqueID={authenticationSpinnerId} />
          <AuthenticationLabelValue label="Codice Cliente">
            <TextField configuration={ibCodeUsernameField} />
          </AuthenticationLabelValue>
          {authenticationState !== "NOT_AUTHENTICATED" && (
            <AuthenticationLabelValue label="Token">
              <TextField configuration={newAuthTokenField} />
            </AuthenticationLabelValue>
          )}
          {authenticationState === "PARTIAL_AUTHENTICATED" && (
            <SmsField
              handleSendSms={sendSmsForNewAuth}
              smsValueFieldConfiguration={smsFieldForNewAuth}
            />
          )}
        </>
      </div>
    );
  }
};

export default withErrorBoundary(AutenticazioneContainer);
