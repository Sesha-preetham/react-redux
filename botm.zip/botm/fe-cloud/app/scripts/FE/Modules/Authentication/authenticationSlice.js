import { createSlice } from "@reduxjs/toolkit";

const defaultAuthenticationDataObject = {
  authenticationState: "NOT_AUTHENTICATED", // NOT_AUTHENTICATED ; VALIDATED;  PARTIAL_AUTHENTICATED ; AUTHENTICATED
  isNewCustomer: false,
  nextStep: "",
  pwdPosition1: "",
  pwdPosition2: "",
  flowToken: null,
  authStep: null,
  authKeys: null,
  authToken: null
};

const defaultAuthenticationObject = {};

const initialState = {
  authentication: {
    noInteraction: {
      showAuthenticationModal: false,
      authenticationData: {},
      disableAutenticaButton: false,
    },
  },
};

const authenticationSlice = createSlice({
  name: "authentication",
  initialState,
  reducers: {
    addAuthenticationInteraction(state, action) {
      const { payload = {} } = action;
      const { interactionId = "noInteraction" } = payload;
      if (!interactionId) return;
      if (!state.authentication[interactionId])
        state.authentication[interactionId] =
          initialState.authentication.noInteraction;
    },
    addAuthenticationValueByInteraction(state, action) {
      const { payload = {} } = action;
      const { interactionId = "noInteraction", authValue } = payload;
      if (!state.authentication[interactionId]) return;
      if (state.authentication[interactionId].authenticationData[authValue])
        return;
      state.authentication[interactionId].authenticationData[authValue] = {
        ...defaultAuthenticationDataObject,
      };
    },
    updateAuthenticationPropertyByInteractionAndValue(state, action) {
      const { payload = {} } = action;
      const {
        interactionId = "noInteraction",
        authValue,
        property,
        value,
      } = payload;
      if (!state.authentication[interactionId]) return;
      if (!state.authentication[interactionId].authenticationData[authValue])
        return;
      if (
        state.authentication[interactionId].authenticationData[authValue][
          property
        ] !== undefined
      ) {
        state.authentication[interactionId].authenticationData[authValue][
          property
        ] = value;
      }
    },
    updateAuthenticationPropertiesByInteractionAndValue(state, action) {
      const { payload = {} } = action;
      const {
        interactionId = "noInteraction",
        authValue,
        value = {},
      } = payload;
      if (!state.authentication[interactionId]) return;
      if (!state.authentication[interactionId].authenticationData[authValue])
        return;
      /*for (const [key, val] of Object.entries(value)) {
        if(state.authentication[interactionId].authenticationData[authValue][key]){
          state.authentication[interactionId].authenticationData[authValue][key] = val;
        }
      }*/
      state.authentication[interactionId].authenticationData[authValue] = {
        ...state.authentication[interactionId].authenticationData[authValue],
        ...value
      }
    },
    setShowAuthenticationModalByInteraction(state, action) {
      const { payload = {} } = action;
      const { interactionId = "noInteraction", value = false } = payload;
      if (!state.authentication[interactionId]) return;
      state.authentication[interactionId].showAuthenticationModal = value;
    },
    updateAutenticaButtonStateByInteraction(state, action) {
      const { payload = {} } = action;
      const { interactionId = "noInteraction", value = false } = payload;
      if (!state.authentication[interactionId]) return;
      state.authentication[interactionId].disableAutenticaButton = value;
    },
    clearAuthenticationDataByInteractionAndValue(state, action) {
      const { payload = {} } = action;
      const { interactionId = "noInteraction", authValue } = payload;
      if (!state.authentication[interactionId]) return;
      state.authentication[interactionId].authenticationData = Object.entries(
        state.authentication[interactionId].authenticationData
      ).reduce((acc, [key, value]) => {
        if (key != authValue) {
          acc[key] = value;
        }
        return acc;
      }, {});
    },
    removeAuthenticationDataByInteraction(state, action) {
      const { payload = {} } = action;
      const { interactionId = "noInteraction" } = payload;
      if (!interactionId || !state.authentication[interactionId]) return;
      state.authentication = Object.entries(state.authentication).reduce(
        (acc, [key, value]) => {
          if (key != interactionId) {
            acc[key] = value;
          }
          return acc;
        },
        {}
      );
    },
  },
});

export const getAuthenticationDataByInteractionAndValue = (
  authentication = {}
) => {
  return (id = "noInteraction", authValue) => {
    if (
      authentication[id] &&
      authentication[id].authenticationData[authValue]
    ) {
      return authentication[id].authenticationData[authValue];
    }
    return {};
  };
};

export const getAuthenticationDataByInteraction = (authentication = {}) => {
  return (id = "noInteraction") => {
    if (authentication[id]) {
      return authentication[id];
    }
    return {};
  };
};

export const {
  addAuthenticationInteraction,
  addAuthenticationValueByInteraction,
  updateAuthenticationPropertyByInteractionAndValue,
  updateAuthenticationPropertiesByInteractionAndValue,
  setShowAuthenticationModalByInteraction,
  clearAuthenticationDataByInteractionAndValue,
  updateAutenticaButtonStateByInteraction,
  removeAuthenticationDataByInteraction,
} = authenticationSlice.actions;

export default authenticationSlice.reducer;
