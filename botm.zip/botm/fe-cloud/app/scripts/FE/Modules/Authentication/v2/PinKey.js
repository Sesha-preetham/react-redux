import React, { useContext, useEffect } from "react";
import TextField from "../../../CommonComponents/Forms/TextField";
import AuthenticationLabelValue from "../Common/AuthenticationLabel";
import AuthContext from "./AuthenticationContext";
import { v4 as uuidv4 } from "uuid";

const PinKey = ({ validateValue = () => {}, authKey = {}, id = uuidv4() }) => {
  const { formFields } = useContext(AuthContext);

  const buildAuthKeyRequest = (value) => {
    let localAuthKey = { ...authKey };
    localAuthKey.value = value;
    console.log("Authv2 PinKey buildAuthKeyResponse: ", id, localAuthKey);
    return [localAuthKey];
  };

  const { validated = false, value = "", key = "Pin" } = authKey;

  useEffect(() => {
    if (validated && formFields.getField(key)) {
      formFields.getField(key).theField.setDisabled(true, false);
    }
  }, [validated]);


  const pinField = {
    uniqueID: key,
    form: formFields,
    value: (validated)?"****":value,
    additionalClass: "password",
    //controlType: "password",
    validation: {
      maxLen: 4,
      type: "Numeric",
    },
    feedback: {
      enable: true,
      component: () => <>* 4 cifre</>,
    },
    setValue: (value) => {
      const { currentValue = "" } = value;
      console.log("Authv2 PinKey setValue pinField ", currentValue, formFields.getFields(), id);
    },
    callBackOnKeyUp: (event, obj) => {
      const { currentValue = "" } = obj;
      if (
        currentValue.length === 4 && !validated && !(event && event.keyCode == 13)
      ) {
        console.log("Authv2 PinKey callBackOnKeyUp Event :" + obj.currentValue, id, event);
        validateValue(buildAuthKeyRequest(currentValue));
      }
    },
  };

  return (
    <AuthenticationLabelValue label="Pin">
      <TextField configuration={pinField} />
    </AuthenticationLabelValue>
  );
};

export default PinKey;
