import React from "react";


const AuthenticationLabelValue = (props) => {
    const { additionalClassName = "", label="", colSize = "col-6" } = props;
    return (
        <div className={`row justify-content-center ${additionalClassName}`}>
        <div className={`${colSize} authentication-label-content`}>
            <div className="authentication-label">{`${label}`}</div>
            <div className="authentication-label-text">
                {props.children}
            </div>
        </div>
    </div>
    );
  };
  
  export default AuthenticationLabelValue;