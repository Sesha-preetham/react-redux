import React, { useState } from "react";
import IconCaretDownFill from "../../../CommonComponents/Common/Icons/IconCaretDownFill";
import IconCaretRightFill from "../../../CommonComponents/Common/Icons/IconCaretRightFill";

const AuthenticationDropdown = (props) => {

    const { title = "" } = props;
    const [ showChildren, setShowChildren ] = useState(false);

    return (
        <>
          <div className={`d-flex flex-row flex-fill authentication-dropdown`}>
            <div className="text-center">
              {(showChildren===true)
                ?<IconCaretDownFill configuration={{ className: "caret-arrow", onClick: () => { setShowChildren(!showChildren)}}} />
                :<IconCaretRightFill configuration={{ className: "caret-arrow", onClick: () => { setShowChildren(!showChildren)}}} />
              }
            </div>
            <div className="ml-2">
              <span className="authentication-dropdown-text">{title}</span>
            </div>
          </div>
          {(showChildren)?props.children:null}
        </>
      );
}

export default AuthenticationDropdown;