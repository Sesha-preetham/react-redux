import { beServiceUrls, pureCloudOrigin } from "../../Client/ClientProperties";
import { exposedDispatch } from "../../Store/store";
import HttpClient from "../../Utils/HttpClient";
import { toast } from "react-toastify";
import {
  authenticationSpinnerId,
  globalSpinnerId,
  toggleSpinnerById,
} from "../../CommonComponents/Spinner/spinnerSlice";
import { authenticationAlertId, globalAlertId } from "../../CommonComponents/AlertToast/AlertIdConstants";
import { getBaseErrorMessage } from "../../Utils/CommonUtil";
import { addAuthenticationInteraction, removeAuthenticationDataByInteraction } from "./authenticationSlice";


const authenticationService = () => {
  const authenticationEventListeners = (event) => {
    if (event.origin !== pureCloudOrigin) return;
    let message = JSON.parse(event.data);
    console.log("authenticationEventListeners: ", message);
    const dispatch = exposedDispatch;
    if (message && message.type == "interactionSubscription") {
      let { data: interactionData = {} } = message;
      let { category = "", interaction = {} } = interactionData;

      switch (category) {
        case "add":
          dispatch(addAuthenticationInteraction({ interactionId: interaction.id }));
          break;
        case "change":
          break;
        case "connect":
          break;
        case "disconnect":
          break;
        case "acw":
          break;
        case "deallocate":
          dispatch(
            removeAuthenticationDataByInteraction({
              interactionId: interaction.id,
            })
          );
          break;
        default:
          console.log("No Event Matched");
      }
    }
  };

  return { authenticationEventListeners };
};

export const { authenticationEventListeners } = authenticationService();

export const httpPostAuthV2Init = async (request={}) => {
  let httpClient = new HttpClient();
  httpClient.setUrl(beServiceUrls().authV2Init);
  exposedDispatch(toggleSpinnerById(authenticationSpinnerId));
  let responseData = await httpClient
    .httpPost(request)
    .then((response) => {
      const { status = "", response: validateCodiceResponse = {} } = response;
      exposedDispatch(toggleSpinnerById(authenticationSpinnerId));
      if (status === "OK") {
        return validateCodiceResponse;
      } else {
        toast.warn(getBaseErrorMessage("Warning: ", response), {
          containerId: authenticationAlertId,
        });
      }
      return validateCodiceResponse;
    })
    .catch((error) => {
      exposedDispatch(toggleSpinnerById(authenticationSpinnerId));
      toast.error(getBaseErrorMessage("Error: ", error), {
        containerId: authenticationAlertId,
      });
      return error;
    });
  return responseData;
}


export const httpPostAuthV2Validate = async (request={}) => {
  let httpClient = new HttpClient();
  httpClient.setUrl(beServiceUrls().authV2Validate);
  exposedDispatch(toggleSpinnerById(authenticationSpinnerId));
  let responseData = await httpClient
    .httpPost(request)
    .then((response) => {
      const { status = "", response: validateCodiceResponse = {} } = response;
      exposedDispatch(toggleSpinnerById(authenticationSpinnerId));
      if (status === "OK") {
        return response;
      } else {
        toast.warn(getBaseErrorMessage("Warning: ", response), {
          containerId: authenticationAlertId,
        });
      }
      return response;
    })
    .catch((error) => {
      exposedDispatch(toggleSpinnerById(authenticationSpinnerId));
      toast.error(getBaseErrorMessage("Error: ", error), {
        containerId: authenticationAlertId,
      });
      return error;
    });
  return responseData;
}



export const httpPostAuthV3Init = async (request={}) => {
  let httpClient = new HttpClient();
  httpClient.setUrl(beServiceUrls().authV3Init);
  exposedDispatch(toggleSpinnerById(authenticationSpinnerId));
  let responseData = await httpClient
    .httpPost(request)
    .then((response) => {
      const { status = "", response: validateCodiceResponse = {} } = response;
      exposedDispatch(toggleSpinnerById(authenticationSpinnerId));
      if (status === "OK") {
        return validateCodiceResponse;
      } else {
        toast.warn(getBaseErrorMessage("Warning: ", response), {
          containerId: authenticationAlertId,
        });
      }
      return validateCodiceResponse;
    })
    .catch((error) => {
      exposedDispatch(toggleSpinnerById(authenticationSpinnerId));
      toast.error(getBaseErrorMessage("Error: ", error), {
        containerId: authenticationAlertId,
      });
      return error;
    });
  return responseData;
}


export const httpPostAuthV3Validate = async (request={}) => {
  let httpClient = new HttpClient();
  httpClient.setUrl(beServiceUrls().authV3Validate);
  exposedDispatch(toggleSpinnerById(authenticationSpinnerId));
  let responseData = await httpClient
    .httpPost(request)
    .then((response) => {
      const { status = "", response: validateCodiceResponse = {} } = response;
      exposedDispatch(toggleSpinnerById(authenticationSpinnerId));
      if (status === "OK") {
        return response;
      } else {
        toast.warn(getBaseErrorMessage("Warning: ", response), {
          containerId: authenticationAlertId,
        });
      }
      return response;
    })
    .catch((error) => {
      exposedDispatch(toggleSpinnerById(authenticationSpinnerId));
      toast.error(getBaseErrorMessage("Error: ", error), {
        containerId: authenticationAlertId,
      });
      return error;
    });
  return responseData;
}

export const httpPostAuthV3Federation = async (request={}) => {
  let httpClient = new HttpClient();
  httpClient.setUrl(beServiceUrls().authV3Federation);
  exposedDispatch(toggleSpinnerById(authenticationSpinnerId));
  let responseData = await httpClient
    .httpPost(request)
    .then((response) => {
      const { status = "", response: validateCodiceResponse = {} } = response;
      exposedDispatch(toggleSpinnerById(authenticationSpinnerId));
      if (status === "OK") {
        return response;
      } else {
        toast.warn(getBaseErrorMessage("Warning: ", response), {
          containerId: authenticationAlertId,
        });
      }
      return response;
    })
    .catch((error) => {
      exposedDispatch(toggleSpinnerById(authenticationSpinnerId));
      toast.error(getBaseErrorMessage("Error: ", error), {
        containerId: authenticationAlertId,
      });
      return error;
    });
  return responseData;
}

export const httpPostValidateCodice = async (request = {}) => {
  let httpClient = new HttpClient();
  httpClient.setUrl(beServiceUrls().authValidateCodice);
  exposedDispatch(toggleSpinnerById(authenticationSpinnerId));
  let responseData = await httpClient
    .httpPost(request)
    .then((response) => {
      const { status = "", response: validateCodiceResponse = {} } = response;
      exposedDispatch(toggleSpinnerById(authenticationSpinnerId));
      if (status === "OK") {
        return response;
      } else {
        toast.warn(getBaseErrorMessage("Warning: ", validateCodiceResponse), {
          containerId: authenticationAlertId,
        });
      }
      return response;
    })
    .catch((error) => {
      exposedDispatch(toggleSpinnerById(authenticationSpinnerId));
      toast.error(getBaseErrorMessage("Error: ", error), {
        containerId: authenticationAlertId,
      });
      return error;
    });
  return responseData;
};

export const httpPostValidatePin = async (request = {}) => {
  let httpClient = new HttpClient();
  httpClient.setUrl(beServiceUrls().authValidatePin);
  exposedDispatch(toggleSpinnerById(authenticationSpinnerId));
  let responseData = await httpClient
    .httpPost(request)
    .then((response) => {
      const { status = "", response: validateResponse = {} } = response;
      exposedDispatch(toggleSpinnerById(authenticationSpinnerId));
      if (status === "OK") {
        return response;
      } else {
        toast.warn(getBaseErrorMessage("Warning: ", response), {
          containerId: authenticationAlertId,
        });
      }
      return response;
    })
    .catch((error) => {
      toast.error(getBaseErrorMessage("Error: ", error), {
        containerId: authenticationAlertId,
      });
      return error;
    });
  return responseData;
};

export const httpPostValidatePwd = async (request = {}) => {
  let httpClient = new HttpClient();
  httpClient.setUrl(beServiceUrls().authValidatePwd);
  exposedDispatch(toggleSpinnerById(authenticationSpinnerId));
  let responseData = await httpClient
    .httpPost(request)
    .then((response) => {
      const { status = "", response: validateResponse = {} } = response;
      exposedDispatch(toggleSpinnerById(authenticationSpinnerId));
      if (status === "OK") {
        return response;
      } else {
        toast.warn(getBaseErrorMessage("Warning: ", response), {
          containerId: authenticationAlertId,
        });
      }
      return response;
    })
    .catch((error) => {
      toast.error(getBaseErrorMessage("Error: ", error), {
        containerId: authenticationAlertId,
      });
      return error;
    });
  return responseData;
};

export const httpPostValidateToken = async (request = {}) => {
  let httpClient = new HttpClient();
  httpClient.setUrl(beServiceUrls().authValidateToken);
  exposedDispatch(toggleSpinnerById(authenticationSpinnerId));
  let responseData = await httpClient
    .httpPost(request)
    .then((response) => {
      const { status = "", response: validateResponse = {} } = response;
      exposedDispatch(toggleSpinnerById(authenticationSpinnerId));
      if (status === "OK") {
        return response;
      } else {
        toast.warn(getBaseErrorMessage("Warning: ", response), {
          containerId: authenticationAlertId,
        });
      }
      return response;
    })
    .catch((error) => {
      toast.error(getBaseErrorMessage("Error: ", error), {
        containerId: authenticationAlertId,
      });
      return error;
    });
  return responseData;
};

export const httpPostSendValidateSms = async (request = {}) => {
  let httpClient = new HttpClient();
  httpClient.setUrl(beServiceUrls().authValidateSms);
  exposedDispatch(toggleSpinnerById(authenticationSpinnerId));
  let responseData = await httpClient
    .httpPost(request)
    .then((response) => {
      const { status = "", response: validateResponse = {} } = response;
      exposedDispatch(toggleSpinnerById(authenticationSpinnerId));
      if (status === "OK") {
        return response;
      } else {
        toast.warn(getBaseErrorMessage("Warning: ", response), {
          containerId: authenticationAlertId,
        });
      }
      return response;
    })
    .catch((error) => {
      toast.error(getBaseErrorMessage("Error: ", error), {
        containerId: authenticationAlertId,
      });
      return error;
    });
  return responseData;
};

export const httpPostValidateTokenForNewAuth = async (request = {}) => {
  let httpClient = new HttpClient();
  httpClient.setUrl(beServiceUrls().authValidateTokenForNewAuth);
  exposedDispatch(toggleSpinnerById(authenticationSpinnerId));
  let responseData = await httpClient
    .httpPost(request)
    .then((response) => {
      const { status = "", response: validateResponse = {} } = response;
      exposedDispatch(toggleSpinnerById(authenticationSpinnerId));
      if (status === "OK") {
        return response;
      } else {
        toast.warn(getBaseErrorMessage("Warning: ", response), {
          containerId: authenticationAlertId,
        });
      }
      return response;
    })
    .catch((error) => {
      toast.error(getBaseErrorMessage("Error: ", error), {
        containerId: authenticationAlertId,
      });
      return error;
    });
  return responseData;
}

export const httpPostSendOtpSms = async (request = {})=> {
    let httpClient = new HttpClient();
  httpClient.setUrl(beServiceUrls().authSendSmsOtpRequest);
  exposedDispatch(toggleSpinnerById(authenticationSpinnerId));
  let responseData = await httpClient
    .httpPost(request)
    .then((response) => {
      const { status = "", response: validateResponse = {} } = response;
      exposedDispatch(toggleSpinnerById(authenticationSpinnerId));
      if (status === "OK") {
        return response;
      } else {
        toast.warn(getBaseErrorMessage("Warning: ", response), {
          containerId: authenticationAlertId,
        });
      }
      return response;
    })
    .catch((error) => {
      toast.error(getBaseErrorMessage("Error: ", error), {
        containerId: authenticationAlertId,
      });
      return error;
    });
  return responseData;
}

export const httpPostValidateOtpSms = async (request = {})=> {
  let httpClient = new HttpClient();
  httpClient.setUrl(beServiceUrls().authValidateSmsOtpRequest);
  exposedDispatch(toggleSpinnerById(authenticationSpinnerId));
  let responseData = await httpClient
    .httpPost(request)
    .then((response) => {
      const { status = "", response: validateResponse = {} } = response;
      exposedDispatch(toggleSpinnerById(authenticationSpinnerId));
      if (status === "OK") {
        return response;
      } else {
        toast.warn(getBaseErrorMessage("Warning: ", response), {
          containerId: authenticationAlertId,
        });
      }
      return response;
    })
    .catch((error) => {
      toast.error(getBaseErrorMessage("Error: ", error), {
        containerId: authenticationAlertId,
      });
      return error;
    });
  return responseData;
}

export const httpPostChangePin = async (request = {} ) => {
  let httpClient = new HttpClient();
  httpClient.setUrl(beServiceUrls().authChangePin);
  exposedDispatch(toggleSpinnerById(authenticationSpinnerId));
  let responseData = await httpClient
    .httpPost(request)
    .then((response) => {
      const { status = "", response: validateResponse = {} } = response;
      exposedDispatch(toggleSpinnerById(authenticationSpinnerId));
      if (status === "OK") {
        return response;
      } else {
        toast.warn(getBaseErrorMessage("Warning: ", response), {
          containerId: authenticationAlertId,
        });
      }
      return response;
    })
    .catch((error) => {
      toast.error(getBaseErrorMessage("Error: ", error), {
        containerId: authenticationAlertId,
      });
      return error;
    });
  return responseData;
}

export const httpPutAuthenticationState = async (request = {}) => {
  let httpClient = new HttpClient();
  httpClient.setUrl(beServiceUrls().authUpdateState);
  exposedDispatch(toggleSpinnerById(globalSpinnerId));
  let responseData = await httpClient.httpPut(request).then( response => {
    const { status = "" } = response;
      exposedDispatch(toggleSpinnerById(globalSpinnerId));
      if (status === "OK") {
        return response;
      } else {
        toast.warn(getBaseErrorMessage("Warning: ", response), {
          containerId: globalAlertId,
        });
      }
      return response;
    })
    .catch((error) => {
      toast.error(getBaseErrorMessage("Error: ", error), {
        containerId: globalAlertId,
      });
      return error;
    });
    return responseData;
}