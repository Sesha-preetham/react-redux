import React, { useContext, useEffect } from "react";
import TextField from "../../../CommonComponents/Forms/TextField";
import AuthenticationLabelValue from "../Common/AuthenticationLabel";
import AuthContext from "./AuthenticationContext";

const PwdTwoChar = ({ validateValue = () => {}, authKey = {} }) => {
  const { formFields } = useContext(AuthContext);

  const { validated = false } = authKey;

  useEffect(() => {
    ["pwd1Field", "pwd2Field"].forEach( field => {
      if (validated && formFields.getField(field)) {
        formFields.getField(field).theField.setDisabled(true);
        if (!formFields.getValue(field)) {
          formFields.getField(field).theField.setValue("*");
        }
      }
    })
    
  }, [validated]);

  const buildAuthKeyRequest = () => {
    let pwd1 = formFields.getValue("pwd1Field");
    let pwd2 = formFields.getValue("pwd2Field");
    let localAuthKey = { ...authKey };
    if (pwd1 && pwd2) localAuthKey.value = pwd1 + pwd2;
    console.log("Authv2 buildAuthKeyRequest: ", localAuthKey);
    return [localAuthKey];
  };

  const getPositionFromKey = (pos) => {
    console.log("Authv2 getPositionFromKey - ", authKey, pos);
    let { key: keyValue } = authKey;
    let position = -1;
    try {
      if (keyValue) {
        let positions = keyValue.split(":")[1].trim();
        position = positions.split(",")[pos];
      }
    } catch (e) {
      console.error(
        "Authv2 Error extracting position, getPositionFromKey",
        pos,
        keyValue,
        e
      );
    }
    return position;
  };

  const pwd1Field = {
    uniqueID: "pwd1Field",
    form: formFields,
    value: "",
    additionalClass: "password",
    //controlType: "password",
    validation: {
      maxLen: 1,
      type: "Alphanumeric",
    },
    setValue: (value) => {
      console.log("setValue pwd1Field ", value);
    },
    feedback: {
      enable: true,
      component: () => <>* 1 carattere alfanumerico</>,
    },
  };

  const pwd2Field = {
    uniqueID: "pwd2Field",
    form: formFields,
    value: "",
    additionalClass: "password",
    //controlType: "password",
    validation: {
      maxLen: 1,
      type: "Alphanumeric",
    },
    callBackOnKeyUp: (event, obj) => {
      if (event && event.keyCode == 13) {
        console.log("Authv2 pwd2Field callBackOnKeyUp :" + obj.currentValue);
        validateValue(buildAuthKeyRequest());
      }
    },
    feedback: {
      enable: true,
      component: () => <>* 1 carattere alfanumerico</>,
    },
  };

  return (
    <AuthenticationLabelValue label="Password">
      <div className="row justify-content-center">
        <div className="col-6 ">
          <div className="authentication-label">
            {`Ch: ${getPositionFromKey(0)}`}{" "}
          </div>
          <div className="authentication-label-text">
            <TextField configuration={pwd1Field} />
          </div>
        </div>
        <div className="col-6">
          <div className="authentication-label">{`Ch: ${getPositionFromKey(
            1
          )}`}</div>
          <div className="authentication-label-text">
            <TextField configuration={pwd2Field} />
          </div>
        </div>
      </div>
    </AuthenticationLabelValue>
  );
};

export default PwdTwoChar;
