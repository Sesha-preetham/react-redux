import React from "react";
import { toast } from "react-toastify";
import { authenticationAlertId } from "../../CommonComponents/AlertToast/AlertIdConstants";
import FormFieldHandler from "../../CommonComponents/Forms/FormFieldHandler";
import TextField from "../../CommonComponents/Forms/TextField";
import { getBaseErrorMessage } from "../../Utils/CommonUtil";
import AuthenticationLabelValue from "./Common/AuthenticationLabel";
import { httpPostChangePin } from "./Service";


const ChangePin = (props) => {

    const { formFields = new FormFieldHandler(), codice = "", currentInteraction = "" } = props;

    const changePin = () => {
        const oldPin = formFields.getField("oldPinField").theField.getValue();
        const newPin =  formFields.getField("newPinField").theField.getValue();
        const newPinConfirm =  formFields.getField("newPinConfirmField").theField.getValue();
        httpPostChangePin({
            interactionId: currentInteraction,
            codice: codice,
            oldPin: oldPin,
            newPin, newPin,
            newPinConfirmation: newPinConfirm
        }).then(response => {
            const { status = "" } = response;
            if(status === "OK"){
                toast.success(window.BTFEDictionary["changePinSuccess"], {containerId: authenticationAlertId});
            }else{
                toast.warn(getBaseErrorMessage("Warning: ", response), {containerId: authenticationAlertId});
            }
        })
    }

    const oldPinField = {
        uniqueID: "oldPinField",
        form: formFields,
        value: "",
        additionalClass: "password",
        //controlType: "password",
        validation: {
          maxLen: 4,
          type: "Numeric",
        },
        feedback: {
          enable: true,
          component: () => <>* 4 cifre</>,
        },
        setValue: (value) => {},
        callBackOnKeyUp: (event, obj) => {}
    }
    
    const newPinField = {
        uniqueID: "newPinField",
        form: formFields,
        value: "",
        //controlType: "password",
        additionalClass: "password",
        validation: {
          maxLen: 4,
          type: "Numeric",
        },
        feedback: {
          enable: true,
          component: () => <>* 4 cifre</>,
        },
        setValue: (value) => {},
        callBackOnKeyUp: (event, obj) => {}
    }

    const newPinConfirmField = {
        uniqueID: "newPinConfirmField",
        form: formFields,
        value: "",
        //controlType: "password",
        additionalClass: "password",
        validation: {
          maxLen: 4,
          type: "Numeric",
        },
        feedback: {
          enable: true,
          component: () => <>* 4 cifre</>,
        },
        setValue: (value) => {},
        callBackOnKeyUp: (event, obj) => {
            const { currentValue = "" } = obj;
            if (
                (event && event.keyCode == 13 && currentValue.length === 4) ||
                currentValue.length === 4
            ) {
                console.log("callBackOnKeyUp Event :" + obj.currentValue);
                changePin();
            }
        }
    }


    return (
        <div className="authentication-change-pin-container" >
            <div className="row justify-content-center">
                <div className="col-4"> 
                    <AuthenticationLabelValue colSize="col-12" label="Pin vecchio" >
                        <TextField configuration={oldPinField} />
                    </AuthenticationLabelValue>
                </div>
                <div className="col-4">
                    <AuthenticationLabelValue colSize="col-12" label="Pin nuovo" >
                        <TextField configuration={newPinField} />
                    </AuthenticationLabelValue>
                </div>
                <div className="col-4"> 
                    <AuthenticationLabelValue colSize="col-12" label="Conferma pin" >
                        <TextField configuration={newPinConfirmField} />
                    </AuthenticationLabelValue>
                </div>
            </div>
        </div>
    )
}

export default ChangePin;
