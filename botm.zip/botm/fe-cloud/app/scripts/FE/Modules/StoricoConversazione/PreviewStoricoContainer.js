import React from "react";
import { useSelector } from "react-redux";
import { CSSTransition } from "react-transition-group";
import {
  getDisplayDataByCode,
  storicoConversazioneWidgetCode,
} from "../Widgets/widgetsSlice";
import WidgetTitle from "../Widgets/WidgetTitle";
import WidgetWrapper from "../Widgets/WidgetWrapper";

const PreviewStoricoContainer = (props) => {
  const { widgets } = useSelector((state) => state.widgets);
  const [
    storicoConversazioneMenuShow,
    storicoConversazioneShow,
  ] = getDisplayDataByCode(widgets)(storicoConversazioneWidgetCode);

  return (
    <WidgetWrapper widgetShow={storicoConversazioneShow}>
      <CSSTransition
        in={storicoConversazioneMenuShow}
        timeout={300}
        classNames="slide-left-toggle"
        unmountOnExit={false}
        mountOnEnter={true}
      >
        <div className="section-conversation d-flex flex-column h-100 mt-3">
          <WidgetTitle title="Storico Conversazione" />
          <div>This is Storico Conversazione Content</div>
        </div>
      </CSSTransition>
    </WidgetWrapper>
  );
};

export default PreviewStoricoContainer;
