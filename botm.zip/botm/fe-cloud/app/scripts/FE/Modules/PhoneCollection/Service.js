import { pureCloudOrigin } from "../../Client/ClientProperties";
import { exposedDispatch } from "../../Store/store";
import {
  addInteractionToEsito,
  removeInteractionFromEsito,
  disconnectEsitoInteraction,
} from "./phoneCollectionSlice";


const phoneCollectionService = () => {
  const phoneCollectionEventListeners = (event) => {
    if (event.origin !== pureCloudOrigin) return;
    let message = JSON.parse(event.data);
    console.log("phoneCollectionEventListeners: ", message);
    const dispatch = exposedDispatch;
    if (message && message.type == "interactionSubscription") {
      let { data: interactionData = {} } = message;
      let { category = "", interaction = {} } = interactionData;

      switch (category) {
        case "add":
          dispatch(addInteractionToEsito({ id: interaction.id }));
          break;
        case "change":
          break;
        case "connect":
          break;
        case "disconnect":
            dispatch(
                disconnectEsitoInteraction({
                  interactionId: interaction.id,
                  isDisconnected: true
                })
              );
          break;
        case "acw":
          break;
        case "deallocate":
          dispatch(
            removeInteractionFromEsito({
              id: interaction.id,
            })
          );
          break;
        default:
          console.log("No Event Matched");
      }
    }
  };

  return { phoneCollectionEventListeners };
};

export const { phoneCollectionEventListeners } = phoneCollectionService();
