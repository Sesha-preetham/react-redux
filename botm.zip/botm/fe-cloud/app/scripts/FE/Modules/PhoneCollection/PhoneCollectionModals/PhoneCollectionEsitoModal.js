import React from "react";
import MyModal from "../../../CommonComponents/Modal/MyModal";
import { v4 as uuidv4 } from "uuid";
import EsitoWidgetMain from "../EsitoWidgetComponents/EsitoWidgetMain";

const PhoneCollectionEsitoModal = (props) => {

  const {
    showModal = false,
    handleOnCloseModal = () => {},
    modalTitle,
    } = props;

    const esitoModal = {
        uniqueID: uuidv4(),
        modalClass: "my-modal authentication-modal",
        dialogClassName: "modal-w",
        modalBodyClass: "my-modal-body modal-h",
        title: {
          content: modalTitle,
          class: "widget-title",
        },
        modalShow: showModal,
        modalHeaderShow: true,
        backdrop: {
          enable: true,
        },
        events: {
          onHide: () => {
            handleOnCloseModal(false);
          },
          onEntered: () => {
            console.log("Confirmation modal onEntered");
          },
          onExited: () => {
            console.log("Confirmation modal onExited");
          },
        },
      };

    return (
      <MyModal configuration={esitoModal}>
          <EsitoWidgetMain type="Modal"  currentInteraction = "noInteraction" />
      </MyModal>
    );
}

export default PhoneCollectionEsitoModal;