import React, { useEffect, useState, useRef } from "react";
import { useDispatch, useSelector } from "react-redux";
import FormFieldHandler from "../../../CommonComponents/Forms/FormFieldHandler";
import DateField from "../../../CommonComponents/Forms/DateField";
import { globalSpinnerId, toggleSpinnerById } from "../../../CommonComponents/Spinner/spinnerSlice";
import {
  stackExpand,
  stackNavPop,
  stackPreview,
} from "../../../Main/StackNavigation/stackNavigationSlice";

import {
  esitoSetBlockPhoneVal,
  esitoSetContrCredVal,
  esitoSetRecipientVal,
  esitoSetEndDateVal,

  checkBlockPhoneValSet,
  checkContrCredValSet,
  checkNewRecipientValSet,
  checkactionEndDateValSet,

  getEsitoDataByInteraction,
} from "../../PhoneCollection/phoneCollectionSlice";

const EsitoDateComponent = (props) => {

  let {componentType , currentInteraction, esitoDateParameters} = props;

  let yesterday = new Date
  let checkDate = yesterday.setDate(yesterday.getDate() - 1);

  const currentInteractionRef = useRef();
  currentInteractionRef.current = currentInteraction;

  let {
    blockPhoneVisible=false,
    blockPhoneEditable=false,
    blockPhoneMaxDate= null,

    blockContrCredVisible=  false,
    blockContrCredEditable= false,
    blockContrCredMaxDate= null,

    newRecipientVisible=  false,
    newRecipientEditable= false,
    newRecipientMaxDate=  null,

    actionEndDateVisible=  false,
    actionEndDateEditable= false,
    actionEndDateMaxDate=  null,
} = esitoDateParameters;

const currentEsitoDateParameters = useRef();
currentEsitoDateParameters.current = esitoDateParameters

const { esitoObjects={}  } = useSelector((state) => state.phoneCollection);

const {
    dateFromNumDaysBlockPhoneVal,
    dateFromNumDaysContrCredVal ,
    dateFromNumDaysNewRecipientVal ,
    actionEndDateVal,
  } = getEsitoDataByInteraction(esitoObjects)(currentInteractionRef.current);

  const [formFields] = useState(new FormFieldHandler(true));


  const phoneCollectionLayoutType = useSelector((state) => state.phoneCollection.phoneCollectionLayoutType);

  const [ bloccoPhoneWarning , setBloccoPhoneWarning ] = useState(false);
  const [ bloccoCreditiWarning , setBloccoCreditiWarning ] = useState(false);
  const [ assegnazioneWarning, setAssegnazioneWarning ] = useState(false);
  const [ dataScadenzaWarning, setDataScadenzaWarning ] = useState(false);


  const dispatch = useDispatch();


  useEffect(() => {
      dateDecider(currentEsitoDateParameters.current );
  }, [currentEsitoDateParameters.current ]);

  let dateDecider = (params) => {

    let {
        blockPhoneVisible=false,
        blockPhoneEditable=false,
        blockPhoneMaxDate= null,

        blockContrCredVisible=  false,
        blockContrCredEditable= false,
        blockContrCredMaxDate= null,
    
        newRecipientVisible=  false,
        newRecipientEditable= false,
        newRecipientMaxDate=  null,
    
        actionEndDateVisible=  false,
        actionEndDateEditable= false,
        actionEndDateMaxDate=  null,
    } = params;

    dispatch(toggleSpinnerById(globalSpinnerId));

      if(!blockPhoneVisible){
        dispatch( esitoSetBlockPhoneVal({  interactionId: currentInteractionRef.current, selectedBlockPhoneVal: null}));
      }
      else if(blockPhoneVisible && blockPhoneMaxDate && !blockPhoneEditable){
        let today = new Date;
        let toSetbloccoPhoneVal = today.setDate(today.getDate()+  blockPhoneMaxDate);
        formFields.getField("bloccoPhoneCollectionDate").theField.setValue(new Date(toSetbloccoPhoneVal));
      }
      else if(blockPhoneVisible && blockPhoneMaxDate && blockPhoneEditable){
        formFields.getField("bloccoPhoneCollectionDate").theField.setValue(new Date());
      }

      if(!blockContrCredVisible){
        dispatch( esitoSetContrCredVal({  interactionId: currentInteractionRef.current, selectedCredVal: null}))
      }
      else if(blockContrCredVisible && blockContrCredMaxDate && !blockContrCredEditable){
        let today = new Date;
        let blockCredVal = today.setDate(today.getDate()+  blockContrCredMaxDate);
        formFields.getField("bloccoCreditiDate").theField.setValue(new Date(blockCredVal));
      }
      else if(blockContrCredVisible && blockContrCredMaxDate && blockContrCredEditable){
        formFields.getField("bloccoCreditiDate").theField.setValue(new Date());
      }

      if(!newRecipientVisible){
        dispatch( esitoSetRecipientVal({ interactionId: currentInteractionRef.current, selectedRecipientVal: null}))
      }
      else if(newRecipientVisible && newRecipientMaxDate && !newRecipientEditable){
        let today = new Date;
        let newRecepientVal = today.setDate(today.getDate()+  newRecipientMaxDate);
        formFields.getField("assegnazioneDate").theField.setValue(new Date(newRecepientVal));
      }
      else if(newRecipientVisible && newRecipientMaxDate && newRecipientEditable){
        formFields.getField("assegnazioneDate").theField.setValue(new Date());
      }

      if(!actionEndDateVisible){
        dispatch( esitoSetEndDateVal({ interactionId: currentInteractionRef.current,selectedEndDateVal: null}))
      }
      else if(actionEndDateVisible && actionEndDateMaxDate && !actionEndDateEditable){
        let today = new Date;
        let actionEndVal = today.setDate(today.getDate()+  actionEndDateMaxDate);
        formFields.getField("dataScadenzaDate").theField.setValue(new Date(actionEndVal));
      }
      else if(actionEndDateVisible && actionEndDateMaxDate && actionEndDateEditable){
        formFields.getField("dataScadenzaDate").theField.setValue(new Date());
      }

    dispatch(toggleSpinnerById(globalSpinnerId));
  };




  const bloccoPhoneCollectionDate = {
    uniqueID: "bloccoPhoneCollectionDate",
    format:"dd/MM/yyyy",
    form: formFields,
    showTime: false,
   // value: dateFromNumDaysBlockPhoneVal ? dateFromNumDaysBlockPhoneVal : new Date(),
    setValue: (value) => {
      const { currentValue } = value;
      let today = new Date;
      let maxBlockDate = today.setDate(today.getDate()+  currentEsitoDateParameters.current.blockPhoneMaxDate+1);
      if( new Date(currentValue).getTime()  < new Date(maxBlockDate).getTime() &&  new Date(currentValue).getTime() > new Date(checkDate).getTime()){
      dispatch( esitoSetBlockPhoneVal({ interactionId: currentInteractionRef.current,selectedBlockPhoneVal: currentValue}));
      setBloccoPhoneWarning(false);
      }
      else {
      setBloccoPhoneWarning(true);
      dispatch( checkBlockPhoneValSet({ interactionId: currentInteractionRef.current,setCheckBlockPhoneVal: false}));
      }
    },
  };
    

  
  const bloccoCreditiDate = {
    uniqueID: "bloccoCreditiDate",
    //value: dateFromNumDaysContrCredVal  ? dateFromNumDaysContrCredVal : new Date(),
    form: formFields,
    format:"dd/MM/yyyy",
    showTime: false,
    setValue: (value) => {
      const { currentValue } = value;
      let today = new Date;
      let maxblockContrCred = today.setDate(today.getDate()+ currentEsitoDateParameters.current.blockContrCredMaxDate+1);
      if( new Date(currentValue).getTime()  < new Date(maxblockContrCred).getTime()  &&  new Date(currentValue).getTime() > new Date(checkDate).getTime()){
        dispatch( esitoSetContrCredVal({ interactionId: currentInteractionRef.current,selectedCredVal: currentValue}))
        setBloccoCreditiWarning(false);
      }
      else {
        setBloccoCreditiWarning(true);
        dispatch( checkContrCredValSet({ interactionId: currentInteractionRef.current,setCheckContrCredVal: false}))
      }
    },
  };

  const assegnazioneDate = {
    uniqueID: "assegnazioneDate",
    //value: dateFromNumDaysNewRecipientVal ? dateFromNumDaysNewRecipientVal : new Date(),
    format:"dd/MM/yyyy",
    form: formFields,
    showTime: false,
    setValue: (value) => {
      const { currentValue } = value;
      let today = new Date;
      let maxNewRecepient = today.setDate(today.getDate()+  currentEsitoDateParameters.current.newRecipientMaxDate+1);
      if( new Date(currentValue).getTime()  < new Date(maxNewRecepient).getTime()  &&  new Date(currentValue).getTime() > new Date(checkDate).getTime()){
        dispatch( esitoSetRecipientVal({ interactionId: currentInteractionRef.current,selectedRecipientVal: currentValue}))
        setAssegnazioneWarning(false);
      }
      else {
        setAssegnazioneWarning(true);
        dispatch( checkNewRecipientValSet({ interactionId: currentInteractionRef.current,setCheckNewRecipientVal: false}))
      }

    },
  };

  const dataScadenzaDate = {
    uniqueID: "dataScadenzaDate",
   // value: actionEndDateVal ? actionEndDateVal : new Date(),
    form: formFields,
    format:"dd/MM/yyyy",
    showTime: false,
    setValue: (value) => {
      const { currentValue } = value;
      let today = new Date;
      let maxActionEnd = today.setDate(today.getDate()+  currentEsitoDateParameters.current.actionEndDateMaxDate+1);
      if( new Date(currentValue).getTime()  < new Date(maxActionEnd).getTime()  &&  new Date(currentValue).getTime() > new Date(checkDate).getTime()){
        dispatch( esitoSetEndDateVal({ interactionId: currentInteractionRef.current, selectedEndDateVal: currentValue}))
        setDataScadenzaWarning(false);
      }
      else {
        setDataScadenzaWarning(true);
        dispatch( checkactionEndDateValSet({ interactionId: currentInteractionRef.current,setCheckactionEndDateVal: false}))
      }

    },
  };


  return (

    (phoneCollectionLayoutType == stackExpand)
    ?
      <>
        <div className="d-flex flex-row mb-3">
{ blockPhoneVisible &&
          <div className="d-flex flex-column w-50">
            <div className={(blockPhoneEditable) ? " btdatepicker hand-cursor " : " btdatepicker hand-cursor-not-allowed "}>
            <div className="small-content-label-class">Blocco invio PhoneCollection</div>
                <div className="flex-fill w-75">
                    <DateField configuration={bloccoPhoneCollectionDate} />
                </div>
                {bloccoPhoneWarning ? <p className="text-red">*seleziona massimo {blockPhoneMaxDate} giorni da oggi</p> :<></>}
          </div>
          </div>
          }

{ blockContrCredVisible &&
          <div className="d-flex flex-column w-50">
            <div className={(blockContrCredEditable) ? " btdatepicker hand-cursor " : " btdatepicker hand-cursor-not-allowed "}>
            <div className="small-content-label-class">Blocco invio controllo crediti</div>
                <div className="flex-fill w-75">
                    <DateField configuration={bloccoCreditiDate} />
                </div>
                {bloccoCreditiWarning ? <p className="text-red">*seleziona massimo {blockContrCredMaxDate} giorni da oggi</p> :<></>}
          </div>
          </div>
          }

{ newRecipientVisible &&
          <div className="d-flex flex-column w-50">
            <div className={(newRecipientEditable) ? " btdatepicker hand-cursor " : " btdatepicker hand-cursor-not-allowed "}>
            <div className="small-content-label-class">Assegnazione temporanea ruolo</div>
                <div className="flex-fill w-75">
                    <DateField configuration={assegnazioneDate} />
                </div>
                {assegnazioneWarning ? <p className="text-red">*seleziona massimo {newRecipientMaxDate} giorni da oggi</p> :<></>}
          </div>
          </div>
          }

{ actionEndDateVisible &&
          <div className="d-flex flex-column w-50">
            <div className={(actionEndDateEditable) ? " btdatepicker hand-cursor " : " btdatepicker hand-cursor-not-allowed "}>
            <div className="small-content-label-class">Data scadenza</div>
                <div className="flex-fill w-75">
                    <DateField configuration={dataScadenzaDate} />
                </div>
                {dataScadenzaWarning ? <p className="text-red">*seleziona massimo {actionEndDateMaxDate} giorni da oggi</p> :<></>}
          </div>
          </div>
          }

        </div>
    </>

    :
    <>

      <div className="d-flex flex-row mb-3 flex-wrap ">
{ blockPhoneVisible &&
          <div className="d-flex flex-column w-50 slide-left-toggle mt-2">
            <div className={(blockPhoneEditable) ? "btdatepicker hand-cursor " : "btdatepicker hand-cursor-not-allowed "}>
            <div className="small-content-label-class">Blocco invio PhoneCollection</div>
                <div  className=" flex-fill w-75  ">
                    <DateField configuration={bloccoPhoneCollectionDate} />
                </div>
                {bloccoPhoneWarning ? <p className="text-red">*seleziona massimo {blockPhoneMaxDate} giorni da oggi</p> :<></>}
          </div>
          </div>
          }

{ blockContrCredVisible &&
          <div className="d-flex flex-column w-50 slide-left-toggle mt-2">
            <div className={(blockContrCredEditable) ? "btdatepicker hand-cursor " : "btdatepicker hand-cursor-not-allowed "}>
            <div className="small-content-label-class">Blocco invio controllo crediti</div>
                <div  className=" flex-fill w-75  ">
                    <DateField configuration={bloccoCreditiDate} />
                </div>
                {bloccoCreditiWarning ? <p className="text-red">*seleziona massimo {blockContrCredMaxDate} giorni da oggi</p> :<></>}
          </div>
          </div>
          }

{ newRecipientVisible &&
          <div className="d-flex flex-column w-50 slide-left-toggle mt-2">
            <div className={(newRecipientEditable) ? "btdatepicker hand-cursor " : "btdatepicker hand-cursor-not-allowed "}>
            <div className="small-content-label-class">Assegnazione temporanea ruolo</div>
                <div  className=" flex-fill w-75  ">
                    <DateField configuration={assegnazioneDate} />
                </div>
                {assegnazioneWarning ? <p className="text-red">*seleziona massimo {newRecipientMaxDate} giorni da oggi</p> :<></>}
          </div>
          </div>
          }

{ actionEndDateVisible &&
          <div className="d-flex flex-column w-50 slide-left-toggle mt-2">
            <div className={(actionEndDateEditable) ? "btdatepicker hand-cursor " : "btdatepicker hand-cursor-not-allowed "}>
            <div className="small-content-label-class">Data scadenza</div>
                <div  className=" flex-fill w-75  ">
                    <DateField configuration={dataScadenzaDate} />
                </div>
                {dataScadenzaWarning ? <p className="text-red">*seleziona massimo {actionEndDateMaxDate} giorni da oggi</p> :<></>}
          </div>
          </div>
          }
        </div>

    </>

  );
};

export default EsitoDateComponent;
