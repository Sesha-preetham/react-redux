import React,{useRef} from "react";
import { useDispatch , useSelector} from "react-redux";
import IconBlueClose from "../../../CommonComponents/Common/Icons/IconBlueClose";
import {
  stackExpand,
  stackNavPop,
  stackPreview,
} from "../../../Main/StackNavigation/stackNavigationSlice";
import ExpandedWidgetWrapper from "../../Widgets/ExpandedWidgetWrapper";
import WidgetTitle from "../../Widgets/WidgetTitle";
import {
  updatePhoneCollectionLayout,
} from "../phoneCollectionSlice";
import EsitoWidgetMain from "../EsitoWidgetComponents/EsitoWidgetMain";
import EsitoCRMWidgetMain from "../../PhoneCollectionCRM/EsitoWidgetCRMComponents/EsitoCRMWidgetMain";
import { getInteractionDetails } from "../../../Modules/Interaction/interactionSlice";

const ExpandEsitoWidgetContainer = (props) => {
  const { elStack = {} } = props;
  const dispatch = useDispatch();
  const { currentInteraction = "noInteraction",  interactions = [] } = useSelector(
    (state) => state.interaction
  );

  const currentInteractionRef = useRef();
  currentInteractionRef.current = currentInteraction;

  const { attributes = {} } = getInteractionDetails(interactions)(currentInteractionRef.current);

  let handleOnStackMounted = (stack) => {
    dispatch(updatePhoneCollectionLayout(stackExpand));
  };

  let handleOnStackUnMounted = (stack) => {
    dispatch(updatePhoneCollectionLayout(stackPreview));
  };

  let handleOnStackClose = () => {
    dispatch(stackNavPop());
  };

  return (
    <ExpandedWidgetWrapper
      className={"consult-expand-main-container"}
      elStack={elStack}
      events={{
        handleOnStackMounted,
        handleOnStackUnMounted,
      }}
    >
      <WidgetTitle
        title="Esito Contatto"
        iconElement={
          <IconBlueClose
            configuration={{
              onClick: (active) => {
                handleOnStackClose();
              },
            }}
          />
        }
      />
      {attributes["subsystem"] && attributes["subsystem"] == "CRM" ? (
        <EsitoCRMWidgetMain
          type="Widget"
          currentInteraction={currentInteractionRef.current}
        />
      ) : attributes["subsystem"] && attributes["subsystem"] == "PEG" ? (
        <EsitoWidgetMain
          type="Widget"
          currentInteraction={currentInteractionRef.current}
        />
      ) : (
        <></>
      )}
    </ExpandedWidgetWrapper>
  );
};

export default ExpandEsitoWidgetContainer;
