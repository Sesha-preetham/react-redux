import React, { useEffect, useState, useRef } from "react";
import { toast } from "react-toastify";
import { useDispatch, useSelector } from "react-redux";
import IconBlueClose from "../../CommonComponents/Common/Icons/IconBlueClose";
import FormFieldHandler from "../../CommonComponents/Forms/FormFieldHandler";
import SelectField from "../../CommonComponents/Forms/SelectField";
import DateField from "../../CommonComponents/Forms/DateField";
import SimpleTable from "../../CommonComponents/SimpleTable/SimpleTable";
import MySpinner from "../../CommonComponents/Spinner/MySpinner";
import { stackNavPop } from "../../Main/StackNavigation/stackNavigationSlice";
import ExpandedWidgetWrapper from "../Widgets/ExpandedWidgetWrapper";
import {
  getDisplayDataByCode,
  phoneCollectionWidgetCode,
  updateWidgetMenuEventByCode,
  getMainWidgetConfigByIdAndCode,
} from "../Widgets/widgetsSlice";
import WidgetTitle from "../Widgets/WidgetTitle";
import WidgetWrapper from "../Widgets/WidgetWrapper";
import AlertToast from "../../CommonComponents/AlertToast/AlertToast";
import {phoneCollectionAlertId }from "../../CommonComponents/AlertToast/AlertIdConstants";
import { globalSpinnerId, toggleSpinnerById, phoneCollectionPEGSpinnerId } from "../../CommonComponents/Spinner/spinnerSlice";
import { reduceToOptions, getBaseErrorMessage } from "../../Utils/CommonUtil";
import MyPopover from "../../CommonComponents/Popover/MyPopover";
import IconOptions from "../../CommonComponents/Common/Icons/IconOptions";

import {
  setAssegnatiCDRResponse,
  setPCAgentResponse,
  setBancaResponse,
  setStatoResponse,
  setDueDatePhoneCollection,

  setAssegnatiCDRFilter,
  setPCAgentFilter,
  setBancaFilter,
  setStatoFilter,
  setPhoneCollectionTable,
  setShowEsitoModal,
  setClickValueToEsito,

  setShowConfirmationModal,
  updateMakeOutboundCall,
} from "../PhoneCollection/phoneCollectionSlice";
import {
  httpGetAssegnatiCDRArr,
  httpGetPcAgentList,
  httpPostStatoList,
  httpPostPhoneCollectionTable,
  httpPostSendEmail,
  httpPostNoteList,
} from "../PhoneCollection/PhoneCollectionService";
import PhoneCollectionEsitoModal from "./PhoneCollectionModals/PhoneCollectionEsitoModal";
import NoteOperatorModal from "./PhoneCollectionModals/NoteOperatorModal";
import ClickToDialModal from "../../CommonComponents/Modal/ClickToDialModal";


const ExpandPhoneCollectionContainer = (props) => {
  const { elStack = {} } = props;
  const [formFields] = useState(new FormFieldHandler(true));
  const { widgets } = useSelector((state) => state.widgets);

  const { profile } = useSelector((state) => state.preference);
  const { id = ""} = profile;

  const { banks = [] } = useSelector((state) => state.common);

  const assegnatiCDRResponseData = useSelector((state) => state.phoneCollection.assegnatiCDRResponseData);
  const pcAgentResponseData = useSelector((state) => state.phoneCollection.pcAgentResponseData);
  const bancaResponseData = useSelector((state) => state.phoneCollection.bancaResponseData);
  const statoResponseData = useSelector((state) => state.phoneCollection.statoResponseData);
  
  const assegnatiCDRSelectedData = useSelector((state) => state.phoneCollection.assegnatiCDRSelectedData);
  const pcAgentSelectedData = useSelector((state) => state.phoneCollection.pcAgentSelectedData);
  const bancaSelectedData = useSelector((state) => state.phoneCollection.bancaSelectedData);
  const statoSelectedData = useSelector((state) => state.phoneCollection.statoSelectedData);
  const dueDateSelectedDate = useSelector((state) => state.phoneCollection.dueDateSelectedDate);
  
  const phoneCollectionTableData = useSelector((state) => state.phoneCollection.phoneCollectionTableData);
  const makeOutboundCall = useSelector((state) => state.phoneCollection.makeOutboundCall);

  const { showEsitoModal=false }  = useSelector((state) => state.phoneCollection.esitoModalData);
  const showModal= useSelector((state) => state.phoneCollection.showModal);

  const dispatch = useDispatch();

  const [phoneCollectionMenuShow, phoneCollectionShow] = getDisplayDataByCode(widgets)( phoneCollectionWidgetCode );

  const{phoneNumberVal, passAttributes} = makeOutboundCall;
  const { outboundQueueId } = getMainWidgetConfigByIdAndCode(widgets)(phoneCollectionWidgetCode);

  const[bancaSelected, setBancaSelected] = useState(false);
  const[statoSelected, setStatoSelected] = useState(false);
  const[assegnatiSelected, setAssegnatiSelected] = useState(false);
  const[assegnatiCDRSelected, setAssegnatiCDRSelected] = useState(false);
  const[showNoteOperator, setShowNoteOperator] = useState(false);
  const[dataNoteOperator, setDataNoteOperator] = useState([]);


  useEffect(()=> {
    onMount();
  },[]);

  useEffect(async() => {
    const {value} = bancaSelectedData;
    if(value){
      dispatch(toggleSpinnerById(phoneCollectionPEGSpinnerId));
    await httpPostStatoList({abi :value }).then((response) => {
      formFields.getField("statoFilterId").theField.reloadOptions(response);
      dispatch(setStatoResponse({statoResp:response}));
    }).catch((err) => {
      toast.error(getBaseErrorMessage("Error",err), { containerId: phoneCollectionAlertId });
    });
    dispatch(toggleSpinnerById(phoneCollectionPEGSpinnerId));
    }
  }, [bancaSelectedData])

  // Estari  service to call after Esito Modal close and on opening PhoneCollection table
  // useEffect(() => {
  //   if(!showEsitoModal || (!showEsitoModal && bancaSelected && statoSelected && assegnatiSelected && assegnatiCDRSelected && phoneCollectionTableData.length>0))
  //     estraiButtonClick();
  // }, [showEsitoModal,assegnatiCDRSelected]);

  useEffect(()=>{
    if (formFields.getField("bancaFilterField") && (banks && Object.keys(banks).length!=0)){
      let options = reduceToOptions(banks)("abicode", "desctiption")
      formFields.getField("bancaFilterField").theField.reloadOptions(options) ;
      setDefaultBank(options, "bancaFilterField");
    }
  },[banks])
  
  let onMount = async () => {
    
    if(formFields.getField("assegnatiCDRFilterField") && (assegnatiCDRResponseData && Object.keys(assegnatiCDRResponseData).length==0))  
    {
      dispatch(toggleSpinnerById(phoneCollectionPEGSpinnerId));
      await httpGetAssegnatiCDRArr().then((response) => {
        dispatch(toggleSpinnerById(phoneCollectionPEGSpinnerId));
        formFields.getField("assegnatiCDRFilterField").theField.reloadOptions(response);
        dispatch(setAssegnatiCDRResponse({assegnatiCDRResp:response}));
        if(response.length!=0)
        formFields.getField("assegnatiCDRFilterField").theField.setValue(response[0]);
      }).catch((err) => {
        dispatch(toggleSpinnerById(phoneCollectionPEGSpinnerId));
        toast.error(getBaseErrorMessage("Error",err), { containerId: phoneCollectionAlertId });
      });
    }

    if (formFields.getField("pcAgentFilterField") && (pcAgentResponseData && Object.keys(pcAgentResponseData).length==0))  
        {
          dispatch(toggleSpinnerById(phoneCollectionPEGSpinnerId));
          await httpGetPcAgentList().then((response) => {
            dispatch(toggleSpinnerById(phoneCollectionPEGSpinnerId));
            formFields.getField("pcAgentFilterField").theField.reloadOptions(response);
            dispatch(setPCAgentResponse({pcAgentResp:response}));
            response.forEach(element => {
              let {value} = element;
              if(value == id){
                formFields.getField("pcAgentFilterField").theField.setValue(element);
              }
            });
          }).catch((err) => {
            dispatch(toggleSpinnerById(phoneCollectionPEGSpinnerId));
            toast.error(getBaseErrorMessage("Error",err), { containerId: phoneCollectionAlertId });
          });;
        }

        if (formFields.getField("bancaFilterField") && (banks && Object.keys(banks).length!=0)){
          let options = reduceToOptions(banks)("abicode", "desctiption")
          formFields.getField("bancaFilterField").theField.reloadOptions(options) ;
          setDefaultBank(options, "bancaFilterField");
        }
        
  
   if (
    assegnatiCDRResponseData &&
     Object.keys(assegnatiCDRResponseData).length != 0
   )
     formFields
       .getField("assegnatiCDRFilterField")
       .theField.reloadOptions(assegnatiCDRResponseData);

   if (pcAgentResponseData && Object.keys(pcAgentResponseData).length != 0)
     formFields
       .getField("pcAgentFilterField")
       .theField.reloadOptions(pcAgentResponseData); 

    if (statoResponseData && Object.keys(statoResponseData).length != 0)
       formFields
         .getField("statoFilterId")
         .theField.reloadOptions(statoResponseData); 
         
  };

  const setDefaultBank = (options, fieldName) => {
    let defaultOption = undefined;
    for (let i = 0; i < options.length; i++) {
      const { rlData = {} } = options[i];
      const { default: def = false } = rlData;
      if (def === true) {
        defaultOption = options[i];
        break;
      }
    }
    if (defaultOption) {
      if(formFields.getField(fieldName))
      formFields.getField(fieldName).theField.setValue(defaultOption);
    }
  };

  
 let estraiButtonClick = () =>{
  let abi, cdrRecipient, codeStatus, userId, dueDate;
  let req = {};
  const statoFieldCheck = formFields.getField("statoFilterId");
  if(statoFieldCheck){
    let { value = "" } = statoFieldCheck.theField.getValue() || {};
    if( value !== null && value !== ""){
      codeStatus = value;
    }
  };

  const bancaFieldCheck = formFields.getField("bancaFilterField");
  if(bancaFieldCheck){
    let { value = "" , label = ""} = bancaFieldCheck.theField.getValue() || {};
    if( value !== null && value !== ""){
      abi = value;
    }
  }

  const assegnatiCDRCheck = formFields.getField("assegnatiCDRFilterField");
  if(assegnatiCDRCheck){
    let { value = "" } = assegnatiCDRCheck.theField.getValue() || {};
    if( value !== null && value !== ""){
      cdrRecipient = value;
    }
  }

  const dueDateValue = formFields.getField("dueDateConfigurationField");
  if(dueDateValue){
    let duedateSelected = dueDateValue.theField.getValue() || null ;
    if (duedateSelected) {
      dueDate = changeFormat(duedateSelected);
    } else dueDate = null;
  }

  const pcAgentCheck = formFields.getField("pcAgentFilterField");
  if(pcAgentCheck){
    let { value = "" } = pcAgentCheck.theField.getValue() || {};
    if( value !== null && value !== ""){
      userId = value;
    }
  }

  if(abi && cdrRecipient && codeStatus && userId){
  if (userId == "TUTTI")
    req = {
      abi,
      cdrRecipient,
      codeStatus,
      dueDate,
    };
  else
    req = {
      abi,
      cdrRecipient,
      codeStatus,
      userId,
      dueDate,
    };
  loadPhoneCollectionTable(req);
  }
};


let changeFormat = (changeDate) =>{
  let day = changeDate.getDate();
  let month = changeDate.getMonth();
  let year = changeDate.getFullYear();
  let returnDate = `${day}/${month+1}/${year}`
  return returnDate
}

 const loadPhoneCollectionTable = async (request) => {
    dispatch(toggleSpinnerById(phoneCollectionPEGSpinnerId));
       await httpPostPhoneCollectionTable(request).then( responseList => {
          dispatch(setPhoneCollectionTable({phoneCollectionValue : responseList}));
          dispatch(toggleSpinnerById(phoneCollectionPEGSpinnerId));
        }).catch((err) => {
            dispatch(toggleSpinnerById(phoneCollectionPEGSpinnerId));
            toast.error(getBaseErrorMessage("Error",err), { containerId: phoneCollectionAlertId });
        });;
 }

  let pcAgentFilterField = {
    uniqueID: "pcAgentFilterField",
    multiSelect: false,
    label: "",
    placeHolder: "PC Agent",
    readonly: false,
    visible: true,
    disabled: false,
    options: [],
    searchEnabled: true,
    value: (pcAgentSelectedData && Object.keys(pcAgentSelectedData).length!=0) ? pcAgentSelectedData : {},
    setValue: (obj) => {
      dispatch(
        setPCAgentFilter({
          pcAgentfilter : obj.currentValue
        })
      );
      if (obj.currentValue && Object.keys(obj.currentValue).length != 0)
        setAssegnatiSelected(true);
    },
    form: formFields,
    validation: {
      externalCheck: (value) => {
        if (value && !Array.isArray(value)) {
          return true;
        }
        return false;
      },
    },
    feedback: {
      enable: true,
      component: () => <>* Obbligatorio</>,
    },
  };

  let assegnatiCDRFilterField = {
    uniqueID: "assegnatiCDRFilterField",
    multiSelect: false,
    label: "",
    placeHolder: "Assegnati CDR",
    readonly: false,
    visible: true,
    disabled: false,
    options: [],
    searchEnabled: true,
    value: (assegnatiCDRSelectedData && Object.keys(assegnatiCDRSelectedData).length!=0) ? assegnatiCDRSelectedData : {},
    setValue: (obj) => {
      dispatch(
        setAssegnatiCDRFilter({
          assegnatiCDRfilter : obj.currentValue
        })
      );
      if (obj.currentValue && Object.keys(obj.currentValue).length != 0)
        setAssegnatiCDRSelected(true);
    },
    form: formFields,
    validation: {
      externalCheck: (value) => {
        if (value && !Array.isArray(value)) {
          return true;
        }
        return false;
      },
    },
    feedback: {
      enable: true,
      component: () => <>* Obbligatorio</>,
    },
  };

  

  let bancaFilterField = {
    uniqueID: "bancaFilterField",
    multiSelect: false,
    label: "",
    placeHolder: "banca",
    readonly: false,
    visible: true,
    disabled: false,
    options: [],
    searchEnabled: true,
    value: (bancaSelectedData && Object.keys(bancaSelectedData).length!=0) ? bancaSelectedData : {},
    setValue: (obj) => {
      dispatch(
        setBancaFilter({
          bancaSelected : obj.currentValue
        })
      );
      if (obj.currentValue && Object.keys(obj.currentValue).length != 0)
        setBancaSelected(true);
    },
    form: formFields,
    validation: {
      externalCheck: (value) => {
        if (value && !Array.isArray(value)) {
          return true;
        }
        return false;
      },
    },
    feedback: {
      enable: true,
      component: () => <>* Obbligatorio</>,
    },
  };

  const dueDateConfigurationField = {
    uniqueID: "dueDateConfigurationField",
    clearable: true,
    value: dueDateSelectedDate ? new Date(dueDateSelectedDate) : null,
    form: formFields,
    format:"dd/MM/yyyy",
    showTime: false,
    setValue: (value) => {
      const { currentValue } = value;
        dispatch(setDueDatePhoneCollection({dueDateVal:currentValue}));
    },
  };
  
  let statoFilterField = {
    uniqueID: "statoFilterId",
    multiSelect: false,
    label: "",
    placeHolder: "stato",
    readonly: false,
    visible: true,
    disabled: false,
    options: [],
    searchEnabled: true,
    value: (statoSelectedData && Object.keys(statoSelectedData).length!=0) ? statoSelectedData : {},
    setValue: (obj) => {
      dispatch(
        setStatoFilter({
          statoSelected : obj.currentValue
        })
      );
      if (obj.currentValue && Object.keys(obj.currentValue).length != 0)
        setStatoSelected(true);
    },
    form: formFields,
    validation: {
      externalCheck: (value) => {
        if (value && !Array.isArray(value)) {
          return true;
        }
        return false;
      },
    },
    feedback: {
      enable: true,
      component: () => <>* Obbligatorio</>,
    },
  };

   let phoneCollectionTable = {
    uniqueID: "phoneCollectionTable",
    lastColumnFixed: true,
    globalSearch: {
      show: true,
      placeholder: "Search…",
      width: "30%",
    },
    scrollY: true,
    metaData: [
      {
        Header: "S.No",
        accessor: "sNo",
      },
      {
        id: "codice",
        Header: "Codice",
        accessor: "codice",
      },
      {
        id: "cognomeNome",
        Header: "Cognome/Denom.",
        accessor: "cognomeNome"
      },
      {
        id: "dataNascita",
        Header: "Data Nascita/Costit.",
        accessor: "dataNascita"
      },
      {
        id: "telefono1",
        Header: "Telefono 1",
        accessor: "telefono1",
        Cell: (cellInfo) => {
          let { row } = cellInfo;
          let { original } = row;
          let { telefono1, idPEG,idNotifica, idSoggetto , sectionId, priorityRuleId, abicode, stato } = original
          return (
            <div className="text-left hand-cursor">
              <a onClick={ ()=>{ telefono1 ? makeCall(telefono1,idPEG,idNotifica,idSoggetto, sectionId, priorityRuleId, abicode, stato)  : {}}}>
                {telefono1}
              </a>
            </div>
          );
        },
        
      },
      {
        id: "telefono2",
        Header: "Telefono 2",
        accessor: "telefono2",
        Cell: (cellInfo) => {
          let { row } = cellInfo;
          let { original } = row;
          let { telefono2,idPEG,idNotifica,idSoggetto,sectionId, priorityRuleId, abicode, stato } = original
          return (
            <div className="text-left hand-cursor">
              <a onClick={ ()=>{ telefono2 ? makeCall(telefono2,idPEG,idNotifica,idSoggetto,sectionId, priorityRuleId, abicode, stato) : {}}}>
                {telefono2}
              </a>
            </div>
          );
        },
      },
      {
        id: "note",
        Header: "Note",
        accessor: "note"
      },
      {
        id: "esito",
        Header: "Ultima azione inserita in PEG",
        accessor: "esito"
      },
      {
        id: "dataScadenza",
        Header: "Data scadenza",
        accessor: "dataScadenza"
      },
      {
        id: "opUltimaMod",
        Header: "Op. Ultima Mod.",
        accessor: "opUltimaMod"
      },
      {
        id: "dataUltimaMod",
        Header: "Data Ultima",
        accessor: "dataUltimaMod"
      },
      {
        id: "idPEG",
        Header: "Id PEG",
        accessor: "idPEG",
        Cell: (cellInfo) => {
          let { original } = cellInfo.row;
          return (
            <a href={original.pegUrl} target="_blank">{original.idPEG}</a>
          );
        },
      },
      {
        id: "idNotifica",
        Header: "Id Notifica",
        accessor: "idNotifica"
      },
      {
        id: "altriLink",
        Header: (headerInfo, props) => {
          return null;
        },
        Cell: (cellInfo) => {
          let { original } = cellInfo.row;
          let { codice,idPEG,idNotifica,sectionId, priorityRuleId, abicode, idSoggetto, stato } = original
          const [showPopover, setShowPopover] = useState(false);
          return (
            <MyPopover
              configuration={{
                uniqueID: "optionsPopOver",
                popoverShow: showPopover,
                popoverPlacement: "left-start",
                popoverClass: "sospesi-tabellla-row-popover",
                overlayTriggerElement: (
                  <IconOptions
                    configuration={{
                      onClick: () => {
                        setShowPopover(!showPopover);
                      },
                    }}
                  />
                ),
              }}
            >
              <div className="d-flex flex-column">
                <div
                  className="sospesi-options-content my-2"
                  onClick={() => {
                    handleOnOpenEsitoModal(idPEG,idNotifica,sectionId, priorityRuleId, abicode,stato, idSoggetto) 
                    setShowPopover(!showPopover);
                  }}
                >
                  <span>Aggiorna Esito</span>
                </div>
                <div
                  className="sospesi-options-content my-2"
                  onClick={() => {
                    httpPostSendEmail({
                      pegId: idPEG,
                      idSoggetto: idSoggetto,
                      abi: abicode,
                    })
                    setShowPopover(!showPopover);
                  }}
                >
                  <span>Crea draft email</span>
                </div>
                <div
                  className="sospesi-options-content my-2"
                  onClick={() => {
                    openNoteModal(idPEG)
                  }}
                >
                  <span>Visualizza note</span>
                </div>
              </div>
            </MyPopover>
          );
        },
      },
    ],
    sort: [
      {
        id: "sNo",
        desc: false,
      },
    ],
    pagination: true,
    showTotalCount: true,
    paginationOptions: {
      pageSize: 10,
    },
    data: [...phoneCollectionTableData],
  };

  const makeCall =(phn,idPEG,idNotifica,idSoggetto,sectionId, priorityRuleId, abicode, stato) =>{
  dispatch(setShowConfirmationModal({showVal : true}));
  dispatch(updateMakeOutboundCall({
    data:{
      phoneVal: phn,
      passObjVal:{
        idPEG,
        idNotifica,
        idSoggetto,
        sectionId, 
        ruleId: priorityRuleId,
        abicode,
        stato
      },
    }
  }));
  }

  let openNoteModal = async (idPeg) =>{
    let request = {pegId : idPeg, subsystem:"PEG"}
    dispatch(toggleSpinnerById(globalSpinnerId));
    await httpPostNoteList(request).then((responseVal) => {
      const { status = "", response = [] } = responseVal;
      if (status && status == "OK") {
        setDataNoteOperator(response);
        setShowNoteOperator(true);
      }
      dispatch(toggleSpinnerById(globalSpinnerId));
    })   
  }

  let handleOnCloseNoteOperatorModal = () =>{
    setShowNoteOperator(false);
  }


  const handleOnCloseClickToDialModal = () => {
    dispatch(setShowConfirmationModal({showVal : false}));
  };

  const handleOnConfirmClickToDialModal = () => {
    dispatch(setShowConfirmationModal({showVal : false}));
  };



  const clickToDialConfig = {
    showModal: showModal,
    events: {
      handleOnCloseModal: () => {
        handleOnCloseClickToDialModal();
      },
      handleOnConfirmationModal: () => {
        handleOnConfirmClickToDialModal();
      },
    },
    dialOptions: {
      number: phoneNumberVal,
      address: null,
      queueId: outboundQueueId,
      type: "call",
      attributes: {
        ...passAttributes,
        subsystem:"PEG",
      },
    },
    queueSelection: false,
    channelSelection: false,
  };


  let handleOnPhoneCollectionStackMounted = (stack) => {
    console.log(stack);
  };

  let handleOnPhoneCollectionStackUnMounted = (stack) => {
    console.log(stack);
  };

  let handleOnOpenEsitoModal = (idPEG,idNotifica,sectionId, priorityRuleId, abicode, stato, idSoggetto) => {
    dispatch(setShowEsitoModal({showVal : true}));
    dispatch(
      setClickValueToEsito({
        selectedSoggettoIdVal : idSoggetto,
        selectedPegIdVal: idPEG,
        selectedNotificationIdVal: idNotifica,
        selectedSectionIdVal: sectionId,
        selectedRuleIdVal: priorityRuleId,
        selectedAbiVal: abicode,
        selectedStatoVal: stato
      })
    );
  }

  let handleOnCloseEsitoModal = () =>{
    dispatch(setShowEsitoModal({showVal : false}));
  }

  return (
    <WidgetWrapper widgetShow={phoneCollectionShow}>
      <ExpandedWidgetWrapper
        className={"sospesi-expand-main-container"}
        elStack={elStack}
        events={{
          handleOnStackMounted: handleOnPhoneCollectionStackMounted,
          handleOnStackUnMounted: handleOnPhoneCollectionStackUnMounted,
        }}
      >
        <WidgetTitle
          title="Phone Collection"
          iconElement={
            <IconBlueClose
              configuration={{
                onClick: (active) => {
                  dispatch(
                    updateWidgetMenuEventByCode({
                      widget: {
                        code: phoneCollectionWidgetCode,
                        menuEventState: !phoneCollectionMenuShow,
                      },
                    })
                  );
                  dispatch(stackNavPop());
                },
              }}
            />
          }
        />
        <>
        <MySpinner uniqueID={phoneCollectionPEGSpinnerId} type="global" />
         <AlertToast
              configuration={{
                unqiueID: phoneCollectionAlertId,
                className: "inline-toast-container",
                transition: "flip",
              }}
          />
          <div className="d-flex flex-column">
            <div className="d-flex">
              <div className="row no-gutters flex-fill">

                <div className="col-2 ml-2 ">
                <div className="small-content-label-class">Banca</div>
                  <SelectField configuration={bancaFilterField} />
                </div>

                <div className="col-2 ml-2 ">
                <div className="small-content-label-class">Stato</div>
                  <SelectField configuration={statoFilterField} />
                </div>

                <div className="col-2 ml-2 ">
                <div className="small-content-label-class">Assegnati a</div>
                  <SelectField configuration={pcAgentFilterField} />
                </div>

                <div className="col-2 ml-2 ">
                <div className="small-content-label-class">Assegnati al CDR</div>
                  <SelectField configuration={assegnatiCDRFilterField} />
                </div>

                <div className="col-1.5 ml-2 ">
                <div className="small-content-label-class">Due Date</div>
                  <DateField configuration={dueDateConfigurationField} />
                </div>

                <div className="col ml-1 p-1 mt-2">
                     <button type="button" className={`btn Rectangle-Button-Blue w-100`}
                        onClick= {estraiButtonClick}
                        disabled = {!(bancaSelected  && statoSelected && assegnatiCDRSelected && assegnatiSelected)}
                        >
                         Estrai
                    </button>
                    {!(bancaSelected  && statoSelected && assegnatiCDRSelected && assegnatiSelected) ? 
                    <p className="text-red">*Seleziona Tutto</p> 
                    :<></>}
                </div>
              </div>
            </div>
            <div className="mt-2">
              <SimpleTable configuration={phoneCollectionTable} />
            </div>
             <ClickToDialModal configuration={clickToDialConfig} />
             <PhoneCollectionEsitoModal 
                  showModal={showEsitoModal}
                  handleOnCloseModal={handleOnCloseEsitoModal}
                  modalTitle="Esito"
              />
              <NoteOperatorModal 
                  showModal={showNoteOperator}
                  handleOnCloseModal={handleOnCloseNoteOperatorModal}
                  tableData = {dataNoteOperator}
              />
          </div>
        </>
      </ExpandedWidgetWrapper>
    </WidgetWrapper>
  );
};

export default ExpandPhoneCollectionContainer;
