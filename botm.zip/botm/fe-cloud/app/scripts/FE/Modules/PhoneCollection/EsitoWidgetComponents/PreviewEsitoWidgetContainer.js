import React, { useRef,useEffect } from "react";
import {  useDispatch ,useSelector } from "react-redux";
import { CSSTransition } from "react-transition-group";
import IconExplode from "../../../CommonComponents/Common/Icons/IconExplode";
import { stackNavEsitoContainer } from "../../../Main/StackNavigation/StackNavComponents";
import {
  stackNavPush,
} from "../../../Main/StackNavigation/stackNavigationSlice";
import {
  esitoWidgetCode,
  getDisplayDataByCode,
} from "../../Widgets/widgetsSlice";
import WidgetTitle from "../../Widgets/WidgetTitle";
import WidgetWrapper from "../../Widgets/WidgetWrapper";
import { getInteractionDetails } from "../../../Modules/Interaction/interactionSlice";
import EsitoWidgetMain from "../EsitoWidgetComponents/EsitoWidgetMain";
import EsitoCRMWidgetMain from "../../PhoneCollectionCRM/EsitoWidgetCRMComponents/EsitoCRMWidgetMain";
import { withErrorBoundary } from "../../../CommonComponents/ErrorBoundary/withErrorBoudary";

const PreviewEsitoWidgetContainer = (props) => {
  const { widgets } = useSelector((state) => state.widgets);
  const dispatch = useDispatch();

  const [esitoComponentMenuShow, esitoComponentShow] = getDisplayDataByCode(widgets)( esitoWidgetCode );

  const { currentInteraction = "noInteraction", interactions = [] } = useSelector(
    (state) => state.interaction
  );

  const currentInteractionRef = useRef();
  currentInteractionRef.current = currentInteraction;

  const { attributes = {} } = getInteractionDetails(interactions)(currentInteractionRef.current);

 let handleOnStackExpand = () => {
    dispatch(stackNavPush(stackNavEsitoContainer));
  };

  return (
    <WidgetWrapper widgetShow={esitoComponentShow}>
      <CSSTransition
        in={esitoComponentShow}
        timeout={300}
        classNames="slide-right-toggle"
        unmountOnExit={false}
        mountOnEnter={true}
      >
        <div className="d-flex flex-column section-consult">
          <WidgetTitle
            title="Esito Contatto"
            iconElement={
              <IconExplode
                configuration={{
                  onClick: (active) => {
                    handleOnStackExpand();
                  },
                }}
              />
            }
          />
          <div className="d-flex flex-column">
            {attributes["subsystem"] && attributes["subsystem"] == "CRM" ? (
              <EsitoCRMWidgetMain
                type="Widget"
                currentInteraction={currentInteractionRef.current}
              />
            ) : attributes["subsystem"] && attributes["subsystem"] == "PEG" ? (
              <EsitoWidgetMain
                type="Widget"
                currentInteraction={currentInteractionRef.current}
              />
            ) : (
              <></>
            )}
          </div>
        </div>
      </CSSTransition>
    </WidgetWrapper>
  );
};

export default withErrorBoundary(PreviewEsitoWidgetContainer);
