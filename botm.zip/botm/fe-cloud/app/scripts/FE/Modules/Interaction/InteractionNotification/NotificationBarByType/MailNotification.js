import React from "react";

const MailNotification = (props) => {
  const { interaction = {} } = props;
  const { displayAddress = "", state = "" } = interaction;

  let displayLabel = (label = "") => {
    if (label && label.length > 18) {
      return label.substring(0, 18) + "..";
    }
    return label;
  };

  return (
    <div
      className={`row no-gutters interactions-item mb-4 ${
        state == "CONNECTED" ? "active shadow" : ""
      }`}
      onClick={() => {}}
    >
      <div className="col-2">
        <svg
          xmlns="http://www.w3.org/2000/svg"
          width="16"
          height="16"
          fill="currentColor"
          className="bi bi-envelope icon-type"
          viewBox="0 0 16 16"
        >
          <path d="M0 4a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2V4zm2-1a1 1 0 0 0-1 1v.217l7 4.2 7-4.2V4a1 1 0 0 0-1-1H2zm13 2.383l-4.758 2.855L15 11.114v-5.73zm-.034 6.878L9.271 8.82 8 9.583 6.728 8.82l-5.694 3.44A1 1 0 0 0 2 13h12a1 1 0 0 0 .966-.739zM1 11.114l4.758-2.876L1 5.383v5.73z" />
        </svg>
      </div>
      <div className="col-8">
        <span className="content-text">{displayLabel(displayAddress)}</span>
      </div>
      <div className="col-2">
        <svg
          xmlns="http://www.w3.org/2000/svg"
          width="16"
          height="16"
          fill="currentColor"
          className="bi bi-three-dots-vertical ml-3"
          viewBox="0 0 16 16"
        >
          <path d="M9.5 13a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0zm0-5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0zm0-5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0z" />
        </svg>
      </div>
    </div>
  );
};

export default MailNotification;
