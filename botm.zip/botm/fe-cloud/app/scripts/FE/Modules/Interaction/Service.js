import { toast } from "react-toastify";
import { beServiceUrls, pureCloudOrigin } from "../../Client/ClientProperties";
import { globalAlertId } from "../../CommonComponents/AlertToast/AlertIdConstants";
import { exposedDispatch, exposedGetState } from "../../Store/store";
import {
  getBaseErrorMessage,
  getBTChannelOfInteraction,
  ChangeAutoFocus,
  isCustomFunctionAvailable,
  isFullAuthenticatedCall,
  isAuthenticatedChat,
  isTMLAvailable,
  isPartialAuthenticatedCall,
  addParticipantDataToInteraction,
  sendUserNotifictionOnPEF,
  updateSystemPresence,
  isContactIDAvailable,
  isNTCodeAvailable,
  isAbandonRecallConversation,
  isIdSoggettoAvailable,
  isSospesoConversation,
} from "../../Utils/CommonUtil";
import HttpClient from "../../Utils/HttpClient";
import {
  addInteraction,
  getInteractionDetails,
  removeInteraction,
  setCurrentInteraction,
  updateInteraction,
  updateInteractionProperty,
  serviceTypePrivato,
  serviceTypeAzienda,
  addNotificationData,
  updateNotificationProperty,
} from "./interactionSlice";

import { httpGetLastClientSearched } from "../Anagrafica/httpService";
import { customFunctionCodes } from "../../Store/commonSlice";
import { httpPostClientSearch } from "../../Main/Header/UserSearch/Service";
import {
  httpPutAuthenticationState,
  httpPostAuthV3Federation,
} from "../Authentication/Service";
import {
  updateAuthenticationPropertyByInteractionAndValue,
  addAuthenticationValueByInteraction,
} from "../Authentication/authenticationSlice";
import { lightAuthenticationServiceCall } from "../LightAuthentication/Service";
import {
  setCurrentTabKey,
  setPrivatoSelectedIbCode,
  setNotClientDefaultDataPropertyMap,
} from "../Anagrafica/anagraficaSlice";
import {
  privatoWidgetCode,
  aziendaWidgetCode,
} from "../Widgets/internalWidgetsSlice";
import {
  globalSpinnerId,
  toggleSpinnerById,
} from "../../CommonComponents/Spinner/spinnerSlice";
import { httpPostEliminaSpam } from "../Consuntivazione/Service";
import { stackNavMandAuth } from "../../Main/StackNavigation/StackNavComponents";
import {
  findIndexByCode,
  stackNavPop,
  stackNavPush,
} from "../../Main/StackNavigation/stackNavigationSlice";
import {
  updateConsunDataByProperty,
  getConsunDataById,
} from "../Consuntivazione/consuntivaSlice";
import {
  transferAutoTraceEmailType,
  transferAutoTraceChatType,
  transferAutoTraceCallType,
} from "../../Utils/CommonConstantUtil";
import { showAbandonRecallRecallConfirmationModal } from "../AbandonRecall/abandonRecallSlice";
import { updateSospesoAfterPEFEvent } from "../Sospesi/SospesiService";

const httpMissingInteractions = async (request = {}) => {
  const dispatch = exposedDispatch;
  let httpMissingInteractions = new HttpClient();
  httpMissingInteractions.setUrl(beServiceUrls().getMissingInteractions);
  await httpMissingInteractions.httpGet(request).then((response) => {
    const { status = "", response: interactionResponse = [] } = response;
    if (status == "OK") {
      interactionResponse.map((currInteraction) => {
        dispatch(addInteraction({ data: currInteraction }));
      });
    }
  });
};

const dispatchIntxIdResponse = (response = {}) => {
  return (interactionId = "") => {
    const dispatch = exposedDispatch;
    const {
      intxId,
      messageId,
      divisionId,
      mailForm = false,
      mailFormCheckPassed = false,
    } = response;
    if (interactionId && interactionId !== "") {
      dispatch(
        updateInteractionProperty({
          id: interactionId,
          property: "intxId",
          value: intxId,
        })
      );
      dispatch(
        updateInteractionProperty({
          id: interactionId,
          property: "messageId",
          value: messageId,
        })
      );
      dispatch(
        updateInteractionProperty({
          id: interactionId,
          property: "barraDivisionId",
          value: divisionId,
        })
      );
    }
    if (mailForm === true && mailFormCheckPassed === false) {
      dispatch(
        updateInteractionProperty({
          id: interactionId,
          property: "showMailFormAlert",
          value: true,
        })
      );
    }
  };
};

const httpPostStartGeolocalizationFlow = async (request = {}, params = {}) => {
  console.log("httpPostInsertInteraction", request, params);
  let httpInsertInteraction = new HttpClient();
  httpInsertInteraction.setUrl(beServiceUrls().startGeolocalizationFlow);
  let res = await httpInsertInteraction
    .httpPost(request, params)
    .then((response = {}) => {
      const { status } = response;
      if (status !== "OK") {
        toast.warn(
          "ATTENZIONE: MESSAGGIO GEOLOCALIZZAZIONE KO! PRESENTATI AL CLIENTE!!",
          {
            containerId: globalAlertId,
          }
        );
      }
      return response;
    })
    .catch((err) => {
      toast.error(
        "ATTENZIONE: MESSAGGIO GEOLOCALIZZAZIONE KO! PRESENTATI AL CLIENTE!!",
        {
          containerId: globalAlertId,
        }
      );
      return {};
    });
  return res;
};

export const httpChatAuthenticate = async (request) => {
  let httpClient = new HttpClient();
  httpClient.setUrl(beServiceUrls().sendChatMessage);
  let res = await httpClient
    .httpPost(request)
    .then((response) => {
      const { status = "" } = response;
      if (status === "OK") {
        console.log("httpChatAuthenticate success");
        toast.success("Link di autenticazione inviato correttamente", {
          containerId: globalAlertId,
        });
      } else if (status === "KO") {
        toast.warn(getBaseErrorMessage("Warning", response), {
          containerId: globalAlertId,
        });
      } else {
        throw response;
      }
      return status;
    })
    .catch((err) => {
      toast.error(getBaseErrorMessage("Error", err), {
        containerId: globalAlertId,
      });
    });

  return res;
};

export const httpPostCreateEmail = async ( request = {} ) => {
  let httpClient = new HttpClient();
  httpClient.setUrl(beServiceUrls().createEmail);
  let res = await httpClient
    .httpPost(request)
    .then((response) => {
      const { status = "" } = response;
      if (status === "OK") {
        console.log("httpPostTransferAutoTrace success");
      } else {
        toast.warn(getBaseErrorMessage("Warning", response), {
          containerId: globalAlertId,
        });
      }
    })
    .catch((err) => {
      toast.error(getBaseErrorMessage("Error", err), {
        containerId: globalAlertId,
      });
    });
  return res;
}

const httpPostTransferAutoTrace = async (request = {}, params = {}) => {
  console.log("httpPostTransferAutoTrace", request, params);
  let httpInsertInteraction = new HttpClient();
  httpInsertInteraction.setUrl(beServiceUrls().insertAutoTrace);
  let res = await httpInsertInteraction
    .httpPost(request, params)
    .then((response) => {
      const { status = "" } = response;
      if (status === "OK") {
        console.log("httpPostTransferAutoTrace success");
      } else {
        toast.warn(getBaseErrorMessage("Warning", response), {
          containerId: globalAlertId,
        });
      }
    })
    .catch((err) => {
      toast.error(getBaseErrorMessage("Error", err), {
        containerId: globalAlertId,
      });
    });
};

const httpPostAutoCompleteACWTrace = async (request = {}, params = {}) => {
  console.log("httpPostAutoCompleteACWTrace", request, params);
  let httpInsertInteraction = new HttpClient();
  httpInsertInteraction.setUrl(beServiceUrls().autoCompleteACWTrace);
  let res = await httpInsertInteraction
    .httpPost(request, params)
    .then((response) => {
      const { status = "" } = response;
      if (status === "OK") {
        console.log("Post AutoComplete ACW Trace success");
      } else {
        toast.warn(getBaseErrorMessage("Warning", response), {
          containerId: globalAlertId,
        });
      }
    })
    .catch((err) => {
      toast.error(getBaseErrorMessage("Error", err), {
        containerId: globalAlertId,
      });
    });
};

const httpPostInsertInteraction = async (request = {}, params = {}) => {
  console.log("httpPostInsertInteraction", request, params);
  let httpInsertInteraction = new HttpClient();
  httpInsertInteraction.setUrl(beServiceUrls().insertInteraction);
  let res = await httpInsertInteraction
    .httpPost(request, params)
    .then((response) => {
      const { status = "", intxId } = response;
      if (status == "OK") {
        console.log("intxId=", intxId);
      }
      const { interactionId } = params;
      dispatchIntxIdResponse(response)(interactionId);
      return response;
    })
    .catch((err) => {
      toast.error(getBaseErrorMessage("Error", err), {
        containerId: globalAlertId,
      });
      return {};
    });
  return res;
};

const httpPostEvent = async (request = {}) => {
  console.log("httpPostEvent", request);
  let httpEvent = new HttpClient();
  httpEvent.setUrl(beServiceUrls().event);
  httpEvent
    .httpPost(request)
    .then((response) => {
      const { status = "" } = response;
      if (status !== "OK") {
        //toast.warn("Warning: Event Service", { containerId: globalAlertId });
      }
    })
    .catch((err) => {
      /*toast.error(getBaseErrorMessage("Error", err),{
      containerId: globalAlertId,
    });*/
    });
};

const httpGetIntxId = async (request = {}, params = {}) => {
  console.log("httpGetIntxId", request, params);
  const dispatch = exposedDispatch;
  let httpClient = new HttpClient();
  httpClient.setUrl(beServiceUrls().getIntxId);
  await httpClient.httpGet(request, params).then((response) => {
    const { status = "", intxId, serviceType } = response;
    const { interactionId } = params;
    if (status == "OK") {
      console.log("intxId=", intxId);
      if (intxId) {
        let tabKey = serviceType
          ? serviceType == serviceTypePrivato
            ? privatoWidgetCode
            : serviceType == serviceTypeAzienda
            ? aziendaWidgetCode
            : privatoWidgetCode
          : privatoWidgetCode;
        dispatch(
          setCurrentTabKey({
            interactionId: interactionId,
            key: tabKey,
          })
        );
      }
    }
    dispatchIntxIdResponse(response)(interactionId);
  });
};

const httpPostUpdateCampaignContact = async (request = {}) => {
  let httpClient = new HttpClient();
  httpClient.setUrl(beServiceUrls().updatecampaigncontact);
  await httpClient
    .httpPost(request)
    .then((response) => {
      const { status = "" } = response;
      if (status !== "OK") {
        toast.warn(getBaseErrorMessage("Warning", response), {
          containerId: globalAlertId,
        });
      }
    })
    .catch((err) => {
      toast.error(getBaseErrorMessage("Error", err), {
        containerId: globalAlertId,
      });
    });
};

export const httpPostInsertInsertCampaignContact = async (request) => {
  let httpClient = new HttpClient();
  httpClient.setUrl(beServiceUrls().insertcampaigncontact);
  await httpClient
    .httpPost(request)
    .then((response) => {
      const { status = "" } = response;
      if (status !== "OK") {
        toast.warn(getBaseErrorMessage("Warning", response), {
          containerId: globalAlertId,
        });
      }
    })
    .catch((err) => {
      toast.error(getBaseErrorMessage("Error", err), {
        containerId: globalAlertId,
      });
    });
};

const httpPostUpdateDisconnectedInteraction = async (
  request = {},
  params = {}
) => {
  let httpClient = new HttpClient();
  httpClient.setUrl(beServiceUrls().disconnect);
  await httpClient
    .httpPost(request, params)
    .then((response) => {
      const { status = "" } = response;
      if (status === "OK") {
        console.log("httpPostUpdateDisconnectedInteraction success");
      } else if (status === "KO") {
        toast.warn(getBaseErrorMessage("Warning", response), {
          containerId: globalAlertId,
        });
      } else {
        throw response;
      }
    })
    .catch((err) => {
      toast.error(getBaseErrorMessage("Error", err), {
        containerId: globalAlertId,
      });
    });
};

export const httpPostChatMessage = async (request) => {
  let httpClient = new HttpClient();
  httpClient.setUrl(beServiceUrls().sendChatMessage);
  await httpClient
    .httpPost(request)
    .then((response) => {
      const { status = "" } = response;
      if (status === "OK") {
        console.log("httpPostChatMessage success");
      } else if (status === "KO") {
        toast.warn(getBaseErrorMessage("Warning", response), {
          containerId: globalAlertId,
        });
      } else {
        throw response;
      }
    })
    .catch((err) => {
      toast.error(getBaseErrorMessage("Error", err), {
        containerId: globalAlertId,
      });
    });
};

const Service = () => {
  const interactionEventListener = (event) => {
    if (event.origin !== pureCloudOrigin) return;
    let message = JSON.parse(event.data);
    const dispatch = exposedDispatch;
    if (message && message.type == "interactionSubscription") {
      console.log("Service interactionSubscription");
      //Below is code for logging the events
      httpPostEvent({ eventString: event.data });
      let { data: interactionData = {} } = message;

      let { category = "", interaction = {} } = interactionData;

      switch (category) {
        case "add":
          // TRIGGERS WHEN INETERACTION ADDED IN LIST
          dispatch(
            addInteraction({
              data: interaction,
            })
          );
          if (interaction.state === window.BTFEDictionary["connected"]) {
            dispatch(setCurrentInteraction({ id: interaction.id }));
          }
          if (
            interaction.state === window.BTFEDictionary["connected"] ||
            interaction.state === window.BTFEDictionary["held"]
          ) {
            checkIntxIdExists(interaction, false);
          }
          //Below code is related to CCLOUD-195 . Connect event is not called for outbound rejected calls
          if (
            interaction.isConnected == false &&
            interaction.isDisconnected == false &&
            getBTCallType(interaction) === "OUTBOUND" &&
            getBTChannel(interaction) === "VOICE" &&
            interaction.state != window.BTFEDictionary["connected"] &&
            interaction.state != window.BTFEDictionary["held"] &&
            interaction.state != window.BTFEDictionary["disconnected"]
          ) {
            insertInteraction(interaction).then((response) => {
              const { intxId } = response;
            });
          }
          //Commenting CCCLOUD-209/Voice inbound interaction auto focus changes
          // if(getBTChannel(interaction) === "VOICE" && getBTCallType(interaction) === "INBOUND"){
          //   ChangeAutoFocus(interaction.id);
          // }
          break;
        case "change":
          // TRIGGERS WHEN INTERACTION IS CHANGED
          dispatch(
            updateInteraction({
              data: interaction.new,
            })
          );
          if (interaction.new.state == window.BTFEDictionary["connected"]) {
            dispatch(setCurrentInteraction({ id: interaction.new.id }));
          }
          //CCCLOUD-553
          const { attributes: attributesOld = {} } = interaction.old;
          const { attributes: attributesNew = {} } = interaction.new;
          if (
            attributesOld["transfertype"] === "start_consult" &&
            attributesNew["transfertype"] === "complete_consult" &&
            getBTChannel(interaction.new) === "VOICE" &&
            isCustomFunctionAvailable(
              customFunctionCodes().playGeolocalizationMessage
            ) &&
            !attributesNew["first_geolocalizzazione"] &&
            getBTCallType(interaction.new) !== "CALLBACK" 
          ) {
            httpPostStartGeolocalizationFlow({
              conversationId: interaction.new.id,
              callType: getCallTypeForGeolocalization(interaction.new),
            });
          }
          //CCCLOUD-645
          if (
            attributesNew["authenticatedchat"] === "true" &&
            getBTChannel(interaction.new) === "CHAT"
            //&& getBTCallType(interaction.new) === "INBOUND" //"OUTBOUND" - showing for chat
          ) {
            let { interactions = [] } = exposedGetState().interaction;
            const { intxId } = getInteractionDetails(interactions)(
              interaction.new.id
            );
            let updatedInteractionDetails = {
              ...interaction.new,
              intxId,
            };
            dispatch(
              setPrivatoSelectedIbCode({
                value: {},
                interactionId: interaction.new.id,
              })
            );
            loadCustomerDataFromIbCodeAuthenticatedInteraction(
              updatedInteractionDetails,
              attributesNew["chatibcode"],
              attributesNew["chatabicode"]
            );
          }
          break;
        case "connect":
          const { attributes = {} } = interaction;
          //CCCLOUD-388:: add auto focus, since there is issue
          //    when there are already interactions on barra (e.g. emails)
          //    since for barra currentInteraction is the call but for PEF focus is on email
          if (
            getBTChannel(interaction) === "VOICE" &&
            getBTCallType(interaction) === "INBOUND"
          ) {
            ChangeAutoFocus(interaction.id);
          }
          insertInteraction(interaction).then((response) => {
            const { intxId, serviceType } = response;
            if (intxId) {
              let tabKey = serviceType
                ? serviceType == serviceTypePrivato
                  ? privatoWidgetCode
                  : serviceType == serviceTypeAzienda
                  ? aziendaWidgetCode
                  : privatoWidgetCode
                : privatoWidgetCode;
              dispatch(
                setCurrentTabKey({
                  interactionId: interaction.id,
                  key: tabKey,
                })
              );
              httpGetLastClientSearched({
                interactionId: interaction.id,
                intxId: intxId,
              }).then((response = {}) => {
                const { lastClientSearchFound = false } = response;
                if (lastClientSearchFound === false) {
                  const updatedInteractionDetails = {
                    ...interaction,
                    intxId,
                  };
                  const { attributes = {} } = interaction;
                  console.log("Interaction attributes: ", attributes);
                  if (isAuthenticatedChat(interaction)) {
                    loadCustomerDataFromIbCodeAuthenticatedInteraction(
                      updatedInteractionDetails,
                      attributes["context.verified:ibcode"],
                      attributes["context.verified:abicode"]
                    );
                  } else if (isFullAuthenticatedCall(interaction)) {
                    loadCustomerDataFromIbCodeAuthenticatedInteraction(
                      updatedInteractionDetails,
                      attributes["ibcode"]
                    );
                  } else if (isPartialAuthenticatedCall(interaction)) {
                    loadCustomerDataFromIbCodePartialAuthenticatedInteraction(
                      updatedInteractionDetails,
                      attributes["ibcode"]
                    );
                  } else if (isTMLAvailable(interaction)) {
                    loadCustomerDataFromTmlCode(
                      updatedInteractionDetails,
                      attributes["tml"]
                    );
                  } else if (isContactIDAvailable(interaction)) {
                    loadCustomerDataFromContactId(
                      updatedInteractionDetails,
                      attributes["contactid"]
                    );
                  } else if (isNTCodeAvailable(interaction)) {
                    loadCustomerDataFromNTCode(
                      updatedInteractionDetails,
                      attributes["usernt"],
                      attributes["abi"]
                    );
                  } else if (isIdSoggettoAvailable(interaction)) {
                    loadCustomerDataFromIdSoggetto(
                      updatedInteractionDetails,
                      attributes["idsoggetto"],
                      attributes["abicode"]
                    );
                  } else {
                    lightAuthenticationServiceCall(updatedInteractionDetails);
                  }
                }
              });
            }
            if (attributes["autenticazioneobbligatoria"] === "true") {
              dispatch(stackNavPush(stackNavMandAuth));
            }
          });
          if (
            // CCCLOUD-368: removed condition for inbound, logic is done on purecloud flow
            //getBTCallType(interaction) === "INBOUND" &&
            getBTChannel(interaction) === "VOICE" &&
            isCustomFunctionAvailable(
              customFunctionCodes().playGeolocalizationMessage
            ) &&
            !attributes["first_geolocalizzazione"] &&
            attributes["transfertype"] !== "start_consult" &&
            getBTCallType(interaction) !== "CALLBACK"
          ) {
            httpPostStartGeolocalizationFlow({
              conversationId: interaction.id,
              callType: getCallTypeForGeolocalization(interaction),
            });
          }
          if (interaction.dialerCampaignId) {
            handleCampaignCallConnected(interaction);
          }
          if (getBTChannel(interaction) === "CHAT") {
            const { attributes = {} } = interaction;
            let { chatDisturboTimeout = 0, timeoutMap = {} } =
              exposedGetState().preference.profile;
            httpPostChatMessage({
              conversationId: interaction.id,
              defaultMessage: "CHAT_INIT",
              category: attributes["context.category"],
            });
            /*if(chatDisturboTimeout && chatDisturboTimeout>0){
              setTimeout(checkClientMessages, chatDisturboTimeout, interaction.id);
            }*/
            let chatCheckAgentWriteTimeout =
              timeoutMap["CHAT_CHECK_AGENT_WRITE"];
            if (chatCheckAgentWriteTimeout && chatCheckAgentWriteTimeout > 0) {
              setTimeout(checkClientMessages, chatCheckAgentWriteTimeout, {
                conversationId: interaction.id,
                category: attributes["context.category"],
                triggeredByTimeout: "CHAT_CHECK_AGENT_WRITE",
              });
            }
            //set nome , cognome , email for Free Chat to be Filled in Non-Cliente
            if(attributes["context.authenticated"] === "false")
            dispatch(
              setNotClientDefaultDataPropertyMap({
                interactionId: interaction.id,
                setvalue: [
                  { property: "name", value: attributes["context.firstname"] || ""},
                  { property: "surname", value: attributes["context.lastname"] || "" },
                  { property: "recapitoMail", value: attributes["context.email"] || "" },
                ],
              })
            );
          }
          // TRIGGERS WHEN INETERACTION INTERACTION SUCCESSFULLY CONNECTED
          dispatch(
            updateInteraction({
              data: interaction,
            })
          );
          break;
        case "disconnect":
          // TRIGGERS WHEN INETERACTION WRAP-UP BUTTON FRAMEWORK
          const { attributes: attributesDisconnect = {} } = interaction;
          dispatch(
            updateInteraction({
              data: interaction,
            })
          );
          const { intxId } = getInteractionDetails(
            exposedGetState().interaction.interactions
          )(interaction.id);
          httpPostUpdateDisconnectedInteraction(
            {
              intxId: intxId,
            },
            { interactionId: interaction.id }
          );
          if (!interaction.disposition) {
            const { timeoutMap = {} } = exposedGetState().preference.profile;
            let callType = getBTCallType(interaction);
            let channelType = getBTChannel(interaction);
            let checkTimeoutToTrigger;
            if (callType === "INBOUND" && channelType === "EMAIL")
              checkTimeoutToTrigger =
                timeoutMap["TIMEOUT_AUTOCLOSEACW_EMAIL_INBOUND"];
            else if (callType === "OUTBOUND" && channelType === "EMAIL")
              checkTimeoutToTrigger =
                timeoutMap["TIMEOUT_AUTOCLOSEACW_EMAIL_OUTBOUND"];
            else if (callType === "INBOUND" && channelType === "VOICE")
              checkTimeoutToTrigger =
                timeoutMap["TIMEOUT_AUTOCLOSEACW_VOICE_INBOUND"];
            else if (callType === "OUTBOUND" && channelType === "VOICE")
              checkTimeoutToTrigger =
                timeoutMap["TIMEOUT_AUTOCLOSEACW_VOICE_OUTBOUND"];
            else if (callType === "INBOUND" && channelType === "CHAT")
              checkTimeoutToTrigger =
                timeoutMap["TIMEOUT_AUTOCLOSEACW_CHAT_INBOUND"];
            else if (callType === "OUTBOUND" && channelType === "CHAT")
              checkTimeoutToTrigger =
                timeoutMap["TIMEOUT_AUTOCLOSEACW_CHAT_OUTBOUND"];
            // CCCLOUD-493: added condition for intxId
            if (intxId && checkTimeoutToTrigger && checkTimeoutToTrigger > 0) {
              let timeoutID = setTimeout(
                disconnectTimeoutTriggered,
                checkTimeoutToTrigger,
                {
                  interaction: interaction,
                }
              );
              dispatch(
                updateConsunDataByProperty({
                  interactionId: interaction.id,
                  data: {
                    property: "disconnectTimeoutId",
                    value: timeoutID,
                  },
                })
              );
            }
          }
          if (isAbandonRecallConversation(interaction)) {
            dispatch(
              showAbandonRecallRecallConfirmationModal({
                show: true,
                data: {
                  intxId: intxId,
                  conversationId:
                    attributesDisconnect["abandonrecallconversation"],
                },
              })
            );
          } else if (isSospesoConversation(interaction)) {
            updateSospesoAfterPEFEvent(
              {
                ...interaction,
                intxId,
              },
              attributesDisconnect["idsospeso"]
            );
          }
          /*
           * Not able to send the message since conversation is disconnected!
          if (getBTChannel(interaction) === "CHAT") {
            httpPostChatMessage({
              conversationId: interaction.id,
              defaultMessage: "CHAT_FINISH",
            });
          }*/
          break;
        case "acw":
          // TRIGGERS WHEN INTERACTION WILL BE MOVED TO QUEUE
          dispatch(
            updateInteraction({
              data: interaction,
            })
          );
          const { consunData } = exposedGetState().consuntiva;
          let { disconnectTimeoutId } = getConsunDataById(consunData)(
            interaction.id
          );
          if (disconnectTimeoutId) {
            clearTimeout(disconnectTimeoutId);
          }
          break;
        case "deallocate":
          // TRIGGERS WHEN INETERACTION SUCCESSFULLY HANGS UP
          dispatch(
            removeInteraction({
              data: interaction,
            })
          );
          break;
        case "consultTransfer":
          addParticipantDataToInteraction(interaction, {
            transferType: "start_consult",
          });
          break;
        case "blindTransfer":
          addParticipantDataToInteraction(interaction, {
            isAgentTransfer: "true",
            transferType: "blind",
          });
          if (
            !isCustomFunctionAvailable(
              customFunctionCodes().disableTransferAutoTrace
            )
          ) {
            transferAutoTrace(interaction);
          }
          break;
        case "completeConsultTransfer":
          addParticipantDataToInteraction(interaction, {
            isAgentTransfer: "true",
            transferType: "complete_consult",
          });
          if (
            !isCustomFunctionAvailable(
              customFunctionCodes().disableTransferAutoTrace
            )
          ) {
            transferAutoTrace(interaction);
          }
          break;
        default:
          console.log("No Event Matched");
      }
    } else if (message && message.type == "notificationSubscription") {
      const { data: notificationData = {} } = message;
      const { category = "" } = notificationData;
      //Below is code for logging the events
      httpPostEvent({ eventString: event.data });
      if (category == "interactionSelection") {
        const { data: currentNotificationData = {} } = notificationData;
        const { interactionId = "" } = currentNotificationData;
        if (interactionId) {
          console.log("inter-service state", exposedGetState().interaction);
          let currInteraction = exposedGetState().interaction.interactions.find(
            (currentInteraction) => {
              return currentInteraction.id === interactionId;
            }
          );
          if (currInteraction) {
            dispatch(setCurrentInteraction({ id: interactionId }));
            const { attributes = {} } = currInteraction;
            if (attributes["autenticazioneobbligatoria"] === "true") {
              dispatch(stackNavPush(stackNavMandAuth));
            } else {
              if (
                findIndexByCode(exposedGetState().stackNavigation.globalStack)(
                  stackNavMandAuth
                ) !== -1
              ) {
                dispatch(stackNavPop());
              }
            }
          } else {
            httpMissingInteractions({}).then(
              dispatch(setCurrentInteraction({ id: interactionId }))
            );
          }
        }
      }
    } else if (message && message.type == "processCallLog") {
      let { data: interactionData = {} } = message;

      let { category = "", interaction = {} } = interactionData;
    }
  };

  const disconnectTimeoutTriggered = ({ interaction }) => {
    const dispatch = exposedDispatch;
    dispatch(
      updateConsunDataByProperty({
        interactionId: interaction.id,
        data: {
          property: "disconnectTimeoutId",
          value: null,
        },
      })
    );
    autoCompleteACWTraceMethod(interaction);
    updateSystemPresence({ setSystemStatus: "AVAILABLE" });
    sendUserNotifictionOnPEF({
      message: `Attenzione! Non sei più in pronto`,
      type: "info",
    });
  };

  const autoCompleteACWTraceMethod = async (interaction) => {
    let { interactions = [] } = exposedGetState().interaction;
    const { intxId } = getInteractionDetails(interactions)(interaction.id);
    let reqData = {
      intxId: intxId,
    };
    await httpPostAutoCompleteACWTrace(reqData, {
      interactionId: interaction.id,
    });
  };

  const checkIntxIdExists = (interaction, insertIfNotExists = true) => {
    let { interactions = [] } = exposedGetState().interaction;
    const { intxId } = getInteractionDetails(interactions)(interaction.id);
    if (!intxId) {
      if (insertIfNotExists === true) {
        insertInteraction(interaction);
      } else {
        getIntxID(interaction);
      }
    }
  };

  const transferAutoTrace = async (interaction) => {
    const { intxId } = getInteractionDetails(
      exposedGetState().interaction.interactions
    )(interaction);
    const channel = getBTChannel(
      getInteractionDetails(exposedGetState().interaction.interactions)(
        interaction
      )
    );
    let traceType;
    if (channel == "EMAIL") traceType = transferAutoTraceEmailType;
    else if (channel == "CHAT") traceType = transferAutoTraceChatType;
    else traceType = transferAutoTraceCallType;
    let reqData = {
      traceType: traceType,
      intxId: intxId,
    };
    await httpPostTransferAutoTrace(reqData, { interactionId: interaction });
  };

  const getIntxID = async (interaction = {}) => {
    const channel = getBTChannel(interaction);
    const callType = getBTCallType(interaction);
    const { queueName, ani, calledNumber, id } = interaction;
    const { x_servizio } = interaction.attributes || {};
    let reqData = {
      channel: channel,
      callType: callType,
      queueName: queueName,
      service: x_servizio,
      ani: ani,
      dnis: calledNumber,
    };
    await httpGetIntxId(reqData, { interactionId: id });
  };

  const getBTChannel = (interaction) => {
    return getBTChannelOfInteraction(interaction);
    /*let channels = exposedGetState().common.channels;
    let myChannel = "";
    if (interaction.isEmail) {
      myChannel = channels.email;
    } else if (interaction.isChat) {
      myChannel = channels.chat;
    } else if (interaction.isMessage) {
      myChannel = channels.messages;
    } else {
      myChannel = channels.voice;
    }
    return myChannel;*/
  };

  /**
   * CCCLOUD-552: sometimes PEF send direction Outbound on inbound call,
   * this function check if there is the participant data "payload trasf acd", if available the direction is inbound since
   * this participant is set only by IVR.
   * This is a workaround to use until Genesys solve the issue
   * @param {*} interaction PEF interaction obj
   * @returns true if participant data is available, false otherwise
   */
  const isInboundWorkaroundDirection = (interaction = {}) => {
    let isInbound = false;
    try {
      const { attributes = {} } = interaction || {};
      if (attributes["payload trasfacd"] !== undefined) {
        isInbound = true;
      }
    } catch (e) {
      console.log("outbound workaround activated!", e);
    }
    return isInbound;
  };

  const getBTCallType = (interaction = {}) => {
    let callTypes = exposedGetState().common.callTypes;
    let myCallType = "";
    if (interaction.isInternal) {
      myCallType = callTypes.internal;
    } else if (interaction.isCallback) {
      myCallType = callTypes.callback;
    } else if (interaction.direction) {
      if (interaction.direction.toUpperCase() === callTypes.outbound) {
        myCallType = callTypes.outbound;
        if (isInboundWorkaroundDirection(interaction)) {
          myCallType = callTypes.inbound;
        }
      } else if (interaction.direction.toUpperCase() === callTypes.inbound) {
        myCallType = callTypes.inbound;
      }
    } else {
      myCallType = callTypes.inbound;
    }
    return myCallType;
  };

  const getCallTypeForGeolocalization = (interaction = {}) => {
    let callType = "";
    let callTypes = exposedGetState().common.callTypes;
    if (interaction.dialerCampaignId) {
      callType = "Recall";
    } else if (
      interaction.direction &&
      interaction.direction.toUpperCase() === callTypes.outbound
    ) {
      callType = "Outbound";
      if (isInboundWorkaroundDirection(interaction)) {
        callType = "Inbound";
      }
    } else {
      callType = "Inbound";
    }
    return callType;
  };

  const insertInteraction = (interaction) => {
    /*
    let channels = exposedGetState().common.channels;
    let callTypes = exposedGetState().common.callTypes;
    let myChannel = "";
    let myCallType = "";
    if (interaction.isEmail) {
      myChannel = channels.email;
    } else if (interaction.isChat) {
      myChannel = channels.chat;
    } else if (interaction.isMessage) {
      myChannel = channels.messages;
    } else {
      myChannel = channels.voice;
    }

    if (interaction.isInternal) {
      myCallType = callTypes.internal;
    } else if (interaction.isCallback) {
      myCallType = callTypes.callBack;
    } else if (interaction.direction.toUpperCase() === callTypes.outbound) {
      myCallType = callTypes.outbound;
    } else {
      myCallType = callTypes.inbound;
    }*/
    let myChannel = getBTChannel(interaction);
    let myCallType = getBTCallType(interaction);

    const { attributes = {} } = interaction;
    let startQueueUTC = attributes["startqueueutc"];
    let ani = interaction.ani;
    if(myChannel === window.BTFEDictionary["messages"]){
      const { displayAddress } = interaction;
      ani = displayAddress && `+${displayAddress}`
    }
    let reqData = {
      channel: myChannel,
      callType: myCallType,
      queueName: interaction.queueName,
      service:
        interaction.attributes && interaction.attributes.x_service
          ? interaction.attributes.x_service
          : null,
      ani: ani,
      dnis: interaction.calledNumber,
      startQueueUTC: startQueueUTC,
    };
    return httpPostInsertInteraction(reqData, {
      interactionId: interaction.id,
    });
  };

  const handleCampaignCallConnected = (interaction) => {
    const { dialerCampaignId, dialerContactId, dialerContactListId } =
      interaction;
    console.log(
      "handleCampaignCallConnected",
      dialerContactId,
      dialerContactListId
    );
    if (dialerContactId && dialerContactListId) {
      httpPostUpdateCampaignContact({
        interactionId: interaction.id,
        campaignId: dialerCampaignId,
        contactId: dialerContactId,
        contactListId: dialerContactListId,
        data: {
          Stato: "Answer",
        },
      });
    }
  };

  const loadCustomerDataFromIbCodePartialAuthenticatedInteraction = (
    interaction,
    ibCode,
    abiCode
  ) => {
    console.log(
      "loadCustomerDataFromIbCodePartialAuthenticatedInteraction",
      interaction,
      ibCode
    );
    const { intxId, id: interactionId, queueName } = interaction;
    let clientSearchRequest = {
      searchType: "codCliUsername",
      value: ibCode,
      interactionId,
      queueName,
      intxId,
      abiCode,
    };
    httpPostClientSearch(clientSearchRequest).then((response = {}) => {
      const { attributes = {} } = interaction;
      httpPutAuthenticationState({
        intxId,
        codice: ibCode,
        state: 1, // partial authenticated!
      }).then((res = {}) => {
        const { status } = res;
        let authFlow = exposedGetState().preference.profile.authFlow;
        if (status === "OK") {
          exposedDispatch(
            addAuthenticationValueByInteraction({
              authValue: ibCode,
              interactionId,
            })
          );
          if (authFlow === "v2") {
            let flowToken = attributes["authtoken"];
            let stepThree = attributes["auth_challenge ultimo"];
            if (!stepThree) {
              stepThree = attributes["auth_challenge step3"];
            }
            console.log(
              "Authv2 loadCustomerDataFromIbCodePartialAuthenticatedInteraction ",
              flowToken,
              stepThree
            );
            let authKeys = [...JSON.parse(`{ ${stepThree} }`).authChallenges];
            console.log(
              "Authv2 loadCustomerDataFromIbCodePartialAuthenticatedInteraction ",
              authKeys
            );
            if (flowToken && authKeys) {
              exposedDispatch(
                updateAuthenticationPropertyByInteractionAndValue({
                  authValue: ibCode,
                  interactionId,
                  property: "flowToken",
                  value: flowToken,
                })
              );
              exposedDispatch(
                updateAuthenticationPropertyByInteractionAndValue({
                  authValue: ibCode,
                  interactionId,
                  property: "authKeys",
                  value: authKeys,
                })
              );
              exposedDispatch(
                updateAuthenticationPropertyByInteractionAndValue({
                  authValue: ibCode,
                  interactionId,
                  property: "authenticationState",
                  value: "PARTIAL_AUTHENTICATED_IVR",
                })
              );
            }
          } else if (authFlow === "v3") {
            let ivrAuthToken = attributes["ivrauthtoken"];
            if (ivrAuthToken) {
              httpPostAuthV3Federation({
                ivrAuthToken: ivrAuthToken,
              }).then((response = {}) => {
                const { response: federationResponse } = response;
                const { authToken } = federationResponse || {};
                if (authToken) {
                  exposedDispatch(
                    updateAuthenticationPropertyByInteractionAndValue({
                      authValue: ibCode,
                      interactionId,
                      property: "authToken",
                      value: authToken,
                    })
                  );
                  exposedDispatch(
                    updateAuthenticationPropertyByInteractionAndValue({
                      authValue: ibCode,
                      interactionId,
                      property: "authenticationState",
                      value: "PARTIAL_AUTHENTICATED_IVR",
                    })
                  );
                }
              });
            }
          }
          // below call should be updated after authKeys thus on AutenticazioneV2Container the authKeys are updated when state change
        }
      });
      //end code for AutenticazioneV2
    });
  };

  const loadCustomerDataFromIbCodeAuthenticatedInteraction = (
    interaction,
    ibCode,
    abiCode
  ) => {
    const { intxId, id: interactionId, queueName } = interaction;
    let clientSearchRequest = {
      searchType: ( typeof abiCode != "undefined" && abiCode=="191429") ? "codice" : "codCliUsername",//Codice - Will search Leasing customer in specific
      value: ibCode,
      interactionId,
      queueName,
      intxId,
      abiCode,
    };
    httpPostClientSearch(clientSearchRequest).then((response = {}) => {
      httpPutAuthenticationState({
        intxId,
        codice: ibCode,
        state: 2, // authenticated!
      }).then((res = {}) => {
        const { status } = res;
        if (status === "OK") {
          exposedDispatch(
            addAuthenticationValueByInteraction({
              authValue: ibCode,
              interactionId,
            })
          );
          exposedDispatch(
            updateAuthenticationPropertyByInteractionAndValue({
              authValue: ibCode,
              interactionId,
              property: "authenticationState",
              value: "AUTHENTICATED",
            })
          );
        }
      });
    });
  };

  const loadCustomerDataFromTmlCode = (interaction, tml, abiCode) => {
    const { intxId, id: interactionId, queueName } = interaction;
    let clientSearchRequest = {
      searchType: "codTml",
      value: tml,
      interactionId,
      queueName,
      intxId,
      abiCode,
    };
    httpPostClientSearch(clientSearchRequest);
  };

  const loadCustomerDataFromContactId = (interaction, tml, abiCode) => {
    const { intxId, id: interactionId, queueName } = interaction;
    let clientSearchRequest = {
      searchType: "idContatto",
      value: tml,
      interactionId,
      queueName,
      intxId,
      abiCode,
    };
    httpPostClientSearch(clientSearchRequest);
  };

  const loadCustomerDataFromNTCode = (interaction, ntCode, abi) => {
    const { intxId, id: interactionId, queueName } = interaction;
    let clientSearchRequest = {
      searchType: "GBSNTh2oCode",
      value: ntCode,
      interactionId,
      queueName,
      intxId,
      abiCode: abi,
    };
    httpPostClientSearch(clientSearchRequest);
  };

  const loadCustomerDataFromIdSoggetto = (interaction, idSoggetto, abi) => {
    const { intxId, id: interactionId, queueName } = interaction;
    let clientSearchRequest = {
      searchType: "idSoggetto",
      value: idSoggetto,
      interactionId,
      queueName,
      intxId,
      abiCode: abi,
    };
    httpPostClientSearch(clientSearchRequest);
  };

  const interactionIdChangeSubcription = () => {
    let select = (state) => {
      return state.interaction.currentInteraction;
    };

    let currentValue;
    return () => {
      let previousValue = currentValue;
      currentValue = select(exposedGetState());
      if (!currentValue || currentValue === "noInteraction") return;
      if (previousValue !== currentValue) {
        console.log(
          "interactionSlice currentInteraction property changed from",
          previousValue,
          "to",
          currentValue
        );
        document.getElementById("softphone").contentWindow.postMessage(
          JSON.stringify({
            type: "updateInteractionState",
            data: {
              action: "pickup",
              id: currentValue,
            },
          }),
          "*"
        );
      }
    };
  };

  const httpPostCallbackDisconnect = async (conversationId, requestData = {}) => {
    let httpClient = new HttpClient();
    httpClient.setUrl(beServiceUrls().callbackDisconnect);
    let responseData = await httpClient
      .httpPost(requestData, {
        conversationId
      })
      .then((response) => {
        const { status = "" } = response;
        if (status === "OK") {
          console.log("httpPostCallbackDisconnect success");
        } else if (status === "KO") {
          toast.warn(getBaseErrorMessage("Warning", response), {
            containerId: globalAlertId,
          });
        } else {
          throw response;
        }
        return response;
      })
      .catch((err) => {
        toast.error(getBaseErrorMessage("Error", err), {
          containerId: globalAlertId,
        });
      });
    return responseData;
  }

  const httpPostChatClientMessageCheck = async (requestData) => {
    let httpClient = new HttpClient();
    httpClient.setUrl(beServiceUrls().chatCheckClientMessage);
    let responseData = await httpClient
      .httpPost(requestData)
      .then((response) => {
        const { status = "" } = response;
        if (status === "OK") {
          console.log("httpPostChatClientMessageCheck success");
        } else if (status === "KO") {
          toast.warn(getBaseErrorMessage("Warning", response), {
            containerId: globalAlertId,
          });
        } else {
          throw response;
        }
        return response;
      })
      .catch((err) => {
        toast.error(getBaseErrorMessage("Error", err), {
          containerId: globalAlertId,
        });
      });
    return responseData;
  };

  const checkClientMessages = (paramObj = {}) => {
    const {
      conversationId,
      category,
      chatAlertMsgDone = false,
      showAgentPopup = false,
      sendAlertMsgIfClientNotWrite = false,
      triggeredByTimeout,
    } = paramObj;
    console.log("checkClientMessages ", paramObj);
    httpPostChatClientMessageCheck({
      conversationId: conversationId,
      category: category,
    }).then((response) => {
      const { status } = response || {};
      if (status === "OK") {
        const { state } = getInteractionDetails(
          exposedGetState().interaction.interactions
        )(conversationId);
        if (!state || state === window.BTFEDictionary["disconnected"]) {
          console.log(
            "checkClientMessages interaction is disconnected, return."
          );
          return;
        }
        const { clientWrite = true, agentWrite = false } = response;
        /*if(agentWrite === false && showAgentPopup === true
          ){
          httpPostChatMessage({
            conversationId: conversationId,
            defaultMessage: "CHAT_CHECKING_MSG",
            category: category,
          });
          exposedDispatch(addNotificationData({
            id: conversationId,
            data: {
              title: "Timeout chat",
              text: "Rispondi a cliente!"
            }
          }));
          exposedDispatch(updateNotificationProperty({
            id: conversationId,
            property: "showPopover",
            value: true
          }));
          return;
        }*/
        if (!clientWrite) {
          if (chatAlertMsgDone === true) {
            const { intxId } = getInteractionDetails(
              exposedGetState().interaction.interactions
            )(conversationId);
            // if I have already sent the alert message to the client close the chat
            exposedDispatch(toggleSpinnerById(globalSpinnerId));
            httpPostEliminaSpam(
              {
                intxId,
                chatSpam: true,
              },
              {
                interactionId: conversationId,
              }
            ).then((responseSpam) => {
              exposedDispatch(toggleSpinnerById(globalSpinnerId));
              const { status: mailSpamStatus } = responseSpam || {};
              if (mailSpamStatus === "OK") {
                toast.success("Success - Chat Disturbo", {
                  containerId: globalAlertId,
                });
              } else {
                toast.warn(getBaseErrorMessage("Warning", responseSpam), {
                  containerId: globalAlertId,
                });
              }
            });
            return;
          } else if (sendAlertMsgIfClientNotWrite) {
            httpPostChatMessage({
              conversationId: conversationId,
              defaultMessage: "CHAT_ALERT_MSG",
              category: category,
            });
            const { timeoutMap = {} } = exposedGetState().preference.profile;
            let chatCheckClientAfterMsgTimeout =
              timeoutMap["CHAT_CHECK_CLIENT_AFTER_MSG"];
            if (
              chatCheckClientAfterMsgTimeout &&
              chatCheckClientAfterMsgTimeout > 0
            ) {
              setTimeout(checkClientMessages, chatCheckClientAfterMsgTimeout, {
                conversationId: conversationId,
                category: category,
                chatAlertMsgDone: true,
                triggeredByTimeout: "CHAT_CHECK_CLIENT_AFTER_MSG",
              });
            }
          } else if (agentWrite) {
            const { timeoutMap = {} } = exposedGetState().preference.profile;
            // send custom message
            let alertMsgTimeout = timeoutMap["CHAT_CLIENT_NOWRITE_ALERT"];
            if (alertMsgTimeout && alertMsgTimeout > 0) {
              setTimeout(checkClientMessages, alertMsgTimeout, {
                conversationId: conversationId,
                category: category,
                sendAlertMsgIfClientNotWrite: true,
                triggeredByTimeout: "CHAT_CLIENT_NOWRITE_ALERT",
              });
            }
          } else if (!agentWrite) {
            // if the agent have not written something after the first timeout show a popup
            /* //incontro 09/02/2022 al posto di fare partire un altro timeout, 
               // appena scade il primo manda un messaggio di "sto verificando, attenda" e manda notifica ad operatore.
            const { timeoutMap = {} } = exposedGetState().preference.profile;
            let popMsgTimeout = timeoutMap["CHAT_AGENT_MSG_POPUP"];
            if(popMsgTimeout && popMsgTimeout >0){
              setTimeout(checkClientMessages, popMsgTimeout, {
                conversationId: conversationId,
                category: category,
                showAgentPopup: true
              });
            }*/
            httpPostChatMessage({
              conversationId: conversationId,
              defaultMessage: "CHAT_CHECKING_WAIT_MSG",
              category: category,
            });
            /*exposedDispatch(addNotificationData({
              id: conversationId,
              data: {
                title: "Timeout chat",
                text: "Rispondi a cliente!"
              }
            }));
            exposedDispatch(updateNotificationProperty({
              id: conversationId,
              property: "showPopover",
              value: true
            }));
            */
            let { timeoutMap = {} } = exposedGetState().preference.profile;
            let waitingMinute = timeoutMap[triggeredByTimeout] / 60000;
            let { attributes = {} } = getInteractionDetails(
              exposedGetState().interaction.interactions
            )(conversationId);
            let nameSurname = conversationId;
            if (
              attributes["context.firstname"] &&
              attributes["context.lastname"]
            ) {
              nameSurname = `${attributes["context.firstname"]} ${attributes["context.lastname"]}`;
            }
            sendUserNotifictionOnPEF({
              message: `Attenzione! Non stai rispondendo alla chat con ${nameSurname} da ${waitingMinute} min. Rispondi!`,
              type: "warning",
            });
            return;
          }
        }
      }
    });
  };

  return {
    httpPostCallbackDisconnect,
    interactionEventListener,
    interactionIdChangeSubcription,
    getBTCallType,
  };
};

export const {
  httpPostCallbackDisconnect,
  interactionEventListener,
  interactionIdChangeSubcription,
  getBTCallType,
} = Service();
