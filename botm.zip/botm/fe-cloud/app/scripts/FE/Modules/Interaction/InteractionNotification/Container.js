import React, { useEffect } from "react";
// import { useSelector } from "react-redux";
// import { v4 as uuidv4 } from "uuid";
// import { interactionEventListener } from "./Service";
// import MailNotification from "./NotificationBarByType/MailNotification";
// import ChatNotification from "./NotificationBarByType/ChatNotification";

const Container = (props) => {
  // const { interactions = [] } = useSelector(
  //   (state) => state.interactionNotification
  // );

  // useEffect(() => {
  //   window.addEventListener("message", interactionEventListener, false);
  //   return () => {
  //     window.removeEventListener("message", interactionEventListener, false);
  //   };
  // }, []);

  return (
    null
  );
};

export default Container;
