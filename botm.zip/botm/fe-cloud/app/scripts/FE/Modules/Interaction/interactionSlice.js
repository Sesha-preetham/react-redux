import { createSlice } from "@reduxjs/toolkit";

let initialInteractionNotificationObj = {
  data: [],
  read: false,
  showPopover: false,
};

let initialState = {
  interactions: [],
  notifications: {
    noInteraction: { ...initialInteractionNotificationObj },
  },
  currentInteraction: "noInteraction",
};

const interactionSliceCodes = () => {
  return {
    serviceTypePrivato: "PRIVATO",
    serviceTypeAzienda: "AZIENDA",
  };
};

export const { serviceTypePrivato, serviceTypeAzienda } =
  interactionSliceCodes();

const interactionSlice = createSlice({
  name: "interaction",
  initialState,
  reducers: {
    addInteraction(state, action) {
      const { payload = {} } = action;
      const { data = {} } = payload;
      const { id = "noInteraction" } = data;
      let currentIndex = state.interactions.findIndex((currentInteraction) => {
        return currentInteraction.id === id;
      });
      if (currentIndex == -1) {
        state.interactions.push(data);
      }
      if (!state.notifications[id]) {
        state.notifications[id] = { ...initialInteractionNotificationObj };
      }
    },
    updateInteraction(state, action) {
      const { payload = {} } = action;
      const { data = {} } = payload;
      const { id = "noInteraction" } = data;
      let currentIndex = state.interactions.findIndex((currentInteraction) => {
        return currentInteraction.id === id;
      });
      if (currentIndex != -1) {
        let currentInteractionData = state.interactions[currentIndex];
        state.interactions[currentIndex] = {
          ...currentInteractionData,
          ...data,
        };
      }
    },
    updateInteractionProperty(state, action) {
      const { payload = {} } = action;
      const { id = "noInteraction", property, value } = payload;
      if (!property) return;
      let currentIndex = state.interactions.findIndex((currentInteraction) => {
        return currentInteraction.id === id;
      });
      if (currentIndex !== -1) {
        state.interactions[currentIndex][property] = value;
      }
    },
    setCurrentInteraction(state, action) {
      console.log("setCurrentInteraction");
      const { payload = {} } = action;
      const { id = "noInteraction" } = payload;
      state.currentInteraction = id;
    },
    removeInteraction(state, action) {
      const { payload = {} } = action;
      const { data = {} } = payload;
      const { id = "noInteraction" } = data;
      let currentIndex = state.interactions.findIndex((currentInteraction) => {
        return currentInteraction.id === id;
      });
      if (currentIndex != -1) {
        state.interactions.splice(currentIndex, 1);
      }
      if (state.notifications[id]) {
        delete state.notifications[id];
      }
      if (state.interactions.length === 0) {
        state.currentInteraction = "noInteraction";
      }
    },
    resetInteractions(state, action) {
      state = initialState;
    },
    addNotificationData(state, action) {
      const { payload = {} } = action;
      const { data = {}, id = "noInteraction" } = payload;
      if (!state.notifications[id]) return;
      state.notifications[id].data.push(data);
    },
    resetNotificationInteraction(state, action) {
      const { payload = {} } = action;
      const { id = "noInteraction" } = payload;
      if (!state.notifications[id]) return;
      state.notifications[id] = { ...initialInteractionNotificationObj };
    },
    updateNotificationProperty(state, action) {
      const { payload = {} } = action;
      const { id = "noInteraction", property, value } = payload;
      if (!state.notifications[id]) return;
      if (!property) return;
      state.notifications[id][property] = value;
    },
  },
});

export const getInteractionDetails = (interactions) => {
  return (id = "noInteraction") => {
    for (let i = 0; i < interactions.length; i++) {
      if (interactions[i]) {
        const { id: interactionId = "noInteraction" } = interactions[i];
        if (interactionId != "" && interactionId === id) {
          return interactions[i];
        }
      }
    }
    return {};
  };
};

export const getNotificationDetails = (notifications = {}) => {
  return (id = "noInteraction") => {
    if (notifications[id]) {
      return { ...notifications[id] };
    }
    return {};
  };
};

export const {
  addInteraction,
  updateInteraction,
  removeInteraction,
  setCurrentInteraction,
  resetInteractions,
  updateInteractionProperty,
  addNotificationData,
  resetNotificationInteraction,
  updateNotificationProperty,
} = interactionSlice.actions;

export default interactionSlice.reducer;
