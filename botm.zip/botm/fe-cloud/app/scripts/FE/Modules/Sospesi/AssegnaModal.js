import React, { useEffect, useState } from "react"
import FormFieldHandler from "../../CommonComponents/Forms/FormFieldHandler";
import SelectField from "../../CommonComponents/Forms/SelectField";
import MyModal from "../../CommonComponents/Modal/MyModal";
import MySpinner from "../../CommonComponents/Spinner/MySpinner";
import { httpGetAgents } from "../../Utils/CommonUtil";
import { exposedDispatch } from "../../Store/store";
import { httpPostUpdateSospeso } from "./SospesiService";
import { sospesoModalSpinnerId, toggleSpinnerById } from "../../CommonComponents/Spinner/spinnerSlice";

const AssegnaModal = ({ configuration = {} } = props) => {

    const {
        showAssegnaModal,
        modalData,
        handleOnCloseModal,
        handleOnAssegnaClickCallBack = () => { console.log("Success")},
    } = configuration;

    let handleOnhide = () => {
        console.log("insertMediaType modal onHide");
        handleOnCloseModal(false);
    };


    const [ formFields ] = useState(new FormFieldHandler(true));

    useEffect(()=>{
        const dispatch=exposedDispatch;
        if(showAssegnaModal === true){
            dispatch(toggleSpinnerById(sospesoModalSpinnerId));
            httpGetAgents({},true).then((agentOptions = []) => {
                dispatch(toggleSpinnerById(sospesoModalSpinnerId));
                let filteredOptions = agentOptions.filter(el => (el.label)?true:false);
                formFields.getField("agentField").theField.reloadOptions(filteredOptions);
            });
        }
    },[showAssegnaModal]);

    const agentField = {
        uniqueID: "agentField",
        multiSelect: false,
        label: "",
        placeHolder: "Seleziona operatore",
        readonly: false,
        visible: true,
        disabled: false,
        options: [],
        searchEnabled: true,
        setValue: (obj) => {
            console.log("setValue", obj);
        },
        form: formFields,
    }

    const assegnaModal = {
        uniqueID: "assegnaModal",
        modalClass: "my-modal",
        dialogClassName: "modal-w",
        title: {
          content: "Assegna Sospeso",
          class: "widget-title",
        },
        modalShow: showAssegnaModal,
        modalHeaderShow: true,
        backdrop: {
          enable: true,
        },
        events: {
          onHide: () => {
            handleOnhide();
          },
          onEntered: () => {
            console.log("multiClienteModal modal onEntered");
          },
          onExited: () => {
            console.log("multiClienteModal modal onExited");
          },
        },
    };

    let handleAssegnaModalClick = () => {
        const dispatch = exposedDispatch;
        const { id = "" } = modalData;
        const formValue = formFields.getField("agentField").theField.getValue();
        const{ value: agentCode = "" } = formValue; //CCCLOUD-178
        if(agentCode !== "" && id !== ""){
            dispatch(toggleSpinnerById(sospesoModalSpinnerId));
            httpPostUpdateSospeso({
                id: id,
                agent: agentCode,
                updateType: "Assegna"
            }).then( (r) => {
                dispatch(toggleSpinnerById(sospesoModalSpinnerId));
                handleOnAssegnaClickCallBack();
                handleOnCloseModal(false);
            })
        }
    }

    
    return(
        <MyModal configuration={assegnaModal}>
            <>
                <MySpinner uniqueID={sospesoModalSpinnerId} />
                <div className="assegna-modal-internal">
                    <div className="row no-gutters">
                        <div className="col-12">
                            <SelectField configuration={agentField} />
                        </div>
                    </div>
                    <div className="row no-gutters">
                        <div className="col-10 offset-1 ">
                            <button
                                type="button"
                                className={`btn Rectangle-Button-Blue w-100`}
                                onClick={() => {handleAssegnaModalClick(modalData)}}
                            >Assegna</button>
                        </div>
                    </div>
                </div>
            </>
        </MyModal>
    );
}

export default AssegnaModal;