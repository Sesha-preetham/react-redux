import { beServiceUrls, pureCloudOrigin } from "../../Client/ClientProperties";
import { toast } from "react-toastify";
import { globalAlertId, sospesiAlertId } from "../../CommonComponents/AlertToast/AlertIdConstants";
import { getBaseErrorMessage, getBTChannelOfInteraction } from "../../Utils/CommonUtil";
import HttpClient from "../../Utils/HttpClient";
import { exposedDispatch } from "../../Store/store";
import { setSospesiCount } from "./sosposeSlice";

export const httpGetSospesiCount = async (request = {}) => {
  let httpClient = new HttpClient();
  httpClient.setUrl(beServiceUrls().getSospesiCount);
  let responseData = await httpClient.httpGet(request).then((response) => {
    const { status = "", count } = response;
    if (status === "OK") {
      if (count >= 0) {
        exposedDispatch(
          setSospesiCount({
            count: count,
          })
        );
      }
      return response;
    }
    return response;
  });
  return responseData;
};

export const httpPostSospesiGetRecapito = async (request = {}) => {
  let httpClient = new HttpClient();
  httpClient.setUrl(beServiceUrls().getSospesiRecapito);
  let recapito = await httpClient.httpPost(request).then((response) => {
    const { recapito } = response;
    return recapito;
  }).catch(err => {
    toast.error(getBaseErrorMessage("Error", err), {
      containerId: sospesiAlertId,
    });
    return undefined;
  });
  return recapito;
};

export const httpGetSospesiList = async (request = {}) => {
  let httpClient = new HttpClient();
  httpClient.setUrl(beServiceUrls().getSospesiList);
  let responseData = await httpClient
    .httpGet(request)
    .then((response) => {
      const { status = "", sospesiList: sospesiResponse = [] } = response;
      if (status === "OK") {
        return sospesiResponse;
      } else if (status === "KO") {
        toast.warn(getBaseErrorMessage("Warning", response), {
          containerId: sospesiAlertId,
        });
      } else {
        throw response;
      }
      return [];
    })
    .catch((err) => {
      toast.error(getBaseErrorMessage("Error", err), {
        containerId: sospesiAlertId,
      });
      return [];
    });
  return responseData;
};

export const httpPostUpdateSospeso = async (request = {}) => {
  let httpClient = new HttpClient();
  httpClient.setUrl(beServiceUrls().updateSospeso);
  let responseData = await httpClient
    .httpPost(request)
    .then((response) => {
      const { status = "", errorCode = "", errorMessage = "" } = response;
      if (status === "OK") {
        toast.success("Success", { containerId: sospesiAlertId });
        return response;
      } else if (status === "KO") {
        toast.warn(getBaseErrorMessage("Warning", response), {
          containerId: sospesiAlertId,
        });
      } else {
        throw response;
      }
      return response;
    })
    .catch((err) => {
      toast.error(getBaseErrorMessage("Error", err), {
        containerId: sospesiAlertId,
      });
      return err;
    });
  return responseData;
};

export const updateSospesoAfterPEFEvent = (interaction = {}, idSospeso) => {
  const { intxId } = interaction;
  if(!idSospeso || !intxId) return;
  const channel = getBTChannelOfInteraction(interaction);
  const state = (channel === window.BTFEDictionary["voice"]) ? "Chiuso con voce": (channel === window.BTFEDictionary["email"]) ? "Chiuso con mail" : undefined;
  if(state){
    httpPostUpdateSospeso({
      id: idSospeso,
      updateType: state,
      intxId 
    }).then((response = {}) => {
      const { status } = response;
      if(status === "OK"){
        toast.success("Sospeso aggiornato", { containerId: globalAlertId });
      }
    })
  }
}

const Service = () => {
  const sospesiEventListener = (event) => {
    if (event.origin !== pureCloudOrigin) return;
    let message = JSON.parse(event.data);
    if (message && message.type == "interactionSubscription") {
      const { data = {} } = message;
      const { category = "", interaction = {} } = data;
      switch (category) {
        case "acw":
          httpGetSospesiCount();
          break;
      }
    }
  };

  return {
    sospesiEventListener,
  };
};

export const { sospesiEventListener } = Service();
