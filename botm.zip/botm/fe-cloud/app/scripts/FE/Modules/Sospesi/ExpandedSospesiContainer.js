import React, { useEffect, useState, useRef } from "react";
import { useDispatch, useSelector } from "react-redux";
import IconBlueClose from "../../CommonComponents/Common/Icons/IconBlueClose";
import IconOptions from "../../CommonComponents/Common/Icons/IconOptions";
import CheckBox from "../../CommonComponents/Forms/CheckBox";
import FormFieldHandler from "../../CommonComponents/Forms/FormFieldHandler";
import SelectField from "../../CommonComponents/Forms/SelectField";
import SimpleTable from "../../CommonComponents/SimpleTable/SimpleTable";
import { stackNavPop } from "../../Main/StackNavigation/stackNavigationSlice";
import ExpandedWidgetWrapper from "../Widgets/ExpandedWidgetWrapper";
import {
  getDisplayDataByCode,
  sospesiWidgetCode,
  updateWidgetMenuEventByCode,
} from "../Widgets/widgetsSlice";
import { reduceToOptions } from "../../Utils/CommonUtil";
import {
  httpGetSospesiCount,
  httpGetSospesiList,
  httpPostSospesiGetRecapito,
  httpPostUpdateSospeso,
} from "./SospesiService";
import WidgetTitle from "../Widgets/WidgetTitle";
import WidgetWrapper from "../Widgets/WidgetWrapper";
import MyPopover from "../../CommonComponents/Popover/MyPopover";
import AssegnaModal from "./AssegnaModal";
import AlertToast from "../../CommonComponents/AlertToast/AlertToast";
import { sospesiAlertId } from "../../CommonComponents/AlertToast/AlertIdConstants";
import {
  globalSpinnerId,
  toggleSpinnerById,
} from "../../CommonComponents/Spinner/spinnerSlice";
import { exposedDispatch } from "../../Store/store";
import ClickToDialModal from "../../CommonComponents/Modal/ClickToDialModal";
import { showSospesiClickToDialModal } from "./sosposeSlice";

const ExpandedSospesiContainer = (props) => {
  const { elStack = {} } = props;
  const [formFields] = useState(new FormFieldHandler(true));
  const { widgets } = useSelector((state) => state.widgets);
  const dispatch = useDispatch();

  const [sospesiList, setSospesiList] = useState([]);

  const { clickToDialModal = {} } = useSelector((state) => state.sospesi);

  const { show: clickToDialShow = false, data: clickToDialData = {} } =
    clickToDialModal;

  const [sospesiMenuShow, sospesiShow] =
    getDisplayDataByCode(widgets)(sospesiWidgetCode);

  const [showAssegnaSospesoModal, setShowAssegnaSospesoModal] = useState(false);
  const [assegnaModalData, setAssegnaModalData] = useState({});

  let handleOnCloseAssegnaModal = () => {
    console.log("AssegnaModal close");
    setShowAssegnaSospesoModal(false);
    setAssegnaModalData({});
  };

  let handleOnAssegnaClickCallBack = () => {
    reloadSospesiList();
  };

  let reloadSospesiList = () => {
    const clientPrivatoField = formFields.getField("clientePrivato");
    if (clientPrivatoField) {
      const { value = "" } = clientPrivatoField.theField.getValue() || {};
      if (value !== null && value !== "") {
        loadSospesiData({ servType: value });
      }
    }
    httpGetSospesiCount();
  };

  let clientPrivatoOptions = [
    {
      value: "PRIVATO",
      label: "Privato",
    },
    {
      value: "AZIENDA",
      label: "Azienda",
    },
  ];

  let handleOnChangeClientePrivato = (obj) => {
    const { currentValue = {} } = obj;
    const { value = "" } = currentValue;
    loadSospesiData({ servType: value });
  };

  let clientePrivato = {
    uniqueID: "clientePrivato",
    multiSelect: false,
    label: "",
    placeHolder: "Cliente privato",
    readonly: false,
    visible: true,
    disabled: false,
    value: {
      value: "AZIENDA",
      label: "Azienda",
    },
    options: [...clientPrivatoOptions],
    searchEnabled: true,
    validation: {
      externalCheck: (value) => {
        return true;
      },
    },
    setValue: handleOnChangeClientePrivato,
    form: formFields,
  };

  let mergeExpenses = {
    uniqueID: "mergeExpenses",
    label: "Unisci spospesi di uno stesso cliente",
    labelClass: "sospesi-merge-expense-label",
    readonly: false,
    visible: false, // for first release keep it hidden
    disabled: false,
    checked: false,
    setValue: (obj) => {
      console.log("setValue", obj);
    },
    form: formFields,
  };
  let testData = () => {
    let array = [];
    for (let i = 0; i < 1000; i++) {
      array.push({
        servizio: "Row " + (i + 1),
      });
    }
    return array;
  };

  const loadSospesiData = (request) => {
    const dispatch = exposedDispatch;
    dispatch(toggleSpinnerById(globalSpinnerId));
    httpGetSospesiList(request).then((responseList) => {
      dispatch(toggleSpinnerById(globalSpinnerId));
      setSospesiList(responseList);
    });
  };

  let handleChiudiWith = (rowData, type) => {
    const { id: idSospeso, queueName, soggetto, serviceId, abiCode } = rowData;
    if (!type || !idSospeso) return;
    exposedDispatch(toggleSpinnerById(globalSpinnerId));
    httpPostSospesiGetRecapito({
      idSospeso,
      type: type === "call" ? "VOICE" : "EMAIL",
    }).then((recapito) => {
      exposedDispatch(toggleSpinnerById(globalSpinnerId));
      exposedDispatch(
        showSospesiClickToDialModal({
          show: true,
          data: {
            type,
            idSospeso,
            queueName,
            servId: serviceId,
            idSoggetto: soggetto,
            abicode: abiCode,
            phone: type === "call" ? recapito : undefined,
            email: type === "email" ? recapito : undefined,
          },
        })
      );
    });
  };

  let handleChiudiSospeso = (rowData, type) => {
    console.log("handleChiudiSospeso", rowData);
    const { id } = rowData;
    if (id) {
      httpPostUpdateSospeso({ id: id, updateType: type }).then((response) => {
        const { status } = response;
        if (status === "OK") {
          reloadSospesiList();
        }
      });
    }
  };

  let handleAssegnaSospeso = (rowData) => {
    console.log("handleAssegnaSospeso", rowData);
    setShowAssegnaSospesoModal(true);
    setAssegnaModalData(rowData);
  };

  useEffect(() => {
    let option = clientPrivatoOptions[1];
    //formFields.getField("clientePrivato").theField.setValue(option);
    //const { value } = option;
    //loadSospesiData({servType: value});
  }, []);

  const handleOnCloseClickToDialModal = () => {
    exposedDispatch(
      showSospesiClickToDialModal({
        show: false,
        data: {},
      })
    );
  };

  const handleOnConfirmClickToDialModal = () => {
    exposedDispatch(
      showSospesiClickToDialModal({
        show: false,
        data: {},
      })
    );
    exposedDispatch(
      updateWidgetMenuEventByCode({
        widget: {
          code: sospesiWidgetCode,
          menuEventState: !sospesiMenuShow,
        },
      })
    );
    exposedDispatch(stackNavPop());
  };

  const filterQueueListForClickToDial = (rlData = {}) => {
    const { servId } = clickToDialData;
    const { serviceId } = rlData;
    if (servId) {
      return servId === serviceId;
    } else {
      return true;
    }
  };

  const getDefaultQueueForClickToDial = (options = []) => {
    const { queueName } = clickToDialData;
    if (!queueName) return;
    let option = options.find((q) => q.label === queueName);
    if (!option && options.length > 0) {
      option = options[0];
    }
    return option;
  };

  const clickToDialConfig = {
    showModal: clickToDialShow,
    events: {
      handleOnCloseModal: () => {
        handleOnCloseClickToDialModal();
      },
      handleOnConfirmationModal: () => {
        handleOnConfirmClickToDialModal();
      },
    },
    dialOptions: {
      number: clickToDialData.phone,
      address: clickToDialData.email,
      type: clickToDialData.type,
      attributes: {
        abicode: clickToDialData.abicode,
        idSoggetto: clickToDialData.idSoggetto,
        idSospeso: clickToDialData.idSospeso,
      },
    },
    queueSelection: true,
    filterQueueList: filterQueueListForClickToDial,
    getDefaultQueue: getDefaultQueueForClickToDial,
    channelSelection: false,
  };

  let sospesiTable = {
    uniqueID: "sospesiTable",
    lastColumnFixed: true,
    scrollY: true,
    metaData: [
      {
        Header: "Servizio",
        accessor: "servizio",
      },
      {
        id: "canale",
        Header: "Canale",
        accessor: "canale",
      },
      {
        id: "dataInizio",
        Header: "Data inizio",
        accessor: "dataInizio",
      },
      {
        id: "ani",
        Header: "Ani",
        accessor: "ani",
      },
      {
        id: "dnis",
        Header: "Dnis",
        accessor: "dnis",
      },
      /*{
        id: "tentativiDiContatto",
        Header: "Tentativi di contatto",
      },
      {
        id: "ultimoContatto",
        Header: "Ultimo contatto",
      },*/
      {
        id: "username",
        Header: "Username",
        accessor: "username",
      },
      {
        id: "codiceCliente",
        Header: "Codice cliente",
        accessor: "codiceCliente",
      },
      {
        id: "Banca",
        Header: "Banca",
        accessor: "banca",
      },
      {
        id: "cognome",
        Header: "Cognome",
        accessor: "cognome",
      },
      {
        id: "nome",
        Header: "Nome",
        accessor: "nome",
      },
      {
        id: "ticketHDA",
        Header: "N° ticket HDA",
        accessor: "ticket",
      },
      {
        id: "soggetto",
        Header: "IdSoggetto",
        accessor: "soggetto",
      },
      {
        id: "denominazione",
        Header: "Denominazione",
        accessor: "denominazione",
      },
      {
        id: "codiceEsercente",
        Header: "Codice Esercente",
        accessor: "codiceEsercente",
      },
      {
        id: "codiceTml",
        Header: "Codice Tml",
        accessor: "codiceTml",
      },
      {
        id: "codiceSia",
        Header: "Codice Sia",
        accessor: "codiceSia",
      },
      {
        id: "altriLink",
        Header: (headerInfo, props) => {
          return null;
        },
        Cell: (cellInfo) => {
          let { original } = cellInfo.row;
          const [showPopover, setShowPopover] = useState(false);
          return (
            <MyPopover
              configuration={{
                uniqueID: "optionsPopOver",
                popoverShow: showPopover,
                popoverPlacement: "left-start",
                popoverClass: "sospesi-tabellla-row-popover",
                overlayTriggerElement: (
                  <IconOptions
                    configuration={{
                      onClick: () => {
                        setShowPopover(!showPopover);
                      },
                    }}
                  />
                ),
              }}
            >
              <div className="d-flex flex-column">
                <div
                  className="sospesi-options-content my-2"
                  onClick={() => {
                    handleChiudiWith(original, "email");
                    //handleChiudiSospeso(original, "Chiuso con mail");
                    setShowPopover(!showPopover);
                  }}
                >
                  <span>Chiudi da mail</span>
                </div>
                <div
                  className="sospesi-options-content my-2"
                  onClick={() => {
                    handleChiudiWith(original, "call");
                    //handleChiudiSospeso(original, "Chiuso con voce");
                    setShowPopover(!showPopover);
                  }}
                >
                  <span>Chiudi da voce</span>
                </div>
                <div
                  className="sospesi-options-content my-2"
                  onClick={() => {
                    handleChiudiSospeso(original, "Chiudi senza ricontatto");
                    setShowPopover(!showPopover);
                  }}
                >
                  <span>Chiudi senza ricontatto</span>
                </div>
                <div
                  className="sospesi-options-content my-2"
                  onClick={() => {
                    handleAssegnaSospeso(original);
                    setShowPopover(!showPopover);
                  }}
                >
                  <span>Assegna</span>
                </div>
              </div>
            </MyPopover>
          );
        },
      },
    ],
    sort: [
      {
        id: "servizio",
        desc: false,
      },
    ],
    pagination: true,
    data: [...sospesiList],
  };

  let handleOnSospesiStackMounted = (stack) => {
    console.log(stack);
  };

  let handleOnSospesiStackUnMounted = (stack) => {
    console.log(stack);
  };

  return (
    <WidgetWrapper widgetShow={sospesiShow}>
      <ExpandedWidgetWrapper
        className={"sospesi-expand-main-container"}
        elStack={elStack}
        events={{
          handleOnStackMounted: handleOnSospesiStackMounted,
          handleOnStackUnMounted: handleOnSospesiStackUnMounted,
        }}
      >
        <WidgetTitle
          title="I miei sospesi"
          iconElement={
            <IconBlueClose
              configuration={{
                onClick: (active) => {
                  dispatch(
                    updateWidgetMenuEventByCode({
                      widget: {
                        code: sospesiWidgetCode,
                        menuEventState: !sospesiMenuShow,
                      },
                    })
                  );
                  dispatch(stackNavPop());
                },
              }}
            />
          }
        />
        <>
          <AlertToast
            configuration={{
              unqiueID: sospesiAlertId,
              className: "inline-toast-container",
              transition: "flip",
            }}
          />
          <AssegnaModal
            configuration={{
              showAssegnaModal: showAssegnaSospesoModal,
              modalData: assegnaModalData,
              handleOnCloseModal: handleOnCloseAssegnaModal,
              handleOnAssegnaClickCallBack: handleOnAssegnaClickCallBack,
            }}
          />
          <div className="d-flex flex-column">
            <div className="d-flex">
              <div className="row no-gutters flex-fill">
                <div className="col-4">
                  <SelectField configuration={clientePrivato} />
                </div>
                <div className="col-4 ml-4 p-2">
                  <CheckBox configuration={mergeExpenses} />
                </div>
              </div>
            </div>
            <div className="mt-2">
              <SimpleTable configuration={sospesiTable} />
            </div>
          </div>
          <ClickToDialModal configuration={clickToDialConfig} />
        </>
      </ExpandedWidgetWrapper>
    </WidgetWrapper>
  );
};

export default ExpandedSospesiContainer;
