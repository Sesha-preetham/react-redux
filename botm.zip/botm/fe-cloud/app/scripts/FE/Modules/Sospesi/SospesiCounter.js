import React, { useEffect } from "react";
import { useSelector } from "react-redux";
import { httpGetSospesiCount, sospesiEventListener } from "./SospesiService";

const SospesiCounter = (props = {}) => {
  const { count: sospesiCount = -1 } = useSelector((state) => state.sospesi);

  const {
      className = ""
  } = props;

  useEffect(() => {
    httpGetSospesiCount();
    window.addEventListener("message", sospesiEventListener, false);
    return () => {
      window.removeEventListener("message", sospesiEventListener, false);
    };
  }, []);

  return sospesiCount > 0 ? (
    <span class={className}> {(sospesiCount>99)?"99+":sospesiCount}</span>
  ) : (
    <></>
  );
};

export default SospesiCounter;
