import { createSlice } from "@reduxjs/toolkit";

let initialState = {
  count: -1,
  clickToDialModal: {
    show: false,
    data: {}
  }
};

const sospesiSlice = createSlice({
  name: "sospesi",
  initialState,
  reducers: {
    setSospesiCount(state, action) {
      const { payload = {} } = action;
      const { count } = payload;
      state.count = count;
    },
    showSospesiClickToDialModal(state,action){
      const { payload = {}} = action;
      const { show = false, data = {}} = payload;
      state.clickToDialModal.show = show;
      state.clickToDialModal.data = {...data};
    }
  },
});

export const {
    setSospesiCount,
    showSospesiClickToDialModal
  } = sospesiSlice.actions;
  
  export default sospesiSlice.reducer;