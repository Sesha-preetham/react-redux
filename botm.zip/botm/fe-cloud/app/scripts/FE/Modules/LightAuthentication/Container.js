import React, { useState } from "react";
import MyModal from "../../CommonComponents/Modal/MyModal";
import SimpleTable from "../../CommonComponents/SimpleTable/SimpleTable";
import { withErrorBoundary } from "../../CommonComponents/ErrorBoundary/withErrorBoudary";
import { useSelector } from "react-redux";
import {
  getLightAuthenticationDataByInteraction,
  setShowLightAuthenticationModal,
} from "./lightAuthenticationSlice";
import { exposedDispatch } from "../../Store/store";
import { httpPostClientSearch } from "../../Main/Header/UserSearch/Service";
import { getDefaultBank } from "../../Utils/CommonUtil";
import { getInteractionDetails } from "../Interaction/interactionSlice";
import {
  getInternalWidgetByIdAndCode,
  lightAuthWidgetCode,
} from "../Widgets/internalWidgetsSlice";

const LightAuthenticationModal = () => {
  const { lightAuthentication } = useSelector(
    (state) => state.lightAuthentication
  );
  const { currentInteraction = "noInteraction", interactions = {} } =
    useSelector((state) => state.interaction);
  const { banks = [] } = useSelector((state) => state.common);

  const { internalWidgets } = useSelector((state) => state.internalWidgets);

  const [lightAuthWidgetShow] = getInternalWidgetByIdAndCode(internalWidgets)(
    currentInteraction,
    lightAuthWidgetCode
  );

  const { queueName = undefined, attributes = {}, intxId } =
    getInteractionDetails(interactions)(currentInteraction);

  let { showModal = false, data = {} } =
    getLightAuthenticationDataByInteraction(lightAuthentication)(
      currentInteraction
    );

  const { multipleClient = [] } = data;

  const handleSelectedClient = (rowData) => {
    console.log("LightAuthenticationModal handleSelectedClient: ", rowData);
    const { original = {} } = rowData;
    const { idSoggetto = "" } = original;
    const { x_servizio } = attributes;
    let abiCode = getDefaultBank(banks).abicode;
    let toUseInteraction =
      currentInteraction !== "noInteraction" ? currentInteraction : undefined;
    httpPostClientSearch({
      searchType: "idSoggetto",
      value: idSoggetto,
      interactionId: toUseInteraction,
      queueName: queueName,
      abiCode: abiCode,
      service: x_servizio,
      intxId: intxId,
      lightAuthentication: true
    }).then((res) => {
      exposedDispatch(
        setShowLightAuthenticationModal({
          id: currentInteraction,
          showModal: false,
        })
      );
    });
  };

  const lightAuthenticationModal = {
    uniqueID: "lightAuthenticationModal",
    modalClass: "multi-cliente-modal my-modal",
    dialogClassName: "modal-w",
    title: {
      content: "Autenticazione Light",
      class: "widget-title",
    },
    modalShow: showModal,
    modalHeaderShow: true,
    backdrop: {
      enable: true,
    },
    events: {
      onHide: () => {
        handleOnhide();
      },
      onEntered: () => {
        console.log("lightAuthenticationModal modal onEntered");
      },
      onExited: () => {
        console.log("lightAuthenticationModal modal onExited");
      },
    },
  };

  const handleOnhide = () => {
    const dispatch = exposedDispatch;
    dispatch(
      setShowLightAuthenticationModal({
        id: currentInteraction,
        showModal: false,
      })
    );
  };
  const lightAuthenticationTable = {
    uniqueID: "lightAuthenticationTable",
    metaData: [
      {
        Header: "Cliente",
        accessor: "client",
      },
      {
        Header: "Data",
        accessor: "data",
      },
      {
        Header: "Codice Fiscale",
        accessor: "codiceFiscale",
      },
      {
        Header: "Id Soggetto",
        accessor: "idSoggetto",
      },
    ],
    data: multipleClient || [],
    events: {
      onRowClick: handleSelectedClient,
    },
  };

  return (
    lightAuthWidgetShow && (
      <MyModal configuration={lightAuthenticationModal}>
        <div className="d-flex">
          <div className="w-100">
            <SimpleTable configuration={lightAuthenticationTable} />
          </div>
        </div>
      </MyModal>
    )
  );
};

export default withErrorBoundary(LightAuthenticationModal);
