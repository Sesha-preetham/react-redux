import { pureCloudOrigin, beServiceUrls } from "../../Client/ClientProperties";
import { exposedDispatch, exposedGetState } from "../../Store/store";
import { getBTChannelOfInteraction } from "../../Utils/CommonUtil";
import HttpClient from "../../Utils/HttpClient";
import {
  addInteractionToLightAuthentication,
  removeInteractionFromLightAuthentication,
  setInteractionLightAuthenticationData,
  setShowLightAuthenticationModal,
} from "./lightAuthenticationSlice";
import { loadClientSearchAnagraficaData } from "../Anagrafica/anagraficaSlice";
import {
  getInternalWidgetByIdAndCode,
  getInternalWidgetConfigByIdAndCode,
  lightAuthWidgetCode,
} from "../Widgets/internalWidgetsSlice";
import {
  globalSpinnerId,
  toggleSpinnerById,
} from "../../CommonComponents/Spinner/spinnerSlice";
import { getBTCallType } from "../Interaction/Service";
import { httpPostClientSearch } from "../../Main/Header/UserSearch/Service";

export const httpPostLightAuthentication = async (request = {}) => {
  const dispatch = exposedDispatch;
  let httpClient = new HttpClient();
  dispatch(toggleSpinnerById(globalSpinnerId));
  httpClient.setUrl(beServiceUrls().lightAuthenticationSearch);
  let responseData = await httpClient.httpPost(request).then((response) => {
    const { status = "", response: authResponse = {} } = response;
    dispatch(toggleSpinnerById(globalSpinnerId));
    if (status == "OK") {
      return authResponse;
    }
    return {};
  });
  return responseData || {};
};

/*export const httpPostClientSearch = async (request = {}) => {
  const dispatch = exposedDispatch;
  let httpClient = new HttpClient();
  httpClient.setUrl(beServiceUrls().clientsearch);
  let interactionId = request.interactionId;
  dispatch(toggleSpinnerById(globalSpinnerId));
  let responseData = await httpClient
    .httpPost(request)
    .then((response) => {
      const { status = "", response: clientSearchResponse = {} } = response;
      const { multipleClientFound = false } = clientSearchResponse;
      dispatch(toggleSpinnerById(globalSpinnerId));
      if (status === "OK") {
        if (multipleClientFound === true) {
          return clientSearchResponse;
        } else {
          dispatch(
            loadClientSearchAnagraficaData({
              interactionId: interactionId,
              clientSearchData: clientSearchResponse,
            })
          );
          return clientSearchResponse;
        }
      }
      return {};
    })
    .catch((err) => {
      console.error("clientsearch", err);
    });
  return responseData;
};*/

const getValueToSearch = (interaction) => {
  const { ani, calledNumber, displayAddress, dialerCampaignId } = interaction; //dialerCampaignId for RECALL
  const attributes = interaction.attributes || {};
  let objToRet = {
    email: undefined,
    phonenumber: undefined,
  };
  const internalChannel = getBTChannelOfInteraction(interaction);
  let contact =
    getBTCallType(interaction) === "INBOUND" || dialerCampaignId
      ? ani
      : calledNumber;
  if (internalChannel === window.BTFEDictionary["email"]) {
    objToRet.email = contact;
  } else if (internalChannel === window.BTFEDictionary["voice"]) {
    objToRet.phonenumber =
      contact && contact.startsWith("+39")
        ? contact.split("+39")[1]
        : undefined;
  } else if (internalChannel === window.BTFEDictionary["chat"]) {
    let email = attributes["context.email"];
    objToRet.email = email;
  } else if (internalChannel === window.BTFEDictionary["messages"]) {
    contact = displayAddress ? "+" + displayAddress : displayAddress;
    objToRet.phonenumber =
      contact && contact.startsWith("+39")
        ? contact.split("+39")[1]
        : undefined;
  }
  console.log("LightAuthentication Service getValueToSearch: ", objToRet);
  return objToRet;
};

export const lightAuthenticationServiceCall = (interaction) => {
  const { id, queueName, attributes, ani, intxId } = interaction;
  const { x_servizio } = attributes || {};
  // need to check if light authentication widget is present for the interaction, call it only if present
  if (isLightAuthenticationWidgetAvailable(id)) {
    httpPostLightAuthentication({
      interactionId: id,
      queueName,
      phoneBook: isPhoneBookSearch(id, queueName),
      ...getValueToSearch(interaction),
    }).then((response) => {
      const { multipleClient = [] } = response;
      if (multipleClient.length > 1) {
        exposedDispatch(
          setInteractionLightAuthenticationData({
            id: id,
            data: response,
          })
        );
        exposedDispatch(
          setShowLightAuthenticationModal({ id: id, showModal: true })
        );
      } else if (multipleClient.length > 0) {
        const { idSoggetto = "" } = multipleClient[0];
        httpPostClientSearch({
          searchType: "idSoggetto",
          value: idSoggetto,
          interactionId: id,
          intxId,
          queueName: queueName,
          service: x_servizio,
          lightAuthentication: true,
        });
      }
    });
  }
};

const isLightAuthenticationWidgetAvailable = (interactionId) => {
  const { internalWidgets = [] } = exposedGetState().internalWidgets;
  const [lightAuthWidgetShow] = getInternalWidgetByIdAndCode(internalWidgets)(
    interactionId,
    lightAuthWidgetCode
  );
  return lightAuthWidgetShow;
};

const isPhoneBookSearch = (interactionId, queueName) => {
  const { internalWidgets = [] } = exposedGetState().internalWidgets;
  const { widgetConfig = {} } = getInternalWidgetConfigByIdAndCode(
    internalWidgets
  )(interactionId, lightAuthWidgetCode);
  const { phoneBookQueues = [] } = widgetConfig || {};
  return phoneBookQueues.findIndex((el) => el === queueName) !== -1
    ? true
    : false;
};

const lightAuthenticationService = () => {
  const lightAuthenticationEventListeners = (event) => {
    if (event.origin !== pureCloudOrigin) return;
    let message = JSON.parse(event.data);
    const dispatch = exposedDispatch;
    console.log("lightAuthenticationEventListeners: ", message);
    if (message && message.type == "interactionSubscription") {
      let { data: interactionData = {} } = message;
      let { category = "", interaction = {} } = interactionData;
      switch (category) {
        case "add":
          dispatch(addInteractionToLightAuthentication({ id: interaction.id }));
          break;
        /*
          Below code is commented for dependencies introduced on authenticated call see Interaction/Service.js connect event
        case "connect":
         const { id, queueName, attributes, ani } = interaction;
          const { x_servizio } = attributes || {};
          const internalChannel = getBTChannelOfInteraction(interaction);
          // need to check if light authentication widget is present for the interaction, call it only if present
          if (isLightAuthenticationWidgetAvailable(id)) {
            httpPostLightAuthentication({
              interactionId: id,
              email:
                internalChannel === window.BTFEDictionary["email"]
                  ? ani
                  : undefined,
              phonenumber:
                internalChannel === window.BTFEDictionary["voice"]
                  ? ani && ani.startsWith("+39")
                    ? ani.split("+39")[1]
                    : ani
                  : undefined,
            }).then((response) => {
              const { multipleClient = [] } = response;
              if (multipleClient.length > 1) {
                exposedDispatch(
                  setInteractionLightAuthenticationData({
                    id: id,
                    data: response,
                  })
                );
                exposedDispatch(
                  setShowLightAuthenticationModal({ id: id, showModal: true })
                );
              } else if (multipleClient.length > 0) {
                const { idSoggetto = "" } = multipleClient[0];
                httpPostClientSearch({
                  searchType: "idSoggetto",
                  value: idSoggetto,
                  interactionId: id,
                  queueName: queueName,
                  service: x_servizio,
                });
              }
            });
          }
          break;
        */
        case "deallocate":
          dispatch(
            removeInteractionFromLightAuthentication({ id: interaction.id })
          );
          break;
        default:
          console.log("No Event Matched");
      }
    }
  };

  return { lightAuthenticationEventListeners };
};

export const { lightAuthenticationEventListeners } =
  lightAuthenticationService();
