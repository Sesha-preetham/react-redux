import { createSlice } from "@reduxjs/toolkit";

const defaultObject = {
  showModal: false,
  data: {},
};

let initialState = {
  lightAuthentication: {
    noInteraction: { ...defaultObject },
  },
};

const lightAuthenticationSlice = createSlice({
  name: "lightAuthentication",
  initialState,
  reducers: {
    addInteractionToLightAuthentication(state, action) {
      const { payload = {} } = action;
      const { id = "noInteraction" } = payload;
      if (!id) return;
      state.lightAuthentication[id] = { ...defaultObject };
    },
    removeInteractionFromLightAuthentication(state, action) {
      const { payload = {} } = action;
      const { id = "noInteraction" } = payload;
      if (!id || id === "noInteraction") return;
      state.lightAuthentication = Object.entries(
        state.lightAuthentication
      ).reduce((acc, [key, value]) => {
        if (key != id) {
          acc[key] = value;
        }
        return acc;
      }, {});
    },
    setShowLightAuthenticationModal(state, action) {
      const { payload = {} } = action;
      const { id = "noInteraction", showModal = false } = payload;
      if (!id || !state.lightAuthentication[id]) return;
      state.lightAuthentication[id].showModal = showModal;
    },
    setInteractionLightAuthenticationData(state, action) {
      const { payload = {} } = action;
      const { id = "noInteraction", data = {} } = payload;
      if (!id || !state.lightAuthentication[id]) return;
      state.lightAuthentication[id].data = data;
    },
  },
});

export const getLightAuthenticationDataByInteraction = (
  lightAuthentication
) => {
  return (id = "noInteraction") => {
    if (lightAuthentication[id]) {
      return { ...lightAuthentication[id] };
    }
    return {};
  };
};

export const {
  addInteractionToLightAuthentication,
  removeInteractionFromLightAuthentication,
  setShowLightAuthenticationModal,
  setInteractionLightAuthenticationData,
} = lightAuthenticationSlice.actions;

export default lightAuthenticationSlice.reducer;
