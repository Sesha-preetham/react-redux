import React from "react";
import { useSelector } from "react-redux";
import IconBlueClose from "../../CommonComponents/Common/Icons/IconBlueClose";
import SimpleTable from "../../CommonComponents/SimpleTable/SimpleTable";
import { stackNavPop } from "../../Main/StackNavigation/stackNavigationSlice";
import { exposedDispatch } from "../../Store/store";
import ExpandedWidgetWrapper from "../Widgets/ExpandedWidgetWrapper";
import {
  getDisplayDataByCode,
  queueActivityCode,
  updateWidgetMenuEventByCode,
} from "../Widgets/widgetsSlice";
import WidgetTitle from "../Widgets/WidgetTitle";
import WidgetWrapper from "../Widgets/WidgetWrapper";

const ExpandQueueActivityContainer = (props = {}) => {
  const { elStack = {} } = props;

  const { widgets } = useSelector((state) => state.widgets);

  const {queueActivity = []} = useSelector((state) => state.purecloudNotification);

  const [queueActivityMenuShow, queueActivityShow] =
    getDisplayDataByCode(widgets)(queueActivityCode);

  const handleOnStackMounted = () => {};

  const handleOnStackUnMounted = () => {};

  const tableConfiguration = {
    uniqueID: "queueActivityTable",
    metaData: [
      {
        Header: "Coda",
        accessor: "queueName",
      },
      {
        Header: "In attesa",
        accessor: "oWaiting",
      },
      {
        Header: "Interazioni",
        accessor: "oInteracting",
      },
      {
        Header: "Op. In coda",
        accessor: "onQueueIdle",
      },
      {
        Header: "Op. Non in coda",
        accessor: "offQueue",
      },
    ],
    data: queueActivity || [],
  }

  return (
    <WidgetWrapper widgetShow={queueActivityShow}>
      <ExpandedWidgetWrapper
        className={"queueactivity-expand-main-container"}
        elStack={elStack}
        events={{
          handleOnStackMounted: handleOnStackMounted,
          handleOnStackUnMounted: handleOnStackUnMounted,
        }}
      >
        <WidgetTitle
          title="Monitoraggio code"
          iconElement={
            <IconBlueClose
              configuration={{
                onClick: (active) => {
                  exposedDispatch(
                    updateWidgetMenuEventByCode({
                      widget: {
                        code: queueActivityCode,
                        menuEventState: !queueActivityMenuShow,
                      },
                    })
                  );
                  exposedDispatch(stackNavPop());
                },
              }}
            />
          }
        />
        <SimpleTable configuration={tableConfiguration} />
      </ExpandedWidgetWrapper>
    </WidgetWrapper>
  );
};

export default ExpandQueueActivityContainer;
