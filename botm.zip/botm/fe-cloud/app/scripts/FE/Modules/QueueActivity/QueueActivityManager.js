import React, { useEffect, useState } from "react";
import { useSelector } from "react-redux";
import { toast } from "react-toastify";
import { eventEmitter } from "../../../App";
import { beServiceUrls } from "../../Client/ClientProperties";
import { globalAlertId } from "../../CommonComponents/AlertToast/AlertIdConstants";
import {
  defaultQueueActivityObj,
  updateQueueActivity,
} from "../../Store/purecloudNotificationSlice";
import { exposedDispatch, exposedGetState } from "../../Store/store";
import {
  httpGetMemberQueues,
  httpPostNotificationSubscribe,
  getOrganizationPresencesById,
  getBaseErrorMessage,
} from "../../Utils/CommonUtil";
import HttpClient from "../../Utils/HttpClient";

const QueueActivityManager = (props = {}) => {
  const { channel, queueActivity = [] } = useSelector(
    (state) => state.purecloudNotification
  );
  const { id } = channel;

  const { organizationPresences } = useSelector((state) => state.common);

  const updateQueueActivityRedux = (eventData = {}, additionalDataObj = {}) => {
    console.log("updateQueueActivityRedux ", eventData);
    const { queueList = [] } = additionalDataObj;
    const { group = {}, data = [] } = eventData;
    const { queueId } = group;
    let queueActivityValue = getCurrentQueueActivity(
      exposedGetState().purecloudNotification.queueActivity,
      queueId
    );
    data.forEach((d) => {
      const { metrics = [] } = d;
      let offQueueMetricCount = 0;
      metrics.forEach((m = {}) => {
        const { metric, qualifier, stats = {} } = m;
        const { count = 0 } = stats;
        if (!metric) return;
        if (metric === "oOnQueueUsers" && qualifier === "IDLE") {
          queueActivityValue["onQueueIdle"] = count;
        } else if (metric === "oOffQueueUsers") {
          let presence = getOrganizationPresencesById(organizationPresences)(
            qualifier
          );
          const { name } = presence;
          if (name !== "Offline") {
            offQueueMetricCount += count;
          }
        } else {
          queueActivityValue[metric] = count;
        }
      });
      queueActivityValue["offQueue"] = offQueueMetricCount;
    });
    if (queueId) {
      exposedDispatch(
        updateQueueActivity({
          queue: queueId,
          value: {
            queueName: getQueueNameById(queueId, queueList),
            ...queueActivityValue,
          },
        })
      );
    }
  };

  const getCurrentQueueActivity = (queueActivityList, queueId) => {
    let i = queueActivityList.findIndex((el) => el.queue === queueId);
    if (i !== -1) {
      return { ...queueActivityList[i] };
    }
    return { ...defaultQueueActivityObj };
  };

  const getQueueNameById = (queueId, queueList) => {
    let i = queueList.findIndex((el) => el.pureCloudId === queueId);
    if (i !== -1) {
      return queueList[i].pureCloudName;
    }
    return "";
  };

  useEffect(() => {
    if (!id) return;
    httpGetMemberQueues().then(async (queueList = []) => {
      let topicToSubcribeList = [];
      let queueIdList = [];
      queueList.forEach((q) => {
        const { pureCloudId } = q;
        if (pureCloudId) {
          queueIdList.push(pureCloudId);
          let topic = `v2.analytics.queues.${pureCloudId}.observations`;
          topicToSubcribeList.push({
            id: topic,
          });
          eventEmitter.subscribe(topic, updateQueueActivityRedux, {
            queueList: queueList,
          });
        }
      });
      httpPostQueueActivityQueueObservation({
        queues: queueIdList,
        metrics: [
          "oOnQueueUsers",
          "oOffQueueUsers",
          "oWaiting",
          "oInteracting"
        ]
      }).then( (queueObservation = {}) => {
        const { results = [] } = queueObservation;
        results.forEach((result = {}) => {
          updateQueueActivityRedux(result, {
            queueList: queueList
          });
        });
      });
      httpPostNotificationSubscribe({
        channelId: id,
        topics: topicToSubcribeList,
      });
    });
  }, [id]);

  return <></>;
};

export const httpPostQueueActivityQueueObservation = async (request) => {
  let httpClient = new HttpClient();
  httpClient.setUrl(beServiceUrls().analyticsQueueObservation);
  let r = await httpClient
    .httpPost({
      type: "QUEUE_ACTIVITY",
      ...request,
    })
    .then((response) => {
      const { status, queueObservation = {} } = response;
      if (status === "OK") {
        return queueObservation;
      } else {
        toast.warning(getBaseErrorMessage("Warning ", response), {
          containerId: globalAlertId,
        });
      }
      return {};
    })
    .catch((error) => {
      toast.error(getBaseErrorMessage("Errore ", error), {
        containerId: globalAlertId,
      });
    });
  return r;
};

export default QueueActivityManager;
