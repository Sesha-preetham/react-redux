import React, { useEffect, useRef } from "react";
import { useDispatch, useSelector } from "react-redux";
import FormFieldHandler from "../../../../../CommonComponents/Forms/FormFieldHandler";
import TextField from "../../../../../CommonComponents/Forms/TextField";

import {
  getNotClientDataByInteraction,
  setNotClientDataProperty,
} from "../../../anagraficaSlice";
import AnagraficaLabelValue from "../../Common/AnagraficaLabelValue";
import PrivatoButton from "../PrivatoButton";

const PrivatoNotClientContainer = ({
  layoutType,
  formFields = new FormFieldHandler(true),
} = props) => {
  const { currentInteraction = "noInteraction" } = useSelector(
    (state) => state.interaction
  );

  const { anagrafica, currentLayoutType } = useSelector(
    (state) => state.anagrafica
  );

  const currenInteractionRef = useRef();
  currenInteractionRef.current = currentInteraction;

  const dispatch = useDispatch();

  const { data: notClient = {} } = getNotClientDataByInteraction(anagrafica)(
    currentInteraction
  );

  const {
    name,
    surname,
    dataNascita,
    luogoNascita,
    citta,
    cap,
    province,
    recapitoMail,
    recapitoCell,
    recapitoFisso,
  } = notClient;

  useEffect(() => {
    console.log("currentLayoutType", currentLayoutType);
    let formFieldWithValue = [
      {
        field: "nameField",
        value: name,
      },
      {
        field: "cognomeField",
        value: surname,
      },
      {
        field: "dataNascitaField",
        value: dataNascita,
      },
      {
        field: "luogoNascitaField",
        value: luogoNascita,
      },
      {
        field: "cittaField",
        value: citta,
      },
      {
        field: "capField",
        value: cap,
      },
      {
        field: "provinceField",
        value: province,
      },
      {
        field: "recapitoCellField",
        value: recapitoCell,
      },
      {
        field: "recapitoFissoField",
        value: recapitoFisso,
      },
      {
        field: "recapitoMailField",
        value: recapitoMail,
      },
    ];
    for (let i = 0; i < formFieldWithValue.length; i++) {
      const { field, value } = formFieldWithValue[i];
      formFields.getField(field).theField.setValue(value);
    }
  }, [currentLayoutType]);

  let nameField = {
    uniqueID: "nameField",
    value: name ? name : "",
    form: formFields,
    setValue: (value) => {
      const { currentValue = "" } = value;
      dispatch(
        setNotClientDataProperty({
          interactionId: currenInteractionRef.current,
          property: "name",
          value: currentValue,
        })
      );
    },
  };
  let cognomeField = {
    uniqueID: "cognomeField",
    form: formFields,
    value: surname ? surname : "",
    setValue: (value) => {
      const { currentValue = "" } = value;
      dispatch(
        setNotClientDataProperty({
          interactionId: currenInteractionRef.current,
          property: "surname",
          value: currentValue,
        })
      );
    },
  };
  let dataNascitaField = {
    uniqueID: "dataNascitaField",
    form: formFields,
    value: dataNascita ? dataNascita : "",
    setValue: (value) => {
      const { currentValue = "" } = value;
      dispatch(
        setNotClientDataProperty({
          interactionId: currenInteractionRef.current,
          property: "dataNascita",
          value: currentValue,
        })
      );
    },
  };
  let luogoNascitaField = {
    uniqueID: "luogoNascitaField",
    form: formFields,
    value: luogoNascita ? luogoNascita : "",
    setValue: (value) => {
      const { currentValue = "" } = value;
      dispatch(
        setNotClientDataProperty({
          interactionId: currenInteractionRef.current,
          property: "luogoNascita",
          value: currentValue,
        })
      );
    },
  };
  let cittaField = {
    uniqueID: "cittaField",
    form: formFields,
    value: citta ? citta : "",
    setValue: (value) => {
      const { currentValue = "" } = value;
      dispatch(
        setNotClientDataProperty({
          interactionId: currenInteractionRef.current,
          property: "citta",
          value: currentValue,
        })
      );
    },
  };

  let capField = {
    uniqueID: "capField",
    form: formFields,
    value: cap ? cap : "",
    setValue: (value) => {
      const { currentValue = "" } = value;
      dispatch(
        setNotClientDataProperty({
          interactionId: currenInteractionRef.current,
          property: "cap",
          value: currentValue,
        })
      );
    },
  };
  let provinceField = {
    uniqueID: "provinceField",
    form: formFields,
    value: province ? province : "",
    setValue: (value) => {
      const { currentValue = "" } = value;
      dispatch(
        setNotClientDataProperty({
          interactionId: currenInteractionRef.current,
          property: "province",
          value: currentValue,
        })
      );
    },
  };
  let recapitoCellField = {
    uniqueID: "recapitoCellField",
    form: formFields,
    value: recapitoCell ? recapitoCell : "",
    setValue: (value) => {
      const { currentValue = "" } = value;
      dispatch(
        setNotClientDataProperty({
          interactionId: currenInteractionRef.current,
          property: "recapitoCell",
          value: currentValue,
        })
      );
    },
  };
  let recapitoFissoField = {
    uniqueID: "recapitoFissoField",
    form: formFields,
    value: recapitoFisso ? recapitoFisso : "",
    setValue: (value) => {
      const { currentValue = "" } = value;
      dispatch(
        setNotClientDataProperty({
          interactionId: currenInteractionRef.current,
          property: "recapitoFisso",
          value: currentValue,
        })
      );
    },
  };
  let recapitoMailField = {
    uniqueID: "recapitoMailField",
    form: formFields,
    value: recapitoMail ? recapitoMail : "",
    type: "Email",
    setValue: (value) => {
      const { currentValue = "" } = value;
      dispatch(
        setNotClientDataProperty({
          interactionId: currenInteractionRef.current,
          property: "recapitoMail",
          value: currentValue,
        })
      );
    },
  };

  return (
    <div
      className={`d-flex flex-column anagrafica-${layoutType}-notclient-container`}
    >
      <div
        className={`d-flex flex-row flex-wrap anagrafica-${layoutType}-section-1`}
      >
        <AnagraficaLabelValue label="Cognome" required={true}>
          <TextField configuration={cognomeField} />
        </AnagraficaLabelValue>
        <AnagraficaLabelValue label="Nome">
          <TextField configuration={nameField} />
        </AnagraficaLabelValue>
        <AnagraficaLabelValue label="Data Nascita">
          <TextField configuration={dataNascitaField} />
        </AnagraficaLabelValue>
        <AnagraficaLabelValue label="Luogo Nascita">
          <TextField configuration={luogoNascitaField} />
        </AnagraficaLabelValue>
        <AnagraficaLabelValue label="Citta">
          <TextField configuration={cittaField} />
        </AnagraficaLabelValue>
        <AnagraficaLabelValue label="Cap">
          <TextField configuration={capField} />
        </AnagraficaLabelValue>
        <AnagraficaLabelValue label="Provincia">
          <TextField configuration={provinceField} />
        </AnagraficaLabelValue>
        <AnagraficaLabelValue label="Recapito Cell.">
          <TextField configuration={recapitoCellField} />
        </AnagraficaLabelValue>
        <AnagraficaLabelValue label="Recapito Fisso.">
          <TextField configuration={recapitoFissoField} />
        </AnagraficaLabelValue>
        <AnagraficaLabelValue label="Recapito Mail.">
          <TextField configuration={recapitoMailField} />
        </AnagraficaLabelValue>
      </div>
      <PrivatoButton />
    </div>
  );
};

export default PrivatoNotClientContainer;
