import { pureCloudOrigin } from "../../../../Client/ClientProperties";
import { exposedDispatch } from "../../../../Store/store";
import {
  addInteractionToHdcConsun,
  removeInteractionFromHdcConsun,
  updateInteractionDisconnect,
} from "./HDCConsunSlice";


const hdcConsunService = () => {
  const hdcEventListeners = (event) => {
    if (event.origin !== pureCloudOrigin) return;
    let message = JSON.parse(event.data);
    console.log("hdcEventListeners: ", message);
    const dispatch = exposedDispatch;
    if (message && message.type == "interactionSubscription") {
      let { data: interactionData = {} } = message;
      let { category = "", interaction = {} } = interactionData;

      switch (category) {
        case "add":
          dispatch(addInteractionToHdcConsun({ id: interaction.id }));
          break;
        case "change":
          break;
        case "connect":
          break;
        case "disconnect":
          dispatch(
            updateInteractionDisconnect({
              id: interaction.id,
              disconnectTrigger: true,
            })
          );
          break;
        case "acw":
          break;
        case "deallocate":
          dispatch(
            removeInteractionFromHdcConsun({
              id: interaction.id,
            })
          );
          break;
        default:
          console.log("No Event Matched");
      }
    }
  };

  return { hdcEventListeners };
};

export const { hdcEventListeners } = hdcConsunService();
