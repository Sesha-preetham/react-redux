import React, { useEffect, useRef, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import IconCopy from "../../../../CommonComponents/Common/Icons/IconCopy";
import IconInfo from "../../../../CommonComponents/Common/Icons/IconInfo";
import FormFieldHandler from "../../../../CommonComponents/Forms/FormFieldHandler";
import { globalAlertId } from "../../../../CommonComponents/AlertToast/AlertIdConstants";
import {
  copyTextToClipboard,
  getBankByCode,
  getDefaultBank,
  reduceToOptions,
  getBaseErrorMessage,
} from "../../../../Utils/CommonUtil";

import {
  privatoCarteExternalLinkCode,
  privatoSercliExternalLinkCode,
} from "../../../Widgets/internalWidgetsSlice";
import {
  getPrivatoDataByInteraction,
  getCarteDataByInteraction,
  getContiDataByInteraction,
  setPrivatoSelectedIbCode,
} from "../../anagraficaSlice";
import {
  httpGetCarteSearch,
  httpGetContiSearch,
  httpGetStoricoCarteSearch,
  httpPostSendEmail,
  httpPostPrivatoService,
  httpGetClientMessages,
} from "../../httpService";
import { getInteractionDetails } from "../../../Interaction/interactionSlice";
import AnagraficaDropdown from "../Common/AnagraficaDropdown";
import AnagraficaLabelValue from "../Common/AnagraficaLabelValue";
import AuthInfoModal from "./AuthInfoModal";
import CarteTable from "./CarteTable";
import CodiceClienteSelect from "./CodiceClienteSelect";
import ContiTable from "./ContiTable";
import DatiAnagraficiBox from "./DatiAnagraficiBox";
import DocumentiBox from "./DocumentiBox";
import IndirizziBox from "./IndirizziBox";
import PrivatoButton from "./PrivatoButton";
import RecapitiBox from "./RecapitiBox";
import { toast } from "react-toastify";
import AnagraficaLinkUtili from "../Common/AnagraficaLinkUtili";

const PrivatoContainer = (props) => {
  const {
    layoutType = "preview",
    formFields: parentForm = new FormFieldHandler(true),
  } = props;

  const dispatch = useDispatch();

  const [formFields] = useState(parentForm);

  const [username, setUsername] = useState("");
  const [bank, setBank] = useState("");
  const [showAuthInfoModal, setShowAuthInfoModal] = useState(false);

  const { currentInteraction = "noInteraction", interactions = [] } =
    useSelector((state) => state.interaction);

  const { internalWidgets } = useSelector((state) => state.internalWidgets);

  const { banks = [] } = useSelector((state) => state.common);

  const { anagrafica, currentLayoutType = "preview" } = useSelector(
    (state) => state.anagrafica
  );

  const {
    selectedIbCode = {},
    data: [
      {
        idSoggetto = "",
        name = "",
        surname = "",
        codiceFiscale = "",
        ottoCifre = "",
        natoIl = "",
        natoA = "",
        recapiti = [],
        residenza = {},
        internetCodes = [],
      } = {},
    ] = [],
  } = getPrivatoDataByInteraction(anagrafica)(currentInteraction);

  const { intxId } = getInteractionDetails(interactions)(currentInteraction);

  const conti = getContiDataByInteraction(anagrafica)(currentInteraction);

  const carte = getCarteDataByInteraction(anagrafica)(currentInteraction);

  // to access the last state value of the currentInteracaction inside the callback handleIbcodeChange
  const localCurrentInteraction = useRef();
  localCurrentInteraction.current = currentInteraction;
  const localSoggetto = useRef();
  localSoggetto.current = idSoggetto;
  const localBanks = useRef();
  localBanks.current = banks;
  const localIntx = useRef();
  localIntx.current = intxId;

  let handleIbcodeChange = (obj) => {
    const { currentValue = {} } = obj;
    const { rlData = {} } = currentValue || {};
    const { ibCode = "", username = "", bank = "" } = rlData;
    let currentI = localCurrentInteraction.current;
    currentI = currentI !== "noInteraction" ? currentI : undefined;
    console.log("handleIbcodeChange...", obj, currentInteraction, currentI);
    if (currentValue) {
      dispatch(
        setPrivatoSelectedIbCode({
          value: currentValue,
          interactionId: currentI,
        })
      );
    }
    setUsername(username);
    setBank(bank);
    let bankObj = getBankByCode(localBanks.current)(bank);
    if (localSoggetto.current && localSoggetto.current !== "") {
      httpGetContiSearch({
        ibCode: ibCode,
        idSoggetto: localSoggetto.current,
        interactionId: currentI,
        abicode: bankObj.abicode,
      });
    }
    if (
      localSoggetto.current &&
      localSoggetto.current !== "" &&
      localIntx.current &&
      localIntx.current !== ""
    ) {
      let requestData = {
        intxId: localIntx.current,
        conversationId: currentI,
        soggetto: localSoggetto.current,
        ibCode: ibCode,
        abiCode: bankObj.abicode,
        username: username,
      };
      httpPostPrivatoService(requestData) //CCCLOUD-246 - Privato Client search change / CCCLOUD-251
        .then((response = {}) => {
          const { status = "" } = response;
          if (status != "OK") {
            toast.warn(getBaseErrorMessage("Warning", response), {
              containerId: globalAlertId,
            });
          }
        })
        .catch((err = {}) => {
          toast.error(getBaseErrorMessage("Error", err), {
            containerId: globalAlertId,
          });
        });
    }
    if (ibCode) {
      httpGetClientMessages(
        {
          intxId: localIntx.current,
          ibcode: ibCode,
        },
        {
          interactionId: currentI,
        }
      );
    }
  };

  const [ibCodeSelectConfiguration] = useState({
    uniqueID: "codiceClientSelectField",
    additionalClass: "anagrafica-ibcode-select",
    setValue: handleIbcodeChange,
    options: [],
    value: selectedIbCode, // this is for: client search + transition client-notclient-client 
    form: formFields,
    multiSelect: false,
    label: "",
    placeHolder: "",
    readonly: false,
    visible: true,
    disabled: false,
    searchEnabled: true,
  });

  useEffect(() => {
    if (idSoggetto && idSoggetto !== "") {
      let currentI =
        localCurrentInteraction.current !== "noInteraction"
          ? localCurrentInteraction.current
          : undefined;
      let { abicode = undefined } = getDefaultBank(localBanks.current)();
      httpGetCarteSearch({
        idSoggetto: idSoggetto,
        interactionId: currentI,
        abicode: abicode,
      });
      httpGetStoricoCarteSearch({
        idSoggetto: idSoggetto,
        interactionId: currentI,
        abicode: abicode,
      });
    }
  }, [idSoggetto]);

  const reloadIbCodeSelect = () => {
    if (internetCodes && formFields.getField("codiceClientSelectField")) {
      formFields
        .getField("codiceClientSelectField")
        .theField.reloadOptions(
          reduceToOptions(internetCodes)("ibCode", "ibCode")
        );
      console.log(
        "reloadIbCodeSelect start",
        layoutType,
        internetCodes,
        selectedIbCode
      );
      let lSelectedIbCode = selectedIbCode || {};
      if (lSelectedIbCode.value) {
        const { value } =
          formFields.getField("codiceClientSelectField").theField.getValue() ||
          {};
        console.log(
          "reloadIbCodeSelect already selected",
          layoutType,
          formFields.getFields(),
          value,
          lSelectedIbCode.value
        );
        if (lSelectedIbCode.value !== value) {
          console.log("reloadIbCodeSelect setting seletected", layoutType);
          formFields
            .getField("codiceClientSelectField")
            .theField.setValue(lSelectedIbCode);
          const { rlData: selectedRlData = {} } = lSelectedIbCode;
          setUsername(selectedRlData.username);
          setBank(selectedRlData.bank);
        }
      } else if (lSelectedIbCode.value === undefined && internetCodes[0]) {
        // set the first element
        let tempInternetCodesOptions = reduceToOptions([internetCodes[0]])(
          "ibCode",
          "ibCode"
        );
        formFields
          .getField("codiceClientSelectField")
          .theField.setValue(tempInternetCodesOptions[0]);
      } else {
        setUsername("");
        setBank("");
      }
    }
  };

  useEffect(() => {
    reloadIbCodeSelect();
  }, [internetCodes]);

  useEffect(() => {
    reloadIbCodeSelect();
  }, [currentLayoutType]);

  /*useEffect(() => {
      reloadIbCodeSelect();
  }, [selectedIbCode]);*/

  let getRecapito = (recapiti, tipo) => {
    let rec = "";
    if (recapiti) {
      let i = recapiti.findIndex((el) => el.tipoCode === tipo);
      if (i !== -1) {
        if (recapiti[i].prefisso) {
          rec = recapiti[i].prefisso.split("-")[0] + " - ";
        }
        rec = rec + recapiti[i].recapito;
      }
    }
    return rec;
  };

  let handleIbCodeCopy = () => {
    const { value = "" } = formFields
      .getField("codiceClientSelectField")
      .theField.getValue();
    copyTextToClipboard(value);
  };

  let openAuthInfo = () => {
    console.log("Hello");
    setShowAuthInfoModal(true);
  };

  let handleOnCloseAuthInfoModal = () => {
    setShowAuthInfoModal(false);
  };

  let handleRecapitoCopy = (value) => {
    copyTextToClipboard(value);
  };

  let handleOnSendMail = () => {
    if (!surname) {
      toast.warn("Client details are not present", {
        containerId: globalAlertId,
      });
    }
    let contiValues = conti.map((item) => item.conto);
    let carteValues = carte.map((item) => item.carta);
    let email = "";
    let call = "";
    let casa = "";
    recapiti.forEach((item) => {
      if (item.tipo) {
        if (
          item.tipoCode.localeCompare("POSTA ELETTRONICA", undefined, {
            sensitivity: "accent",
          }) === 0
        ) {
          email = item.recapito;
        } else if (
          item.tipoCode.localeCompare("TEC", undefined, {
            sensitivity: "accent",
          }) === 0
        ) {
          call = item.recapito;
        } else if (
          item.tipoCode.localeCompare("TEA", undefined, {
            sensitivity: "accent",
          }) === 0
        ) {
          casa = item.recapito;
        }
      }
    });
    const { indirizzo = "", comune = "", provincia = ""} = residenza || {};
    var inputRequest = {
      codiceCliente: selectedIbCode.value,
      email: email,
      cogNome: surname,
      nome: name,
      codFisc: codiceFiscale,
      indirizzo: indirizzo,
      comune: comune,
      prov: provincia,
      cell: call,
      casa: casa,
      carte: carteValues,
      conti: contiValues,
    };
    httpPostSendEmail(inputRequest);
  };

  let recapitoCellulare = getRecapito(recapiti, "TEC");

  return (
    <div className="d-flex flex-column">
      <div
        className={`d-flex flex-row flex-wrap anagrafica-${layoutType}-section-1`}
      >
        <AnagraficaLabelValue label="Cliente">
          <span>{`${name} ${surname}`}</span>
        </AnagraficaLabelValue>
        <AnagraficaLabelValue label="Username">
          <span>{username}</span>
        </AnagraficaLabelValue>
        <AnagraficaLabelValue label="Codice cliente">
          <div className={`row no-gutters`}>
            <div className={`col-9`}>
              <CodiceClienteSelect configuration={ibCodeSelectConfiguration} />
            </div>
            <div className={`col-3`}>
              <IconCopy configuration={{ onClick: handleIbCodeCopy }} />
              <IconInfo configuration={{ onClick: openAuthInfo }} />
            </div>
            <AuthInfoModal
              configuration={{
                showAuthInfoModal: showAuthInfoModal,
                handleOnCloseAuthInfoModal: handleOnCloseAuthInfoModal,
                codiceDetails: selectedIbCode,
              }}
            />
          </div>
        </AnagraficaLabelValue>
        <AnagraficaLabelValue label="Banca">
          <span>{bank}</span>
        </AnagraficaLabelValue>
        <AnagraficaLabelValue label="Codice fiscale">
          <span>{codiceFiscale}</span>
        </AnagraficaLabelValue>
        <AnagraficaLabelValue label="8 cifre">
          <span>{ottoCifre}</span>
        </AnagraficaLabelValue>
        <AnagraficaLabelValue label="Data di nascita">
          <span>{natoIl}</span>
        </AnagraficaLabelValue>
        <AnagraficaLabelValue label="Luogo di nascita">
          <span>{natoA}</span>
        </AnagraficaLabelValue>
        <AnagraficaLabelValue label="Recapito cellulare">
          {recapitoCellulare === "" ? (
            <span>{recapitoCellulare}</span>
          ) : (
            <div className={`row no-gutters`}>
              <div className={`col-10`}>
                <span>{recapitoCellulare}</span>
              </div>
              <div className={`col-2`}>
                <IconCopy
                  configuration={{
                    onClick: () => {
                      handleRecapitoCopy(getRecapito(recapiti, "TEC"));
                    },
                  }}
                />
              </div>
            </div>
          )}
        </AnagraficaLabelValue>
        <AnagraficaLabelValue label="Indirizzo e-mail">
          <span>{getRecapito(recapiti, "Posta Elettronica")}</span>
        </AnagraficaLabelValue>
      </div>
      <AnagraficaDropdown
        className={`anagrafica-${layoutType}-section-2`}
        title="Dati anagrafici"
      >
        <DatiAnagraficiBox layoutType={layoutType} />
      </AnagraficaDropdown>
      {layoutType === "preview" ? null : (
        <AnagraficaDropdown
          className={`anagrafica-${layoutType}-section-2`}
          title="Altri recapiti"
        >
          <RecapitiBox layoutType={layoutType} />
        </AnagraficaDropdown>
      )}
      <AnagraficaDropdown
        className={`anagrafica-${layoutType}-section-2`}
        title="Indirizzi"
      >
        <IndirizziBox layoutType={layoutType} />
      </AnagraficaDropdown>
      <AnagraficaDropdown
        className={`anagrafica-${layoutType}-section-2`}
        title="Documenti d’identità"
      >
        <DocumentiBox layoutType={layoutType} />
      </AnagraficaDropdown>
      <AnagraficaLinkUtili
        layoutType={layoutType}
        widgetCode={privatoCarteExternalLinkCode}
      />
      <AnagraficaLinkUtili
        layoutType={layoutType}
        widgetCode={privatoSercliExternalLinkCode}
      />
      {layoutType === "expand" && (
        <div className="d-flex">
          <div className="w-50 p-3">
            <ContiTable />
          </div>
          <div className="w-50 p-3">
            <CarteTable />
          </div>
        </div>
      )}
      <PrivatoButton handleOnSendMail={handleOnSendMail} />
    </div>
  );
};

export default PrivatoContainer;
