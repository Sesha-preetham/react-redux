import React,{useRef,useState} from "react";
import {  useDispatch ,useSelector } from "react-redux";
import { CSSTransition } from "react-transition-group";
import IconExplode from "../../../../CommonComponents/Common/Icons/IconExplode";
import { stackNavLeasingMainContainer } from "../../../../Main/StackNavigation/StackNavComponents";//
import {
  stackNavPush,
} from "../../../../Main/StackNavigation/stackNavigationSlice";
import {leasingWidgetCode ,getInternalWidgetByIdAndCode} from "../../../Widgets/internalWidgetsSlice";//
import WidgetTitle from "../../../Widgets/WidgetTitle";
import WidgetWrapper from "../../../Widgets/WidgetWrapper";
import FormFieldHandler from "../../../../CommonComponents/Forms/FormFieldHandler";
import { withErrorBoundary } from "../../../../CommonComponents/ErrorBoundary/withErrorBoudary";
import LeasingMainComponent from "./LeasingMainComponent";

const PreviewLeasingContainer = (props) => {
  const dispatch = useDispatch();
  const [formFields] = useState(new FormFieldHandler(true));
  const { currentInteraction = "noInteraction" } = useSelector((state) => state.interaction);

  const currentInteractionRef = useRef();
  currentInteractionRef.current = currentInteraction;

  const { internalWidgets } = useSelector((state) => state.internalWidgets);
  const [leasingWidgetShow] = getInternalWidgetByIdAndCode(internalWidgets)(currentInteractionRef.current,leasingWidgetCode);

 let handleOnStackExpand = () => {
    dispatch(stackNavPush(stackNavLeasingMainContainer));
  };

  
  return (
    <WidgetWrapper widgetShow={leasingWidgetShow}>
      <CSSTransition
        in={leasingWidgetShow}
        timeout={300}
        classNames="slide-right-toggle"
        unmountOnExit={false}
        mountOnEnter={true}
      >
        <div className="d-flex flex-column section-consult leasing-content leasing-preview">
          <WidgetTitle
            title="Leasing Details"
            iconElement={
              <IconExplode
                configuration={{
                  onClick: (active) => {
                    handleOnStackExpand();
                  },
                }}
              />
            }
          />
        <LeasingMainComponent layoutType={"preview"} />
        </div>
      </CSSTransition>
    </WidgetWrapper>
  );
};

export default withErrorBoundary(PreviewLeasingContainer);
