import React from "react";
import { useSelector } from "react-redux";
import IconCopy from "../../../../CommonComponents/Common/Icons/IconCopy";
import SimpleTable from "../../../../CommonComponents/SimpleTable/SimpleTable";
import { copyTextToClipboard } from "../../../../Utils/CommonUtil";
import { getContiDataByInteraction } from "../../anagraficaSlice";

const ContiTable = (props) => {
  const { currentInteraction = "noInteraction" } = useSelector(
    (state) => state.interaction
  );

  const { anagrafica } = useSelector((state) => state.anagrafica);

  const conti = getContiDataByInteraction(anagrafica)(currentInteraction);

  let getContoColor = (contoProfilo) => {
    switch (contoProfilo) {
      case "B":
        return "text-orange";
      case "D":
        return "text-green";
      case "I":
        return "text-red";
      default:
        return "";
    }
  };

  let prepareContiDataForTable = (conti = []) => {
    let contiForTable = conti.map((element = {}) => {
      let {
        conto = "",
        btEnabled = false,
        ibEnabled = false,
        tolenabled = false,
        contoProfiloTOL = "",
        contoProfilo = "*",
      } = element;

      let contoProfiloForTable = contoProfilo === "" ? "*" : contoProfilo;
      let tolProfileForTable = contoProfiloTOL;
      let additionContoClass = getContoColor(contoProfiloForTable);

      if (tolenabled) {
        if (contoProfiloTOL === "X") {
          tolProfileForTable = "Xtrading";
        } else if (contoProfiloTOL === "I") {
          tolProfileForTable = "Tol_Investor";
        } else{
          tolProfileForTable = contoProfiloTOL;
        }
      }
      return {
        ...element,
        additionContoClass: additionContoClass,
        contoProfiloForTable,
        tolProfileForTable,
      };
    });
    return contiForTable;
  };

  const contiDataForTable = prepareContiDataForTable(conti);

  let privatoContiTableConfiguration = {
    uniqueID: "privatoContiTableConfiguration",
    pagination: true,
    paginationOptions: {
      pageSize: 5,
    },
    metaData: [
      {
        id: "conti",
        Header: "Conti",
        Cell: (cellInfo) => {
          let { original } = cellInfo.row;
          let { conto = "", additionContoClass = "" } = original;
          return (
            <div className={`text-left ${additionContoClass}`}>{conto}</div>
          );
        },
      },
      {
        id: "btIb",
        Header: "",
        Cell: (cellInfo) => {
          let { original } = cellInfo.row;
          let {
            ibEnabled = false,
            btEnabled = false,
            additionContoClass = "",
          } = original;
          return (
            <div className={`text-left ${additionContoClass}`}>
              {(btEnabled ? "BT " : "") + (ibEnabled ? "IB" : "")}
            </div>
          );
        },
      },
      {
        id: "contoProfilo",
        Header: "",
        Cell: (cellInfo) => {
          let { original } = cellInfo.row;
          let {
            contoProfiloForTable = "*",
            additionContoClass = "",
          } = original;
          return (
            <div className={`text-left ${additionContoClass}`}>
              {contoProfiloForTable}
            </div>
          );
        },
      },
      {
        id: "tolProfilo",
        Header: "",
        Cell: (cellInfo) => {
          let { original } = cellInfo.row;
          let { tolProfileForTable = "*", additionContoClass = "" } = original;
          return (
            <div className={`text-left ${additionContoClass}`}>
              {tolProfileForTable}
            </div>
          );
        },
      },
      {
        id: "altriLink",
        Header: (headerInfo, props) => {
          console.log("Header", headerInfo, props);
          //<span>Altri link</span> not necessary now
          return (
            <div className="flex-fill text-right">
              <span></span>
            </div>
          );
        },
        Cell: (cellInfo) => {
          let { original } = cellInfo.row;
          return (
            <div className="text-right">
              <IconCopy
                configuration={{
                  onClick: () => {
                    const { conto = "" } = original;
                    copyTextToClipboard(conto);
                  },
                }}
              />
            </div>
          );
        },
      },
    ],
    data: contiDataForTable,
    sort: [
      {
        id: "conti",
        desc: false,
      },
    ],
  };

  return <SimpleTable configuration={privatoContiTableConfiguration} />;
};

export default ContiTable;
