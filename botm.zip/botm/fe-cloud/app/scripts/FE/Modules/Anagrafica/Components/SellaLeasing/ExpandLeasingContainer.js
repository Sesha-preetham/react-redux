import React,{useRef} from "react";
import { useDispatch , useSelector} from "react-redux";
import IconBlueClose from "../../../../CommonComponents/Common/Icons/IconBlueClose";
import {
  stackExpand,
  stackNavPop,
  stackPreview,
} from "../../../../Main/StackNavigation/stackNavigationSlice";
import {
  setLeasingContainerLayoutType
} from "../../../Anagrafica/anagraficaSlice";
import ExpandedWidgetWrapper from "../../../Widgets/ExpandedWidgetWrapper";
import WidgetTitle from "../../../Widgets/WidgetTitle";
import LeasingMainComponent from "./LeasingMainComponent";

const ExpandLeasingContainer = (props) => {
  const { elStack = {} } = props;
  const dispatch = useDispatch();
  const { currentInteraction = "noInteraction" } = useSelector((state) => state.interaction);

  const currentInteractionRef = useRef();
  currentInteractionRef.current = currentInteraction;

  let handleOnStackMounted = (stack) => {
    dispatch(setLeasingContainerLayoutType({interactionId:currentInteractionRef.current, layoutType:stackExpand}));
  };

  let handleOnStackUnMounted = (stack) => {
    dispatch(setLeasingContainerLayoutType({interactionId:currentInteractionRef.current, layoutType:stackPreview}));
  };

  let handleOnStackClose = () => {
    dispatch(stackNavPop());
  };

  return (
    <ExpandedWidgetWrapper
      className={"consult-expand-main-container leasing-content anagrafica-expand-main-container"}
      elStack={elStack}
      events={{
        handleOnStackMounted,
        handleOnStackUnMounted,
      }}
    >
      <WidgetTitle
        title="Leasing Details"
        iconElement={
          <IconBlueClose
            configuration={{
              onClick: (active) => {
                handleOnStackClose();
              },
            }}
          />
        }
      />
      <LeasingMainComponent layoutType={"expand"} />
    </ExpandedWidgetWrapper>
  );
};

export default ExpandLeasingContainer;
