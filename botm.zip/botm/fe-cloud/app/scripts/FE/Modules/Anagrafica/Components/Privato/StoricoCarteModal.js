import React from "react";
import MyModal from "../../../../CommonComponents/Modal/MyModal";
import SimpleTable from "../../../../CommonComponents/SimpleTable/SimpleTable";


const StoricoCarteModal = ({
    showStoricoCarteModal = false,
    handleOnCloseModal = () => {},
    modalData = []
  }) => {
  
    const storicoCarteModal = {
      uniqueID: "storicoCarteModal",
      modalClass: "storico-carte-modal my-modal",
      dialogClassName: "modal-w",
      title: {
        content: "Storico Carte",
        class: "widget-title",
      },
      modalShow: showStoricoCarteModal,
      modalHeaderShow: true,
      backdrop: {
        enable: true,
      },
      events: {
        onHide: () => {
          handleOnhide();
        },
        onEntered: () => {
          console.log("showStoricoCarteModal modal onEntered");
        },
        onExited: () => {
          console.log("showStoricoCarteModal modal onExited");
        },
      },
    };


    let simpleTableConfiguration = {
        uniqueID: "storicoCarteTableConfiguration",
        pagination: true,
        paginationOptions: {
          pageSize: 5
        },
        metaData: [
          {
            Header: "Carta",
            accessor: "carta",
          },
          {
            Header: "Conto",
            accessor: "contoAppoggio",
          },
          {
            Header: "Desc. Carta",
            accessor: "descCarta",
          },
          {
            Header: "Data Blocco",
            accessor: "dataBlocco",
          },
          {
            Header: "Desc. Blocco",
            accessor: "descStatoCarta",
          }
        ],
        data: modalData,
    };

  
    let handleOnhide = () => {
      console.log("insertMediaType modal onHide");
      handleOnCloseModal(false);
    };
  
    return (
      <MyModal configuration={storicoCarteModal}>
        <div className="d-flex">
          <div className="w-100">
            <SimpleTable configuration={simpleTableConfiguration} />
          </div>
        </div>
      </MyModal>
    );
  };
  
  export default StoricoCarteModal;
  