import React, {useState} from "react";
import IconCaretDownFill from "../../../../CommonComponents/Common/Icons/IconCaretDownFill";
import IconCaretRightFill from "../../../../CommonComponents/Common/Icons/IconCaretRightFill";

const AnagraficaDropdown = (props) => {
  const { className = "", title = "" , showChildrenDefault = false } = props;

  const [ showChildren, setShowChildren ] = useState(showChildrenDefault);

  return (
    <>
      <div className={`d-flex flex-row flex-fill my-1 ${className}`}>
        <div className="text-center">
          {(showChildren===true)
            ?<IconCaretDownFill configuration={{ className: "caret-arrow", onClick: () => { setShowChildren(!showChildren)}}} />
            :<IconCaretRightFill configuration={{ className: "caret-arrow", onClick: () => { setShowChildren(!showChildren)}}} />
          }
        </div>
        <div className="ml-2">
          <span className="anagrafica-content-text">{title}</span>
        </div>
      </div>
      {(showChildren)?props.children:null}
    </>
  );
};

export default AnagraficaDropdown;
