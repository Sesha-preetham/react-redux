import React from "react";
import { useSelector } from "react-redux";
import SimpleTable from "../../../../CommonComponents/SimpleTable/SimpleTable";
import { getPrivatoDataByInteraction } from "../../anagraficaSlice";

const RecapitiBox = (props) => {
  const { layoutType = "preview" } = props;

  const { currentInteraction = "noInteraction" } = useSelector(
    (state) => state.interaction
  );

  const { anagrafica } = useSelector((state) => state.anagrafica);
  const { data: [{ recapiti = [] } = {}] = [] } = getPrivatoDataByInteraction(
    anagrafica
  )(currentInteraction);

  /*
        {
            "tipo": "Tel. Cellulare",
            "tipoCode": "TEC",
            "prefisso": "0039 - ITALIA",
            "recapito": "3357777777",
            "dataOperazione": "28/01/2020 12:05:00",
            "note": ""
        }

    */

  let recapitiTableConfiguration = {
    uniqueID: "simpleTableConfiguration",
    metaData: [
      {
        Header: "Tipo",
        accessor: "tipo",
      },
      {
        Header: "Prefisso",
        accessor: "prefisso",
      },
      {
        Header: "Recapito",
        accessor: "recapito",
      },
      {
        Header: "Note",
        accessor: "note",
      },
    ],
    data: recapiti,
  };

  return (
    <div
      className={`d-flex flex-row flex-wrap anagrafica-${layoutType}-section-1 m-2`}
    >
      <SimpleTable configuration={recapitiTableConfiguration} />
    </div>
  );
};

export default RecapitiBox;
