import React, { useState, useRef } from "react";
import { useDispatch, useSelector } from "react-redux";
import { withErrorBoundary } from "../../../../CommonComponents/ErrorBoundary/withErrorBoudary";
import {
  esercenteWidgetCode,
  draftEmailWidgetCode,
  getInternalWidgetByIdAndCode,
  prospectWidgetCode,
} from "../../../Widgets/internalWidgetsSlice";
import {
  getAziendaDataByInteraction,
  updateEcommerceDataByProperty,
  getAbiSearchByInteraction,
} from "../../anagraficaSlice";
import AnagraficaDropdown from "../Common/AnagraficaDropdown";
import AnagraficaLabelValue from "../Common/AnagraficaLabelValue";
import SimpleTable from "../../../../CommonComponents/SimpleTable/SimpleTable";
import AnagraficaCopyValue from "../Common/AnagraficaCopyValue";
import { exposedDispatch } from "../../../../Store/store";
import WidgetWrapper from "../../../Widgets/WidgetWrapper";
import {
  httpPostSendEmailEsercente,
  httpPostEsercenteService,
  httpGetClientMessages,
} from "../../httpService";
import ProspectModal from "../../../Prospect/Components/modal/ProspectModal";
import {
  getProspectDataById,
  updateProspectDataByProperty,
  aziendaProspectData,
} from "../../../Prospect/prospectSlice";
import { updateProspectDataByAziendaClientToggle } from "../../../Prospect/Service";
import { getInteractionDetails } from "../../../Interaction/interactionSlice";
import { toast } from "react-toastify";
import { getBaseErrorMessage } from "../../../../Utils/CommonUtil";
import { globalAlertId } from "../../../../CommonComponents/AlertToast/AlertIdConstants";
import AnagraficaLinkUtili from "../Common/AnagraficaLinkUtili";

const EsercenteContainer = (props) => {
  const { layoutType = "preview" } = props;

  const { currentInteraction = "noInteraction", interactions = [] } =
    useSelector((state) => state.interaction);

  const { anagrafica, currentLayoutType = "preview" } = useSelector(
    (state) => state.anagrafica
  );

  const { internalWidgets } = useSelector((state) => state.internalWidgets);
  const { prospectData } = useSelector((state) => state.prospect);

  const [draftEmailWidgetShow] = getInternalWidgetByIdAndCode(internalWidgets)(
    currentInteraction,
    draftEmailWidgetCode
  );

  const [prospectWidgetShow] = getInternalWidgetByIdAndCode(internalWidgets)(
    currentInteraction,
    prospectWidgetCode
  );

  const {
    privatoPropestClientDisabled = true,
    privatoPropestNotClientDisabled = true,
    aziendaProspectData: {
      showProspectModal = false,
      loadDataFromAnagrafica = false,
    },
  } = getProspectDataById(prospectData)(currentInteraction);

  const { ecommerceData = {}, data: aziendaData = [] } =
    getAziendaDataByInteraction(anagrafica)(currentInteraction);

  const abisearch = getAbiSearchByInteraction(anagrafica)(currentInteraction);

  const { intxId } = getInteractionDetails(interactions)(currentInteraction);

  const { currentDataIndex = 0 } = ecommerceData;

  const {
    ragioneSociale = "",
    partitaIva = "",
    codiceEsercente = "",
    stabilimento = "",
    codiceTml = "",
    insegna = "",
    address = "",
    citta = "",
    property = "",
    descProperty = "",
    dataCostituzione = "",
    cap = "",
    provincia = "",
    telDati1 = "",
    telDati2 = "",
    legaleRappresentante = "",
  } = aziendaData[currentDataIndex] || {};

  let handleCodiceEsercenteRowClick = (rowObj) => {
    const { index = 0 } = rowObj;
    exposedDispatch(
      updateEcommerceDataByProperty({
        interactionId: currentInteraction,
        data: {
          property: "currentDataIndex",
          value: index,
        },
      })
    );

    if (
      aziendaData[index] &&
      aziendaData[index] != null &&
      intxId &&
      intxId !== ""
    ) {
      let requestData = {
        intxId: intxId,
        soggetto: aziendaData[index].idSoggetto,
        conversationId: currentInteraction,
        abiCode: abisearch ? abisearch : null,
        codiceEsercente: aziendaData[index].codiceEsercente,
        codiceTml: aziendaData[index].codiceTml,
        pIva: aziendaData[index].partitaIva,
      };
      httpPostEsercenteService(requestData)
        .then((response = {}) => {
          const { status = "" } = response;
          if (status != "OK") {
            toast.warn(getBaseErrorMessage("Warning", response), {
              containerId: globalAlertId,
            });
          }
        })
        .catch((err = {}) => {
          toast.error(getBaseErrorMessage("Error", err), {
            containerId: globalAlertId,
          });
        });
    }

    if (aziendaData[index] && aziendaData[index] != null) {
      const { codiceEsercente } = aziendaData[index];
      if (codiceEsercente) {
        httpGetClientMessages(
          {
            codiceSia: codiceEsercente,
            intxId: intxId,
          },
          {
            interactionId: currentInteraction,
          }
        );
      }
    }
  };

  const handleOnProspectButton = () => {
    //handleOnProspect();
    exposedDispatch(
      updateProspectDataByProperty({
        interactionId: currentInteraction,
        data: {
          property: "showProspectModal",
          value: true,
        },
        orginData: aziendaProspectData,
      })
    );
  };

  let handleOnSendMail = () => {
    const {
      codiceEsercente = "",
      stabilimento = "",
      address = "",
      citta = "",
      insegna = "",
      provincia = "",
      cap = "",
    } = aziendaData[currentDataIndex] || {};
    httpPostSendEmailEsercente({
      codiceEsercente,
      stabilimento,
      insegna,
      address,
      citta,
      provincia,
      cap,
    });
  };

  let codiceEsercenteTableConfiguration = {
    uniqueID: "codiceEsercenteTable",
    data: aziendaData || [],
    events: {
      onRowClick: handleCodiceEsercenteRowClick,
    },
    metaData: [
      {
        Header: "Codice",
        accessor: "codiceEsercente",
      },
      {
        Header: "Stabilimento",
        accessor: "stabilimento",
      },
      {
        Header: "Insegna",
        accessor: "insegna",
      },
      {
        Header: "Città",
        accessor: "citta",
      },
      {
        Header: "Indirizzo",
        accessor: "address",
      },
    ],
  };

  let prepareDataForContiTable = (aziendaData = []) => {
    let conti = [];
    const {
      idAbi = "",
      cab = "",
      conto = "",
      abiAltre = "",
      cabAltre = "",
      contoAltre = "",
    } = aziendaData[currentDataIndex] || {};
    conti.push({
      desc: "BANCA SELLA",
      abi: idAbi,
      cab: cab,
      conto: conto,
    });
    conti.push({
      desc: "ALTRA BANCA",
      abi: abiAltre,
      cab: cabAltre,
      conto: contoAltre,
    });
    return conti;
  };

  let contiTableConfiguration = {
    uniqueID: "ecommerceContiTable",
    scrollX: true,
    metaData: [
      {
        Header: "Conti",
        accessor: "desc",
      },
      {
        Header: "Abi",
        accessor: "abi",
      },
      {
        Header: "Cab",
        accessor: "cab",
      },
      {
        Header: "Conto",
        accessor: "conto",
      },
    ],
    data: prepareDataForContiTable(aziendaData) || [],
  };

  return (
    <div className="d-flex flex-column">
      <div
        className={`d-flex flex-row flex-wrap ecommerce-${layoutType}-section-1`}
      >
        <AnagraficaLabelValue label="Ragione Sociale">
          <AnagraficaCopyValue value={ragioneSociale} />
        </AnagraficaLabelValue>
        <AnagraficaLabelValue label="PartitaIva">
          <AnagraficaCopyValue value={partitaIva} />
        </AnagraficaLabelValue>
        <AnagraficaLabelValue label="TML (TermID)">
          <AnagraficaCopyValue value={codiceTml} />
        </AnagraficaLabelValue>
        <AnagraficaLabelValue label="Indirizzo">
          <AnagraficaCopyValue value={address} />
        </AnagraficaLabelValue>
        <AnagraficaLabelValue label="Città">
          <AnagraficaCopyValue value={citta} />
        </AnagraficaLabelValue>
        <AnagraficaLabelValue label="Provincia">
          <AnagraficaCopyValue value={provincia} />
        </AnagraficaLabelValue>
        <AnagraficaLabelValue label="Cap">
          <AnagraficaCopyValue value={cap} />
        </AnagraficaLabelValue>
        <AnagraficaLabelValue label="Recapito Tel 1">
          <AnagraficaCopyValue value={telDati1} />
        </AnagraficaLabelValue>
        <AnagraficaLabelValue label="Recapito Tel 2">
          <AnagraficaCopyValue value={telDati2} />
        </AnagraficaLabelValue>
        <AnagraficaLabelValue label="Insegna">
          <AnagraficaCopyValue value={insegna} />
        </AnagraficaLabelValue>
        <AnagraficaLabelValue label="Legale Rappresentante">
          <AnagraficaCopyValue value={legaleRappresentante} />
        </AnagraficaLabelValue>
      </div>
      <AnagraficaDropdown
        className={`ecommerce-${layoutType}-section-2`}
        title="Codice Esercente"
      >
        <SimpleTable configuration={codiceEsercenteTableConfiguration} />
      </AnagraficaDropdown>
      <AnagraficaLinkUtili
        layoutType={layoutType}
        widgetCode={esercenteWidgetCode}
      />
      {layoutType === "expand" && (
        <div className="w-50">
          <SimpleTable configuration={contiTableConfiguration} />
        </div>
      )}
      <div className="d-flex flex-row justify-content-center my-2">
        <WidgetWrapper widgetShow={draftEmailWidgetShow}>
          <div className="w-25 px-2">
            <button
              type="button"
              className={`btn Rectangle-Button-Blue w-100`}
              onClick={handleOnSendMail}
              disabled={ragioneSociale === "" ? true : false}
            >
              Send e-mail
            </button>
          </div>
        </WidgetWrapper>
        <WidgetWrapper widgetShow={prospectWidgetShow}>
          <>
            <div className="w-25 pl-2">
              <button
                type="button"
                className={`btn Rectangle-Button-Blue w-100`}
                onClick={handleOnProspectButton}
                disabled={privatoPropestClientDisabled}
              >
                Prospect
              </button>
            </div>
            <ProspectModal
              configuration={{
                showProspectModal: showProspectModal,
                orginTab: "aziendaProspect",
                orginData: aziendaProspectData,
                handleOnHideProspectModal: () => {
                  exposedDispatch(
                    updateProspectDataByProperty({
                      interactionId: currentInteraction,
                      data: {
                        property: "showProspectModal",
                        value: false,
                      },
                      orginData: aziendaProspectData,
                    })
                  );
                },
                handleOnEnteringProspectModal: () => {
                  updateProspectDataByAziendaClientToggle();
                },
              }}
            />
          </>
        </WidgetWrapper>
      </div>
    </div>
  );
};

export default withErrorBoundary(EsercenteContainer);
