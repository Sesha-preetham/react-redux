import React from "react";
import { useSelector } from "react-redux";
import SimpleTable from "../../../../CommonComponents/SimpleTable/SimpleTable";
import {
  getInternalWidgetByIdAndCode,
  getInternalWidgetConfigByIdAndCode,
} from "../../../Widgets/internalWidgetsSlice";
import WidgetWrapper from "../../../Widgets/WidgetWrapper";
import AnagraficaDropdown from "./AnagraficaDropdown";

const AnagraficaLinkUtili = (props) => {
  const { layoutType = "preview", widgetCode } = props;

  const { currentInteraction = "noInteraction" } = useSelector(
    (state) => state.interaction
  );

  const { internalWidgets } = useSelector((state) => state.internalWidgets);

  const [externalLinkShow] = getInternalWidgetByIdAndCode(internalWidgets)(
    currentInteraction,
    widgetCode
  );

  
  const { widgetConfig: widgetConfig } = getInternalWidgetConfigByIdAndCode(
    internalWidgets
  )(currentInteraction, widgetCode);
  
  const { externalLink } = widgetConfig || {};

  const linkTableConfiguration = {
    uniqueID: `linkTableConfiguration-${widgetCode}`,
    pagination: true,
    paginationOptions: {
      pageSize: 5,
    },
    scrollX: true,
    metaData: [
      {
        Header: "Name",
        accessor: "name",
      },
      {
        Header: "URL",
        Cell: (cellInfo) => {
          let { original } = cellInfo.row;
          console.log("original :" + original);
          return (
            <div className="text-left">
              <a href={original.url} target="_blank" rel="noopener noreferrer">
                {original.url}
              </a>
            </div>
          );
        },
      },
    ],
    data: externalLink || [],
  };
  

  return (
    <WidgetWrapper widgetShow={externalLinkShow}>
      <AnagraficaDropdown
        className={`anagrafica-${layoutType}-section-2`}
        title="Link utili"
      >
        {layoutType === "preview" ? (
          <div className={`remotebanking-${layoutType}-linkTable`}>
            <SimpleTable configuration={linkTableConfiguration} />
          </div>
        ) : (
          <div className="d-flex">
            <div className="w-100 p-3">
              <SimpleTable configuration={linkTableConfiguration} />
            </div>
          </div>
        )}
      </AnagraficaDropdown>
    </WidgetWrapper>
  );
};

export default AnagraficaLinkUtili;
