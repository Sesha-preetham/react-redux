import React from "react";
import { useSelector } from "react-redux";
import SimpleTable from "../../../../CommonComponents/SimpleTable/SimpleTable";
import { getPrivatoDataByInteraction } from "../../anagraficaSlice";

const IndirizziBox = (props) => {
  const { layoutType = "preview" } = props;

  const { currentInteraction = "noInteraction" } = useSelector(
    (state) => state.interaction
  );

  const { anagrafica } = useSelector((state) => state.anagrafica);
  const { data: [{ residenza = {} } = {}] = [] } = getPrivatoDataByInteraction(
    anagrafica
  )(currentInteraction);

  /*
        "residenza": {
          "indirizzo": "EQHPGRCJUTKIMRNWJ",
          "comune": "MILANO",
          "cap": "20137",
          "provincia": "MI",
          "stato": "ITALIA"
        },

    */


  let indirizziTableConfiguration = {
    uniqueID: "simpleTableConfiguration",
    metaData: [
      {
        Header: "Indirizzo",
        accessor: "indirizzo",
      },
      {
        Header: "Comune",
        accessor: "comune",
      },
      {
        Header: "Cap",
        accessor: "cap",
      },
      {
        Header: "Provincia",
        accessor: "provincia",
      },
      {
        Header: "Stato",
        accessor: "stato",
      }
    ],
    data: [residenza || {}],
  };

  return (
    <div
      className={`d-flex flex-row flex-wrap anagrafica-${layoutType}-section-1 m-2 overflow-auto`}
    >
      <SimpleTable configuration={indirizziTableConfiguration} />
    </div>
  );
};

export default IndirizziBox;
