import React from "react";
import { useDispatch , useSelector} from "react-redux";
import IconBlueClose from "../../../../CommonComponents/Common/Icons/IconBlueClose";

import {
  stackExpand,
  stackNavPop,
  stackPreview,
} from "../../../../Main/StackNavigation/stackNavigationSlice";
import ExpandedWidgetWrapper from "../../../Widgets/ExpandedWidgetWrapper";
import WidgetTitle from "../../../Widgets/WidgetTitle";
import {
  updateHdcConsunLayout,
} from "./HDCConsunSlice";
import HDCConsunMain from "./HDCConsunMain"

const ExpandMotivoContattoHDC = (props) => {
  const { elStack = {} } = props;
  const dispatch = useDispatch();

  let handleOnStackMounted = (stack) => {
    dispatch(updateHdcConsunLayout(stackExpand));
  };

  let handleOnStackUnMounted = (stack) => {
    dispatch(updateHdcConsunLayout(stackPreview));
  };

  let handleOnStackClose = () => {
    dispatch(stackNavPop());
  };

  return (
    <ExpandedWidgetWrapper
      className={"consult-expand-main-container"}
      elStack={elStack}
      events={{
        handleOnStackMounted,
        handleOnStackUnMounted,
      }}
    >
      <WidgetTitle
        title="Consuntivazione"
        iconElement={
          <IconBlueClose
            configuration={{
              onClick: (active) => {
                handleOnStackClose();
              },
            }}
          />
        }
      />
      <HDCConsunMain layoutType = "expand" />
    </ExpandedWidgetWrapper>
  );
};

export default ExpandMotivoContattoHDC;
