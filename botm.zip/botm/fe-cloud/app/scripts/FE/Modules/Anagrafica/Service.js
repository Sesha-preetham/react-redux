import { pureCloudOrigin } from "../../Client/ClientProperties";
import { exposedDispatch } from "../../Store/store";
import {
  addInteractionToAnagrafica,
  removeInteractionFromAnagrafica,
} from "./anagraficaSlice";


const anagraficaService = () => {
  const anagraficaEventListeners = (event) => {
    if (event.origin !== pureCloudOrigin) return;
    let message = JSON.parse(event.data);
    console.log("anagraficaEventListeners: ", message);
    const dispatch = exposedDispatch;
    if (message && message.type == "interactionSubscription") {
      let { data: interactionData = {} } = message;
      let { category = "", interaction = {} } = interactionData;

      switch (category) {
        case "add":
          dispatch(addInteractionToAnagrafica({ id: interaction.id }));
          break;
        case "change":
          break;
        case "connect":
          break;
        case "disconnect":
          break;
        case "acw":
          break;
        case "deallocate":
          dispatch(
            removeInteractionFromAnagrafica({
              id: interaction.id,
            })
          );
          break;
        default:
          console.log("No Event Matched");
      }
    }
  };

  return { anagraficaEventListeners };
};

export const { anagraficaEventListeners } = anagraficaService();
