import React from "react";
import IconCopy from "../../../../CommonComponents/Common/Icons/IconCopy";
import { copyTextToClipboard } from "../../../../Utils/CommonUtil";

const AnagraficaCopyValue = (props) => {
  const { value = "" , onCopyClick, onCopy = () => {} } = props;

  let handleOnCopyClick = () => {
    if(onCopyClick){
        onCopyClick(value);
    }else{
        copyTextToClipboard(value);
        onCopy();
    }
  }

  return (
    <>
      {value === "" ? (
        <span>{value}</span>
      ) : (
        <div className={`row no-gutters`}>
          <div className={`d-flex pr-2`}>
            <span>{value}</span>
          </div>
          <div className={`d-flex`}>
            <IconCopy
              configuration={{
                onClick: handleOnCopyClick
              }}
            />
          </div>
        </div>
      )}
    </>
  );
};

export default AnagraficaCopyValue;
