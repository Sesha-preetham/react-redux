import { createSlice } from "@reduxjs/toolkit";

let defaultHDCObject = {
  selectedAnomaliaRPList:{},
  noteText:"",
  selectedTire1Value:{},
  selectedTire2Value:{},
  selectedTire3Value:{},
  selectedTire4Value:{},
  selectedTire5Value:{},
  TelDisturboBtnDisable: false,
  InserisciDatiBtnDisable: true,
  intrDisconnectDisable : false,
  hdcConsuntivaDone: false,
}

let initialState = {
  currentLayoutType: "preview",
  categorizationListResp:[],
  anomaliaRPListResp:[],
  hdcBanks:[],
  hdcConsunObj: {
    noInteraction: { ...defaultHDCObject },
  },
};

const hdcConsunSlice = createSlice({
  name: "hdcConsun",
  initialState,
  reducers: {
    updateHdcConsunLayout(state, action) {
        const { payload = "" } = action;
        state.currentLayoutType = payload;
      },
      setHDCBanks(state, action) {
        const { payload = {} } = action;
        const { hdcBankList = [] } = payload;
        state.hdcBanks = [...hdcBankList];
      },
    setCategorizationListData(state, action) {
        const { payload = {} } = action;
        const {categorizationListData=[] } = payload;
        state.categorizationListResp = [...categorizationListData];
      },
    setAnomaliaRPListData(state, action) {
        const { payload = {} } = action;
        const { anomaliaRPListData = [] } = payload;
        state.anomaliaRPListResp = [...anomaliaRPListData];
      },
     setAnomaliaRPListSelectData(state, action) {
        const { payload = {} } = action;
        const { id = "noInteraction" , selectAnomaliaRPListData={}  } = payload;
        state.hdcConsunObj[id].selectedAnomaliaRPList = selectAnomaliaRPListData;
      },
      setNoteTextData(state, action) {
        const { payload = {} } = action;
        const { id = "noInteraction" , noteTextData="" } = payload;
        state.hdcConsunObj[id].noteText = noteTextData;
      },
      setInserisciDatiButtonsDisable(state, action) {
        const { payload = {} } = action;
        const { id = "noInteraction", inserisciDatiBtn= false } = payload;
        state.hdcConsunObj[id].InserisciDatiBtnDisable = inserisciDatiBtn;
      },
      setTelDisturboButtonsDisable(state, action) {
        const { payload = {} } = action;
        const { id = "noInteraction", telDisturboBtn= false } = payload;
        state.hdcConsunObj[id].TelDisturboBtnDisable = telDisturboBtn;
      },
      

      //Tire data updates
      updateTire1SelectData(state, action) {
        const { payload = {} } = action;
        const { id = "noInteraction" , updateTire1Data={}  } = payload;
        state.hdcConsunObj[id].selectedTire1Value = updateTire1Data;
      },
      updateTire2SelectData(state, action) {
        const { payload = {} } = action;
        const { id = "noInteraction" , updateTire2Data={}  } = payload;
        state.hdcConsunObj[id].selectedTire2Value = updateTire2Data;
      },
      updateTire3SelectData(state, action) {
        const { payload = {} } = action;
        const { id = "noInteraction" , updateTire3Data={}  } = payload;
        state.hdcConsunObj[id].selectedTire3Value = updateTire3Data;
      },
      updateTire4SelectData(state, action) {
        const { payload = {} } = action;
        const { id = "noInteraction" , updateTire4Data={}  } = payload;
        state.hdcConsunObj[id].selectedTire4Value = updateTire4Data;
      },
      updateTire5SelectData(state, action) {
        const { payload = {} } = action;
        const { id = "noInteraction" , updateTire5Data={}  } = payload;
        state.hdcConsunObj[id].selectedTire5Value = updateTire5Data;
      },

    updateInteractionDisconnect(state, action) {
      const { payload = {} } = action;
      const { id = "noInteraction", disconnectTrigger = false } = payload;
      state.hdcConsunObj[id].intrDisconnectDisable  = disconnectTrigger;
    },
    updateHdcConsuntivaDone(state, action) {
      const { payload = {} } = action;
      const { id = "noInteraction", isConsuntivaDone = false } = payload;
      state.hdcConsunObj[id].hdcConsuntivaDone  = isConsuntivaDone;
    },
    addInteractionToHdcConsun(state, action) {
      const { payload = {} } = action;
      const { id = "noInteraction" } = payload;
      if (!id) return;
      if (!state.hdcConsunObj[id]) {
        state.hdcConsunObj[id] = { ...defaultHDCObject };
      }
    },
    removeInteractionFromHdcConsun(state, action) {
      const { payload = {} } = action;
      const { id = "noInteraction" } = payload;
      if (!id || id === "noInteraction") return;
      state.hdcConsunObj = Object.entries(state.hdcConsunObj).reduce(
        (acc, [key, value]) => {
          if (key != id) {
            acc[key] = value;
          }
          return acc;
        },
        {}
      );
    },
  },
});


export const {
  setHDCBanks,
  addInteractionToHdcConsun,
  removeInteractionFromHdcConsun,
  updateInteractionDisconnect,
  updateHdcConsuntivaDone,
  updateHdcConsunLayout,
  setCategorizationListData,
  setAnomaliaRPListData,
  setAnomaliaRPListSelectData,
  setNoteTextData,
  setInserisciDatiButtonsDisable,
  setTelDisturboButtonsDisable,

  updateTire1SelectData,
  updateTire2SelectData,
  updateTire3SelectData,
  updateTire4SelectData,
  updateTire5SelectData,
 
} = hdcConsunSlice.actions;

export const getHdcConsunDataById = (hdcConsunObj) => {
  return (id = "noInteraction") => {
    if (hdcConsunObj[id]) {
      return hdcConsunObj[id];
    }
    return initialState.hdcConsunObj.noInteraction;
  };
};


export default hdcConsunSlice.reducer;
