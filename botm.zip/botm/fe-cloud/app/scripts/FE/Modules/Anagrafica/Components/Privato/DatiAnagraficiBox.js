import React from "react";
import { useSelector } from "react-redux";
import { getPrivatoDataByInteraction } from "../../anagraficaSlice";
import AnagraficaLabelValue from "../Common/AnagraficaLabelValue";

const DatiAnagraficiBox = (props) => {
  const { layoutType = "preview" } = props;

  const { currentInteraction = "noInteraction" } = useSelector(
    (state) => state.interaction
  );
  const { anagrafica } = useSelector((state) => state.anagrafica);
  const {
    data: [
      {
        sesso = "",
        nazionalita = "",
        provincia = "",
        nazioneNascita = "",
      } = {},
    ] = [],
  } = getPrivatoDataByInteraction(anagrafica)(currentInteraction);

  return (
    <div
      className={`d-flex flex-row flex-wrap anagrafica-${layoutType}-section-1 m-2`}
    >
      <AnagraficaLabelValue label="Sesso">
        <span>{sesso}</span>
      </AnagraficaLabelValue>
      <AnagraficaLabelValue label="Nazionalità">
        <span>{nazionalita}</span>
      </AnagraficaLabelValue>
      <AnagraficaLabelValue label="Provincia">
        <span>{provincia}</span>
      </AnagraficaLabelValue>
      <AnagraficaLabelValue label="Nazione">
        <span>{nazioneNascita}</span>
      </AnagraficaLabelValue>
    </div>
  );
};

export default DatiAnagraficiBox;
