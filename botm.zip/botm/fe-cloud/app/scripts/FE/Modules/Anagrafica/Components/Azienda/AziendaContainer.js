import React from "react";
import { useSelector } from "react-redux";
import {
  getInternalWidgetByIdAndCode,
  remoteBankingWidgetCode,
  esercenteWidgetCode,
  esercentePOSWidgetCode,
} from "../../../Widgets/internalWidgetsSlice";
import WidgetWrapper from "../../../Widgets/WidgetWrapper";
import RemoteBankingContainer from "../Azienda/RemoteBankingContainer";
import EsercenteContainer from "./EsercenteContainer";
import EsercentePosContainer from "./EsercentePosContainer";


const AziendaContainer = (props) => {
  const { layoutType = "preview" } = props;

  const { currentInteraction = "noInteraction" } = useSelector(
    (state) => state.interaction
  );

  const { internalWidgets } = useSelector((state) => state.internalWidgets);

  const [remoteBankingWidgetShow] = getInternalWidgetByIdAndCode(
    internalWidgets
  )(currentInteraction, remoteBankingWidgetCode);

  const [esercenteWidgetShow] = getInternalWidgetByIdAndCode(
    internalWidgets
  )(currentInteraction, esercenteWidgetCode);

  const [esercentePOSWidgetShow] = getInternalWidgetByIdAndCode(
    internalWidgets
  )(currentInteraction, esercentePOSWidgetCode);

  return (
    <>
    <WidgetWrapper widgetShow={remoteBankingWidgetShow}>
      <RemoteBankingContainer layoutType={layoutType} />
    </WidgetWrapper>
    <WidgetWrapper widgetShow={esercenteWidgetShow}>
      <EsercenteContainer layoutType={layoutType} />
    </WidgetWrapper>
    <WidgetWrapper widgetShow={esercentePOSWidgetShow}>
      <EsercentePosContainer layoutType={layoutType} />
    </WidgetWrapper>
    </>
  );
};

export default AziendaContainer;
