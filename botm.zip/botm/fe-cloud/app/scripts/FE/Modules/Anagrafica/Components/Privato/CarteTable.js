import React, { useState } from "react";
import { useSelector } from "react-redux";
import IconCopy from "../../../../CommonComponents/Common/Icons/IconCopy";
import SimpleTable from "../../../../CommonComponents/SimpleTable/SimpleTable";
import { copyTextToClipboard } from "../../../../Utils/CommonUtil";
import {
  getCarteDataByInteraction,
  getStoricoCarteDataByInteraction,
} from "../../anagraficaSlice";
import StoricoCarteModal from "./StoricoCarteModal";

const CarteTable = (props) => {
  const { currentInteraction = "noInteraction" } = useSelector(
    (state) => state.interaction
  );

  const { anagrafica } = useSelector((state) => state.anagrafica);

  const [showStoricoCarteModal, setShowStoricoCarteModal] = useState(false);

  const carte = getCarteDataByInteraction(anagrafica)(currentInteraction);

  const storicoCarte = getStoricoCarteDataByInteraction(anagrafica)(
    currentInteraction
  );

  let handleStoricoCarte = () => {
    console.log("Storicocarte clicked!");
    setShowStoricoCarteModal(!showStoricoCarteModal);
  };

  let handleOnCloseStoricoCarteModal = () => {
    setShowStoricoCarteModal(!showStoricoCarteModal);
  };

  let carteTableConfiguration = {
    uniqueID: "carteTableConfiguration",
    pagination: true,
    paginationOptions: {
      pageSize: 5,
    },
    metaData: [
      {
        id: "carte",
        Header: "Carte di pagamento",
        accessor: "carta",
      },
      {
        id: "cartedesc",
        Header: "",
        accessor: "cartedesc",
      },
      {
        id: "altriLink",
        Header: (headerInfo, props) => {
          console.log("Header", headerInfo, props);
          //<span>Altri link</span> not necessary now
          return (
            <div
              className="flex-fill text-right tabella-head-row-action-cell"
              onClick={handleStoricoCarte}
            >
              <span>Storico carte</span>
            </div>
          );
        },
        Cell: (cellInfo) => {
          let { original } = cellInfo.row;
          let { carta = "" } = original;
          return (
            <div className="text-right">
              <IconCopy
                configuration={{
                  onClick: () => {
                    copyTextToClipboard(carta);
                  },
                }}
              />
            </div>
          );
        },
      },
    ],
    data: carte,
    sort: [
      {
        id: "carte",
        desc: false,
      },
    ],
  };

  return (
    <>
      <StoricoCarteModal
        showStoricoCarteModal={showStoricoCarteModal}
        handleOnCloseModal={handleOnCloseStoricoCarteModal}
        modalData={storicoCarte}
      />
      <SimpleTable configuration={carteTableConfiguration} />
    </>
  );
};

export default CarteTable;
