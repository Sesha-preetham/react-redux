import React, { useState, useRef, useEffect } from "react";
import { CopyToClipboard } from "react-copy-to-clipboard";
import { useSelector } from "react-redux";
import IconOptions from "../../../../CommonComponents/Common/Icons/IconOptions";
import MyPopover from "../../../../CommonComponents/Popover/MyPopover";
import SimpleTable from "../../../../CommonComponents/SimpleTable/SimpleTable";
import { httpPostPrivatoData } from "../../../../Main/Header/UserSearch/Service";
import { exposedDispatch } from "../../../../Store/store";
import { getInteractionDetails } from "../../../Interaction/interactionSlice";
import {
  getInternalWidgetByIdAndCode,
  remoteBankingWidgetCode,
  draftEmailWidgetCode,
} from "../../../Widgets/internalWidgetsSlice";
import {
  clearAnagraficaPrivatoData,
  getAziendaDataByInteraction,
} from "../../anagraficaSlice";
import WidgetWrapper from "../../../Widgets/WidgetWrapper";
import {
  httpGetClientMessages,
  httpPostSendEmailRemote,
  httpPostRemoteTrace,
} from "../../httpService";
import AnagraficaLinkUtili from "../Common/AnagraficaLinkUtili";

const RemoteBankingContainer = (props) => {
  const { layoutType = "preview" } = props;

  const { currentInteraction = "noInteraction", interactions = [] } =
    useSelector((state) => state.interaction);

  const currentInteractionRef = useRef();
  currentInteractionRef.current = currentInteraction;

  const { internalWidgets } = useSelector((state) => state.internalWidgets);

  const [draftEmailWidgetCodeShow] = getInternalWidgetByIdAndCode(
    internalWidgets
  )(currentInteraction, draftEmailWidgetCode);

  const { anagrafica } = useSelector((state) => state.anagrafica);

  const {
    queueName = undefined,
    attributes = {},
    intxId,
  } = getInteractionDetails(interactions)(currentInteraction);

  const { data: rbdata = [] } =
    getAziendaDataByInteraction(anagrafica)(currentInteraction);

  const { x_servizio } = attributes;

  let onCodiceIBClick = (original) => {
    let codiceIB = original.ibCode
    let interactionToBePassed = undefined;
    if (
      currentInteractionRef.current &&
      currentInteractionRef.current != "noInteraction"
    ) {
      interactionToBePassed = currentInteractionRef.current;
    }
    searchClient({
      searchType: "codCliUsername",
      abiCode: "03268",
      value: codiceIB,
      interactionId: interactionToBePassed,
      queueName: queueName,
      service: x_servizio,
      widgets: [{ code: "privatoWidget" }],
      intxId: intxId,
    });

    httpPostRemoteTrace({
      intxId: intxId,
      codiceSia: original.siaCode,
      soggetto: original.idSoggetto,
      ibCode: original.ibCode,
      pIva: original.partitaIva,
      abiCode: original.abiCode,
    });
  };

  let copyContent = (data) => {
    const copyValue =
      "Tipo:" +
      data.type +
      " , Codice SIA:" +
      data.siaCode +
      " , 8Cifre:" +
      data.ottoCifre +
      " , Denominazione azienda:" +
      data.denominazione +
      " , Codice Cliente IB:" +
      data.ibCode +
      " , Nome Cliente:" +
      data.client +
      " , Email:" +
      data.email +
      " , 13cifre:" +
      data.trediciConto +
      " , partiva IVA:" +
      data.partitaIva;

    return copyValue;
  };

  let searchClient = (request) => {
    const dispatch = exposedDispatch;
    dispatch(
      clearAnagraficaPrivatoData({ interactionId: request.interactionId })
    );
    httpPostPrivatoData(request).then((response) => {
      console.log(response);
    });
  };

  let handleOnSendMail = (originalData) => {
    const {
      ibCode,
      username,
      client,
      siaCode,
      denominazione,
      ottoCifre,
      trediciConto,
      email,
    } = originalData;
    httpPostSendEmailRemote({
      ibCode,
      username,
      client,
      siaCode,
      denominazione,
      ottoCifre,
      trediciConto,
      email,
    });
  };

  const handleRBRowClick = async (rowObj = {}) => {
    console.log("handleRBRowClick", rowObj);
    const { original = {} } = rowObj;
    const { siaCode } = original;
    if (siaCode) {
      await httpGetClientMessages(
        {
          codiceSia: siaCode,
          intxId,
        },
        {
          interactionId: currentInteractionRef.current,
        }
      )
    }
  };

  let rbPreviewTableConfiguration = {
    uniqueID: "rbPreviewTableConfiguration",
    events: {
      onRowClick: handleRBRowClick,
    },
    scrollX: true,
    lastColumnFixed: false,
    metaData: [
      {
        Header: "Codice SIA",
        accessor: "siaCode",
      },
      {
        Header: "8Cifre",
        accessor: "ottoCifre",
      },
      {
        id: "previewRemoteCodiceIB",
        Header: "Codice Cliente IB",
        accessor: "ibCode",
        Cell: (cellInfo) => {
          let { original } = cellInfo.row;
          console.log("original :" + original);
          return (
            <div
              className="text-left"
              onDoubleClick={() => onCodiceIBClick(original)}
            >
              {original.ibCode}
            </div>
          );
        },
      },
      {
        Header: "Denominazione azienda",
        accessor: "denominazione",
      },
    ],
    data: rbdata || [],
  };

  let rbTableConfiguration = {
    uniqueID: "rbTableConfiguration",
    events: {
      onRowClick: handleRBRowClick,
    },
    scrollX: true,
    lastColumnFixed: true,
    globalSearch: {
      show: true,
      placeholder: "Search Users…",
      width: "20%",
    },
    metaData: [
      {
        Header: "Tipo",
        accessor: "type",
      },
      {
        Header: "Codice SIA",
        accessor: "siaCode",
      },
      {
        Header: "8Cifre",
        accessor: "ottoCifre",
      },
      {
        Header: "Denominazione azienda",
        accessor: "denominazione",
      },
      {
        id: "remoteCodiceIB",
        Header: "Codice Cliente IB",
        accessor: "ibCode",
        Cell: (cellInfo) => {
          let { original } = cellInfo.row;
          console.log("original :" + original);
          return (
            <div
              className="text-left"
              onDoubleClick={() => onCodiceIBClick(original)}
            >
              {original.ibCode}
            </div>
          );
        },
      },
      {
        Header: "Nome Cliente",
        accessor: "client",
      },
      {
        Header: "Email Address",
        accessor: "email",
      },
      {
        Header: "13cifre",
        accessor: "trediciConto",
      },
      {
        Header: "partiva IVA",
        accessor: "partitaIva",
      },
      {
        id: "remoteSelection",
        Header: (headerInfo, props) => {
          return null;
        },
        Cell: (cellInfo) => {
          let { original } = cellInfo.row;
          const [showPopover, setShowPopover] = useState(false);
          return (
            <MyPopover
              configuration={{
                uniqueID: "optionsPopOver",
                popoverShow: showPopover,
                popoverPlacement: "left-start",
                popoverClass: "remotebanking-tabellla-row-popover",
                overlayTriggerElement: (
                  <IconOptions
                    configuration={{
                      onClick: () => {
                        setShowPopover(!showPopover);
                      },
                    }}
                  />
                ),
              }}
            >
              <div className="d-flex flex-column">
                <div className="remotebanking-options-content my-1">
                  <CopyToClipboard
                    text={copyContent(original)}
                    onCopy={() => setShowPopover(!showPopover)}
                  >
                    <span>Copia contenuto riga</span>
                  </CopyToClipboard>
                </div>
                <WidgetWrapper widgetShow={draftEmailWidgetCodeShow}>
                  <div className="remotebanking-options-content my-1">
                    <span onClick={() => handleOnSendMail(original)}>
                      Send e-mail
                    </span>
                  </div>
                </WidgetWrapper>
              </div>
            </MyPopover>
          );
        },
      },
    ],
    data: rbdata || [],
  };

  return (
    <div>
      {layoutType === "preview" ? (
        <div className={`remotebanking-${layoutType}-section-1 my-3`}>
          <SimpleTable configuration={rbPreviewTableConfiguration} />
        </div>
      ) : (
        <div className={`remotebanking-${layoutType}-section-1 my-3`}>
          <SimpleTable configuration={rbTableConfiguration} />
        </div>
      )}
      <AnagraficaLinkUtili
        layoutType={layoutType}
        widgetCode={remoteBankingWidgetCode}
      />
    </div>
  );
};

export default RemoteBankingContainer;
