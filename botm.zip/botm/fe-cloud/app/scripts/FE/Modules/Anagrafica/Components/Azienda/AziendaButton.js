import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { exposedDispatch } from "../../../../Store/store";
import { getInteractionDetails } from "../../../Interaction/interactionSlice";
import ProspectModal from "../../../Prospect/Components/modal/ProspectModal";
import {
  getProspectDataById,
  updateProspectDataByProperty,
  aziendaProspectData
} from "../../../Prospect/prospectSlice";
import { updateProspectDataByAziendaClientToggle} from "../../../Prospect/Service";
import {
  getInternalWidgetByIdAndCode,
  prospectWidgetCode,
} from "../../../Widgets/internalWidgetsSlice";
import WidgetWrapper from "../../../Widgets/WidgetWrapper";
import {
  getNotClientDataByInteraction,
  getAziendaDataByInteraction,
} from "../../anagraficaSlice";

const AziendaButton = (props) => {
  const {
    handleOnProspect = () => {},
  } = props;

  const dispatch = useDispatch();

  const { internalWidgets } = useSelector((state) => state.internalWidgets);
  const { prospectData } = useSelector((state) => state.prospect);
  const { anagrafica } = useSelector((state) => state.anagrafica);
  const {
    currentInteraction = "noInteraction",
    interactions = [],
  } = useSelector((state) => state.interaction);

  const [prospectWidgetShow] = getInternalWidgetByIdAndCode(internalWidgets)(
    currentInteraction,
    prospectWidgetCode
  );

  const {
    aziendaProspectClientDisabled = true,
    aziendaProspectNotClientDisabled = true,
    aziendaProspectData: {showProspectModal = false , loadDataFromAnagrafica = false}
  } = getProspectDataById(prospectData)(currentInteraction);

  const {
    clientToggle = true,
    data: notClienteData = {},
  } = getNotClientDataByInteraction(anagrafica)(currentInteraction);

  const { selectedIbCode = {} } = getAziendaDataByInteraction(anagrafica)(
    currentInteraction
  );

 

  const interactionDetails = getInteractionDetails(interactions)(
    currentInteraction
  );

  const { denominazione = "" } = notClienteData;

  useEffect(() => {
    if (denominazione) {
      aziendaProspectNotClientDisabled &&
        dispatch(
          updateProspectDataByProperty({
            interactionId: currentInteraction,
            data: {
              property: "aziendaProspectNotClientDisabled",
              value: false,
            },
          })
        );
    } else {
      !aziendaProspectNotClientDisabled &&
        dispatch(
          updateProspectDataByProperty({
            interactionId: currentInteraction,
            data: {
              property: "aziendaProspectNotClientDisabled",
              value: true,
            },
          })
        );
    }
  }, [denominazione]);

  useEffect(() => {
    dispatch(
      updateProspectDataByProperty({
        interactionId: currentInteraction,
        data: {
          property: "aziendaProspectNotClientDisabled",
          value: !clientToggle,
        },
      })
    );
    !loadDataFromAnagrafica &&
      dispatch(
        updateProspectDataByProperty({
          interactionId: currentInteraction,
          data: {
            property: "loadDataFromAnagrafica",
            value: true,
          },
          orginData: aziendaProspectData
        })
      );
  }, [clientToggle]);

  useEffect(() => {
    loadDataFromAnagrafica &&
      dispatch(
        updateProspectDataByProperty({
          interactionId: currentInteraction,
          data: {
            property: "prospectCrmNote",
            value: "",
          },
          orginData : aziendaProspectData
        })
      );
  }, [loadDataFromAnagrafica]);

  const handleOnProspectButton = () => {
    //handleOnProspect();
    dispatch(
      updateProspectDataByProperty({
        interactionId: currentInteraction,
        data: {
          property: "showProspectModal",
          value: true
        },
        orginData : aziendaProspectData
      })
    );
  };

 


  return (
    <div className="d-flex flex-row justify-content-center my-2">
      <WidgetWrapper widgetShow={prospectWidgetShow}>
        <>
          <div className="w-25 pl-2">
            <button
              type="button"
              className={`btn Rectangle-Button-Blue w-100`}
              onClick={handleOnProspectButton}
              disabled={
                clientToggle
                  ? aziendaProspectClientDisabled
                  : aziendaProspectNotClientDisabled
              }
            >
              Prospect
            </button>
          </div>
          <ProspectModal
            configuration={{
              showProspectModal: showProspectModal,
              orginTab : "aziendaProspect",
              orginData : aziendaProspectData,
              handleOnHideProspectModal: () => {
                dispatch(
                  updateProspectDataByProperty({
                    interactionId: currentInteraction,
                    data: {
                      property: "showProspectModal",
                      value: false,
                    },
                    orginData:aziendaProspectData
                  })
                );
              },
              handleOnEnteringProspectModal: () => {
                updateProspectDataByAziendaClientToggle();
              },
            }}
          />
        </>
      </WidgetWrapper>
    </div>
  );
};

export default AziendaButton;
