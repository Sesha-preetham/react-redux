import React, { useState } from "react";
import MyModal from "../../../../CommonComponents/Modal/MyModal";
import { httpGetAuthInfo } from "../../../../Main/Header/UserSearch/Service";
import { withErrorBoundary } from "../../../../CommonComponents/ErrorBoundary/withErrorBoudary";

const AuthInfoModal = ({ configuration = {} } = props) => {
  const {
    showAuthInfoModal,
    codiceDetails,
    handleOnCloseAuthInfoModal
  } = configuration;

  const { rlData = {}, value: codiceIB = "" } = codiceDetails || {};
  const { bank = "" } = rlData;
  const [authInfoDetails, setAuthInfoDetails] = useState({
    codice: "",
    pinErr: "",
    passErr: "",
    dobErr: "",
    tokenErr: null,
    scadanzaPin: null,
    scadanzaPass: null,
    scadanzaPinDate: null,
    scadanzaPassDate: null,
    isNewCustomer: false,
    userName: ""
  });

  let handleOnhide = () => {
    handleOnCloseAuthInfoModal(false);
  };

  let handleOnOpen = () => {
    if(codiceIB){
      httpGetAuthInfo({
        codice: codiceIB,
        bank: bank
      }).then(r => {
        setAuthInfoDetails(r.response);
      });
    }else{
      handleOnCloseAuthInfoModal(false);
    }
  };

  const authenticationInfoModal = {
    uniqueID: "authenticationInfoModal",
    modalClass: "authentication-info my-modal",
    dialogClassName: "modal-w",
    title: {
      content: "Authentication Info",
      class: "widget-title"
    },
    modalShow: showAuthInfoModal,
    modalHeaderShow: true,
    backdrop: {
      enable: true
    },
    events: {
      onHide: () => {
        console.log("multiClienteModal modal onHide");
        handleOnhide();
      },
      onEntered: () => {
        handleOnOpen();
        console.log("multiClienteModal modal onEntered");
      },
      onExited: () => {
        console.log("multiClienteModal modal onExited");
      }
    }
  };

  return (
    <MyModal configuration={authenticationInfoModal}>
      <div className="d-flex flex-column">
        <div className="d-flex justify-content-start  mb-3">
        {(authInfoDetails && authInfoDetails.isNewCustomer == false && 
        <div className="d-flex info-content section-1">
        <div className="mx-3 info-label">Pin:</div>
        <div className="mx-3 info-value">{authInfoDetails.pinErr}</div>
       </div>)}
          
          <div className="d-flex info-content section-1">
            <div className="mx-3 info-label">Password:</div>
            <div className="mx-3 info-value">{authInfoDetails.passErr}</div>
          </div>
          <div className="d-flex info-content section-1">
            <div className="mx-3 info-label">DOB:</div>
            <div className="mx-3 info-value">{authInfoDetails.dobErr}</div>
          </div>
          <div className="d-flex info-content section-1">
            <div className="mx-3 info-label">Token:</div>
            <div className="mx-3 info-value">{authInfoDetails.tokenErr}</div>
          </div>
        </div>
        
        <div className="d-flex justify-content-start  mb-3">
        {(authInfoDetails && authInfoDetails.isNewCustomer == false && 
          <div className="d-flex info-content section-2">
            <div className="mx-3 info-label">Scandanza Pin:</div>
            <div className="mx-3 info-value">{authInfoDetails.scadanzaPin}</div>
          </div>)}
          <div className="d-flex info-content section-2">
            <div className="mx-3 info-label">Scandanza Pwd:</div>
            <div className="mx-3 info-value">{authInfoDetails.scadanzaPass}</div>
          </div>
          <div className="d-flex info-content section-2">
            <div className="mx-3 info-label">Antidos flag:</div>
            <div className="mx-3 info-value">S</div>
          </div>
        </div>
        <div className="d-flex justify-content-start  mb-3">
        {(authInfoDetails && authInfoDetails.isNewCustomer == false && 
          <div className="d-flex info-content section-3">
            <div className="mx-3 info-label">Pin last change:</div>
            <div className="mx-3 info-value">{authInfoDetails.scadanzaPinDate}</div>
            </div>)}
            <div className="d-flex info-content section-3">
            <div className="mx-3 info-label">Pwd last change:</div>
            <div className="mx-3 info-value">{authInfoDetails.scadanzaPassDate}</div>
          </div>
        </div>
      </div>
    </MyModal>
  );
};

export default withErrorBoundary(AuthInfoModal);
