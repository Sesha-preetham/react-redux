import React, { useEffect } from "react";
import {  useDispatch ,useSelector } from "react-redux";
import { CSSTransition } from "react-transition-group";
import IconExplode from "../../../../CommonComponents/Common/Icons/IconExplode";
import { stackNavHDC } from "../../../../Main/StackNavigation/StackNavComponents";
import {
  stackNavPush,
} from "../../../../Main/StackNavigation/stackNavigationSlice";
import {hdcConsunWidgetCode,getInternalWidgetByIdAndCode} from "../../../Widgets/internalWidgetsSlice";
import WidgetTitle from "../../../Widgets/WidgetTitle";
import WidgetWrapper from "../../../Widgets/WidgetWrapper";
import {
  hdcEventListeners,
} from "./Service";
import { withErrorBoundary } from "../../../../CommonComponents/ErrorBoundary/withErrorBoudary";
import HDCConsunMain from "./HDCConsunMain"

const PreviewMotivoContattoHDC = (props) => {
  const dispatch = useDispatch();
  const { currentInteraction = "noInteraction" } = useSelector((state) => state.interaction);
  const { internalWidgets } = useSelector((state) => state.internalWidgets);
  const [hdcConsunWidgetShow] = getInternalWidgetByIdAndCode(internalWidgets)( currentInteraction, hdcConsunWidgetCode);

  useEffect(() => {
    window.addEventListener("message", hdcEventListeners, false);
    return () => {
      window.removeEventListener("message", hdcEventListeners, false);
    };
  }, []);

 let handleOnStackExpand = () => {
    dispatch(stackNavPush(stackNavHDC));
  };

  return (
    <WidgetWrapper widgetShow={hdcConsunWidgetShow}>
      <CSSTransition
        in={hdcConsunWidgetShow}
        timeout={300}
        classNames="slide-right-toggle"
        unmountOnExit={false}
        mountOnEnter={true}
      >
        <div className="d-flex flex-column section-consult">
          <WidgetTitle
            title="Consuntivazione"
            iconElement={
              <IconExplode
                configuration={{
                  onClick: (active) => {
                    handleOnStackExpand();
                  },
                }}
              />
            }
          />
                <HDCConsunMain layoutType = "preview" />
        </div>
      </CSSTransition>
    </WidgetWrapper>
  );
};

export default withErrorBoundary(PreviewMotivoContattoHDC);
