import { toast } from "react-toastify";
import { hdcWidgetAlertId } from "../../../../CommonComponents/AlertToast/AlertIdConstants";
import { beServiceUrls } from "../../../../Client/ClientProperties";
import { exposedDispatch,exposedGetState } from "../../../../Store/store";
import { reduceToOptions, getBaseErrorMessage } from "../../../../Utils/CommonUtil";
import HttpClient from "../../../../Utils/HttpClient";
import { setAnomaliaRPListData ,setCategorizationListData, setHDCBanks } from "./HDCConsunSlice";


   export const httpPostQueueAnomaliaService = async (request = {}) => {
    let httpClient = new HttpClient();
    const dispatch = exposedDispatch;
    httpClient.setUrl(beServiceUrls().queueAnomalia);
    let responseData = await httpClient.httpPost(request).then((responseVal) => {
      const { status = "", response = [] } = responseVal;
      if (status === "OK") {
        dispatch(setAnomaliaRPListData({anomaliaRPListData : response}))
        return reduceToOptions(response)("id", "value");
      }else if(status ==="KO"){
        toast.warn(getBaseErrorMessage("Warning",responseVal), { containerId: hdcWidgetAlertId });
      }else{
        throw responseVal
      }
      return [];
    }).catch((err) => {
      toast.error(getBaseErrorMessage("Error",err), { containerId: hdcWidgetAlertId });
      return [];
    });
    return responseData;
  }

  export const httpPostCategorizationListService = async (request = {}) => {
    let httpClient = new HttpClient();
    const dispatch = exposedDispatch;
    httpClient.setUrl(beServiceUrls().categorizationList);
    let responseData = await httpClient.httpPost(request).then((responseVal) => {
      const { status = "", response = [] } = responseVal;
      if (status === "OK") {
        dispatch(setCategorizationListData({categorizationListData: response}))
        return response;
      }else if(status ==="KO"){
        toast.warn(getBaseErrorMessage("Warning",responseVal), { containerId: hdcWidgetAlertId });
      }else{
        throw responseVal
      }
      return [];
    }).catch((err) => {
      toast.error(getBaseErrorMessage("Error",err), { containerId: hdcWidgetAlertId });
      return [];
    });
    return responseData;
  }

  export const httpSendHDCConsunService = async (request = {}) => {
    let httpClient = new HttpClient();
    const dispatch = exposedDispatch;
    httpClient.setUrl(beServiceUrls().createIncident);
    let responseData = await httpClient.httpPost(request).then((responseVal) => {
      const { status = "", response = [] } = responseVal;
      if (status === "OK") {
       return responseVal
      }else if(status ==="KO"){
        toast.warn(getBaseErrorMessage("Warning",responseVal), { containerId: hdcWidgetAlertId });
      }else{
        throw responseVal
      }
      return [];
    }).catch((err) => {
      toast.error(getBaseErrorMessage("Error",err), { containerId: hdcWidgetAlertId });
      return [];
    });
    return responseData;
  }

  export const httpHDCTraceService = async (bodyRequest = {}, params = {}) => {
    const dispatch = exposedDispatch;
    let httpClient = new HttpClient();
    httpClient.setUrl(beServiceUrls().hdcTrace);
    let responseData = await httpClient
      .httpPost(bodyRequest, params)
      .then((response) => {
        const { status = "" } = response;
        if (status === "OK") {
          toast.success("Success trace", { containerId: hdcWidgetAlertId });
          return response
        }else if(status ==="KO"){
          toast.warn(getBaseErrorMessage("Warning",response), { containerId: hdcWidgetAlertId });
        }else{
          throw response
        }
        return [];
      })
      .catch((err) => {
        toast.error(getBaseErrorMessage("Error",err), { containerId: hdcWidgetAlertId });
        return [];
      });
    return responseData;
  };

  export const httpGetHDCBanks = async (request = {}) => {
    let httpClient = new HttpClient();
    httpClient.setUrl(beServiceUrls().hdcBanksUrl);
    const dispatch = exposedDispatch;
    let visibleBanks = await httpClient.httpGet(request).then((responseVal) => {
      const { status = "", response: hdcBanksResponse = [] } = responseVal;
      if (status === "OK") {
        dispatch(setHDCBanks({hdcBankList: reduceToOptions(hdcBanksResponse)("bankCode", "desctiption")}))
        return reduceToOptions(hdcBanksResponse)("bankCode", "desctiption");
      }
      return [];
    });
    return visibleBanks;
  };
  