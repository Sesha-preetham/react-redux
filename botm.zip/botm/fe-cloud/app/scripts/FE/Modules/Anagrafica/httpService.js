import { beServiceUrls } from "../../Client/ClientProperties";
import { toast } from "react-toastify";
import { getBaseErrorMessage } from "../../Utils/CommonUtil";
import { globalAlertId } from "../../CommonComponents/AlertToast/AlertIdConstants";
import store, { exposedGetState } from "../../Store/store";
import {
  globalSpinnerId,
  toggleSpinnerById,
} from "../../CommonComponents/Spinner/spinnerSlice";

import HttpClient from "../../Utils/HttpClient";

import {
  loadContiData,
  loadCarteData,
  loadStoricoCarteData,
  loadClientSearchAnagraficaData,
  pushNotification,
} from "./anagraficaSlice";

import {
  addAuthenticationValueByInteraction,
  updateAuthenticationPropertyByInteractionAndValue,
} from "../Authentication/authenticationSlice";
import {
  getInteractionDetails,
  updateInteractionProperty,
} from "../Interaction/interactionSlice";
import { updateStateAfterClientSearch } from "../../Main/Header/UserSearch/Service";

export const httpGetContiSearch = async (request = {}) => {
  const dispatch = store.dispatch;
  let httpClient = new HttpClient();
  httpClient.setUrl(beServiceUrls().clientConti);
  const { interactionId } = request;
  let responseData = await httpClient.httpGet(request).then((response) => {
    const { status = "", response: contiResponse = [] } = response;
    if (status === "OK") {
      dispatch(
        loadContiData({ interactionId: interactionId, conti: contiResponse })
      );
      return contiResponse;
    }
    return [];
  });
  return responseData;
};

export const httpGetCarteSearch = async (request = {}) => {
  const dispatch = store.dispatch;
  let httpClient = new HttpClient();
  httpClient.setUrl(beServiceUrls().clientCarte);
  const { interactionId } = request;
  let responseData = await httpClient.httpGet(request).then((response) => {
    const { status = "", response: carteResponse = [] } = response;
    if (status === "OK") {
      dispatch(
        loadCarteData({ interactionId: interactionId, carte: carteResponse })
      );
      return carteResponse;
    }
    return [];
  });
  return responseData;
};

export const httpGetStoricoCarteSearch = async (request = {}) => {
  const dispatch = store.dispatch;
  let httpClient = new HttpClient();
  httpClient.setUrl(beServiceUrls().clientStoricoCarte);
  const { interactionId } = request;
  let responseData = await httpClient.httpGet(request).then((response) => {
    const { status = "", response: storicoCarteResponse = [] } = response;
    if (status === "OK") {
      dispatch(
        loadStoricoCarteData({
          interactionId: interactionId,
          carte: storicoCarteResponse,
        })
      );
      return storicoCarteResponse;
    }
    return [];
  });
  return responseData;
};

export const httpPostSendEmail = async (request = {}) => {
  const dispatch = store.dispatch;
  let httpClient = new HttpClient();
  httpClient.setUrl(beServiceUrls().draftPrivato);
  dispatch(toggleSpinnerById(globalSpinnerId));
  let responseData = await httpClient.httpPost(request).then((response) => {
    const { status = "" } = response;
    dispatch(toggleSpinnerById(globalSpinnerId));
    if (status === "KO") {
      toast.warn(getBaseErrorMessage("Warning", response), {
        containerId: globalAlertId,
      });
    } else if (status === "EXCEPTION") {
      toast.error(getBaseErrorMessage("Error", response), {
        containerId: globalAlertId,
      });
    }
    return {};
  });
  return responseData;
};

export const httpPostSendEmailRemote = async (request = {}) => {
  const dispatch = store.dispatch;
  let httpClient = new HttpClient();
  httpClient.setUrl(beServiceUrls().draftMailRemote);
  dispatch(toggleSpinnerById(globalSpinnerId));
  let responseData = await httpClient.httpPost(request).then((response) => {
    const { status = "" } = response;
    dispatch(toggleSpinnerById(globalSpinnerId));
    if (status === "KO") {
      toast.warn(getBaseErrorMessage("Warning", response), {
        containerId: globalAlertId,
      });
    } else if (status === "EXCEPTION") {
      toast.error(getBaseErrorMessage("Error", response), {
        containerId: globalAlertId,
      });
    }
    return {};
  });
  return responseData;
};

export const httpPostSendEmailEsercente = async (request = {}) => {
  const dispatch = store.dispatch;
  let httpClient = new HttpClient();
  httpClient.setUrl(beServiceUrls().draftMailEsercente);
  dispatch(toggleSpinnerById(globalSpinnerId));
  let responseData = await httpClient.httpPost(request).then((response) => {
    const { status = "" } = response;
    dispatch(toggleSpinnerById(globalSpinnerId));
    if (status === "KO") {
      toast.warn(getBaseErrorMessage("Warning", response), {
        containerId: globalAlertId,
      });
    } else if (status === "EXCEPTION") {
      toast.error(getBaseErrorMessage("Error", response), {
        containerId: globalAlertId,
      });
    }
    return {};
  });
  return responseData;
};

export const httpPostPrivatoService = async (bodyRequest = {}) => {
  let httpClient = new HttpClient();
  httpClient.setUrl(beServiceUrls().clientPrivatoSearch);
  let responseData = await httpClient
    .httpPost(bodyRequest)
    .then((response) => {
      return response;
    })
    .catch((err) => {
      throw err;
    });
  return responseData;
};

export const httpPostRemoteTrace = async(bodyRequest = {}) => {
  let httpClient = new HttpClient();
  httpClient.setUrl(beServiceUrls().traceRemoteAnagrafica);
  let responseData = await httpClient
    .httpPost(bodyRequest)
    .then((response) => {
      return response;
    })
    .catch((err) => {
      throw err;
    });
  return responseData;
};

export const httpPostEsercenteService = async (bodyRequest = {}) => {
  let httpClient = new HttpClient();
  httpClient.setUrl(beServiceUrls().clientEsercenteSearch);
  let responseData = await httpClient
    .httpPost(bodyRequest)
    .then((response) => {
      return response;
    })
    .catch((err) => {
      throw err;
    });
  return responseData;
};

export const httpGetLastClientSearched = async (request = {}) => {
  const dispatch = store.dispatch;
  let httpClient = new HttpClient();
  httpClient.setUrl(beServiceUrls().getLastClientSearch);
  const { interactionId } = request;
  let responseData = await httpClient.httpGet(request).then((responseData) => {
    const {
      status = "",
      response = {},
      lastClientSearchFound = false,
    } = responseData;
    if (status === "OK" && response) {
      updateStateAfterClientSearch({
        interactionId: interactionId,
        clientSearchData: response,
      });
      dispatch(
        updateInteractionProperty({
          id: interactionId,
          property: "lastClientSearchFound",
          value: lastClientSearchFound,
        })
      );
      /*dispatch(
        loadClientSearchAnagraficaData({
          interactionId: interactionId,
          clientSearchData: response,
        })
      );
      dispatch(
        updateInteractionProperty({
          id: interactionId,
          property: "lastClientSearchFound",
          value: lastClientSearchFound,
        })
      );
      */
      const { privato = privato || [] } = response;
      privato.map((val) => {
        const { internetCodes = internetCodes || [] } = val;
        internetCodes.map((ic) => {
          const {
            ibCode,
            authenticationState = authenticationState || "NOT_AUTHENTICATED",
            credentialType,
            isNewCustomer = false,
          } = ic;
          if (ibCode) {
            dispatch(
              addAuthenticationValueByInteraction({
                interactionId: interactionId,
                authValue: ibCode,
              })
            );
            dispatch(
              updateAuthenticationPropertyByInteractionAndValue({
                interactionId: interactionId,
                authValue: ibCode,
                property: "authenticationState",
                value: authenticationState,
              })
            );
            dispatch(
              updateAuthenticationPropertyByInteractionAndValue({
                interactionId: interactionId,
                authValue: ibCode,
                property: "isNewCustomer",
                value: isNewCustomer,
              })
            );
            if (
              !isNewCustomer &&
              authenticationState === "PARTIAL_AUTHENTICATED"
            ) {
              dispatch(
                updateAuthenticationPropertyByInteractionAndValue({
                  interactionId: interactionId,
                  authValue: ibCode,
                  property: "nextStep",
                  value: credentialType,
                })
              );
            }
            if (authenticationState === "PARTIAL_AUTHENTICATED") {
              const { attributes = {} } = getInteractionDetails(
                exposedGetState().interaction.interactions
              )(interactionId);
              const { authFlow } = exposedGetState().preference.profile;
              let isAgentTransfer = attributes["isagenttransfer"];
              if (authFlow === "v2") {
                let flowToken = attributes["authtoken"];
                let authKey = attributes["auth_challenge ultimo"];
                if (flowToken && authKey) {
                  console.log(
                    "Authv2 httpGetLastClientSearched",
                    authenticationState,
                    attributes,
                    isAgentTransfer
                  );
                  dispatch(
                    updateAuthenticationPropertyByInteractionAndValue({
                      interactionId: interactionId,
                      authValue: ibCode,
                      property: "flowToken",
                      value: flowToken,
                    })
                  );
                  if (isAgentTransfer === "true") {
                    dispatch(
                      updateAuthenticationPropertyByInteractionAndValue({
                        interactionId: interactionId,
                        authValue: ibCode,
                        property: "authenticationState",
                        value: "PARTIAL_AUTHENTICATED_TRASF",
                      })
                    );
                  }
                  if (authKey.includes("authChallenges")) {
                    authKey = [...JSON.parse(`{ ${authKey} }`).authChallenges];
                  }
                  dispatch(
                    updateAuthenticationPropertyByInteractionAndValue({
                      interactionId: interactionId,
                      authValue: ibCode,
                      property: "authKeys",
                      value: authKey,
                    })
                  );
                }
              } else if (authFlow === "v3") {
                let barraAuthToken = attributes["barraauthtoken"];
                if (barraAuthToken) {
                  dispatch(
                    updateAuthenticationPropertyByInteractionAndValue({
                      authValue: ibCode,
                      interactionId,
                      property: "authToken",
                      value: barraAuthToken,
                    })
                  );
                  dispatch(
                    updateAuthenticationPropertyByInteractionAndValue({
                      authValue: ibCode,
                      interactionId,
                      property: "authenticationState",
                      value: "PARTIAL_AUTHENTICATED_TRASF",
                    })
                  );
                }
              }
            }
          }
        });
      });
      return response;
    }
    return {};
  });
  return responseData;
};

export const httpGetClientMessages = async (
  bodyRequest = {},
  metaData = {}
) => {
  let httpClient = new HttpClient();
  const dispatch = store.dispatch;
  httpClient.setUrl(beServiceUrls().getClientMessages);
  let responseData = await httpClient
    .httpPost(bodyRequest)
    .then((response = {}) => {
      const { response: responseData = {} } = response;
      const { warningMessages = [] } = responseData;
      const { interactionId = "noInteraction" } = metaData;
      if (warningMessages && warningMessages.length > 0) {
        dispatch(
          pushNotification({
            interactionId,
            notification: warningMessages,
          })
        );
      }
      return response;
    })
    .catch((err) => {
      throw err;
    });
  return responseData;
};
