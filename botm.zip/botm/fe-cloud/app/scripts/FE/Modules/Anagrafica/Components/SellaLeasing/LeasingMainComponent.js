import React, {useEffect, useState} from "react";
import { useSelector } from "react-redux";

import AnagraficaLabelValue from "../Common/AnagraficaLabelValue";
import AnagraficaDropdown from "../Common/AnagraficaDropdown";
import { getLeasingByInteraction } from "../../anagraficaSlice";
import FormFieldHandler from "../../../../CommonComponents/Forms/FormFieldHandler";

const LeasingMainComponent = (props) => {
  const { layoutType = "preview" , formFields = new FormFieldHandler(true), } = props;

  const { currentInteraction = "noInteraction" } = useSelector((state) => state.interaction);
  const { anagrafica } = useSelector((state) => state.anagrafica);
  const { data: leasingDataObj = {} } = getLeasingByInteraction(anagrafica)(currentInteraction); 

  const {
    clienteSellaLeasing,
    utenteSellaLeasingWeb,
  } = leasingDataObj;

  let initialClientVal  = {
    dsUser: "",
    codInt: "",
    cf: "",
  }

  let initialUtenteVal = {
    ibCode: "",
    codIntUser: "",
    nomeUtente: "",
    cogNomeUtente: "",
    cfUtente: "",
    emailUtente:"",
    nMobileUtente: "",
    userType: "",
    userStatus: "",
    userGrantType: "",
    dateLastChange: "",
    loginType: "",
    tokenStatus: "",
    tokenExpirationDate: "",
    tokenSerialNumber: "",
    pinResetBlockedDate: "",
  }
  const [clientval, setClientVal] = useState(initialClientVal);
  const [utenteSellaVal, setUtenteSellaVal] = useState(initialUtenteVal);


 useEffect(() => {
   if (clienteSellaLeasing) {
     let clientObject = convertArrayToObject(
       clienteSellaLeasing,
       "id",
       "value"
     );
     setClientVal(clientObject);
   } else setClientVal(initialClientVal);

   if (utenteSellaLeasingWeb) {
     let utenteObject = convertArrayToObject(
       utenteSellaLeasingWeb,
       "id",
       "value"
     );
     setUtenteSellaVal(utenteObject);
   } else setUtenteSellaVal(initialUtenteVal);
 }, [clienteSellaLeasing, utenteSellaLeasingWeb]);

 const convertArrayToObject = (array, key, val) => {
  const initialValue = {};
  return array.reduce((obj, item) => {
    return {
      ...obj,
      [item[key]]: item[val],
    };
  }, initialValue);
};

  return (
    <>
      <div className="d-flex flex-column">
        <AnagraficaDropdown
          className={`anagrafica-${layoutType}-section-2`}
          title="Cliente Sella Leasing"
        >
          <div
            className={`d-flex flex-row flex-wrap anagrafica-${layoutType}-section-1 m-2`}
          >
            <AnagraficaLabelValue label="DS_USER">
              <span>{clientval.dsUser}</span>
            </AnagraficaLabelValue>
            <AnagraficaLabelValue label="COD_INT">
              <span>{clientval.codInt}</span>
            </AnagraficaLabelValue>
            <AnagraficaLabelValue label="CF / P.IVA CLIENTE">
              <span>{clientval.cf}</span>
            </AnagraficaLabelValue>
          </div>
        </AnagraficaDropdown>

        <AnagraficaDropdown
          className={`anagrafica-${layoutType}-section-2`}
          title="Utente Sella Leasing Web"
          showChildrenDefault={true}
        >
          <div
            className={`d-flex flex-row flex-wrap anagrafica-${layoutType}-section-1 m-2`}
          >
            <AnagraficaLabelValue label="IB_CODE">
              <span>{utenteSellaVal.ibCode}</span>
            </AnagraficaLabelValue>
            <AnagraficaLabelValue label="COD_INT_USER">
              <span>{utenteSellaVal.codIntUser}</span>
            </AnagraficaLabelValue>
            <AnagraficaLabelValue label="NOME UTENTE">
              <span>{utenteSellaVal.nomeUtente}</span>
            </AnagraficaLabelValue>
            <AnagraficaLabelValue label="COGNOME UTENTE">
              <span>{utenteSellaVal.cogNomeUtente}</span>
            </AnagraficaLabelValue>
            <AnagraficaLabelValue label="C.F. UTENTE">
              <span>{utenteSellaVal.cfUtente}</span>
            </AnagraficaLabelValue>
            <AnagraficaLabelValue label="EMAIL UTENTE">
              <span>{utenteSellaVal.emailUtente}</span>
            </AnagraficaLabelValue>
            <AnagraficaLabelValue label="N_MOBILE UTENTE">
              <span>{utenteSellaVal.nMobileUtente}</span>
            </AnagraficaLabelValue>
            <AnagraficaLabelValue label="USER_TYPE">
              <span>{utenteSellaVal.userType}</span>
            </AnagraficaLabelValue>
            <AnagraficaLabelValue label="USER_STATUS">
              <span>{utenteSellaVal.userStatus}</span>
            </AnagraficaLabelValue>
            <AnagraficaLabelValue label="USER_GRANT_TYPE">
              <span>{utenteSellaVal.userGrantType}</span>
            </AnagraficaLabelValue>
            <AnagraficaLabelValue label="DT_LAST_CHANGE">
              <span>{utenteSellaVal.dateLastChange}</span>
            </AnagraficaLabelValue>
            <AnagraficaLabelValue label="LOGIN_TYPE">
              <span>{utenteSellaVal.loginType}</span>
            </AnagraficaLabelValue>
            <AnagraficaLabelValue label="TOKEN_STATUS">
              <span>{utenteSellaVal.tokenStatus}</span>
            </AnagraficaLabelValue>
            <AnagraficaLabelValue label="TOKEN_EXPIRATION_DATE">
              <span>{utenteSellaVal.tokenExpirationDate}</span>
            </AnagraficaLabelValue>
            <AnagraficaLabelValue label="TOKEN_SERIAL_NUMBER">
              <span>{utenteSellaVal.tokenSerialNumber}</span>
            </AnagraficaLabelValue>
            <AnagraficaLabelValue label="PIN_RESET_BLOCKED_DATE">
              <span>{utenteSellaVal.pinResetBlockedDate}</span>
            </AnagraficaLabelValue>
          </div>
        </AnagraficaDropdown>
      </div>
    </>
  );
};

export default LeasingMainComponent;