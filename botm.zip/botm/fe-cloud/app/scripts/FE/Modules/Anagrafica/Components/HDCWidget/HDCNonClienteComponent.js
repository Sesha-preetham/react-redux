import React, { useState, useEffect, useRef } from "react";
import { useDispatch, useSelector } from "react-redux";
import FormFieldHandler from "../../../../CommonComponents/Forms/FormFieldHandler";
import TextField from "../../../../CommonComponents/Forms/TextField";
import SelectField from "../../../../CommonComponents/Forms/SelectField";

import {
  getNotClientDataByInteraction,
  setNotClientDataProperty,
  getHdcLayoutByInteraction,
} from "../../../Anagrafica/anagraficaSlice";
import { httpGetHDCBanks } from "./HDCService";
import AnagraficaLabelValue from "../Common/AnagraficaLabelValue";

const HDCNonClienteComponent = (props) => {
   const { layoutType } = props;
   const [formFields] = useState(new FormFieldHandler(true));
  const { currentInteraction = "noInteraction" } = useSelector( (state) => state.interaction );
  const { anagrafica, currentLayoutType } = useSelector( (state) => state.anagrafica );
  const hdcBanks  = useSelector((state) => state.hdcConsun.hdcBanks);

  const currenInteractionRef = useRef();
  currenInteractionRef.current = currentInteraction;

  const dispatch = useDispatch();

  const { data: notClient = {},  } = getNotClientDataByInteraction(anagrafica)(currenInteractionRef.current);

  const hdcContainerLayout = getHdcLayoutByInteraction(anagrafica)(currentInteraction);

  const {
    hdcName,
    hdcSurname,
    hdcBankCode,
  } = notClient;

  useEffect(() => {
    if (formFields.getField("bankCodeHdcField") && (hdcBanks && hdcBanks.length==0)){
      callHDCBankService();
    }
    console.log("layoutType", hdcContainerLayout);
    let formFieldWithValue = [
      {
        field: "nameHdcField",
        value: hdcName,
      },
      {
        field: "cognomeHdcField",
        value: hdcSurname,
      },
      {
        field: "bankCodeHdcField",
        value: hdcBankCode,
      },
    ];
    for (let i = 0; i < formFieldWithValue.length; i++) {
      const { field, value } = formFieldWithValue[i];
      formFields.getField(field).theField.setValue(value);
    }
  }, [hdcContainerLayout]);

  const callHDCBankService = async () => {
    let request = {}
    await httpGetHDCBanks(request)
      .then((response) => {
        if(response)
          formFields.getField("bankCodeHdcField").theField.reloadOptions(response) ;
      })
      .catch((err) => {
        
      });
  };

  let nameHdcField = {
    uniqueID: "nameHdcField",
    value: hdcName ? hdcName : "",
    form: formFields,
    setValue: (value) => {
      const { currentValue = "" } = value;
      dispatch(
        setNotClientDataProperty({
          interactionId: currenInteractionRef.current,
          property: "hdcName",
          value: currentValue,
        })
      );
    },
  };


  let cognomeHdcField = {
    uniqueID: "cognomeHdcField",
    form: formFields,
    value: hdcSurname ? hdcSurname : "",
    setValue: (value) => {
      const { currentValue = "" } = value;
      dispatch(
        setNotClientDataProperty({
          interactionId: currenInteractionRef.current,
          property: "hdcSurname",
          value: currentValue,
        })
      );
    },
  };

  
  let bankCodeHdcField = {
    uniqueID: "bankCodeHdcField",
    multiSelect: false,
    label: "",
    placeHolder: "bank",
    readonly: false,
    visible: true,
    disabled: false,
    options: hdcBanks || [],
    searchEnabled: true,
    value: hdcBankCode ? hdcBankCode : {},
    setValue: (obj) => {
        const { currentValue = "" } = obj;
        dispatch(
          setNotClientDataProperty({
            interactionId: currenInteractionRef.current,
            property: "hdcBankCode",
            value: currentValue,
          })
        );
    },
    form: formFields,

  };

  return (
    <div
      className={`d-flex flex-column section-anagrafica anagrafica-${layoutType} mb-3`}
    >
    <div className={`d-flex flex-column anagrafica-${layoutType}-notclient-container`}
    >
      <div
        className={`d-flex flex-row flex-wrap anagrafica-${layoutType}-section-1`}
      >
        <AnagraficaLabelValue label="Cognome" required= {true} >
          <TextField configuration={cognomeHdcField} />
        </AnagraficaLabelValue>
        <AnagraficaLabelValue label="Nome" >
          <TextField configuration={nameHdcField} />
        </AnagraficaLabelValue>
        <AnagraficaLabelValue label="Codice Banca">
          <SelectField configuration={bankCodeHdcField} />
        </AnagraficaLabelValue>
      </div>
      </div>
    </div>
  );
};

export default HDCNonClienteComponent;
