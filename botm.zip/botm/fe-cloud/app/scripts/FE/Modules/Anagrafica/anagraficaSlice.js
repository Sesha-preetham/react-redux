import { createSlice } from "@reduxjs/toolkit";
import { privatoWidgetCode } from "../Widgets/internalWidgetsSlice";

let defaultNotClientData = {
  name: undefined,
  surname: undefined,
  dataNascita: undefined,
  luogoNascita: undefined,
  citta: undefined,
  cap: undefined,
  province: undefined,
  recapitoCell: undefined,
  recapitoFisso: undefined,
  recapitoMail: undefined,
  denominazione: undefined, // azienda
  insegna: undefined,
  partitaIva: undefined,
  rifPersona: undefined,
  aziendaCitta: undefined,
  aziendaCap: undefined,
  aziendaProvincia: undefined,
  aziendaRecapitoCell: undefined,
  aziendaRecapitoFisso: undefined,
  aziendaRecapitoMail: undefined,
  hdcName:undefined,
  hdcSurname:undefined,
  hdcBankCode:undefined,
};

let defaultAnagraficaObject = {
  currentTabKey: privatoWidgetCode,
  multipleClientModal: {
    data: [],
  },
  hdcContainerLayout:"preview",
  notClientData: {
    clientToggle: true,
    hdcClientToggle:true,
    defaultData:{
      name: undefined,
      surname: undefined,
      recapitoMail: undefined,
    },
    data: {
      name: undefined,
      surname: undefined,
      dataNascita: undefined,
      luogoNascita: undefined,
      citta: undefined,
      cap: undefined,
      province: undefined,
      recapitoCell: undefined,
      recapitoFisso: undefined,
      recapitoMail: undefined,
      denominazione: undefined, // azienda
      insegna: undefined,
      partitaIva: undefined,
      rifPersona: undefined,
      aziendaCitta: undefined,
      aziendaCap: undefined,
      aziendaProvincia: undefined,
      aziendaRecapitoCell: undefined,
      aziendaRecapitoFisso: undefined,
      aziendaRecapitoMail: undefined,
      hdcName:undefined,
      hdcSurname:undefined,
      hdcBankCode:undefined,
    },
  },
  abisearch: undefined,
  privatoData: {
    selectedIbCode: {},
    data: [],
  },
  aziendaData: {
    ecommerceData: {
      currentDataIndex: 0,
    },
    data: [],
    tmlData: [],
    posCommissioniData: [],
  },
  employeeData: {
    data: []
  },
  leasingDate:{
    data:{},
  },
  contiData: [],
  carteData: [],
  storicoCarteData: [],
  notification: {
    read: false,
    data: [],
    showPopover: false,
  },
};

let initialState = {
  currentLayoutType: "preview",
  anagrafica: {
    noInteraction: { ...defaultAnagraficaObject },
  },
};

const anagraficaSlice = createSlice({
  name: "anagrafica",
  initialState,
  reducers: {
    addInteractionToAnagrafica(state, action) {
      const { payload = {} } = action;
      const { id = "noInteraction" } = payload;
      if (!id) return;
      if (!state.anagrafica[id]) {
        state.anagrafica[id] = { ...defaultAnagraficaObject };
      }
    },
    removeInteractionFromAnagrafica(state, action) {
      const { payload = {} } = action;
      const { id = "noInteraction" } = payload;
      if (!id || id === "noInteraction") return;
      state.anagrafica = Object.entries(state.anagrafica).reduce(
        (acc, [key, value]) => {
          if (key != id) {
            acc[key] = value;
          }
          return acc;
        },
        {}
      );
    },
    clearAnagraficaData(state, action) {
      const { payload = {} } = action;
      const { interactionId = "noInteraction", currentTabKey } = payload;
      state.anagrafica[interactionId] = {
        ...defaultAnagraficaObject,
        currentTabKey: currentTabKey,
      };
    },
    clearAnagraficaPrivatoData(state, action) {
      const { payload = {} } = action;
      const { interactionId = "noInteraction" } = payload;
      if (!state.anagrafica[interactionId]) return;
      state.anagrafica[interactionId].privatoData = {
        ...defaultAnagraficaObject.privatoData,
      };
    },
    loadClientSearchAnagraficaData(state, action) {
      const { payload = {} } = action;
      const { interactionId = "noInteraction", clientSearchData = {} } =
        payload;
      if (!state.anagrafica[interactionId]) return;
      const {
        abisearch,
        privato = [],
        azienda = [],
        warningMessages = [],
        employee,
        leasingDetails={},
      } = clientSearchData || {};
      if (!state.anagrafica[interactionId]) return;
      state.anagrafica[interactionId].abisearch = abisearch;
      state.anagrafica[interactionId].privatoData.data =
        privato !== null ? [...privato] : [];
      state.anagrafica[interactionId].aziendaData.data =
        azienda !== null ? [...azienda] : [];
      state.anagrafica[interactionId].employeeData.data =
        employee != null ? [...employee] : [];
      state.anagrafica[interactionId].leasingDate.data =
      leasingDetails != null ? {...leasingDetails} : {};
      state.anagrafica[interactionId].notification.data =
        getNewNotificationData(
          state.anagrafica[interactionId].notification.data,
          warningMessages || []
        );
    },
    loadClientSearchPrivatoData(state, action) {
      const { payload = {} } = action;
      const { interactionId = "noInteraction", clientSearchData = {} } =
        payload;
      const { privato = [], azienda = [] } = clientSearchData;
      if (!state.anagrafica[interactionId]) return;
      state.anagrafica[interactionId].privatoData.data =
        privato !== null ? [...privato] : [];
    },
    loadContiData(state, action) {
      const { payload = {} } = action;
      const { interactionId = "noInteraction", conti = [] } = payload;
      if (!state.anagrafica[interactionId]) return;
      state.anagrafica[interactionId].contiData = [...conti];
    },
    loadCarteData(state, action) {
      const { payload = {} } = action;
      const { interactionId = "noInteraction", carte = [] } = payload;
      if (!state.anagrafica[interactionId]) return;
      state.anagrafica[interactionId].carteData = [...carte];
    },
    loadStoricoCarteData(state, action) {
      const { payload = {} } = action;
      const { interactionId = "noInteraction", carte = [] } = payload;
      if (!state.anagrafica[interactionId]) return;
      state.anagrafica[interactionId].storicoCarteData = [...carte];
    },
    setPrivatoSelectedIbCode(state, action) {
      const { payload = {} } = action;
      const { interactionId = "noInteraction", value = {} } = payload;
      if (!state.anagrafica[interactionId]) return;
      state.anagrafica[interactionId].privatoData.selectedIbCode = value;
    },
    setMultipleClientModalData(state, action) {
      const { payload = {} } = action;
      const { interactionId = "noInteraction", data = [] } = payload;
      if (!state.anagrafica[interactionId]) return;
      state.anagrafica[interactionId].multipleClientModal.data = data;
    },
    setHdcContainerLayoutType(state, action) {
      const { payload = {} } = action;
      const { interactionId = "noInteraction", layoutType = "preview" } = payload;
      if (!state.anagrafica[interactionId]) return;
      state.anagrafica[interactionId].hdcContainerLayout = layoutType;
    },
    setLeasingContainerLayoutType(state, action) {
      const { payload = {} } = action;
      const { interactionId = "noInteraction", layoutType = "preview" } = payload;
      if (!state.anagrafica[interactionId]) return;
      state.anagrafica[interactionId].hdcContainerLayout = layoutType;
    },
    setHDCNotClientToggle(state, action) {
      const { payload = {} } = action;
      const { interactionId = "noInteraction", value = false } = payload;
      if (!state.anagrafica[interactionId]) return;
      state.anagrafica[interactionId].notClientData.hdcClientToggle = value;
    },
    setNotClientToggle(state, action) {
      const { payload = {} } = action;
      const { interactionId = "noInteraction", value = false } = payload;
      if (!state.anagrafica[interactionId]) return;
      state.anagrafica[interactionId].notClientData.clientToggle = value;
    },
    setNotClientDataProperty(state, action) {
      const { payload = {} } = action;
      const { interactionId = "noInteraction", value, property } = payload;
      if (property !== undefined && state.anagrafica[interactionId])
        state.anagrafica[interactionId].notClientData.data[property] = value;
    },
    setNotClientDefaultDataPropertyMap(state, action){
      const { payload = {} } = action;
      const { interactionId = "noInteraction", setvalue } = payload;
      if (setvalue.length>0 && state.anagrafica[interactionId]){
        setvalue.map((item)=>{
          let { property , value } = item;
          state.anagrafica[interactionId].notClientData.defaultData[property] = value;
        })
      }
    },
    clearNotClientData(state, action) {
      const { payload = {} } = action;
      const { interactionId = "noInteraction" } = payload;
      if (!state.anagrafica[interactionId]) return;
      state.anagrafica[interactionId].notClientData.data = {
        ...defaultNotClientData, ...state.anagrafica[interactionId].notClientData.defaultData
      };
    },
    setCurrentLayoutType(state, action) {
      const { payload = {} } = action;
      const { interactionId = "noInteraction", layoutType = "preview" } =
        payload;
      state.currentLayoutType = layoutType;
      //state.anagrafica.currentLayoutType=layoutType;
    },
    setCurrentTabKey(state, action) {
      const { payload = {} } = action;
      const { interactionId = "noInteraction", key = privatoWidgetCode } =
        payload;
      if (!state.anagrafica[interactionId]) return;
      state.anagrafica[interactionId].currentTabKey = key;
    },
    pushNotification(state, action) {
      const { payload = {} } = action;
      const { interactionId = "noInteraction", notification = [] } = payload;
      if (!state.anagrafica[interactionId]) return;
      state.anagrafica[interactionId].notification.data =
        getNewNotificationData(
          state.anagrafica[interactionId].notification.data,
          notification || []
        );
    },
    clearNotification(state, action) {
      const { payload = {} } = action;
      const { interactionId = "noInteraction" } = payload;
      if (!state.anagrafica[interactionId]) return;
      state.anagrafica[interactionId].notification.data = [];
    },
    setNotificationRead(state, action) {
      const { payload = {} } = action;
      const { interactionId = "noInteraction", value = false } = payload;
      if (!state.anagrafica[interactionId]) return;
      state.anagrafica[interactionId].notification.read = value;
    },
    setNotificationPopover(state, action) {
      const { payload = {} } = action;
      const { interactionId = "noInteraction", value = false } = payload;
      if (!state.anagrafica[interactionId]) return;
      state.anagrafica[interactionId].notification.showPopover = value;
    },
    updateEcommerceDataByProperty(state, action) {
      const { payload = {} } = action;
      const { interactionId = "noInteraction", data = {} } = payload;
      const { property, value } = data;
      if (!property || value === undefined || !state.anagrafica[interactionId])
        return;
      state.anagrafica[interactionId].aziendaData.ecommerceData[property] =
        value;
    },
    loadTmlData(state, action) {
      const { payload = {} } = action;
      const { interactionId = "noInteraction", tmlData = [] } = payload;
      if (!state.anagrafica[interactionId]) return;
      state.anagrafica[interactionId].aziendaData.tmlData = [...tmlData];
    },
    loadPosCommissioniData(state, action) {
      const { payload = {} } = action;
      const { interactionId = "noInteraction", posCommissioniData = [] } =
        payload;
      if (!state.anagrafica[interactionId]) return;
      state.anagrafica[interactionId].aziendaData.posCommissioniData = [
        ...posCommissioniData,
      ];
    },
  },
});

const getNewNotificationData = (
  currentNotification = [],
  newNotification = []
) => {
  let newList = [...currentNotification];
  newNotification.forEach((el) => {
    if (
      newList.findIndex(
        (n) => n.message === el.message && n.title === el.title
      ) === -1
    ) {
      newList.push(el);
    }
  });
  return newList;
};

export const getAbiSearchByInteraction = (anagrafica) => {
  return (id = "noInteraction") => {
    if (anagrafica[id]) {
      return anagrafica[id].abisearch;
    }
    return undefined;
  };
};

export const getHdcLayoutByInteraction = (anagrafica) => {
  return (id = "noInteraction") => {
    if (anagrafica[id]) {
      return anagrafica[id].hdcContainerLayout;
    }
    return undefined;
  };
};

export const getPrivatoDataByInteraction = (anagrafica) => {
  return (id = "noInteraction") => {
    if (anagrafica[id]) {
      return { ...anagrafica[id].privatoData };
    }
    return {};
  };
};

export const getAnagraficaNotification = (anagrafica) => {
  return (id = "noInteraction") => {
    if (anagrafica[id]) {
      return { ...anagrafica[id].notification };
    }
    return {};
  };
};

export const getAziendaDataByInteraction = (anagrafica) => {
  return (id = "noInteraction") => {
    if (anagrafica[id]) {
      return { ...anagrafica[id].aziendaData };
    }
    return {};
  };
};

export const getContiDataByInteraction = (anagrafica) => {
  return (id = "noInteraction") => {
    if (anagrafica[id]) {
      return [...anagrafica[id].contiData];
    }
    return [];
  };
};

export const getCarteDataByInteraction = (anagrafica) => {
  return (id = "noInteraction") => {
    if (anagrafica[id]) {
      return [...anagrafica[id].carteData];
    }
    return [];
  };
};

export const getNotClientDataByInteraction = (anagrafica) => {
  return (id = "noInteraction") => {
    if (anagrafica[id]) {
      return { ...anagrafica[id].notClientData };
    }
    return {};
  };
};

export const getStoricoCarteDataByInteraction = (anagrafica) => {
  return (id = "noInteraction") => {
    if (anagrafica[id]) {
      return [...anagrafica[id].storicoCarteData];
    }
    return [];
  };
};

export const getCurrentLayoutTypeByInteraction = (anagrafica) => {
  return (id = "noInteraction") => {
    if (anagrafica[id]) {
      //return anagrafica[id].currentLayoutType;
      return anagrafica.currentLayoutType;
    }
    return "preview";
  };
};

export const getCurrentTabKeyByInteraction = (anagrafica) => {
  return (id = "noInteraction") => {
    console.log("getCurrentTabKeyByInteraction", id);
    if (anagrafica[id]) {
      return anagrafica[id].currentTabKey;
    }
    return privatoWidgetCode;
  };
};

export const getEmployeeDataByInteraction = (anagrafica) => {
  return (id = "noInteraction") => {
    if(anagrafica[id]) {
      return { ...anagrafica[id].employeeData };
    }
    return {};
  }
}

export const getLeasingByInteraction = (anagrafica) => {
  return (id = "noInteraction") => {
    if(anagrafica[id]) {
      return { ...anagrafica[id].leasingDate };
    }
    return {};
  }
}

export const {
  addInteractionToAnagrafica,
  removeInteractionFromAnagrafica,
  clearAnagraficaData,
  clearAnagraficaPrivatoData,
  loadClientSearchAnagraficaData,
  loadClientSearchPrivatoData,
  loadContiData,
  loadCarteData,
  loadStoricoCarteData,
  setPrivatoSelectedIbCode,
  setMultipleClientModalData,
  setHdcContainerLayoutType,
  setLeasingContainerLayoutType,
  setHDCNotClientToggle,
  setNotClientToggle,
  setNotClientDataProperty,
  setNotClientDefaultDataPropertyMap,
  clearNotClientData,
  setCurrentLayoutType,
  setCurrentTabKey,
  pushNotification,
  clearNotification,
  setNotificationRead,
  setNotificationPopover,
  updateEcommerceDataByProperty,
  loadTmlData,
  loadPosCommissioniData,
} = anagraficaSlice.actions;

export default anagraficaSlice.reducer;
