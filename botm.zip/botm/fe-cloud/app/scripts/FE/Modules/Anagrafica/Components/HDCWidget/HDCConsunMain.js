import React, { useEffect, useState, useRef } from "react";
import { toast } from "react-toastify";
import { useDispatch, useSelector } from "react-redux";
import FormFieldHandler from "../../../../CommonComponents/Forms/FormFieldHandler";
import SelectField from "../../../../CommonComponents/Forms/SelectField";
import TextField from "../../../../CommonComponents/Forms/TextField";

import { reduceToOptions,getBaseErrorMessage } from "../../../../Utils/CommonUtil";
import MySpinner from "../../../../CommonComponents/Spinner/MySpinner";
import { getInteractionDetails } from "../../../../Modules/Interaction/interactionSlice";
import {
  httpPostQueueAnomaliaService,
  httpPostCategorizationListService,
  httpSendHDCConsunService,
  httpHDCTraceService,
} from "./HDCService";
import { hdcWidgetAlertId } from "../../../../CommonComponents/AlertToast/AlertIdConstants";
import AlertToast from "../../../../CommonComponents/AlertToast/AlertToast";
import {
  hdcConsunWidgetSpinnerId,
  toggleSpinnerById,
} from "../../../../CommonComponents/Spinner/spinnerSlice";
import {
  getHdcConsunDataById,
  setAnomaliaRPListSelectData,
  setInserisciDatiButtonsDisable,
  setTelDisturboButtonsDisable,
  setNoteTextData,

  updateTire1SelectData,
  updateTire2SelectData,
  updateTire3SelectData,
  updateTire4SelectData,
  updateTire5SelectData,
  updateHdcConsuntivaDone,
} from "./HDCConsunSlice";
import {
  getNotClientDataByInteraction,
  setNotClientDataProperty,
  getHdcLayoutByInteraction,
} from "../../../Anagrafica/anagraficaSlice";

const HDCConsunMain = (props) => {

  let layoutType = props;

  const [formFields] = useState(new FormFieldHandler(true));

  const { currentInteraction = "noInteraction", interactions = [],} = useSelector((state) => state.interaction);
  const interactionId = useRef();
  interactionId.current = currentInteraction;

  const anomaliaRPListResp = useSelector((state) => state.hdcConsun.anomaliaRPListResp);
  const categorizationListResp  = useSelector((state) => state.hdcConsun.categorizationListResp);
  const categorizationListRespRef = useRef();
  categorizationListRespRef.current = categorizationListResp;

  const {hdcConsunObj={}} = useSelector((state) => state.hdcConsun);

  const { 
  selectedAnomaliaRPList = {},  
  selectedTire1Value={},
  selectedTire2Value={},
  selectedTire3Value={},
  selectedTire4Value={},
  selectedTire5Value={},
  noteText="",
  TelDisturboBtnDisable= false,
  InserisciDatiBtnDisable = true,
  intrDisconnectDisable   = false,
  hdcConsuntivaDone = false,
   } = getHdcConsunDataById(hdcConsunObj)( interactionId.current );

  const { queueName = undefined, intxId } = getInteractionDetails(interactions)(interactionId.current);

  const { anagrafica, currentLayoutType } = useSelector( (state) => state.anagrafica );
  const { data: notClient = {}, hdcClientToggle } = getNotClientDataByInteraction(anagrafica)(interactionId.current);
  const {
    hdcName,
    hdcSurname,
    hdcBankCode,
  } = notClient;

  const dispatch = useDispatch();

  useEffect(() => {
    loadFieldValues();
  }, [layoutType, interactionId.current])

  useEffect(() => {
    onMount()
  }, [])

  const onMount = async() =>{
    let request  = {queueName : queueName}
    dispatch(toggleSpinnerById(hdcConsunWidgetSpinnerId));
    if(categorizationListResp && categorizationListResp.length==0)  
    {
      await httpPostCategorizationListService(request).then((response) => {
        setTireReloadOptions(response)
      })
    }
    if (anomaliaRPListResp && anomaliaRPListResp.length==0){
      await httpPostQueueAnomaliaService(request).then((response) => {
        formFields.getField("TipoNoteSelect").theField.reloadOptions(response);
      });
    }

    if (categorizationListResp && categorizationListResp.length!=0)
      setTireReloadOptions(categorizationListResp);
    if (anomaliaRPListResp && anomaliaRPListResp.length!=0)
      formFields.getField("TipoNoteSelect").theField.reloadOptions(reduceToOptions(anomaliaRPListResp)("id", "value")); 

    dispatch(toggleSpinnerById(hdcConsunWidgetSpinnerId));
  }


  const setTireReloadOptions = (list) =>{
    let copyResp = list;
    let arr = []
    let listVal = []
    copyResp.map((value)=>{
      const {categorizationTier1} = value;
      arr.push(categorizationTier1)
    })
    arr = new Set(arr);
    arr.forEach((element)=>{
      listVal.push({id:element,value:element})
    })
    console.log(listVal)
    formFields.getField("Tire1FilterField").theField.reloadOptions(reduceToOptions(listVal)("id", "value"));
  }


  const generalSetReloadOptionTires = (tire, step)=>{
    let copyResp = categorizationListRespRef.current;
    let arr = []
    let listVal = []
    let {label : tire1DataVal }= formFields.getField("Tire1FilterField").theField.getValue();
    let {label : tire2DataVal }= formFields.getField("Tire2FilterField").theField.getValue();
    let {label : tire3DataVal }= formFields.getField("Tire3FilterField").theField.getValue();
    
    copyResp.map((value)=>{
      const {categorizationTier1,categorizationTier2, categorizationTier3, categorizationTier4, categorizationTier5} = value;
      if(step == "1"){
      if(categorizationTier1 == tire && categorizationTier2 )
        arr.push(categorizationTier2)
      }
      else if(step == "2"){
        if(categorizationTier1 == tire1DataVal && categorizationTier2 == tire && categorizationTier3)
          arr.push(categorizationTier3)
        }
      else if(step == "3"){
        if(categorizationTier1 == tire1DataVal && categorizationTier2 == tire2DataVal && categorizationTier3 == tire && categorizationTier4)
          arr.push(categorizationTier4)
        }
      else if(step == "4"){
        if(categorizationTier1 == tire1DataVal && categorizationTier2 == tire2DataVal && categorizationTier3 == tire3DataVal && categorizationTier4 == tire && categorizationTier5 )
          arr.push(categorizationTier5)
        }
    })
    console.log(arr)
    arr = new Set(arr);
    arr.forEach((element)=>{
      listVal.push({id:element,value:element})
    })
    console.log(listVal)
    if(listVal.length!=0)
    dispatch(
      setInserisciDatiButtonsDisable({id: interactionId.current, inserisciDatiBtn: true})
    )
    else
    dispatch(
      setInserisciDatiButtonsDisable({id: interactionId.current, inserisciDatiBtn: false})
    )

    if(step == "1")
    formFields.getField("Tire2FilterField").theField.reloadOptions(reduceToOptions(listVal)("id", "value"));
    else if(step == "2")
    formFields.getField("Tire3FilterField").theField.reloadOptions(reduceToOptions(listVal)("id", "value"));
    else if(step == "3")
    formFields.getField("Tire4FilterField").theField.reloadOptions(reduceToOptions(listVal)("id", "value"));
    else if(step == "4")
    formFields.getField("Tire5FilterField").theField.reloadOptions(reduceToOptions(listVal)("id", "value"));
  }

  const loadFieldValues = () =>{
    const { 
      selectedAnomaliaRPList = {},  
      selectedTire1Value={},
      selectedTire2Value={},
      selectedTire3Value={},
      selectedTire4Value={},
      selectedTire5Value={},
      noteText="" } = getHdcConsunDataById(hdcConsunObj)( interactionId.current );

      formFields.getField("Tire1FilterField").theField.setValue((selectedTire1Value && Object.keys(selectedTire1Value).length>0) ? selectedTire1Value : {})
      formFields.getField("Tire2FilterField").theField.setValue((selectedTire2Value && Object.keys(selectedTire2Value).length>0) ? selectedTire2Value : {})
      formFields.getField("Tire3FilterField").theField.setValue((selectedTire3Value && Object.keys(selectedTire3Value).length>0) ? selectedTire3Value : {})
      formFields.getField("Tire4FilterField").theField.setValue((selectedTire4Value && Object.keys(selectedTire4Value).length>0) ? selectedTire4Value : {})
      formFields.getField("Tire5FilterField").theField.setValue((selectedTire5Value && Object.keys(selectedTire5Value).length>0) ? selectedTire5Value : {})
      formFields.getField("TipoNoteSelect").theField.setValue((selectedAnomaliaRPList && Object.keys(selectedAnomaliaRPList).length>0) ? selectedAnomaliaRPList : {})
      formFields.getField("noteTextField").theField.setValue(noteText ? noteText : "")
  }

  const resetAllValues = () =>{
      formFields.getField("Tire1FilterField").theField.setValue({});
      formFields.getField("Tire2FilterField").theField.setValue({});
      formFields.getField("Tire3FilterField").theField.setValue({});
      formFields.getField("Tire4FilterField").theField.setValue({});
      formFields.getField("Tire5FilterField").theField.setValue({});
      formFields.getField("TipoNoteSelect").theField.setValue({});
      formFields.getField("noteTextField").theField.setValue("");

      dispatch(updateTire1SelectData({id:interactionId.current, updateTire1Data:null}));
      dispatch(updateTire2SelectData({id:interactionId.current, updateTire2Data:null}));
      dispatch(updateTire3SelectData({id:interactionId.current, updateTire3Data:null}));
      dispatch(updateTire4SelectData({id:interactionId.current, updateTire4Data:null}));
      dispatch(updateTire5SelectData({id:interactionId.current, updateTire5Data:null}));

      dispatch(setTelDisturboButtonsDisable({id: interactionId.current, telDisturboBtn: true}))
      dispatch(setInserisciDatiButtonsDisable({id: interactionId.current, inserisciDatiBtn: true}))
  }

  let Tire1FilterField = {
    uniqueID: "Tire1FilterField",
    multiSelect: false,
    label: "",
    placeHolder: "Tier1",
    readonly: false,
    visible: true,
    disabled: false,
    value : selectedTire1Value ? selectedTire1Value : {},
    options: [],
    searchEnabled: true,
    setValue: (obj) => {
      let {value} = obj.currentValue
      if(value){
        formFields.getField("Tire2FilterField").theField.setValue({})
        formFields.getField("Tire3FilterField").theField.setValue({})
        formFields.getField("Tire4FilterField").theField.setValue({})
        formFields.getField("Tire5FilterField").theField.setValue({})
       dispatch(updateTire1SelectData({id:interactionId.current, updateTire1Data:obj.currentValue}))
       dispatch(updateTire2SelectData({id:interactionId.current, updateTire2Data:null}))
       dispatch(updateTire3SelectData({id:interactionId.current, updateTire3Data:null}))
       dispatch(updateTire4SelectData({id:interactionId.current, updateTire4Data:null}))
       dispatch(updateTire5SelectData({id:interactionId.current, updateTire5Data:null}))
       generalSetReloadOptionTires(value,"1");
      }
    },
    form: formFields,
    validation: {
      externalCheck: (value) => {
        if (value && !Array.isArray(value)) {
          return true;
        }
        return false;
      },
    },
    feedback: {
      enable: true,
      component: () => <>* Obbligatorio</>,
    },
  };

  let Tire2FilterField = {
    uniqueID: "Tire2FilterField",
    multiSelect: false,
    label: "",
    placeHolder: "Tier2",
    readonly: false,
    visible: true,
    value : selectedTire2Value ? selectedTire2Value : {},
    disabled: false,
    options: [],
    searchEnabled: true,
    setValue: (obj) => {
      let {value} = obj.currentValue
      if(value){
        formFields.getField("Tire3FilterField").theField.setValue({})
        formFields.getField("Tire4FilterField").theField.setValue({})
        formFields.getField("Tire5FilterField").theField.setValue({})
       dispatch(updateTire2SelectData({id:interactionId.current, updateTire2Data:obj.currentValue}))
       dispatch(updateTire3SelectData({id:interactionId.current, updateTire3Data:null}))
       dispatch(updateTire4SelectData({id:interactionId.current, updateTire4Data:null}))
       dispatch(updateTire5SelectData({id:interactionId.current, updateTire5Data:null}))
       generalSetReloadOptionTires(value,"2");
      }
    },
    form: formFields,
    validation: {
      externalCheck: (value) => {
        if (value && !Array.isArray(value)) {
          return true;
        }
        return false;
      },
    },
    feedback: {
      enable: true,
      component: () => <>* Obbligatorio</>,
    },
  };

  let Tire3FilterField = {
    uniqueID: "Tire3FilterField",
    multiSelect: false,
    label: "",
    placeHolder: "Tier3",
    readonly: false,
    visible: true,
    value : selectedTire3Value ? selectedTire3Value : {},
    disabled: false,
    options: [],
    searchEnabled: true,
    setValue: (obj) => {
      let {value} = obj.currentValue
      if(value){
        formFields.getField("Tire4FilterField").theField.setValue({})
        formFields.getField("Tire5FilterField").theField.setValue({})
       dispatch(updateTire3SelectData({id:interactionId.current, updateTire3Data:obj.currentValue}))
       dispatch(updateTire4SelectData({id:interactionId.current, updateTire4Data:null}))
       dispatch(updateTire5SelectData({id:interactionId.current, updateTire5Data:null}))
       generalSetReloadOptionTires(value,"3");
      }
    },
    form: formFields,
    validation: {
      externalCheck: (value) => {
        if (value && !Array.isArray(value)) {
          return true;
        }
        return false;
      },
    },
    feedback: {
      enable: true,
      component: () => <>* Obbligatorio</>,
    },
  };

  let Tire4FilterField = {
    uniqueID: "Tire4FilterField",
    multiSelect: false,
    label: "",
    placeHolder: "Tier4",
    readonly: false,
    visible: true,
    value : selectedTire4Value ? selectedTire4Value : {},
    disabled: false,
    options: [],
    searchEnabled: true,
    setValue: (obj) => {
      let {value} = obj.currentValue
      if(value){
        formFields.getField("Tire5FilterField").theField.setValue({})
       dispatch(updateTire4SelectData({id:interactionId.current, updateTire4Data:obj.currentValue}))
       dispatch(updateTire5SelectData({id:interactionId.current, updateTire5Data:null}))
       generalSetReloadOptionTires(value,"4");
      }
    },
    form: formFields,
    validation: {
      externalCheck: (value) => {
        if (value && !Array.isArray(value)) {
          return true;
        }
        return false;
      },
    },
    feedback: {
      enable: true,
      component: () => <>* Obbligatorio</>,
    },
  };

  let Tire5FilterField = {
    uniqueID: "Tire5FilterField",
    multiSelect: false,
    label: "",
    placeHolder: " Tier5 ",
    readonly: false,
    visible: true,
    value : selectedTire5Value ? selectedTire5Value : {},
    disabled: false,
    options: [],
    searchEnabled: true,
    setValue: (obj) => {
      let {value} = obj.currentValue
      if(value){
       dispatch(updateTire5SelectData({id:interactionId.current, updateTire5Data:obj.currentValue}))
       generalSetReloadOptionTires(value,"5");
      }
    },
    form: formFields,
    validation: {
      externalCheck: (value) => {
        if (value && !Array.isArray(value)) {
          return true;
        }
        return false;
      },
    },
    feedback: {
      enable: true,
      component: () => <>* Obbligatorio</>,
    },
  };

  let TipoNoteSelect = {
    uniqueID: "TipoNoteSelect",
    multiSelect: false,
    label: "",
    placeHolder: "Tipo Note Select",
    readonly: false,
    visible: true,
    disabled: false,
    options: [],
    value: selectedAnomaliaRPList ? selectedAnomaliaRPList : {},
    searchEnabled: true,
    setValue: (obj) => {
      let val = obj.currentValue
      if(val)
      dispatch(
        setAnomaliaRPListSelectData({id: interactionId.current , selectAnomaliaRPListData : val})
      )
    },
    form: formFields,
    validation: {
      externalCheck: (value) => {
        if (value && !Array.isArray(value)) {
          return true;
        }
        return false;
      },
    },
    feedback: {
      enable: true,
      component: () => <>* Obbligatorio</>,
    },
  };


  let noteTextField = {
    uniqueID: "noteTextField",
    placeHolder: "Inserisci nota",
    readonly: false,
    visible: true,
    value: noteText? noteText : "",
    validation: {
      mandatory: false,
      type: "Alphanumeric",
    },    
    setValue: (value) => {
        const { currentValue = "" } = value;
        if(currentValue.length>0)
        dispatch(
          setNoteTextData({id: interactionId.current , noteTextData : currentValue})
        )
      },
    form: formFields,
  };

  const handleOnClickTelDisturboButton = async() =>{
    if(!hdcClientToggle && hdcSurname=="" ){
      toast.warn("Cognome sono obbligatori!", {
        containerId: hdcWidgetAlertId,
      });
    }
    else{
    let noteVal = formFields.getField("noteTextField").theField.getValue();

    let abicode, bankCode;
    if (hdcBankCode && typeof(hdcBankCode)!="undefined" && Object.keys(hdcBankCode).length != 0) {
      let { rlData = {} } = hdcBankCode;
      if (rlData && typeof(rlData)!="undefined" && Object.keys(rlData).length != 0) {
        let { abicode = "", bankCode = "" } = rlData;
        abicode = abicode;
        bankCode = bankCode;
      }
    }

    let request={
      intxId :intxId,
      tipoAnomalia :  null ,  
      categorizationTier1  :  "TEL DISTURBO",
      categorizationTier2  :  "CONS DISTURBO",
      categorizationTier3  :  null,
      categorizationTier4  :  null,
      categorizationTier5  :  null,
      note   :  noteVal || "",
      notCliente: hdcClientToggle ? false : true,
    }

    let traceRequest = hdcClientToggle
      ? {
          intxId: intxId,
          categorizationTier1: "TEL DISTURBO",
        }
      : {
          intxId: intxId,
          categorizationTier1: "TEL DISTURBO",
          notClient: {
            name: hdcName || "",
            surname: hdcSurname || "",
            codiceBanca: bankCode || "",
            abiCode: abicode || "",
          },
        };
    dispatch(toggleSpinnerById(hdcConsunWidgetSpinnerId));
    await httpSendHDCConsunService(request).then((response) => {
      let {status=""} = response;
      if(status=="OK"){
        dispatch(updateHdcConsuntivaDone({id: interactionId.current , isConsuntivaDone : true}))
        hdcTraceCall(traceRequest);
      }
    }).catch((err) => {
      toast.error(getBaseErrorMessage("Error",err), { containerId: hdcWidgetAlertId });
    });
    dispatch(toggleSpinnerById(hdcConsunWidgetSpinnerId));
  }
  }

  const handleOnClickInserisciDatiButton = async() =>{
    if(!hdcClientToggle && hdcSurname=="" ){
      toast.warn("Cognome sono obbligatori!", {
        containerId: hdcWidgetAlertId,
      });
    }
    else{
    let {label : tire1DataVal }= formFields.getField("Tire1FilterField").theField.getValue();
    let {label : tire2DataVal }= formFields.getField("Tire2FilterField").theField.getValue();
    let {label : tire3DataVal }= formFields.getField("Tire3FilterField").theField.getValue();
    let {label : tire4DataVal }= formFields.getField("Tire4FilterField").theField.getValue();
    let {label : tire5DataVal }= formFields.getField("Tire5FilterField").theField.getValue();
    let {label : TipoNoteSelectVal }= formFields.getField("TipoNoteSelect").theField.getValue();
    let noteVal = formFields.getField("noteTextField").theField.getValue();
    
    let request={
      intxId :intxId,
      tipoAnomalia : TipoNoteSelectVal || "" ,  
      categorizationTier1  :  tire1DataVal || "",
      categorizationTier2  :  tire2DataVal || "",
      categorizationTier3  :  tire3DataVal || "",
      categorizationTier4  :  tire4DataVal || "",
      categorizationTier5  :  tire5DataVal || "",
      note   :  noteVal || "",
      notCliente: hdcClientToggle ? false : true,
     }

     let abicode, bankCode;
     if (hdcBankCode && typeof(hdcBankCode)!="undefined" && Object.keys(hdcBankCode).length != 0) {
       let { rlData = {} } = hdcBankCode;
       if (rlData && typeof(rlData)!="undefined" && Object.keys(rlData).length != 0) {
         let { abicode = "", bankCode = "" } = rlData;
         abicode = abicode;
         bankCode = bankCode;
       }
     }

     let traceRequest = hdcClientToggle
       ? {
           intxId: intxId,
           categorizationTier1: tire1DataVal || "",
           note: noteVal || "",
         }
       : {
           intxId: intxId,
           categorizationTier1: tire1DataVal || "",
           note: noteVal || "",
           notClient: {
             name : hdcName || "",
             surname : hdcSurname || "",
             codiceBanca : bankCode || "",
             abiCode : abicode || "",
           },
         };

     dispatch(toggleSpinnerById(hdcConsunWidgetSpinnerId));
     await httpSendHDCConsunService(request).then((response) => {
      let {status=""} = response;
      if(status=="OK"){
        hdcTraceCall(traceRequest)
      }
     }).catch((err) => {
      toast.error(getBaseErrorMessage("Error",err), { containerId: hdcWidgetAlertId });
    });
     dispatch(toggleSpinnerById(hdcConsunWidgetSpinnerId));
    }
  }

  const hdcTraceCall = async(traceRequest)=>{
    await httpHDCTraceService(traceRequest, {interactionId: interactionId.current,}).then((response) => {
      const { status = "" } = response;
      if(status=="OK"){
        dispatch(updateHdcConsuntivaDone({id: interactionId.current , isConsuntivaDone : true}))
        resetAllValues()
      }
    }).catch((err) => {
      toast.error(getBaseErrorMessage("Error",err), { containerId: hdcWidgetAlertId });
    });
  }


  return (
    <div className="d-flex flex-column">
    <MySpinner uniqueID={hdcConsunWidgetSpinnerId}  type="global"/>
    <AlertToast
      configuration={{
        unqiueID: hdcWidgetAlertId,
        className: "inline-toast-container",
        transition: "flip",
      }}
    />
      <>
          <div className="d-flex flex-column h-100">
              
            <div className="d-flex flex-row mb-3">
              <div className="d-flex flex-column w-50">
                <div className="small-content-label-class">Tier1</div>
                <div className="flex-fill w-75">
                  <SelectField configuration={Tire1FilterField} />
                </div>
              </div>

              <div className="d-flex flex-column w-50">
                <div className="small-content-label-class">
                Tier2
                </div>
                <div className="flex-fill w-75">
                  <SelectField configuration={Tire2FilterField} />
                </div>
              </div>
            </div>

            <div className="d-flex flex-row mb-3">
              <div className="d-flex flex-column w-50">
                <div className="small-content-label-class">
                  Tier3
                </div>
                <div className="flex-fill w-75">
                  <SelectField configuration={Tire3FilterField} />
                </div>
              </div>

              <div className="d-flex flex-column w-50">
                <div className="small-content-label-class">
                  Tier4
                </div>
                <div className="flex-fill w-75 ">
                  <SelectField configuration={Tire4FilterField} />
                </div>
              </div>
            </div>

            <div className="d-flex flex-row mb-3">
              <div className="d-flex flex-column w-50">
                <div className="small-content-label-class">
                  Tier5
                </div>
                <div className="flex-fill  w-75">
                  <SelectField configuration={Tire5FilterField} />
                </div>
              </div>

              <div className="d-flex flex-column w-50">
                <div className="small-content-label-class">
                Tipo Anomalia / Dettaglio Note
                </div>
                <div className="flex-fill  w-75">
                  <SelectField configuration={TipoNoteSelect} />
                </div>
              </div>
            </div>

              <div className="d-flex flex-column ">
                <div className="small-content-label-class">Note</div>
                <div className="flex-fill ">
                  <TextField configuration={noteTextField} />
                </div>
              </div>

            <div className="d-flex justify-content-center flex-row ">

            <div className="w-50 pr-2">
                <button
                  type="button"
                  className={`btn Rectangle-Button-White w-100`}
                  disabled={(TelDisturboBtnDisable == false 
                              && intrDisconnectDisable == true
                              && hdcConsuntivaDone == false ) ? false : true}
                  onClick={handleOnClickTelDisturboButton}
                >
                  Tel Disturbo
                </button>
              </div>

              <div className="w-50 pr-2">
                <button
                  type="button"
                  className={`btn Rectangle-Button-Blue w-100`}
                  disabled={(InserisciDatiBtnDisable == false
                           && intrDisconnectDisable == true 
                           && hdcConsuntivaDone == false ) ? false : true 
                            }
                  onClick={handleOnClickInserisciDatiButton}
                >
                  Inserisci Dati
                </button>
              </div>
            </div>
          </div>
     
        </>
      </div>
   
  );
};

export default HDCConsunMain;
