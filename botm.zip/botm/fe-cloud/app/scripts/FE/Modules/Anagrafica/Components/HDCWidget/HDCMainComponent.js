import React from "react";
import { useSelector } from "react-redux";
import AnagraficaLabelValue from "../Common/AnagraficaLabelValue";
import { getEmployeeDataByInteraction } from "../../../Anagrafica/anagraficaSlice";

const HDCMainComponent = (props) => {
  const { layoutType = "preview" } =   props;

  const { currentInteraction = "noInteraction" } = useSelector(
    (state) => state.interaction
  );
  const { anagrafica } = useSelector((state) => state.anagrafica);

  const { data: employeeArray = [] } = getEmployeeDataByInteraction(anagrafica)(currentInteraction); 

  const employee = employeeArray.length > 0 ? employeeArray[0] : {};

  const {
    name,
    surname,
    codicePrincipale,
    codiceBanca,
    codiceFilale,
    descrFilale,
    cdr,
    gbsCode,
  } = employee;

  return (
    <>
    <div className={`d-flex flex-column section-anagrafica anagrafica-${layoutType} mb-3`}>
      <div
        className={`d-flex flex-row flex-wrap anagrafica-${layoutType}-section-1`}
      >
        <AnagraficaLabelValue label="Nome">
          <span>{name || ""}</span>
        </AnagraficaLabelValue>
        <AnagraficaLabelValue label="Cognome">
          <span>{surname || ""}</span>
        </AnagraficaLabelValue>
        <AnagraficaLabelValue label="Codice Principale">
          <span>{codicePrincipale || ""}</span>
        </AnagraficaLabelValue>
        <AnagraficaLabelValue label="Codice Banca">
          <span>{codiceBanca || ""}</span>
        </AnagraficaLabelValue>
        <AnagraficaLabelValue label="Codice Filiale">
          <span>{codiceFilale || ""}</span>
        </AnagraficaLabelValue>
        <AnagraficaLabelValue label="Descr Filiale">
          <span>{descrFilale || ""}</span>
        </AnagraficaLabelValue>
        <AnagraficaLabelValue label="CDR">
          <span>{cdr || ""}</span>
        </AnagraficaLabelValue>
        <AnagraficaLabelValue label="GBS Code">
          <span>{gbsCode || ""}</span>
        </AnagraficaLabelValue>
        </div>
    </div>
    </>
  );
};

export default HDCMainComponent;
