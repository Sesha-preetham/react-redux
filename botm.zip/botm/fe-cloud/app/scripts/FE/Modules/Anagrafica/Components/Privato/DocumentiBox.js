import React from "react";
import { useSelector } from "react-redux";
import SimpleTable from "../../../../CommonComponents/SimpleTable/SimpleTable";
import { getPrivatoDataByInteraction } from "../../anagraficaSlice";

const DocumentiBox = (props) => {
  const { layoutType = "preview" } = props;

  const { currentInteraction = "noInteraction" } = useSelector(
    (state) => state.interaction
  );

  const { anagrafica } = useSelector((state) => state.anagrafica);
  const { data: [{ documenti = [] } = {}] = [] } = getPrivatoDataByInteraction(
    anagrafica
  )(currentInteraction);

  /*
        {
            "tipo": "Carta d'identita",
            "numero": "1023780",
            "emessoA": null,
            "emessoIl": "09/06/2014",
            "emessoDa": "COMUNE",
            "dataScadenza": "11/02/2025"
        }

    */

  let documentiTableConfiguration = {
    uniqueID: "simpleTableConfiguration",
    metaData: [
      {
        Header: "Tipo",
        accessor: "tipo",
      },
      {
        Header: "Numero",
        accessor: "numero",
      },
      {
        Header: "Emesso A",
        accessor: "emessoA",
      },
      {
        Header: "Emesso Il",
        accessor: "emessoIl",
      },
      {
        Header: "Emesso Da",
        accessor: "emessoDa",
      },
      {
        Header: "Data Scadenza",
        accessor: "dataScadenza",
      },
    ],
    data: documenti,
  };

  return (
    <div
      className={`d-flex flex-row flex-wrap anagrafica-${layoutType}-section-1 m-2 overflow-auto`}
    >
      <SimpleTable configuration={documentiTableConfiguration} />
    </div>
  );
};

export default DocumentiBox;
