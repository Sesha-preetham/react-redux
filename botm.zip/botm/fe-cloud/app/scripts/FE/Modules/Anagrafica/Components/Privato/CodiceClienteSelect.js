import React from "react";
import SelectField from "../../../../CommonComponents/Forms/SelectField";


const CodiceClienteSelect = (props) => {

    const statusColorMap = {
      Attivo: "#00cb4d",
      Bloccato: "#f2662b",
      Sospeso: "#fbad02"
    }

    const customStyles = {
        control: (provided, state) => {
            return {
              ...provided,
              minHeight: "20px",
              borderRadius: "4px",
              border: state.isFocused ? "solid 1.5px #0033cc" : "solid 1.5px #b4bcc1",
              backgroundColor: "#ffffff",
              boxShadow: "transparent",
              ":hover": {
                border: state.isFocused ? "solid 1.5px #0033cc" : "solid 1.5px #b4bcc1",
                boxShadow: "transparent",
              },
            };
          },
          indicatorSeparator: (provided, state) => {
            return {
              ...provided,
              backgroundColor: state.isFocused ? "#0033cc" : "#b4bcc1",
            };
          },
          placeholder: (provided, state) => {
            return {
              ...provided,
              color: "#0033cc",
              fontSize: "14px",
              fontFamily: "Lato-Regular",
              letterSpacing: "normal",
            };
          },
          singleValue: (provided, state) => {
            return {
              ...provided,
              color: (state && state.data && state.data.rlData && state.data.rlData.status && statusColorMap[state.data.rlData.status])?statusColorMap[state.data.rlData.status]:"#0033cc",
              fontSize: "14px",
              fontFamily: "Lato-Regular",
              letterSpacing: "normal",
            };
          },
          multiValue: (provided, state) => {
            return {
              ...provided,
              borderRadius: "16px",
              backgroundColor: "#f2f5fc",
            };
          },
          multiValueLabel: (provided, state) => {
            return {
              ...provided,
              color: "#1b1b1b",
              fontSize: "14px",
              fontFamily: "Lato-Regular",
              letterSpacing: "normal",
            };
          },
          multiValueRemove: (provided, state) => {
            return {
              ...provided,
              color: "#b4bcc1",
              ":hover": {
                color: "#4d606f",
                backgroundColor: "transparent",
              },
            };
          },
          dropdownIndicator: (provided, state) => {
            return {
              ...provided,
              padding: "0px",
              color: state.isFocused ? "#0033cc" : "#b4bcc1",
              ":hover": {
                color: state.isFocused ? "#00269a" : "#1b1b1b",
              },
            };
          },
          option: (provided, state) => {
            return {
              ...provided,
              borderRadius: "4px",
              backgroundColor: state.isSelected ? "#d9e1f8" : "#ffffff",
              color: "#1b1b1b",
              fontSize: "12px",
              fontFamily: "Lato-Regular",
              letterSpacing: "normal",
              ":hover": {
                backgroundColor: state.isSelected ? "#d9e1f8" : "#f2f5fc",
                color: "#1b1b1b",
              },
            };
          }
    }

    return(
        <SelectField configuration={{
          ...props.configuration,
          customStyles
        }} />
    )
}

export default CodiceClienteSelect;