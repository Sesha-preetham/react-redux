import React, { useEffect, useRef } from "react";
import { useDispatch, useSelector } from "react-redux";
import FormFieldHandler from "../../../../../CommonComponents/Forms/FormFieldHandler";
import TextField from "../../../../../CommonComponents/Forms/TextField";
import {
  getNotClientDataByInteraction,
  setNotClientDataProperty,
} from "../../../anagraficaSlice";
import AnagraficaLabelValue from "../../Common/AnagraficaLabelValue";
import AziendaButton from "../AziendaButton";

const AziendaNotClientContainer = ({
  layoutType,
  formFields = new FormFieldHandler(true),
} = props) => {
  const { currentInteraction = "noInteraction" } = useSelector(
    (state) => state.interaction
  );

  const { anagrafica, currentLayoutType } = useSelector(
    (state) => state.anagrafica
  );

  const currenInteractionRef = useRef();
  currenInteractionRef.current = currentInteraction;

  const dispatch = useDispatch();

  const { data: notClient = {} } = getNotClientDataByInteraction(anagrafica)(
    currentInteraction
  );

  /*
            denominazione: undefined, // azienda
            insegna: undefined,
            partitaIva: undefined,
            rifPersona: undefined
            aziendaCitta: undefined,
            aziendaCap: undefined,
            aziendaProvincia: undefined,
            aziendaRecapitoCell: undefined,
            aziendaRecapitoMail: undefined
    */
  const {
    denominazione,
    insegna,
    rifPersona,
    partitaIva,
    aziendaCitta,
    aziendaCap,
    aziendaProvincia,
    aziendaRecapitoMail,
    aziendaRecapitoCell,
    aziendaRecapitoFisso,
  } = notClient;

  useEffect(() => {
    console.log("currentLayoutType", currentLayoutType);
    let formFieldWithValue = [
      {
        field: "denominazioneField",
        value: denominazione,
      },
      {
        field: "insegnaField",
        value: insegna,
      },
      {
        field: "rifPersonaField",
        value: rifPersona,
      },
      {
        field: "partitaIvaField",
        value: partitaIva,
      },
      {
        field: "aziendaCittaField",
        value: aziendaCitta,
      },
      {
        field: "aziendaCapField",
        value: aziendaCap,
      },
      {
        field: "aziendaProvinciaField",
        value: aziendaProvincia,
      },
      {
        field: "aziendaRecapitoCellField",
        value: aziendaRecapitoCell,
      },
      {
        field: "aziendaRecapitoFissoField",
        value: aziendaRecapitoFisso,
      },
      {
        field: "aziendaRecapitoMailField",
        value: aziendaRecapitoMail,
      },
    ];
    for (let i = 0; i < formFieldWithValue.length; i++) {
      const { field, value } = formFieldWithValue[i];
      formFields.getField(field).theField.setValue(value);
    }
  }, [currentLayoutType]);

  let denominazioneField = {
    uniqueID: "denominazioneField",
    value: denominazione ? denominazione : "",
    form: formFields,
    setValue: (value) => {
      const { currentValue = "" } = value;
      dispatch(
        setNotClientDataProperty({
          interactionId: currenInteractionRef.current,
          property: "denominazione",
          value: currentValue,
        })
      );
    },
  };
  let insegnaField = {
    uniqueID: "insegnaField",
    form: formFields,
    value: insegna ? insegna : "",
    setValue: (value) => {
      const { currentValue = "" } = value;
      dispatch(
        setNotClientDataProperty({
          interactionId: currenInteractionRef.current,
          property: "insegna",
          value: currentValue,
        })
      );
    },
  };
  let rifPersonaField = {
    uniqueID: "rifPersonaField",
    form: formFields,
    value: rifPersona ? rifPersona : "",
    setValue: (value) => {
      const { currentValue = "" } = value;
      dispatch(
        setNotClientDataProperty({
          interactionId: currenInteractionRef.current,
          property: "rifPersona",
          value: currentValue,
        })
      );
    },
  };
  let partitaIvaField = {
    uniqueID: "partitaIvaField",
    form: formFields,
    value: partitaIva ? partitaIva : "",
    setValue: (value) => {
      const { currentValue = "" } = value;
      dispatch(
        setNotClientDataProperty({
          interactionId: currenInteractionRef.current,
          property: "partitaIva",
          value: currentValue,
        })
      );
    },
  };
  let aziendaCittaField = {
    uniqueID: "aziendaCittaField",
    form: formFields,
    value: aziendaCitta ? aziendaCitta : "",
    setValue: (value) => {
      const { currentValue = "" } = value;
      dispatch(
        setNotClientDataProperty({
          interactionId: currenInteractionRef.current,
          property: "aziendaCitta",
          value: currentValue,
        })
      );
    },
  };

  let aziendaCapField = {
    uniqueID: "aziendaCapField",
    form: formFields,
    value: aziendaCap ? aziendaCap : "",
    setValue: (value) => {
      const { currentValue = "" } = value;
      dispatch(
        setNotClientDataProperty({
          interactionId: currenInteractionRef.current,
          property: "aziendaCap",
          value: currentValue,
        })
      );
    },
  };
  let aziendaProvinciaField = {
    uniqueID: "aziendaProvinciaField",
    form: formFields,
    value: aziendaProvincia ? aziendaProvincia : "",
    setValue: (value) => {
      const { currentValue = "" } = value;
      dispatch(
        setNotClientDataProperty({
          interactionId: currenInteractionRef.current,
          property: "aziendaProvincia",
          value: currentValue,
        })
      );
    },
  };
  let aziendaRecapitoCellField = {
    uniqueID: "aziendaRecapitoCellField",
    form: formFields,
    value: aziendaRecapitoCell ? aziendaRecapitoCell : "",
    setValue: (value) => {
      const { currentValue = "" } = value;
      dispatch(
        setNotClientDataProperty({
          interactionId: currenInteractionRef.current,
          property: "aziendaRecapitoCell",
          value: currentValue,
        })
      );
    },
  };
  let aziendaRecapitoFissoField = {
    uniqueID: "aziendaRecapitoFissoField",
    form: formFields,
    value: aziendaRecapitoFisso ? aziendaRecapitoFisso : "",
    setValue: (value) => {
      const { currentValue = "" } = value;
      dispatch(
        setNotClientDataProperty({
          interactionId: currenInteractionRef.current,
          property: "aziendaRecapitoFisso",
          value: currentValue,
        })
      );
    },
  };
  let aziendaRecapitoMailField = {
    uniqueID: "aziendaRecapitoMailField",
    form: formFields,
    value: aziendaRecapitoMail ? aziendaRecapitoMail : "",
    type: "Email",
    setValue: (value) => {
      const { currentValue = "" } = value;
      dispatch(
        setNotClientDataProperty({
          interactionId: currenInteractionRef.current,
          property: "aziendaRecapitoMail",
          value: currentValue,
        })
      );
    },
  };

  return (
    <div
      className={`d-flex flex-column anagrafica-${layoutType}-notclient-container`}
    >
      <div
        className={`d-flex flex-row flex-wrap anagrafica-${layoutType}-section-1`}
      >
        <AnagraficaLabelValue label="Denominazione" required={true}>
          <TextField configuration={denominazioneField} />
        </AnagraficaLabelValue>
        <AnagraficaLabelValue label="Insegna">
          <TextField configuration={insegnaField} />
        </AnagraficaLabelValue>
        <AnagraficaLabelValue label="Persona Rif.">
          <TextField configuration={rifPersonaField} />
        </AnagraficaLabelValue>
        <AnagraficaLabelValue label="Partita Iva">
          <TextField configuration={partitaIvaField} />
        </AnagraficaLabelValue>
        <AnagraficaLabelValue label="Citta">
          <TextField configuration={aziendaCittaField} />
        </AnagraficaLabelValue>
        <AnagraficaLabelValue label="Cap">
          <TextField configuration={aziendaCapField} />
        </AnagraficaLabelValue>
        <AnagraficaLabelValue label="Provincia">
          <TextField configuration={aziendaProvinciaField} />
        </AnagraficaLabelValue>
        <AnagraficaLabelValue label="Recapito Cell.">
          <TextField configuration={aziendaRecapitoCellField} />
        </AnagraficaLabelValue>
        <AnagraficaLabelValue label="Recapito Fisso.">
          <TextField configuration={aziendaRecapitoFissoField} />
        </AnagraficaLabelValue>
        <AnagraficaLabelValue label="Recapito Mail.">
          <TextField configuration={aziendaRecapitoMailField} />
        </AnagraficaLabelValue>
      </div>
      <AziendaButton />
    </div>
  );
};

export default AziendaNotClientContainer;
