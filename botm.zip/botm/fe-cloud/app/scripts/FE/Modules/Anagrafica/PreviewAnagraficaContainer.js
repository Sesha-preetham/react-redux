import React, { useEffect, useRef, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { CSSTransition } from "react-transition-group";
import IconExplode from "../../CommonComponents/Common/Icons/IconExplode";
import FormFieldHandler from "../../CommonComponents/Forms/FormFieldHandler";
import ToggleSwitch from "../../CommonComponents/Forms/ToggleSwitch";
import { stackNavAnagrafica } from "../../Main/StackNavigation/StackNavComponents";
import { stackNavPush } from "../../Main/StackNavigation/stackNavigationSlice";
import { prospectEventListeners } from "../Prospect/Service";
import { authenticationEventListeners } from "../Authentication/Service";
import {
  anagraficaWidgetCode,
  getDisplayDataByCode,
} from "../Widgets/widgetsSlice";
import WidgetTitle from "../Widgets/WidgetTitle";
import WidgetWrapper from "../Widgets/WidgetWrapper";
import {
  clearNotClientData,
  getNotClientDataByInteraction,
  setNotClientToggle,
} from "./anagraficaSlice";
import TabsPrivatoOrAzienda from "./Components/TabsPrivatoOrAzienda";
import { anagraficaEventListeners } from "./Service";
import AnagraficaNotification from "./Components/Common/AnagraficaNotification";

const PreviewAnagraficaContainer = (props) => {
  const { widgets } = useSelector((state) => state.widgets);
  const dispatch = useDispatch();
  const [anagraficaMenuShow, anagraficaShow] = getDisplayDataByCode(widgets)(
    anagraficaWidgetCode
  );

  const [formFiels] = useState(new FormFieldHandler(true));

  useEffect(() => {
    window.addEventListener("message", anagraficaEventListeners, false);
    return () => {
      window.removeEventListener("message", anagraficaEventListeners, false);
    };
  }, []);

  useEffect(() => {
    window.addEventListener("message", prospectEventListeners, false);
    return () => {
      window.removeEventListener("message", prospectEventListeners, false);
    };
  }, []);

  useEffect(() => {
    window.addEventListener("message", authenticationEventListeners, false);
    return () => {
      window.removeEventListener("message", authenticationEventListeners, false);
    };
  }, []);


  const { currentInteraction = "noInteraction" } = useSelector(
    (state) => state.interaction
  );

  const { anagrafica, currentLayoutType } = useSelector(
    (state) => state.anagrafica
  );

  const currentInteractionRef = useRef();
  currentInteractionRef.current = currentInteraction;

  const { clientToggle } = getNotClientDataByInteraction(anagrafica)(
    currentInteraction
  );

  let handleNotClientToggle = (value) => {
    console.log("NotClient value", value);
    const { currentValue = false } = value;
    dispatch(
      setNotClientToggle({
        interactionId: currentInteractionRef.current,
        value: currentValue,
      })
    );
    if (currentValue === false) {
      dispatch(
        clearNotClientData({ interactionId: currentInteractionRef.current })
      );
    }
  };

  useEffect(() => {
    console.log("notClientToggleField", formFiels.getFields());
    if (formFiels.getField("notClientToggleField"))
      formFiels
        .getField("notClientToggleField")
        .theField.setValue(clientToggle);
  }, [currentLayoutType, clientToggle]);

  return (
    <WidgetWrapper widgetShow={anagraficaShow}>
      <CSSTransition
        in={anagraficaMenuShow}
        timeout={300}
        classNames="slide-left-toggle"
        unmountOnExit={false}
        mountOnEnter={true}
      >
        <div className="d-flex flex-column section-anagrafica anagrafica-preview mb-3">
          <WidgetTitle
            title="Anagrafica cliente"
            centralElement={
              <ToggleSwitch
                configuration={{
                  uniqueID: "notClientToggleField",
                  activeDesc: "Cliente",
                  deactiveDesc: "Non Cliente",
                  checked: clientToggle,
                  setValue: handleNotClientToggle,
                  form: formFiels,
                }}
              />
            }
            iconElement={
              <div className="d-flex">
                <AnagraficaNotification />
                <IconExplode
                  configuration={{
                    onClick: (active) => {
                      dispatch(stackNavPush(stackNavAnagrafica));
                    },
                  }}
                />
              </div>
            }
          />
          <TabsPrivatoOrAzienda
            formFields={formFiels}
            clientToggle={clientToggle}
          />
        </div>
      </CSSTransition>
    </WidgetWrapper>
  );
};

export default PreviewAnagraficaContainer;
