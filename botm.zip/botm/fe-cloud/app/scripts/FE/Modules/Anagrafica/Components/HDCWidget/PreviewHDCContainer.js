import React,{useRef,useState, useEffect} from "react";
import {  useDispatch ,useSelector } from "react-redux";
import { CSSTransition } from "react-transition-group";
import IconExplode from "../../../../CommonComponents/Common/Icons/IconExplode";
import { stackNavHDCMainContainer } from "../../../../Main/StackNavigation/StackNavComponents";
import {
  stackNavPush,
} from "../../../../Main/StackNavigation/stackNavigationSlice";
import {hdcWidgetCode ,getInternalWidgetByIdAndCode} from "../../../Widgets/internalWidgetsSlice";
import WidgetTitle from "../../../Widgets/WidgetTitle";
import WidgetWrapper from "../../../Widgets/WidgetWrapper";
import FormFieldHandler from "../../../../CommonComponents/Forms/FormFieldHandler";
import ToggleSwitch from "../../../../CommonComponents/Forms/ToggleSwitch";
import { withErrorBoundary } from "../../../../CommonComponents/ErrorBoundary/withErrorBoudary";
import {
  getNotClientDataByInteraction,
  setNotClientDataProperty,
  setHDCNotClientToggle,
  clearNotClientData,
} from "../../../Anagrafica/anagraficaSlice";
import HDCMainComponent from "./HDCMainComponent";
import HDCNonClienteComponent from "./HDCNonClienteComponent";

const PreviewHDCContainer = (props) => {
  const dispatch = useDispatch();
  const [formFields] = useState(new FormFieldHandler(true));
  const { currentInteraction = "noInteraction" } = useSelector((state) => state.interaction);

  const currentInteractionRef = useRef();
  currentInteractionRef.current = currentInteraction;

  const { internalWidgets } = useSelector((state) => state.internalWidgets);

  const { anagrafica, currentLayoutType } = useSelector((state) => state.anagrafica );
  const { hdcClientToggle } = getNotClientDataByInteraction(anagrafica)(currentInteractionRef.current);

  const [hdcWidgetShow] = getInternalWidgetByIdAndCode(internalWidgets)(currentInteractionRef.current,hdcWidgetCode);

 let handleOnStackExpand = () => {
    dispatch(stackNavPush(stackNavHDCMainContainer));
  };

  useEffect(() => {
    if (formFields.getField("notClientHDCToggleField"))
    formFields
        .getField("notClientHDCToggleField")
        .theField.setValue(hdcClientToggle);
  }, [hdcClientToggle]);

  let handleHDCNotClientToggle = (value) => {
    const { currentValue = false } = value;
    dispatch(
      setHDCNotClientToggle({
        interactionId: currentInteractionRef.current,
        value: currentValue,
      })
    );
    if (currentValue === false) {
      dispatch(
        clearNotClientData({ interactionId: currentInteractionRef.current})
      );
    }
  };

  return (
    <WidgetWrapper widgetShow={hdcWidgetShow}>
      <CSSTransition
        in={hdcWidgetShow}
        timeout={300}
        classNames="slide-right-toggle"
        unmountOnExit={false}
        mountOnEnter={true}
      >
        <div className="d-flex flex-column section-consult">
          <WidgetTitle
            title="Contatto Succursale"
            centralElement={
              <ToggleSwitch
                configuration={{
                  uniqueID: "notClientHDCToggleField",
                  activeDesc: "Collega",
                  deactiveDesc: "Non Collega",
                  checked: hdcClientToggle,
                  setValue: handleHDCNotClientToggle,
                  form: formFields,
                }}
              />
            }
            iconElement={
              <IconExplode
                configuration={{
                  onClick: (active) => {
                    handleOnStackExpand();
                  },
                }}
              />
            }
          />
          {hdcClientToggle ? (
            <HDCMainComponent layoutType={"preview"} />
          ) : (
            <HDCNonClienteComponent layoutType={"preview"} />
          )}
        </div>
      </CSSTransition>
    </WidgetWrapper>
  );
};

export default withErrorBoundary(PreviewHDCContainer);
