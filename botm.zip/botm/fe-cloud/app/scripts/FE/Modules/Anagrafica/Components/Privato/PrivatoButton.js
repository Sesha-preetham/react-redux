import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { exposedDispatch } from "../../../../Store/store";
import { getBTChannelOfInteraction } from "../../../../Utils/CommonUtil";
import {
  getAuthenticationDataByInteraction,
  getAuthenticationDataByInteractionAndValue,
  setShowAuthenticationModalByInteraction,
} from "../../../Authentication/authenticationSlice";
import AuthenticationModal from "../../../Authentication/Modal/AuthenticationModal";
import { getInteractionDetails } from "../../../Interaction/interactionSlice";
import { getBTCallType } from "../../../Interaction/Service";
import ProspectModal from "../../../Prospect/Components/modal/ProspectModal";
import {
  getProspectDataById,
  updateProspectDataByProperty,
  privatoProspectData
} from "../../../Prospect/prospectSlice";
import { updateProspectDataByPrivatoClientToggle } from "../../../Prospect/Service";
import {
  authenticationWidgetCode,
  getInternalWidgetByIdAndCode,
  prospectWidgetCode,
  draftEmailWidgetCode
} from "../../../Widgets/internalWidgetsSlice";
import WidgetWrapper from "../../../Widgets/WidgetWrapper";
import {
  getNotClientDataByInteraction,
  getPrivatoDataByInteraction,
} from "../../anagraficaSlice";

const PrivatoButton = (props) => {
  const {
    handleOnAuthenticate = () => {},
    handleOnSendMail = () => {},
    handleOnProspect = () => {},
  } = props;

  const [authenticationBtnDisabled, setAuthenticationBtnDisabled] = useState(
    true
  );

  const dispatch = useDispatch();

  const { internalWidgets } = useSelector((state) => state.internalWidgets);
  const { prospectData } = useSelector((state) => state.prospect);
  const { anagrafica } = useSelector((state) => state.anagrafica);
  const {
    currentInteraction = "noInteraction",
    interactions = [],
  } = useSelector((state) => state.interaction);

  const { authentication } = useSelector((state) => state.authentication);

  const [prospectWidgetShow] = getInternalWidgetByIdAndCode(internalWidgets)(
    currentInteraction,
    prospectWidgetCode
  );

  const [authenticationWidgetShow] = getInternalWidgetByIdAndCode(
    internalWidgets
  )(currentInteraction, authenticationWidgetCode);

  const [draftEmailWidgetCodeShow] = getInternalWidgetByIdAndCode(
    internalWidgets
  )(currentInteraction, draftEmailWidgetCode);

  const {
    privatoPropestClientDisabled = true,
    privatoPropestNotClientDisabled = true,
    privatoProspectData: {showProspectModal = false , loadDataFromAnagrafica = false}
  } = getProspectDataById(prospectData)(currentInteraction);

  const {
    clientToggle = true,
    data: notClienteData = {},
  } = getNotClientDataByInteraction(anagrafica)(currentInteraction);

  const { selectedIbCode = {} } = getPrivatoDataByInteraction(anagrafica)(
    currentInteraction
  );

  const {
    authenticationState = "NOT_AUTHENTICATED",
  } = getAuthenticationDataByInteractionAndValue(authentication)(
    currentInteraction,
    selectedIbCode.value
  );

  const {
    showAuthenticationModal = false,
  } = getAuthenticationDataByInteraction(authentication)(currentInteraction);

  const interactionDetails = getInteractionDetails(interactions)(
    currentInteraction
  );

  const { surname = "" } = notClienteData;

  useEffect(() => {
    if (surname) {
      privatoPropestNotClientDisabled &&
        dispatch(
          updateProspectDataByProperty({
            interactionId: currentInteraction,
            data: {
              property: "privatoPropestNotClientDisabled",
              value: false,
            },
          })
        );
    } else {
      !privatoPropestNotClientDisabled &&
        dispatch(
          updateProspectDataByProperty({
            interactionId: currentInteraction,
            data: {
              property: "privatoPropestNotClientDisabled",
              value: true,
            },
          })
        );
    }
  }, [surname]);

  useEffect(() => {
    !loadDataFromAnagrafica &&
      dispatch(
        updateProspectDataByProperty({
          interactionId: currentInteraction,
          data: {
            property: "loadDataFromAnagrafica",
            value: true,
          },
          orginData: privatoProspectData
        })
      );
  }, [clientToggle]);

  useEffect(() => {
    loadDataFromAnagrafica &&
      dispatch(
        updateProspectDataByProperty({
          interactionId: currentInteraction,
          data: {
            property: "prospectCrmNote",
            value: "",
          },
          orginData : privatoProspectData
        })
      );
  }, [loadDataFromAnagrafica]);

  const handleOnProspectButton = () => {
    handleOnProspect();
    dispatch(
      updateProspectDataByProperty({
        interactionId: currentInteraction,
        data: {
          property: "showProspectModal",
          value: true
        },
        orginData : privatoProspectData
      })
    );
  };

  const handleOnAuthenticationButton = () => {
    handleOnAuthenticate();
    dispatch(
      setShowAuthenticationModalByInteraction({
        interactionId: currentInteraction,
        value: true,
      })
    );
  };

  useEffect(() => {
    if (
      interactionDetails 
      &&
      getBTChannelOfInteraction(interactionDetails) === "VOICE" &&
      getBTCallType(interactionDetails) !="OUTBOUND"
    ) {
      setAuthenticationBtnDisabled(false);
    }
    else{
      setAuthenticationBtnDisabled(true);
    }
  }, [currentInteraction]);

  const authenticationStateClass = {
    NOT_AUTHENTICATED: "Rectangle-Button-Red",
    VALIDATED: "Rectangle-Button-Red",
    PARTIAL_AUTHENTICATED: "Rectangle-Button-Orange",
    PARTIAL_AUTHENTICATED_IVR: "Rectangle-Button-Orange",
    PARTIAL_AUTHENTICATED_TRASF: "Rectangle-Button-Orange",
    AUTHENTICATED: "Rectangle-Button-Green",
  };

  let authenticationBtnClass = "Rectangle-Button-White";
  if (!authenticationBtnDisabled || authenticationState === "AUTHENTICATED") {
    authenticationBtnClass =
      authenticationStateClass[authenticationState] || "Rectangle-Button-White";
  }


  return (
    <div className="d-flex flex-row justify-content-center my-2">
      <WidgetWrapper widgetShow={authenticationWidgetShow && clientToggle}>
        <>
          <div className="w-25 pr-2">
            <button
              type="button"
              className={`btn ${authenticationBtnClass} w-100`}
              onClick={handleOnAuthenticationButton}
              disabled={authenticationBtnDisabled}
            >
              Autenticazione
            </button>
          </div>
          <AuthenticationModal
            configuration={{
              showAuthenticationModal: showAuthenticationModal,
              valueToAuthenticate: selectedIbCode.value,
              handleOnHideAuthenticationModal: () => {
                exposedDispatch(
                  setShowAuthenticationModalByInteraction({
                    interactionId: currentInteraction,
                    value: false,
                  })
                );
              },
            }}
          />
        </>
      </WidgetWrapper>
      <WidgetWrapper widgetShow={draftEmailWidgetCodeShow}>
        <div className="w-25 px-2">
          <button
            type="button"
            className={`btn Rectangle-Button-Blue w-100`}
            onClick={handleOnSendMail}
            disabled={
              clientToggle
                ? false
                : true
            }
          >
            Send e-mail
          </button>
        </div>
      </WidgetWrapper>
      <WidgetWrapper widgetShow={prospectWidgetShow}>
        <>
          <div className="w-25 pl-2">
            <button
              type="button"
              className={`btn Rectangle-Button-Blue w-100`}
              onClick={handleOnProspectButton}
              disabled={
                clientToggle
                  ? privatoPropestClientDisabled
                  : privatoPropestNotClientDisabled
              }
            >
              Prospect
            </button>
          </div>
          <ProspectModal
            configuration={{
              showProspectModal: showProspectModal,
              orginTab : "privatoProspect",
              orginData : privatoProspectData,
              handleOnHideProspectModal: () => {
                dispatch(
                  updateProspectDataByProperty({
                    interactionId: currentInteraction,
                    data: {
                      property: "showProspectModal",
                      value: false,
                    },
                    orginData:privatoProspectData
                  })
                );
              },
              handleOnEnteringProspectModal: () => {
                updateProspectDataByPrivatoClientToggle();
              },
            }}
          />
        </>
      </WidgetWrapper>
    </div>
  );
};

export default PrivatoButton;
