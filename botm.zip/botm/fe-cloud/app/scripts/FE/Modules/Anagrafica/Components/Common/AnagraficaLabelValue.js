import React from "react";

const AnagraficaLabelValue = (props) => {
  const { label = "", required=false } = props;

  let requiredClass = (required)?"required":"";
  return (
    <div className={`anagrafica-content my-2 ${requiredClass}`}>
      <div className={`anagrafica-content-label`}>{label}</div>
      <div className={`anagrafica-content-text`}>{props.children}</div>
    </div>
  );
};

export default AnagraficaLabelValue;
