import React from "react";
import { Tab, Tabs } from "react-bootstrap";
import { useSelector } from "react-redux";
import FormFieldHandler from "../../../CommonComponents/Forms/FormFieldHandler";
import { exposedDispatch } from "../../../Store/store";
import {
  aziendaWidgetCode,
  leasingWidgetCode,
  getInternalWidgetByIdAndCode,
  privatoWidgetCode,
  getAziendaWidgetCheck,
  getPrivatoWidgetCheck,
} from "../../Widgets/internalWidgetsSlice";
import WidgetWrapper from "../../Widgets/WidgetWrapper";
import {
  getCurrentTabKeyByInteraction,
  setCurrentTabKey,
} from "../anagraficaSlice";
import AziendaContainer from "./Azienda/AziendaContainer";
import AziendaNotClientContainer from "./Azienda/NotClient/AziendaNotClientContainer";
import PrivatoNotClientContainer from "./Privato/NotClient/PrivatoNotClientContainer";
import PrivatoContainer from "./Privato/PrivatoContainer";

const TabsPrivatoOrAzienda = (props) => {
  const {
    layoutType = "preview",
    formFields = new FormFieldHandler(),
    clientToggle = true,
  } = props;
  //const [privatoOrAzienda, setPrivatoOrAzienda] = useState(privatoWidgetCode);

  //STE moved WidgetWrapper here from PrivatoContainer to rebuild the state of the PrivatoContainer otherwise state remains but child components are destroyed
  const { currentInteraction = "noInteraction" } = useSelector(
    (state) => state.interaction
  );
  const { internalWidgets } = useSelector((state) => state.internalWidgets);

  const [privatoWidgetShow] = getInternalWidgetByIdAndCode(internalWidgets)(
    currentInteraction,
    privatoWidgetCode
  );

  const { anagrafica = {} } = useSelector((state) => state.anagrafica);

  const currentTabKey =
    getCurrentTabKeyByInteraction(anagrafica)(currentInteraction);

  const showAziendaTabContainer =
    getAziendaWidgetCheck(internalWidgets)(currentInteraction);

  const showPrivatoWidget =  getPrivatoWidgetCheck(internalWidgets)(currentInteraction);

  //recreated each time an interaction change
  //let formFields = new FormFieldHandler();

  return (
    <>
      <Tabs
        id="privatoOrAziendaTabs"
        //activeKey={privatoOrAzienda}
        //onSelect={(tabKey) => setPrivatoOrAzienda(tabKey)}
        activeKey={currentTabKey}
        onSelect={(tabKey) =>
          exposedDispatch(
            setCurrentTabKey({
              interactionId: currentInteraction,
              key: tabKey,
            })
          )
        }
      >
        { showPrivatoWidget &&
        <Tab eventKey={privatoWidgetCode} title="Privato">
          <WidgetWrapper widgetShow={privatoWidgetShow}>
            {clientToggle ? (
              <PrivatoContainer
                layoutType={layoutType}
                formFields={formFields}
              />
            ) : (
              <PrivatoNotClientContainer
                layoutType={layoutType}
                formFields={formFields}
              />
            )}
          </WidgetWrapper>
        </Tab>
        }
        {showAziendaTabContainer && (
          <Tab eventKey={aziendaWidgetCode} title="Azienda">
            {clientToggle ? (
              <AziendaContainer layoutType={layoutType} />
            ) : (
              <AziendaNotClientContainer
                layoutType={layoutType}
                formFields={formFields}
              />
            )}
          </Tab>
        )}
      </Tabs>
    </>
  );
};

export default TabsPrivatoOrAzienda;
