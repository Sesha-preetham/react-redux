import React, { useEffect, useRef, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import IconBlueClose from "../../CommonComponents/Common/Icons/IconBlueClose";
import { withErrorBoundary } from "../../CommonComponents/ErrorBoundary/withErrorBoudary";
import FormFieldHandler from "../../CommonComponents/Forms/FormFieldHandler";
import ToggleSwitch from "../../CommonComponents/Forms/ToggleSwitch";
import { stackNavPop } from "../../Main/StackNavigation/stackNavigationSlice";
import ExpandedWidgetWrapper from "../Widgets/ExpandedWidgetWrapper";
import WidgetTitle from "../Widgets/WidgetTitle";
import {
  clearNotClientData,
  getNotClientDataByInteraction,
  setCurrentLayoutType,
  setNotClientToggle,
} from "./anagraficaSlice";
import AnagraficaNotification from "./Components/Common/AnagraficaNotification";
import TabsPrivatoOrAzienda from "./Components/TabsPrivatoOrAzienda";

const ExpandAnagrficaContainer = (props) => {
  const { elStack = {} } = props;
  const [formFields] = useState(new FormFieldHandler(true));
  const dispatch = useDispatch();

  let handleOnAnagraficaStackMounted = (stack) => {
    console.log(stack);
    dispatch(
      setCurrentLayoutType({
        interactionId: currentInteractionRef.current,
        layoutType: "expand",
      })
    );
  };

  let handleOnAnagraficaStackUnMounted = (stack) => {
    console.log(stack);
    dispatch(
      setCurrentLayoutType({
        interactionId: currentInteractionRef.current,
        layoutType: "preview",
      })
    );
  };

  const { currentInteraction = "noInteraction" } = useSelector(
    (state) => state.interaction
  );

  const { anagrafica } = useSelector((state) => state.anagrafica);

  const currentInteractionRef = useRef();
  currentInteractionRef.current = currentInteraction;

  const { clientToggle } = getNotClientDataByInteraction(anagrafica)(
    currentInteraction
  );

  useEffect(() => {
    if (formFields.getField("notClientToggleField"))
    formFields
        .getField("notClientToggleField")
        .theField.setValue(clientToggle);
  }, [clientToggle]);


  let handleNotClientToggle = (value) => {
    console.log("NotClient value", value);
    const { currentValue = false } = value;
    dispatch(
      setNotClientToggle({
        interactionId: currentInteractionRef.current,
        value: currentValue,
      })
    );
    if (currentValue === false) {
      dispatch(
        clearNotClientData({ interactionId: currentInteractionRef.current })
      );
    }
  };

  return (
    <ExpandedWidgetWrapper
      className={"section-anagrafica anagrafica-expand-main-container"}
      elStack={elStack}
      events={{
        handleOnStackMounted: handleOnAnagraficaStackMounted,
        handleOnStackUnMounted: handleOnAnagraficaStackUnMounted,
      }}
    >
      <WidgetTitle
        title="Anagrafica cliente"
        centralElement={
          <ToggleSwitch
            configuration={{
              uniqueID: "notClientToggleField",
              activeDesc: "Cliente",
              deactiveDesc: "Non cliente",
              checked: clientToggle,
              setValue: handleNotClientToggle,
              form: formFields,
            }}
          />
        }
        iconElement={
          <div className="d-flex">
            <AnagraficaNotification layoutType="expand"  />
            <IconBlueClose
              configuration={{
                onClick: (active) => {
                  dispatch(stackNavPop());
                },
              }}
            />
          </div>
        }
      />
      <TabsPrivatoOrAzienda
        layoutType="expand"
        formFields={formFields}
        clientToggle={clientToggle}
      />
    </ExpandedWidgetWrapper>
  );
};

export default withErrorBoundary(ExpandAnagrficaContainer);
