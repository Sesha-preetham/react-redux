import React, { useEffect, useState } from "react";
import { Card } from "react-bootstrap";
import { useSelector } from "react-redux";
import { exposedDispatch } from "../../../../Store/store";
import IconNotificationSolid from "../../../../CommonComponents/Common/Icons/IconNotificationSolid";
import MyPopover from "../../../../CommonComponents/Popover/MyPopover";
import {
  getAnagraficaNotification,
  setNotificationPopover,
  setNotificationRead,
} from "../../anagraficaSlice";

const AnagraficaNotification = (props) => {

  const { layoutType = "preview" } = props;
  const { anagrafica, currentLayoutType: currentLayout } = useSelector((state) => state.anagrafica);
  const { currentInteraction = "noInteraction" } = useSelector(
    (state) => state.interaction
  );

  const { read = false, data: notification = [], showPopover = false} =
    getAnagraficaNotification(anagrafica)(currentInteraction);

  useEffect(() => {
    if(!isRead() && isBlocker()){
      exposedDispatch(setNotificationPopover({
        interactionId: currentInteraction,
        value: true,
      }));
      exposedDispatch(
        setNotificationRead({
          interactionId: currentInteraction,
          value: true,
        })
      );
    }
  },[notification]);

  useEffect(() => {
    if(showPopover === true){
      exposedDispatch(setNotificationPopover({
        interactionId: currentInteraction,
        value: false,
      }));
    }
  },[currentLayout])

  const isBlocker = () => {
    let b = false;
    if(notification && notification.length > 0){
      for(let i=0; i<notification.length; i++){
        const { blocker = false } = notification[i];
        b=blocker;
        if(b){
          break;
        }
      }
    }
    return b;
  }

  const isRead = () => {
    if (notification && notification.length > 0) {
      return read;
    } else {
      return true;
    }
  };

  const renderCardContent = (el) => {
    const { title, message, type } = el;
    let typeClass =
      messageTypeConstant[type] && messageTypeConstant[type].class
        ? messageTypeConstant[type].class
        : "notification-card-general";
    return (
      <Card className="notification-card">
        <Card.Header className={`notification-card-header ${typeClass}`}>
          {title || "No title"}
        </Card.Header>
        <Card.Body>
          <Card.Text className="notification-card-message">{message}</Card.Text>
        </Card.Body>
      </Card>
    );
  };

  const getSortedNotification = (notification = []) => {
    let newNotification = [...notification];
    newNotification = newNotification.sort((e1, e2) => {
      const { type: t1 = "G" } = e1; // A - W - G
      const { type: t2 = "G" } = e2;
      let st1 =
        (messageTypeConstant[t1] && messageTypeConstant[t1].priority) || 3;
      let st2 =
        (messageTypeConstant[t2] && messageTypeConstant[t2].priority) || 3;
      return st1 - st2;
    });
    return newNotification;
  };

  return (
    <div className="pr-1 anagrafica-notification">
      <MyPopover
        configuration={{
          uniqueID: "anagraficaNotificationDashboard_"+currentLayout,
          popoverShow: (currentLayout === layoutType)?showPopover:false,
          popoverPlacement: "left-start",
          overlayTriggerElement: (
            <IconNotificationSolid
              configuration={{
                className: !isRead() ? "ring-bell" : "",
                onClick: () => {
                  exposedDispatch(setNotificationPopover({
                    interactionId: currentInteraction,
                    value: !showPopover,
                  }));
                  if (!isRead()) {
                    exposedDispatch(
                      setNotificationRead({
                        interactionId: currentInteraction,
                        value: true,
                      })
                    );
                  }
                },
              }}
            />
          ),
        }}
      >
        <div className={`anagrafica-notification-cards-container  ${(notification && notification.length >0)?"with-value ":""}`}>
          {getSortedNotification(notification).map((el) =>
            renderCardContent(el)
          )}
        </div>
      </MyPopover>
    </div>
  );
};

const messageTypeConstant = {
  A: {
    class: "notification-card-alert",
    priority: 1,
  },
  W: {
    class: "notification-card-warning",
    priority: 2,
  },
  G: {
    class: "notification-card-general",
    priority: 3,
  },
};

export default AnagraficaNotification;
