import React,{useRef, useState, useEffect} from "react";
import { useDispatch , useSelector} from "react-redux";
import IconBlueClose from "../../../../CommonComponents/Common/Icons/IconBlueClose";
import {
  stackExpand,
  stackNavPop,
  stackPreview,
} from "../../../../Main/StackNavigation/stackNavigationSlice";
import ExpandedWidgetWrapper from "../../../Widgets/ExpandedWidgetWrapper";
import WidgetTitle from "../../../Widgets/WidgetTitle";
import FormFieldHandler from "../../../../CommonComponents/Forms/FormFieldHandler";
import ToggleSwitch from "../../../../CommonComponents/Forms/ToggleSwitch";
import {
  getNotClientDataByInteraction,
  setHdcContainerLayoutType,
  setHDCNotClientToggle,
  clearNotClientData,
} from "../../../Anagrafica/anagraficaSlice";
import HDCMainComponent from "./HDCMainComponent";
import HDCNonClienteComponent from "./HDCNonClienteComponent";

const ExpandHDCContainer = (props) => {
  const { elStack = {} } = props;
  const dispatch = useDispatch();
  const [formFields] = useState(new FormFieldHandler(true));
  const { currentInteraction = "noInteraction" } = useSelector((state) => state.interaction);

  const currentInteractionRef = useRef();
  currentInteractionRef.current = currentInteraction;

  const { anagrafica, currentLayoutType } = useSelector((state) => state.anagrafica );
  const { hdcClientToggle } = getNotClientDataByInteraction(anagrafica)(currentInteractionRef.current);

  let handleOnStackMounted = (stack) => {
    dispatch(setHdcContainerLayoutType({interactionId:currentInteractionRef.current, layoutType:stackExpand}));
  };

  let handleOnStackUnMounted = (stack) => {
    dispatch(setHdcContainerLayoutType({interactionId:currentInteractionRef.current, layoutType:stackPreview}));
  };

  let handleOnStackClose = () => {
    dispatch(stackNavPop());
  };

  useEffect(() => {
    if (formFields.getField("notClientHDCToggleField"))
    formFields
        .getField("notClientHDCToggleField")
        .theField.setValue(hdcClientToggle);
  }, [hdcClientToggle]);

  let handleHDCNotClientToggle = (value) => {
    const { currentValue = false } = value;
    dispatch(
      setHDCNotClientToggle({
        interactionId: currentInteractionRef.current,
        value: currentValue,
      })
    );
    if (currentValue === false) {
      dispatch(
        clearNotClientData({ interactionId: currentInteractionRef.current})
      );
    }
  };

  return (
    <ExpandedWidgetWrapper
      className={"consult-expand-main-container"}
      elStack={elStack}
      events={{
        handleOnStackMounted,
        handleOnStackUnMounted,
      }}
    >
      <WidgetTitle
        title="Contatto Succursale"
        centralElement={
          <ToggleSwitch
            configuration={{
              uniqueID: "notClientHDCToggleField",
              activeDesc: "Collega",
              deactiveDesc: "Non Collega",
              checked: hdcClientToggle,
              setValue: handleHDCNotClientToggle,
              form: formFields,
            }}
          />
        }
        iconElement={
          <IconBlueClose
            configuration={{
              onClick: (active) => {
                handleOnStackClose();
              },
            }}
          />
        }
      />
      {hdcClientToggle ? (
        <HDCMainComponent layoutType={"expand"} />
      ) : (
        <HDCNonClienteComponent layoutType={"expand"} />
      )}
    </ExpandedWidgetWrapper>
  );
};

export default ExpandHDCContainer;
