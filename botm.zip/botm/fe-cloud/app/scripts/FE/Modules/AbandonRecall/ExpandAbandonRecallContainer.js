import React, { useEffect, useState } from "react";
import { useSelector } from "react-redux";
import IconBlueClose from "../../CommonComponents/Common/Icons/IconBlueClose";
import SimpleTable from "../../CommonComponents/SimpleTable/SimpleTable";
import { stackNavPop } from "../../Main/StackNavigation/stackNavigationSlice";
import { exposedDispatch } from "../../Store/store";
import ExpandedWidgetWrapper from "../Widgets/ExpandedWidgetWrapper";
import SelectField from "../../CommonComponents/Forms/SelectField";
import FormFieldHandler from "../../CommonComponents/Forms/FormFieldHandler";
import {
  abandonRecallWidgetCode,
  getDisplayDataByCode,
  updateWidgetMenuEventByCode,
} from "../Widgets/widgetsSlice";
import WidgetTitle from "../Widgets/WidgetTitle";
import WidgetWrapper from "../Widgets/WidgetWrapper";
import DateField from "../../CommonComponents/Forms/DateField";
import {
  changeFilterValue,
  loadAbandonRecallTableData,
  showCallConfirmationModal,
} from "./abandonRecallSlice";
import {
  httpPostAbandonRecallList,
  httpPostTraceAbandonRecallState,
} from "./abandonRecallService";
import MyPopover from "../../CommonComponents/Popover/MyPopover";
import IconOptions from "../../CommonComponents/Common/Icons/IconOptions";
import ClickToDialModal from "../../CommonComponents/Modal/ClickToDialModal";

const ExpandAbanonRecallContainer = (props = {}) => {
  const { elStack = {} } = props;
  const [formFields] = useState(new FormFieldHandler(true));

  const { widgets } = useSelector((state) => state.widgets);

  const {
    filters = {},
    tableData = [],
    callConfirmationModal = {},
  } = useSelector((state) => state.abandonRecall);

  const { show: showCallModal, phone: callPhoneModal } = callConfirmationModal;

  const [abandonRecallMenuShow, abandonRecallShow] = getDisplayDataByCode(
    widgets
  )(abandonRecallWidgetCode);

  const handleOnStackMounted = () => {};

  const handleOnStackUnMounted = () => {};

  const getSubjectDetailsColumns = (tableData = []) => {
    let cols = [];
    tableData.forEach((el) => {
      const { subjectDetails = {} } = el;
      for (const p in subjectDetails) {
        const kv = subjectDetails[p];
        let head = kv.key;
        if (cols.findIndex((c) => c.Header === head) === -1) {
          let newCol = {
            Header: head,
            id: head,
            accessor: (originalRow) => {
              let sd = originalRow.subjectDetails || {};
              const { value = "" } = sd[p] || {};
              return value;
            },
          };
          cols.push(newCol);
        }
      }
    });
    return cols;
  };

  const getSubjectDetailsParticipantData = (rowData) => {
    const { subjectDetails = {} } = rowData;
    let participantDataObj = {};
    for (const p in subjectDetails) {
      const { participantData = false, value } = subjectDetails[p];
      if (participantData && value) {
        participantDataObj[p] = value;
      }
    }
    return participantDataObj;
  };

  const handleRichiamaOption = (rowData = {}) => {
    const { phone, conversationId, abandonQueueId } = rowData;
    exposedDispatch(
      showCallConfirmationModal({
        show: true,
        phone,
        conversationId,
        queueId: abandonQueueId,
        subjectDetails: getSubjectDetailsParticipantData(rowData),
      })
    );
  };

  const richiamaOptionEnabled = (rowData) => {
    const { conversationId, worked } = rowData;
    return !worked && conversationId;
  };

  const handleCloseNoContactOption = (rowData) => {
    const { conversationId } = rowData;
    httpPostTraceAbandonRecallState({
      conversationId: conversationId,
      state: "CLOSED NO CONTACT",
    }).then((response = {}) => {
      const { status } = response;
      if (status === "OK") {
        estraiCall(false);
      }
    });
  };

  const tableConfiguration = {
    uniqueID: "abandonRecallTable",
    pagination: true,
    autoResetPage: false,
    scrollX: true,
    paginationOptions: {
      pageSize: 25,
    },
    metaData: [
      {
        id: "tableActions",
        Header: () => {
          return null;
        },
        Cell: (cellInfo) => {
          const { original } = cellInfo.row;
          const [showPopover, setShowPopover] = useState(false);
          return (
            <MyPopover
              configuration={{
                uniqueID: "tableActionsPopover",
                popoverShow: showPopover,
                popoverPlacement: "right-start",
                popoverClass: "sospesi-tabella-row-popover",
                overlayTriggerElement: (
                  <IconOptions
                    configuration={{
                      onClick: () => {
                        setShowPopover(!showPopover);
                      },
                    }}
                  />
                ),
              }}
            >
              <div className="d-flex flex-column">
                {richiamaOptionEnabled(original) && (
                  <div
                    className="sospesi-options-content my-2"
                    onClick={() => {
                      handleRichiamaOption(original);
                      setShowPopover(!showPopover);
                    }}
                  >
                    <span>Richiama</span>
                  </div>
                )}
                {!original.worked && (
                  <div
                    className="sospesi-options-content my-2"
                    onClick={() => {
                      handleCloseNoContactOption(original);
                      setShowPopover(!showPopover);
                    }}
                  >
                    <span>Chiudi senza ricontatto</span>
                  </div>
                )}
              </div>
            </MyPopover>
          );
        },
      },
      {
        Header: "Data Abbandono",
        accessor: "abandonEndDate",
      },
      {
        Header: "ID Conversazione",
        accessor: "conversationId",
      },
      {
        Header: "Coda Abbandono",
        accessor: "abandonQueueName",
      },
      {
        Header: "Telefono",
        accessor: "phone",
      },
      {
        Header: "Lavorata",
        accessor: "worked",
        Cell: (instance = {}) => {
          const { value } = instance;
          const str = value ? "Si" : "No";
          return <span>{str}</span>;
        },
      },
      {
        Header: "Stato",
        accessor: "state",
      },
      ...getSubjectDetailsColumns(tableData),
    ],
    data: tableData,
  };

  const lavorataFilter = {
    uniqueID: "lavorataField",
    multiSelect: false,
    label: "",
    placeHolder: "Lavorata",
    readonly: false,
    visible: true,
    disabled: false,
    value: filters.lavorata,
    setValue: (value) => {
      const { currentValue } = value;
      exposedDispatch(
        changeFilterValue({
          filter: "lavorata",
          value: currentValue,
        })
      );
    },
    options: [
      {
        label: "Tutte",
        value: null,
      },
      {
        label: "Si",
        value: "Y",
      },
      {
        label: "No",
        value: "N",
      },
    ],
    searchEnabled: true,
    form: formFields,
  };

  const startDateField = {
    uniqueID: "startDateField",
    value: filters.startDate,
    form: formFields,
    setValue: (value) => {
      const { currentValue } = value;
      exposedDispatch(
        changeFilterValue({
          filter: "startDate",
          value: currentValue,
        })
      );
    },
  };

  const endDateField = {
    uniqueID: "endDateField",
    form: formFields,
    value: filters.endDate,
    setValue: (value) => {
      const { currentValue } = value;
      exposedDispatch(
        changeFilterValue({
          filter: "endDate",
          value: currentValue,
        })
      );
    },
  };

  const clickToDialConfiguration = {
    showModal: showCallModal,
    events: {
      handleOnCloseModal: () => {
        handleOnCloseClickToDialModal();
      },
      handleOnConfirmationModal: () => {
        handleOnConfirmClickToDialModal();
      },
    },
    dialOptions: {
      number: callConfirmationModal.phone,
      type: "call",
      queueId: callConfirmationModal.queueId,
      attributes: {
        AbandonRecallConversation: callConfirmationModal.conversationId,
        ...callConfirmationModal.subjectDetails,
      },
    },
    queueSelection: true,
    channelSelection: false,
  };

  useEffect(() => {
    estraiCall();
  }, []);

  const estraiCall = (cleanBeforeCall = true) => {
    const { startDate, endDate, lavorata = {} } = filters;
    const { value: lavorataValue } = lavorata;
    let worked = undefined;
    if (lavorataValue) {
      worked = lavorataValue === "Y";
    }
    const request = {
      startDate: startDate.toISOString(),
      endDate: endDate.toISOString(),
      worked,
    };
    // clean table before new call
    if (cleanBeforeCall) {
      exposedDispatch(
        loadAbandonRecallTableData({
          data: [],
        })
      );
    }
    httpPostAbandonRecallList(request).then((responseList = []) => {
      exposedDispatch(
        loadAbandonRecallTableData({
          data: responseList,
        })
      );
    });
    console.log("AbandonRecallRequest ::: ", request);
  };

  const handleOnCloseClickToDialModal = () => {
    exposedDispatch(showCallConfirmationModal(!showCallModal));
  };

  const handleOnConfirmClickToDialModal = () => {
    exposedDispatch(showCallConfirmationModal(!showCallModal));
    closeWidget();
  };

  const closeWidget = () => {
    exposedDispatch(
      updateWidgetMenuEventByCode({
        widget: {
          code: abandonRecallWidgetCode,
          menuEventState: !abandonRecallMenuShow,
        },
      })
    );
    exposedDispatch(stackNavPop());
  };

  return (
    <WidgetWrapper widgetShow={abandonRecallShow}>
      <ExpandedWidgetWrapper
        className={"abandonrecall-expand-main-container"}
        elStack={elStack}
        events={{
          handleOnStackMounted: handleOnStackMounted,
          handleOnStackUnMounted: handleOnStackUnMounted,
        }}
      >
        <WidgetTitle
          title="Gestione Abbandonate"
          iconElement={
            <IconBlueClose
              configuration={{
                onClick: (active) => {
                  closeWidget();
                },
              }}
            />
          }
        />
        <div className="d-flex flex-row">
          <div className="col-2 pr-3">
            <div className="small-content-label-class">Lavorata</div>
            <SelectField configuration={lavorataFilter} />
          </div>
          <div className="flex-column pr-3">
            <div className="small-content-label-class">Data inizio</div>
            <DateField configuration={startDateField} />
          </div>
          <div className="flex-column pr-3">
            <div className="small-content-label-class">Data fine</div>
            <DateField configuration={endDateField} />
          </div>
          <div className="flex-column pt-3">
            <button
              type="button"
              className={`btn Rectangle-Button-Blue w-100`}
              onClick={estraiCall}
            >
              Estrai
            </button>
          </div>
        </div>

        <SimpleTable configuration={tableConfiguration} />
        <ClickToDialModal configuration={clickToDialConfiguration} />
      </ExpandedWidgetWrapper>
    </WidgetWrapper>
  );
};

export default ExpandAbanonRecallContainer;
