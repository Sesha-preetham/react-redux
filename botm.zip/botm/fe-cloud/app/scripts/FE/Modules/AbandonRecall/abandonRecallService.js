import { toast } from "react-toastify";
import { beServiceUrls } from "../../Client/ClientProperties";
import { globalAlertId } from "../../CommonComponents/AlertToast/AlertIdConstants";
import {
  globalSpinnerId,
  toggleSpinnerById,
} from "../../CommonComponents/Spinner/spinnerSlice";
import { exposedDispatch } from "../../Store/store";
import { getBaseErrorMessage } from "../../Utils/CommonUtil";
import HttpClient from "../../Utils/HttpClient";

export const httpPostAbandonRecallList = async (request = {}) => {
  const dispatch = exposedDispatch;
  let httpClient = new HttpClient();
  httpClient.setUrl(beServiceUrls().getAbandonRecallList);
  dispatch(toggleSpinnerById(globalSpinnerId));
  let list = await httpClient.httpPost(request).then((response) => {
    dispatch(toggleSpinnerById(globalSpinnerId));
    const { status = "", response: responseList = [] } = response;
    if (status === "KO") {
      toast.warn(getBaseErrorMessage("Warning", response), {
        containerId: globalAlertId,
      });
    } else if (status === "EXCEPTION") {
      toast.error(getBaseErrorMessage("Error", response), {
        containerId: globalAlertId,
      });
    }
    return responseList || [];
  });
  return list;
};

export const httpPostTraceAbandonRecallState = async (
  request = {},
  showSuccessToast = true
) => {
  const dispatch = exposedDispatch;
  let httpClient = new HttpClient();
  httpClient.setUrl(beServiceUrls().traceAbandonRecallState);
  dispatch(toggleSpinnerById(globalSpinnerId));
  let res = await httpClient.httpPost(request).then((response) => {
    dispatch(toggleSpinnerById(globalSpinnerId));
    const { status = "" } = response;
    if (status === "OK") {
      if (showSuccessToast) {
        toast.success("Record aggiornato!", {
          containerId: globalAlertId,
        });
      }
    } else if (status === "KO") {
      toast.warn(getBaseErrorMessage("Warning", response), {
        containerId: globalAlertId,
      });
    } else if (status === "EXCEPTION") {
      toast.error(getBaseErrorMessage("Error", response), {
        containerId: globalAlertId,
      });
    }
    return response ;
  });
  return res;
};
