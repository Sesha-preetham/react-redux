import { createSlice } from "@reduxjs/toolkit";
import { getEndOfDayDate, getStartOfDayDate } from "../../Utils/DateUtils";

let initialState = {
  filters: {
    lavorata: {
      label: "Tutte",
      value: null,
    },
    startDate: getStartOfDayDate(),
    endDate: getEndOfDayDate(),
  },
  tableData: [],
  callConfirmationModal: {
    show: false,
    phone: undefined,
    conversationId: undefined,
    subjectDetails: {}
  },
  recallConfirmationModal: {
    show: false,
    data: {}
  }
};

const abandonRecallSlice = createSlice({
  name: "abadonRecall",
  initialState,
  reducers: {
    changeFilterValue(state, action) {
      const { payload = {} } = action;
      const { filter, value } = payload;
      if (!filter) return;
      state.filters[filter] = value;
    },
    loadAbandonRecallTableData(state, action) {
      const { payload = {} } = action;
      const { data = [] } = payload;
      state.tableData = data;
    },
    showCallConfirmationModal(state, action) {
      const { payload = {} } = action;
      const { show, phone, conversationId, queueId, subjectDetails = {}} = payload;
      state.callConfirmationModal.show = show;
      state.callConfirmationModal.phone = phone;
      state.callConfirmationModal.conversationId = conversationId;
      state.callConfirmationModal.queueId = queueId;
      state.callConfirmationModal.subjectDetails = subjectDetails
    },
    showAbandonRecallRecallConfirmationModal(state,action){
      const { payload = {} } = action;
      const { show = false, data = {}} = payload;
      state.recallConfirmationModal.show=show;
      state.recallConfirmationModal.data = {...data};
    }
  },
});

export const {
  loadAbandonRecallTableData,
  changeFilterValue,
  showCallConfirmationModal,
  showAbandonRecallRecallConfirmationModal
} = abandonRecallSlice.actions;

export default abandonRecallSlice.reducer;
