import { toast } from "react-toastify";
import { beServiceUrls, pureCloudOrigin } from "../../Client/ClientProperties";
import {
  globalAlertId,
  prospectModalAlertId,
} from "../../CommonComponents/AlertToast/AlertIdConstants";
import {
  prospectModalSpinnerId,
  toggleSpinnerById,
} from "../../CommonComponents/Spinner/spinnerSlice";
import { exposedDispatch, exposedGetState } from "../../Store/store";
import HttpClient from "../../Utils/HttpClient";
import {
  getNotClientDataByInteraction,
  getPrivatoDataByInteraction,
  getAziendaDataByInteraction
} from "../Anagrafica/anagraficaSlice";
import {
  addProspectDataById,
  getCityByName,
  getNationByProperty,
  getProspectDataById,
  removeProspectDataById,
  setProspectProdotto,
  setProspectTipoEsiti,
  updateProspectDataById,
  updateProspectDataByProperty,
  privatoProspectData,
  aziendaProspectData
} from "./prospectSlice";

const getStructuredDataForAziendaCliente = (
  currentInteraction = "noInteraction",
  anagrafica = {}
) => {
  const { cities = [], nations = [] } = exposedGetState().common;
  let {
    ecommerceData = {},
    data: aziendaDataArr = [],
  } = getAziendaDataByInteraction(anagrafica)(currentInteraction);
  let aziendaData  = aziendaDataArr[ecommerceData.currentDataIndex];
  let {
    idSoggetto = "",
    ragioneSociale : ragsoc = "",
    partitaIva : piva = "",
    insegna = "",
    citta = "",
    cap = "",
    banca = "BSE",
    provincia : prov = "",
    address : via = "",
  } = aziendaData;
  
  let residenzaOption = getCityByName(cities)(citta);
  let { rlData: residenzaCityData = {} } = residenzaOption || {};
  let {
    province: residenzaProv = "",
    cap: residenzaCap = "",
  } = residenzaCityData;
  let anagraficiOption = getCityByName(cities)("");
  let { rlData: anagraficiCityData = {} } = anagraficiOption || {};
  let {
    province: anagraficiProv = "",
    cap: anagraficiCap = "",
  } = anagraficiCityData;

  let sturctureProspectData = {
    idSoggetto: idSoggetto,
    ragsoc: ragsoc,
    insegna : insegna,
    piva : piva,
    banca: banca,
    via: via,
    citta: residenzaOption,
    cap: residenzaCap,
    prov: residenzaProv,
    stato: getNationByProperty(nations)("name", ""),
    daCitta: anagraficiOption,
    daCap: anagraficiCap,
    daProv: anagraficiProv,
    nazionalita: getNationByProperty(nations)("nazionalita", ""),
    daStato: getNationByProperty(nations)("name", ""),
  };
  return sturctureProspectData;
};

const getStructuredDataForAziendaNonCliente = (
  currentInteraction = "noInteraction",
  anagrafica = {},
  prospectData = {}
) => {
  const { cities = [] } = exposedGetState().common;
  const { data: notClientData } = getNotClientDataByInteraction(anagrafica)(
    currentInteraction
  );
  let {
    denominazione = "",
    ragioneSociale : ragsoc = "",
    partitaIva : piva = "",
    insegna = "",
    citta = "",
    cap = "",
    banca = "BSE",
    provincia : prov = "",
    address : via = "",
    rifPersona = "",
    aziendaCitta = "",
    aziendaCap = "",
    aziendaProvincia = "",
    aziendaRecapitoCell = "",
    aziendaRecapitoFisso = "",
    aziendaRecapitoMail = ""
  } = notClientData;
  let anagraficiOption = getCityByName(cities)(citta);
  let { rlData: anagraficiCityData = {} } = anagraficiOption || {};
  let {
    province: anagraficiProv = "",
    cap: anagraficiCap = "",
  } = anagraficiCityData;
  let sturctureProspectData = {};

  const { loadDataFromAnagrafica } = getProspectDataById(prospectData)(
    currentInteraction , aziendaProspectData
  );

  if (loadDataFromAnagrafica) {
    sturctureProspectData = {
      ...sturctureProspectData,
      denominazione: denominazione,
      ragsoc: ragsoc,
      insegna : insegna,
      piva : piva,
      banca: banca,
      via: via,
      rifPersona : rifPersona,
      daCitta: anagraficiOption,
      daCap: anagraficiCap,
      daProv: anagraficiProv,
      cell :aziendaRecapitoCell,
      emailCasa : aziendaRecapitoMail,
    }
  } else {
    const {
      denominazione: currentDenominazione,
      ragsoc: currentRagsoc,
      insegna : currentInsegna,
      piva : currentPiva,
      banca: currentBanca,
      rifPersona : currentRifPersona,
      daCitta: currentAnagraficiOption,
      daCap: currentAnagraficiCap,
      daProv: currentAnagraficiProv,
      cell :currentAziendaRecapitoCell,
      emailCasa : currentAziendaRecapitoMail,

    } = getProspectDataById(prospectData)(currentInteraction, aziendaProspectData);
    sturctureProspectData = {
      ...sturctureProspectData,
      denominazione: currentDenominazione ? currentDenominazione : denominazione,
      ragsoc: currentRagsoc ? currentRagsoc : ragsoc,
      insegna : currentInsegna ? currentInsegna : insegna,
      piva : currentPiva ? currentPiva : piva,
      banca: currentBanca ? currentBanca : banca,
      rifPersona : currentRifPersona ? currentRifPersona : rifPersona,
      daCitta: currentAnagraficiOption ? currentAnagraficiOption : anagraficiOption,
      daCap: currentAnagraficiCap ? currentAnagraficiCap : anagraficiCap,
      daProv: currentAnagraficiProv ? currentAnagraficiProv : anagraficiProv,
      cell : currentAziendaRecapitoCell ? currentAziendaRecapitoCell : aziendaRecapitoCell,
      emailCasa : currentAziendaRecapitoMail ? currentAziendaRecapitoMail : aziendaRecapitoMail,
    };
  }
  return sturctureProspectData;
};

const getStructuredDataForCliente = (
  currentInteraction = "noInteraction",
  anagrafica = {}
) => {
  const { cities = [], nations = [] } = exposedGetState().common;
  let {
    selectedIbCode = {},
    data: privatoDataArr = [],
  } = getPrivatoDataByInteraction(anagrafica)(currentInteraction);
  let {
    value: currentCodice = "",
    rlData: currentCodiceData = {},
  } = selectedIbCode;
  let { bank: currentCodiceBank = "" } = currentCodiceData;
  let [privatoData = {}] = privatoDataArr;
  let {
    idSoggetto = "",
    name = "",
    surname = "",
    nazionalita = "",
    nazioneNascita = "",
    natoIl = "",
    natoA = "",
    codiceFiscale = "",
    recapiti = [],
    residenza = {},
  } = privatoData;
  let { cell, emailCasa } = recapiti.reduce((acc, currentRecapiti) => {
    let length = Object.entries(acc).length;
    if (length === 2) return acc;
    if (currentRecapiti.tipoCode === "TEC") {
      acc = {
        ...acc,
        cell: currentRecapiti.recapito,
      };
    } else if (currentRecapiti.tipoCode === "Posta Elettronica") {
      acc = {
        ...acc,
        emailCasa: currentRecapiti.recapito,
      };
    }
    return acc;
  }, {});
  let { indirizzo = "", comune = "", stato = "" } = residenza || {};

  let residenzaOption = getCityByName(cities)(comune);
  let { rlData: residenzaCityData = {} } = residenzaOption || {};
  let {
    province: residenzaProv = "",
    cap: residenzaCap = "",
  } = residenzaCityData;
  let anagraficiOption = getCityByName(cities)(natoA);
  let { rlData: anagraficiCityData = {} } = anagraficiOption || {};
  let {
    province: anagraficiProv = "",
    cap: anagraficiCap = "",
  } = anagraficiCityData;

  let sturctureProspectData = {
    idSoggetto: idSoggetto,
    cognome: surname,
    nome: name,
    codFis: codiceFiscale,
    banca: currentCodiceBank,
    codice: currentCodice,
    via: indirizzo,
    citta: residenzaOption,
    cap: residenzaCap,
    prov: residenzaProv,
    stato: getNationByProperty(nations)("name", stato),
    emailCasa: emailCasa,
    cell: cell,
    natoIl: natoIl,
    daCitta: anagraficiOption,
    daCap: anagraficiCap,
    daProv: anagraficiProv,
    nazionalita: getNationByProperty(nations)("nazionalita", nazionalita),
    daStato: getNationByProperty(nations)("name", nazioneNascita),
  };
  return sturctureProspectData;
};

const getStructuredDataForNonCliente = (
  currentInteraction = "noInteraction",
  anagrafica = {},
  prospectData = {}
) => {
  const { cities = [] } = exposedGetState().common;
  const { data: notClientData } = getNotClientDataByInteraction(anagrafica)(
    currentInteraction
  );
  let {
    name = "",
    surname = "",
    dataNascita = "",
    citta = "",
    recapitoCell = "",
    recapitoMail = "",
  } = notClientData;
  let anagraficiOption = getCityByName(cities)(citta);
  let { rlData: anagraficiCityData = {} } = anagraficiOption || {};
  let {
    province: anagraficiProv = "",
    cap: anagraficiCap = "",
  } = anagraficiCityData;
  let sturctureProspectData = {};

  const { loadDataFromAnagrafica } = getProspectDataById(prospectData)(
    currentInteraction , privatoProspectData
  );

  if (loadDataFromAnagrafica) {
    sturctureProspectData = {
      ...sturctureProspectData,
      cognome: surname,
      nome: name,
      emailCasa: recapitoMail,
      cell: recapitoCell,
      natoIl: dataNascita,
      daCitta: anagraficiOption,
      daCap: anagraficiCap,
      daProv: anagraficiProv,
    };
  } else {
    const {
      cognome: currentCognome,
      nome: currentNome,
      emailCasa: currenteMailCasa,
      cell: currentCell,
      natoIl: currentNatoIl,
      daCitta: currentDaCitta,
      daCap: currentDaCap,
      daProv: currentDaProv,
    } = getProspectDataById(prospectData)(currentInteraction, privatoProspectData);
    sturctureProspectData = {
      ...sturctureProspectData,
      cognome: currentCognome ? currentCognome : surname,
      nome: currentNome ? currentNome : name,
      emailCasa: currenteMailCasa ? currenteMailCasa : recapitoMail,
      cell: currentCell ? currentCell : recapitoCell,
      natoIl: currentNatoIl ? currentNatoIl : dataNascita,
      daCitta: currentDaCitta ? currentDaCitta : anagraficiOption,
      daCap: currentDaCap ? currentDaCap : anagraficiCap,
      daProv: currentDaProv ? currentDaProv : anagraficiProv,
    };
  }
  return sturctureProspectData;
};

export const updateProspectDataByAziendaClientToggle = () => {

  const dispatch = exposedDispatch;
  const {
    currentInteraction = "noInteraction",
  } = exposedGetState().interaction;
  const { anagrafica } = exposedGetState().anagrafica;
  const { clientToggle = true } = getNotClientDataByInteraction(anagrafica)(
    currentInteraction
  );
  const { prospectData } = exposedGetState().prospect;
  const { loadDataFromAnagrafica } = getProspectDataById(prospectData)(
    currentInteraction,aziendaProspectData
  );
  if (clientToggle && !loadDataFromAnagrafica) return;
  const sturctureAziendaData =  clientToggle
                                ? getStructuredDataForAziendaCliente(currentInteraction, anagrafica)
                                : getStructuredDataForAziendaNonCliente(currentInteraction, anagrafica, prospectData) ;
  dispatch(
    updateProspectDataById({
      interactionId: currentInteraction,
      data: sturctureAziendaData,
      orginData : aziendaProspectData
    })
  );
  dispatch(
    updateProspectDataByProperty({
      interactionId: currentInteraction,
      data: {
        property: "loadDataFromAnagrafica",
        value: false,
      },
      orginData:aziendaProspectData
    })
  );

}  
export const updateProspectDataByPrivatoClientToggle = () => {
  const dispatch = exposedDispatch;
  const {
    currentInteraction = "noInteraction",
  } = exposedGetState().interaction;
  const { anagrafica } = exposedGetState().anagrafica;
  const { clientToggle = true } = getNotClientDataByInteraction(anagrafica)(
    currentInteraction
  );
  const { prospectData } = exposedGetState().prospect;
  const { loadDataFromAnagrafica } = getProspectDataById(prospectData)(
    currentInteraction,privatoProspectData
  );
  if (clientToggle && !loadDataFromAnagrafica) return;
  const sturctureProspectData = clientToggle
    ? getStructuredDataForCliente(currentInteraction, anagrafica)
    : getStructuredDataForNonCliente(
        currentInteraction,
        anagrafica,
        prospectData
      );
  dispatch(
    updateProspectDataById({
      interactionId: currentInteraction,
      data: sturctureProspectData,
      originData : privatoProspectData
    })
  );
  dispatch(
    updateProspectDataByProperty({
      interactionId: currentInteraction,
      data: {
        property: "loadDataFromAnagrafica",
        value: false,
      },
      orginData:privatoProspectData
    })
  );
};

export const getRequestDataForInserisci = (tabSelection,orginData) => {
  const {
    currentInteraction = "noInteraction",
  } = exposedGetState().interaction;
  const { prospectData } = exposedGetState().prospect;
  const {
    idSoggetto = "",
    cognome = "",
    nome = "",
    codFis = "",
    banca = "",
    codice = "",
    noteProspect = "",
    via = "",
    citta = null,
    cap = "",
    prov = "",
    stato = null,
    emailCasa = "",
    emailUff = "",
    cell = "",
    casa = "",
    faxCasa = "",
    ufficio = "",
    faxUfficio = "",
    natoIl = "",
    daCitta = null,
    daCap = "",
    daProv = "",
    nazionalita = null,
    daStato = null,
    ragsoc = "",
    insegna = "",
    piva = ""
  } = getProspectDataById(prospectData)(currentInteraction,orginData);

  const {
    prodotto = null,
    tipoEsito = null,
  } = getProspectDataById(prospectData)(currentInteraction);
  const { label: prodottoLabel = "", value: prodottoValue = "" } =
    prodotto || {};
  const { label: tipoEsitoLabel = "", value: tipoEsitoValue = "" } =
    tipoEsito || {};
  const { value: cittaValue = "" } = citta || {};
  const { value: statoValue = "" } = stato || {};
  const { value: daCittaValue = "" } = daCitta || {};
  const { value: daStatoValue = "" } = daStato || {};
  const { value: nazionalitaValue = "" } = nazionalita || {};
  let requestData =  {
    prodottoId: prodottoValue + "",
    prodotto: prodottoLabel,
    tipoEsitoId: tipoEsitoValue + "",
    tipoEsito: tipoEsitoLabel,
    // IDENTITY
    soggettoId: idSoggetto,
    banca: banca,
    codiceIb: codice,
    prospectNote: noteProspect,
    cogNome: cognome,
    nome: nome,
    codiceFiscale: codFis,
    // RESIDENZA
    resVia: via,
    resCitta: cittaValue,
    resCap: cap,
    resProvincia: prov,
    resStato: statoValue,
    // RECAPITI
    emailCasa: emailCasa,
    emailLavoro: emailUff, // UFFICIO
    telCellulare: cell,
    telCasa: casa,
    faxCasa: faxCasa,
    telLavoro: ufficio, // UFFICIO
    faxLavoro: faxUfficio, // UFFICIO
    // DATI
    nasCitta: daCittaValue,
    nasStato: daStatoValue,
    nasCap: daCap,
    nasProvincia: daProv,
    tipoSoggetto: tabSelection == "privatoProspect" ? "PRIVATO":"AZIENDA",
    nazionalita: nazionalitaValue,
    dataNascita: natoIl, // NAT IL
    interactionId: currentInteraction, // NEED ADD
  };
  if(tabSelection == "privatoProspect"){
    requestData.tipoSoggetto = "PRIVATO";
    requestData.cogNome = cognome;
    requestData.nome = nome;
    requestData.codFis = codFis;
  }else{
    requestData.tipoSoggetto = "AZIENDA";
    requestData.ragSoc = ragsoc;
    requestData.insegna = insegna;
    requestData.partitaIva = piva;
  }
  return requestData;
};

export const httpGetProspectProdotto = async () => {
  let httpClient = new HttpClient();
  httpClient.setUrl(beServiceUrls().prospectProdotto);
  await httpClient
    .httpGet()
    .then((response) => {
      const { status = "", products = [] } = response;
      if (status === "OK") {
        const dispatch = exposedDispatch;
        dispatch(setProspectProdotto({ prospectProdotto: products }));
      } else {
        toast.warn("Warning: httpGetProspectProdotto Service", {
          containerId: globalAlertId,
        });
      }
    })
    .catch((err) => {
      toast.error("Error: httpGetProspectProdotto Service", {
        containerId: globalAlertId,
      });
    });
};

export const httpGetProspectTipoEsiti = async () => {
  let httpClient = new HttpClient();
  httpClient.setUrl(beServiceUrls().prospectTipoEsiti);
  await httpClient
    .httpGet()
    .then((response) => {
      const { status = "", esiti = [] } = response;
      if (status === "OK") {
        const dispatch = exposedDispatch;
        dispatch(setProspectTipoEsiti({ prospectTipoEsiti: esiti }));
      } else {
        toast.warn("Warning: httpGetProspectTipoEsiti Service", {
          containerId: globalAlertId,
        });
      }
    })
    .catch((err) => {
      toast.error("Error: httpGetProspectTipoEsiti Service", {
        containerId: globalAlertId,
      });
    });
};

export const httpPostProspectInserisci = async (bodyRequest = {}) => {
  const dispatch = exposedDispatch;
  let httpClient = new HttpClient();
  httpClient.setUrl(beServiceUrls().prospectInserisci);
  dispatch(toggleSpinnerById(prospectModalSpinnerId));
  let responseData = await httpClient
    .httpPost(bodyRequest)
    .then((response) => {
      const { status = "" } = response;
      if (status === "OK") {
        const { prospectInsertNote = "" } = response.response || {};
        const {
          currentInteraction = "noInteraction",
        } = exposedGetState().interaction;
        prospectInsertNote &&
          dispatch(
            updateProspectDataByProperty({
              interactionId: currentInteraction,
              data: {
                property: "prospectCrmNote",
                value: prospectInsertNote,
              },
            })
          );
        toast.success("Success", { containerId: prospectModalAlertId });
      } else {
        toast.warn("Warning", { containerId: prospectModalAlertId });
      }
      return response;
    })
    .catch((err) => {
      toast.error("Error", { containerId: prospectModalAlertId });
      throw err;
    })
    .finally(() => {
      dispatch(toggleSpinnerById(prospectModalSpinnerId));
    });
  return responseData;
};

const prospectService = () => {
  const prospectEventListeners = (event) => {
    if (event.origin !== pureCloudOrigin) return;
    let message = JSON.parse(event.data);
    console.log("prospectEventListeners: ", message);
    const dispatch = exposedDispatch;
    if (message && message.type == "interactionSubscription") {
      let { data: interactionData = {} } = message;
      let { category = "", interaction = {} } = interactionData;

      switch (category) {
        case "add":
          dispatch(addProspectDataById({ interactionId: interaction.id }));
          break;
        case "change":
          break;
        case "connect":
          break;
        case "disconnect":
          break;
        case "acw":
          break;
        case "deallocate":
          dispatch(
            removeProspectDataById({
              interactionId: interaction.id,
            })
          );
          break;
        default:
          console.log("No Event Matched");
      }
    }
  };

  return { prospectEventListeners };
};

export const { prospectEventListeners } = prospectService();
