import React from "react";
import { useDispatch, useSelector } from "react-redux";
import CheckBox from "../../../../CommonComponents/Forms/CheckBox";
import FormFieldHandler from "../../../../CommonComponents/Forms/FormFieldHandler";
import { exposedGetState } from "../../../../Store/store";
import {
  getProspectDataById,
  updateProspectDataByProperty,
} from "../../prospectSlice";

const PresaVisioneField = (props) => {
  const { formFields = new FormFieldHandler() } = props;
  const { currentInteraction = "noInteraction" } = useSelector(
    (state) => state.interaction
  );

  const { prospectData } = useSelector((state) => state.prospect);

  const { presaVisione = false } = getProspectDataById(prospectData)(
    currentInteraction
  );
  const dispatch = useDispatch();

  let presaVisioneField = {
    uniqueID: "presaVisioneField",
    label: "Presa Visione/Effettuata Lettura",
    labelClass: "consenso-privacy-label",
    readonly: false,
    visible: true,
    disabled: false,
    checked: presaVisione,
    setValue: (obj) => {
      console.log("setValue", obj);
      const { currentInteraction } = exposedGetState().interaction;
      dispatch(
        updateProspectDataByProperty({
          interactionId: currentInteraction,
          data: {
            property: "presaVisione",
            value: obj.currentValue,
          },
        })
      );
    },
    form: formFields,
  };

  return <CheckBox configuration={presaVisioneField} />;
};

export default PresaVisioneField;
