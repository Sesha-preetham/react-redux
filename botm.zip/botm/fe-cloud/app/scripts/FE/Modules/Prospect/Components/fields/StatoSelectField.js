import React from "react";
import { useDispatch, useSelector } from "react-redux";
import FormFieldHandler from "../../../../CommonComponents/Forms/FormFieldHandler";
import SelectField from "../../../../CommonComponents/Forms/SelectField";
import { exposedGetState } from "../../../../Store/store";
import { reduceToOptions } from "../../../../Utils/CommonUtil";
import {
  getProspectDataById,
  updateProspectDataByProperty,
} from "../../prospectSlice";

const StatoSelectField = (props) => {
  const { formFields = new FormFieldHandler() , orginData  } = props;

  const { nations = [] } = useSelector((state) => state.common);

  const { currentInteraction = "noInteraction" } = useSelector(
    (state) => state.interaction
  );

  const { prospectData } = useSelector((state) => state.prospect);

  const { stato = null } = getProspectDataById(prospectData)(
    currentInteraction,orginData
  );

  const dispatch = useDispatch();

  let statoSelectField = {
    uniqueID: "statoSelectField",
    multiSelect: false,
    label: "",
    placeHolder: "Seleziona Stato",
    readonly: false,
    visible: true,
    disabled: false,
    value: stato,
    options: reduceToOptions(nations)("name", "name"),
    searchEnabled: true,
    setValue: (obj) => {
      console.log("setValue", obj);
      const { currentInteraction } = exposedGetState().interaction;
      dispatch(
        updateProspectDataByProperty({
          interactionId: currentInteraction,
          data: {
            property: "stato",
            value: obj.currentValue,
          },
          orginData : orginData
        })
      );
    },
    form: formFields,
  };
  return <SelectField configuration={statoSelectField} />;
};

export default StatoSelectField;
