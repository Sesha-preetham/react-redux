import React from "react";
import { useDispatch, useSelector } from "react-redux";
import FormFieldHandler from "../../../../CommonComponents/Forms/FormFieldHandler";
import TextField from "../../../../CommonComponents/Forms/TextField";
import { exposedGetState } from "../../../../Store/store";
import {
  getProspectDataById,
  updateProspectDataByProperty,
} from "../../prospectSlice";

const FaxUfficioField = (props) => {
  const { formFields = new FormFieldHandler() , orginData} = props;

  const { currentInteraction = "noInteraction" } = useSelector(
    (state) => state.interaction
  );

  const { prospectData } = useSelector((state) => state.prospect);

  const { faxUfficio = "" } = getProspectDataById(prospectData)(
    currentInteraction , orginData
  );

  const dispatch = useDispatch();

  let faxUfficioField = {
    uniqueID: "faxUfficioField",
    placeHolder: "Fax Ufficio...",
    readonly: false,
    visible: true,
    value: faxUfficio,
    setValue: (obj) => {
      console.log("setValue", obj);
      const { currentInteraction } = exposedGetState().interaction;
      dispatch(
        updateProspectDataByProperty({
          interactionId: currentInteraction,
          data: {
            property: "faxUfficio",
            value: obj.currentValue,
          },
          orginData : orginData
        })
      );
    },
    validation: {
      mandatory: false,
      type: "Alphanumeric",
    },
    feedback: {
      enable: true,
      component: () => <>Fax Ufficio dovrebbe essere valido alfanumerico.</>,
    },
    form: formFields,
  };

  return <TextField configuration={faxUfficioField} />;
};

export default FaxUfficioField;
