import React from "react";
import { useDispatch, useSelector } from "react-redux";
import FormFieldHandler from "../../../../CommonComponents/Forms/FormFieldHandler";
import SelectField from "../../../../CommonComponents/Forms/SelectField";
import { exposedGetState } from "../../../../Store/store";
import { reduceToOptions } from "../../../../Utils/CommonUtil";
import {
  getProspectDataById,
  updateProspectDataByProperty,
} from "../../prospectSlice";

const DACittaSelectField = (props) => {
  const { formFields = new FormFieldHandler() , orginData } = props;

  const { cities = [] } = useSelector((state) => state.common);

  const { currentInteraction = "noInteraction" } = useSelector(
    (state) => state.interaction
  );

  const { prospectData } = useSelector((state) => state.prospect);

  const { daCitta = null } = getProspectDataById(prospectData)(
    currentInteraction,orginData
  );

  const dispatch = useDispatch();

  let daCittaSelectField = {
    uniqueID: "daCittaSelectField",
    multiSelect: false,
    label: "",
    placeHolder: "Seleziona Citta",
    readonly: false,
    visible: true,
    disabled: false,
    value: daCitta,
    options: reduceToOptions(cities)("name", "name"),
    searchEnabled: true,
    setValue: (obj) => {
      console.log("setValue", obj);
      const { currentInteraction } = exposedGetState().interaction;
      let { rlData: anagraficiCityData = {} } = obj.currentValue || {};
      let {
        province: anagraficiProv = "",
        cap: anagraficiCap = "",
      } = anagraficiCityData;
      dispatch(
        updateProspectDataByProperty({
          interactionId: currentInteraction,
          data: {
            property: "daCitta",
            value: obj.currentValue,
          },
          orginData : orginData
        })
      );
      dispatch(
        updateProspectDataByProperty({
          interactionId: currentInteraction,
          data: {
            property: "daCap",
            value: anagraficiCap,
          },
          orginData : orginData
        })
      );
      dispatch(
        updateProspectDataByProperty({
          interactionId: currentInteraction,
          data: {
            property: "daProv",
            value: anagraficiProv,
          },
          orginData : orginData
        })
      );
      formFields.getField("daCapField") &&
        formFields.getField("daCapField").theField.setValue(anagraficiCap);
      formFields.getField("daCapField") &&
        formFields.getField("daProvField").theField.setValue(anagraficiProv);
    },
    form: formFields,
  };
  return <SelectField configuration={daCittaSelectField} />;
};

export default DACittaSelectField;
