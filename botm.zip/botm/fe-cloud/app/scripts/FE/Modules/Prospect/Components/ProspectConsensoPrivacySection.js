import React from "react";
import { useSelector } from "react-redux";
import FormFieldHandler from "../../../CommonComponents/Forms/FormFieldHandler";
import { getPrivatoDataByInteraction } from "../../Anagrafica/anagraficaSlice";
import {
  getInternalWidgetConfigByIdAndCode,
  prospectWidgetCode,
} from "../../Widgets/internalWidgetsSlice";
import PresaVisioneField from "./fields/PresaVisioneField";

const ProspectConsensoPrivacySection = (props) => {
  const { formFields = new FormFieldHandler() } = props;

  const { currentInteraction = "noInteraction" } = useSelector(
    (state) => state.interaction
  );
  const { anagrafica: anagraficaObj } = useSelector(
    (state) => state.anagrafica
  );

  const { internalWidgets } = useSelector((state) => state.internalWidgets);

  const {
    widgetConfig: prospectConfigObj,
  } = getInternalWidgetConfigByIdAndCode(internalWidgets)(
    currentInteraction,
    prospectWidgetCode
  );
  const { privacySenteces = {} } = prospectConfigObj || {};

  const { selectedIbCode = {} } = getPrivatoDataByInteraction(anagraficaObj)(
    currentInteraction
  );
  const { rlData = {} } = selectedIbCode;
  let { bank = "" } = rlData;
  bank = bank.trim().toUpperCase() || "BSE";

  return (
    <div className="d-flex flex-column">
      <div
        className="H3-11 mb-3"
        dangerouslySetInnerHTML={{
          __html: privacySenteces[bank] || "",
        }}
      />
      <div className="d-flex justify-content-center">
        <div>
          <PresaVisioneField formFields={formFields} />
        </div>
      </div>
    </div>
  );
};

export default ProspectConsensoPrivacySection;
