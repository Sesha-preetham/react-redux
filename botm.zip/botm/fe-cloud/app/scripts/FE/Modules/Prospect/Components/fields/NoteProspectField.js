import React from "react";
import { useDispatch, useSelector } from "react-redux";
import FormFieldHandler from "../../../../CommonComponents/Forms/FormFieldHandler";
import TextArea from "../../../../CommonComponents/Forms/TextArea";
import { exposedGetState } from "../../../../Store/store";
import {
  getProspectDataById,
  updateProspectDataByProperty,
} from "../../prospectSlice";

const NoteProspectField = (props) => {
  const { formFields = new FormFieldHandler() , orginData} = props;

  const { currentInteraction = "noInteraction" } = useSelector(
    (state) => state.interaction
  );

  const { prospectData } = useSelector((state) => state.prospect);

  const { noteProspect = "" } = getProspectDataById(prospectData)(
    currentInteraction,orginData
  );

  const dispatch = useDispatch();

  let noteProspectField = {
    uniqueID: "noteProspectField",
    placeHolder: "Note Prospect....",
    readonly: false,
    visible: true,
    value: noteProspect,
    setValue: (obj) => {
      console.log("setValue", obj);
      const { currentInteraction } = exposedGetState().interaction;
      dispatch(
        updateProspectDataByProperty({
          interactionId: currentInteraction,
          data: {
            property: "noteProspect",
            value: obj.currentValue,
          },
          orginData : orginData
        })
      );
    },
    validation: {
      mandatory: false,
    },
    form: formFields,
  };

  return <TextArea configuration={noteProspectField} />;
};

export default NoteProspectField;
