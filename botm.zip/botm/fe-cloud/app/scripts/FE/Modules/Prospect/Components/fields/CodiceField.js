import React from "react";
import { useDispatch, useSelector } from "react-redux";
import FormFieldHandler from "../../../../CommonComponents/Forms/FormFieldHandler";
import TextField from "../../../../CommonComponents/Forms/TextField";
import { exposedGetState } from "../../../../Store/store";
import {
  getProspectDataById,
  updateProspectDataByProperty,
} from "../../prospectSlice";

const CodiceField = (props) => {
  const { formFields = new FormFieldHandler() ,orginData} = props;

  const { currentInteraction = "noInteraction" } = useSelector(
    (state) => state.interaction
  );

  const { prospectData } = useSelector((state) => state.prospect);

  const { codice = "" } = getProspectDataById(prospectData)(currentInteraction,orginData);

  const dispatch = useDispatch();

  let codiceField = {
    uniqueID: "codiceField",
    placeHolder: "Codice...",
    readonly: false,
    visible: true,
    value: codice,
    setValue: (obj) => {
      console.log("setValue", obj);
      const { currentInteraction } = exposedGetState().interaction;
      dispatch(
        updateProspectDataByProperty({
          interactionId: currentInteraction,
          data: {
            property: "codice",
            value: obj.currentValue,
          },
          orginData : orginData
        })
      );
    },
    validation: {
      mandatory: false,
      type: "Numeric",
    },
    feedback: {
      enable: true,
      component: () => <>Codice è numerico.</>,
    },
    form: formFields,
  };

  return <TextField configuration={codiceField} />;
};

export default CodiceField;
