import React, { useState } from "react";
import { useSelector } from "react-redux";
import FormFieldHandler from "../../../CommonComponents/Forms/FormFieldHandler";
import RowBluCollapse from "../../../CommonComponents/RowBluCollapse/RowBluCollapse";
import { getProspectDataById } from "../prospectSlice";
import ProspectLabelValue from "./common/ProspectLabelValue";
import CasaField from "./fields/CasaField";
import CellField from "./fields/CellField";
import EmailCasaField from "./fields/EmailCasaField";
import EmailUffField from "./fields/EmailUffField";
import FaxCasaField from "./fields/FaxCasaField";
import FaxUfficioField from "./fields/FaxUfficioField";
import UfficioField from "./fields/UfficioField";

const ProspectRecapitiSection = (props) => {
  const { formFields = new FormFieldHandler() , orginData } = props;

  const [showCollapse, setShowCollapse] = useState(true);

  const { currentInteraction = "noInteraction" } = useSelector(
    (state) => state.interaction
  );

  const { prospectData } = useSelector((state) => state.prospect);

  const {
    emailCasa = "",
    emailUff = "",
    cell = "",
    casa = "",
    faxCasa = "",
    ufficio = "",
    faxUfficio = "",
  } = getProspectDataById(prospectData)(currentInteraction,orginData);

  return (
    <RowBluCollapse
      show={showCollapse}
      rowBlu={{ rowBluTitle: "Recapiti" }}
      collapse={{ collapseDefaultShow: true }}
      events={{
        handleOnIconClick: () => {
          setShowCollapse(!showCollapse);
        },
        handleOnCollapseEntered: () => {},
        handleOnCollapseExited: () => {},
      }}
    >
      <div className="d-flex flex-column">
        <ProspectLabelValue
          label="Email Casa"
          value={emailCasa}
          field={<EmailCasaField formFields={formFields} orginData={orginData}/>}
        />
        <ProspectLabelValue
          label="Email Uff"
          value={emailUff}
          field={<EmailUffField formFields={formFields} orginData={orginData} />}
        />
        <ProspectLabelValue
          label="Cell"
          value={cell}
          field={<CellField formFields={formFields} orginData={orginData} />}
        />
        <ProspectLabelValue
          label="Casa"
          value={casa}
          field={<CasaField formFields={formFields}  orginData={orginData}/>}
        />
        <ProspectLabelValue
          label="Fax Casa"
          value={faxCasa}
          field={<FaxCasaField formFields={formFields}  orginData={orginData}/>}
        />
        <ProspectLabelValue
          label="Ufficio"
          value={ufficio}
          field={<UfficioField formFields={formFields}  orginData={orginData}/>}
        />
        <ProspectLabelValue
          label="Fax Ufficio"
          value={faxUfficio}
          field={<FaxUfficioField formFields={formFields}  orginData={orginData}/>}
        />
      </div>
    </RowBluCollapse>
  );
};

export default ProspectRecapitiSection;
