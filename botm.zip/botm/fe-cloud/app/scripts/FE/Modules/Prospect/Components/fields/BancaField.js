import React from "react";
import { useDispatch, useSelector } from "react-redux";
import FormFieldHandler from "../../../../CommonComponents/Forms/FormFieldHandler";
import TextField from "../../../../CommonComponents/Forms/TextField";
import { exposedGetState } from "../../../../Store/store";
import {
  getProspectDataById,
  updateProspectDataByProperty,
} from "../../prospectSlice";

const BancaField = (props) => {
  const { formFields = new FormFieldHandler() ,orginData } = props;

  const { currentInteraction = "noInteraction" } = useSelector(
    (state) => state.interaction
  );

  const { prospectData } = useSelector((state) => state.prospect);

  const { banca = "" } = getProspectDataById(prospectData)(currentInteraction,orginData);

  const dispatch = useDispatch();

  let bancaField = {
    uniqueID: "bancaField",
    placeHolder: "Banca...",
    readonly: false,
    visible: true,
    value: banca,
    setValue: (obj) => {
      console.log("setValue", obj);
      const { currentInteraction } = exposedGetState().interaction;
      dispatch(
        updateProspectDataByProperty({
          interactionId: currentInteraction,
          data: {
            property: "banca",
            value: obj.currentValue,
          },
          orginData : orginData
        })
      );
    },
    validation: {
      mandatory: false,
      type: "Alphabetic",
    },
    feedback: {
      enable: true,
      component: () => <>Banca è alfabetico.</>,
    },
    form: formFields,
  };

  return <TextField configuration={bancaField} />;
};

export default BancaField;
