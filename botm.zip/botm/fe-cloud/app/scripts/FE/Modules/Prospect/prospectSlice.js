import { createSlice } from "@reduxjs/toolkit";

let initialState = {
  prospectProdotto: [],
  prospectTipoEsiti: [],
  prospectData: {
    noInteraction: {
      // DATA CONTROL
      prodotto: null,
      tipoEsito: null,
      privatoProspectData:{
        cognome: "",
        nome: "",
        codFis: "",
        banca: "",
        codice: "",
        noteProspect: "",
        via: "",
        citta: null,
        cap: "",
        prov: "",
        stato: null,
        emailCasa: "",
        emailUff: "",
        cell: "",
        casa: "",
        faxCasa: "",
        ufficio: "",
        faxUfficio: "",
        natoIl: "",
        daCitta: null,
        daCap: "",
        daProv: "",
        nazionalita: null,
        daStato: null,
        soggettoId: "",
        prospectCrmNote: "",
        ragsoc : "",
        insegna : "",
        piva : "",
        showProspectModal: false,
        loadDataFromAnagrafica: false
      },
      aziendaProspectData:{
        denominazione : "",
        ragsoc : "",
        insegna : "",
        piva : "",
        banca: "",
        codice: "",
        noteProspect: "",
        via: "",
        citta: null,
        cap: "",
        prov: "",
        stato: null,
        emailCasa: "",
        emailUff: "",
        cell: "",
        casa: "",
        faxCasa: "",
        ufficio: "",
        faxUfficio: "",
        natoIl: "",
        daCitta: null,
        daCap: "",
        daProv: "",
        nazionalita: null,
        daStato: null,
        soggettoId: "",
        prospectCrmNote: "",
        showProspectModal: false,
        loadDataFromAnagrafica: false
      },
      // COMPONENT CONTROL
      consensoPrivacy: true,
      presaVisione: false,
      privatoPropestClientDisabled: true,
      privatoPropestNotClientDisabled: true,
      aziendaProspectClientDisabled: true,
      aziendaProspectNotClientDisabled : true,      
    },
  },
};

const prospectSlice = createSlice({
  name: "prospect",
  initialState,
  reducers: {
    addProspectDataById(state, action) {
      const { payload = {} } = action;
      const { interactionId = "noInteraction" } = payload;
      if (!interactionId) return;
      if (!state.prospectData[interactionId])
        state.prospectData[interactionId] =
          initialState.prospectData.noInteraction;
    },
    updateProspectDataById(state, action) {
      const { payload = {} } = action;
      const { interactionId = "noInteraction",orginData=privatoProspectData, data = {} } = payload;
      if (!interactionId || !state.prospectData[interactionId]) return;
      const {
        denominazione = "",
        idSoggetto = "",
        cognome = "",
        nome = "",
        codFis = "",
        ragsoc = "",
        insegna = "",
        piva = "",
        banca = "",
        codice = "",
        noteProspect = "",
        via = "",
        citta = null,
        cap = "",
        prov = "",
        stato = null,
        emailCasa = "",
        emailUff = "",
        cell = "",
        casa = "",
        faxCasa = "",
        ufficio = "",
        faxUfficio = "",
        natoIl = "",
        daCitta = null,
        daCap = "",
        daProv = "",
        nazionalita = null,
        daStato = null,
      } = data;
      state.prospectData[interactionId][orginData].denominazione = denominazione || "";
      state.prospectData[interactionId][orginData].idSoggetto = idSoggetto || "";
      state.prospectData[interactionId][orginData].cognome = cognome || "";
      state.prospectData[interactionId][orginData].nome = nome || "";
      state.prospectData[interactionId][orginData].codFis = codFis || "";
      state.prospectData[interactionId][orginData].ragsoc = denominazione || "";
      state.prospectData[interactionId][orginData].insegna = insegna || "";
      state.prospectData[interactionId][orginData].piva = piva || "";
      state.prospectData[interactionId][orginData].banca = banca || "";
      state.prospectData[interactionId][orginData].codice = codice || "";
      state.prospectData[interactionId][orginData].noteProspect = noteProspect || "";
      state.prospectData[interactionId][orginData].via = via || "";
      state.prospectData[interactionId][orginData].citta = citta || null;
      state.prospectData[interactionId][orginData].cap = cap || "";
      state.prospectData[interactionId][orginData].prov = prov || "";
      state.prospectData[interactionId][orginData].stato = stato || null;
      state.prospectData[interactionId][orginData].emailCasa = emailCasa || "";
      state.prospectData[interactionId][orginData].emailUff = emailUff || "";
      state.prospectData[interactionId][orginData].cell = cell || "";
      state.prospectData[interactionId][orginData].casa = casa || "";
      state.prospectData[interactionId][orginData].faxCasa = faxCasa || "";
      state.prospectData[interactionId][orginData].ufficio = ufficio || "";
      state.prospectData[interactionId][orginData].faxUfficio = faxUfficio || "";
      state.prospectData[interactionId][orginData].natoIl = natoIl || "";
      state.prospectData[interactionId][orginData].daCitta = daCitta || null;
      state.prospectData[interactionId][orginData].daCap = daCap || "";
      state.prospectData[interactionId][orginData].daProv = daProv || "";
      state.prospectData[interactionId][orginData].nazionalita = nazionalita || null;
      state.prospectData[interactionId][orginData].daStato = daStato || null;
    },
    updateProspectDataByProperty(state, action) {
      const { payload = {} } = action;
      const { interactionId = "noInteraction", orginData , data = {} } = payload;
      if (!interactionId) return;
      const { property,value } = data;
      if (
        !property ||
        value === undefined ||
        !state.prospectData[interactionId]
      )
        return;
      if(!orginData){
        state.prospectData[interactionId][property] = value;
      }else{
        state.prospectData[interactionId][orginData][property] = value;
      }  
    },
    removeProspectDataById(state, action) {
      const { payload = {} } = action;
      const { interactionId = "noInteraction" } = payload;
      if (!interactionId || !state.prospectData[interactionId]) return;
      state.prospectData = Object.entries(state.prospectData).reduce(
        (acc, [key, value]) => {
          if (key != interactionId) {
            acc[key] = value;
          }
          return acc;
        },
        {}
      );
    },
    setProspectProdotto(state, action) {
      const { payload = {} } = action;
      const { prospectProdotto = [] } = payload;
      state.prospectProdotto = prospectProdotto;
    },
    setProspectTipoEsiti(state, action) {
      const { payload = {} } = action;
      const { prospectTipoEsiti = [] } = payload;
      state.prospectTipoEsiti = prospectTipoEsiti;
    },
    resetProspectData(state) {
      state = initialState;
    },
  },
});

export const {
  updateProspectDataById,
  addProspectDataById,
  updateProspectDataByProperty,
  removeProspectDataById,
  setProspectProdotto,
  setProspectTipoEsiti,
  resetProspectData,
} = prospectSlice.actions;


export const aziendaProspectData = "aziendaProspectData";
export const   privatoProspectData = "privatoProspectData";

export const getProspectDataById = (prospectData = {}) => {
  return (id = "noInteraction",orginData) => {
    if (orginData && prospectData[id]) {
      return prospectData[id][orginData];
    }else if (prospectData[id]) {
      return prospectData[id];
    }
    return initialState.prospectData.noInteraction;
  };
};

export const getCityByName = (cities = []) => {
  return (name = "") => {
    if (!name) return null;

    let foundOption = cities.find((currentCity) => {
      return currentCity.name === name.toUpperCase();
    });
    if (foundOption) {
      foundOption = {
        value: foundOption.name,
        label: foundOption.name,
        rlData: foundOption,
      };
    }
    return foundOption || null;
  };
};

export const getNationByProperty = (nations = []) => {
  return (property = "", value = "") => {
    if (!property || !value) return null;

    let foundOption = nations.find((currentNation) => {
      return currentNation[property] === value.toUpperCase();
    });
    if (foundOption) {
      foundOption = {
        value: foundOption[property],
        label: foundOption[property],
        rlData: foundOption,
      };
    }
    return foundOption || null;
  };
};

export default prospectSlice.reducer;
