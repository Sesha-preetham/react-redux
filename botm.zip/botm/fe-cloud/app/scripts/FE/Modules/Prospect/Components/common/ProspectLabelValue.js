import React, { useState } from "react";
import IconLeftArrowBlue from "../../../../CommonComponents/Common/Icons/IconLeftArrowBlue";
import IconRightArrowBlue from "../../../../CommonComponents/Common/Icons/IconRightArrowBlue";

const ProspectLabelValue = (props) => {
  const { label = "", value = "", field } = props;

  const [showRightIcon, setShowRightIcon] = useState(false);
  const [showField, setShowField] = useState(true);
  const [showLeftIcon, setShowLeftIcon] = useState(false);

  return (
    <div className="d-flex">
      <div className={`d-flex flex-column prospect-content my-2`}>
        <div className={`prospect-content-label`}>{label}</div>
        <div
          className={`prospect-content-text`}
          onMouseEnter={() => {
            !showField && setShowRightIcon(true);
          }}
          onMouseLeave={() => {
            !showField && setShowRightIcon(false);
          }}
        >
          <span
            className="word-warp"
            dangerouslySetInnerHTML={{ __html: value || "None" }}
          />
          <span
            className={`hand-cursor ${
              showRightIcon ? "show-icon" : "hide-icon"
            }`}
          >
            <IconRightArrowBlue
              configuration={{
                onClick: (active) => {
                  setShowField(true);
                  setShowRightIcon(false);
                },
              }}
            />
          </span>
        </div>
      </div>
      {showField && field && (
        <div
          className="d-flex prospect-field"
          onMouseEnter={() => {
            showField && setShowLeftIcon(true);
          }}
          onMouseLeave={() => {
            showField && setShowLeftIcon(false);
          }}
        >
          <div
            className={`hand-cursor padding-top-6px ${
              showLeftIcon ? "show-icon" : "hide-icon"
            }`}
          >
            <IconLeftArrowBlue
              configuration={{
                onClick: (active) => {
                  setShowField(false);
                  setShowLeftIcon(false);
                },
              }}
            />
          </div>
          <div className="flex-fill">{field}</div>
        </div>
      )}
    </div>
  );
};

export default ProspectLabelValue;
