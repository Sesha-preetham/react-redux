import React from "react";
import { useDispatch, useSelector } from "react-redux";
import FormFieldHandler from "../../../../CommonComponents/Forms/FormFieldHandler";
import SelectField from "../../../../CommonComponents/Forms/SelectField";
import { exposedGetState } from "../../../../Store/store";
import { reduceToOptions } from "../../../../Utils/CommonUtil";
import {
  getProspectDataById,
  updateProspectDataByProperty,
} from "../../prospectSlice";

const CittaSelectField = (props) => {
  const { formFields = new FormFieldHandler() , orginData  } = props;

  const { cities = [] } = useSelector((state) => state.common);
  const { currentInteraction = "noInteraction" } = useSelector(
    (state) => state.interaction
  );
  const { prospectData } = useSelector((state) => state.prospect);

  const { citta = null } = getProspectDataById(prospectData)(
    currentInteraction,orginData
  );

  const dispatch = useDispatch();

  let cittaSelectField = {
    uniqueID: "cittaSelectField",
    multiSelect: false,
    label: "",
    placeHolder: "Seleziona Citta",
    readonly: false,
    visible: true,
    disabled: false,
    value: citta,
    options: reduceToOptions(cities)("name", "name"),
    searchEnabled: true,
    setValue: (obj) => {
      console.log("setValue", obj);
      const { currentInteraction } = exposedGetState().interaction;
      let { rlData: residenzaCityData = {} } = obj.currentValue || {};
      let {
        province: residenzaProv = "",
        cap: residenzaCap = "",
      } = residenzaCityData;
      dispatch(
        updateProspectDataByProperty({
          interactionId: currentInteraction,
          data: {
            property: "citta",
            value: obj.currentValue,
          },
          orginData : orginData
        })
      );
      dispatch(
        updateProspectDataByProperty({
          interactionId: currentInteraction,
          data: {
            property: "cap",
            value: residenzaCap,
          },
          orginData : orginData
        })
      );
      dispatch(
        updateProspectDataByProperty({
          interactionId: currentInteraction,
          data: {
            property: "prov",
            value: residenzaProv,
          },
          orginData : orginData
        })
      );
      formFields.getField("capField") &&
        formFields.getField("capField").theField.setValue(residenzaCap);
      formFields.getField("provField") &&
        formFields.getField("provField").theField.setValue(residenzaProv);
    },
    validation: {
      externalCheck: (value) => {
        if (value && !Array.isArray(value)) {
          return true;
        }
        return false;
      },
    },
    feedback: {
      enable: true,
      component: () => <>* Citta obbligatorio</>,
    },
    form: formFields,
  };
  return <SelectField configuration={cittaSelectField} />;
};

export default CittaSelectField;
