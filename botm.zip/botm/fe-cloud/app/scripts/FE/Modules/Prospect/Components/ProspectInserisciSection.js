import { current } from "@reduxjs/toolkit";
import React from "react";
import { useDispatch, useSelector } from "react-redux";
import { toast } from "react-toastify";
import { prospectModalAlertId } from "../../../CommonComponents/AlertToast/AlertIdConstants";
import AlertToast from "../../../CommonComponents/AlertToast/AlertToast";
import IconCopy from "../../../CommonComponents/Common/Icons/IconCopy";
import FormFieldHandler from "../../../CommonComponents/Forms/FormFieldHandler";
import MySpinner from "../../../CommonComponents/Spinner/MySpinner";
import { prospectModalSpinnerId } from "../../../CommonComponents/Spinner/spinnerSlice";
import { copyTextToClipboard } from "../../../Utils/CommonUtil";
import { getInteractionDetails } from "../../Interaction/interactionSlice";
import { getProspectDataById } from "../prospectSlice";
import {
  getRequestDataForInserisci,
  httpPostProspectInserisci,
} from "../Service";
import { httpPostWrapUpHashTagDetails } from "../../Consuntivazione/Service";
import { autoWrapProspect } from "../../../Utils/CommonConstantUtil";

const ProspectInserisciSection = (props) => {
  const { formFields = new FormFieldHandler() , orginData , tabSelection } = props;

  const { currentInteraction = "noInteraction", interactions = [] } = useSelector(
    (state) => state.interaction
  );

  const { prospectData } = useSelector((state) => state.prospect);

  const { prospectCrmNote = "" } = getProspectDataById(prospectData)(
    currentInteraction
  );

  const dispatch = useDispatch();

  const handleOnClickInserici = async () => {
    if (formFields.isFormValid()) {
      const { intxId , queueName } = getInteractionDetails(interactions)(currentInteraction);
      let requestData = getRequestDataForInserisci(tabSelection, orginData);
      requestData = {
        ...requestData,
        intxId: intxId
      };
    let checkStatus = await httpPostProspectInserisci(requestData);
    const { status = "" } = checkStatus;
    if(status === "OK" )
    {
      let wrapupRequest = {
        interactionId : currentInteraction,
        queueName,
        wrapupFunction : autoWrapProspect
      }
    httpPostWrapUpHashTagDetails(wrapupRequest);
    }
    } else {
      toast.warn(
        "Prodotto, Esito, Identificazione, Citta di residenza sono obbligatori !",
        {
          containerId: prospectModalAlertId,
        }
      );
    }
  };

  return (
    <>
      {prospectCrmNote && (
        <div className="d-flex justify-content-center my-2">
          <div className="row no-gutters d-flex justify-content-center">
            <div className="prospect-crm-label">
              Dati da CRM:
            </div>
            <div className="prospect-crm-value">
              <span className="mr-2">{prospectCrmNote}</span>
              <IconCopy
                configuration={{
                  onClick: () => {
                    copyTextToClipboard(prospectCrmNote);
                  },
                }}
              />
            </div>
          </div>
        </div>
      )}
      <div className="d-flex justify-content-center">
        <div className="w-50">
          <AlertToast
            configuration={{
              unqiueID: prospectModalAlertId,
              className: "inline-toast-container",
              transition: "flip",
            }}
          />
        </div>
      </div>
      <MySpinner uniqueID={prospectModalSpinnerId} />
      <div className="d-flex justify-content-center my-2">
        <div className="w-50">
          <button
            type="button"
            className={`btn Rectangle-Button-Blue w-100`}
            onClick={handleOnClickInserici}
          >
            Inserisci
          </button>
        </div>
      </div>
    </>
  );
};

export default ProspectInserisciSection;
