import React, { useEffect, useState } from "react";
import { withErrorBoundary } from "../../../../CommonComponents/ErrorBoundary/withErrorBoudary";
import MyModal from "../../../../CommonComponents/Modal/MyModal";
import ProspectContainer from "../../ProspectContainer";
import {
  httpGetProspectProdotto,
  httpGetProspectTipoEsiti,
} from "../../Service";

const ProspectModal = ({ configuration = {} } = props) => {
  const [mountProspect, setMountProspect] = useState(false);

  const {
    showProspectModal = false,
    handleOnHideProspectModal = () => {},
    handleOnEnteredProspectModal = () => {},
    handleOnExitedProspectModal = () => {},
    handleOnEnteringProspectModal = () => {},
    handleOnExitingProspectModal = () => {},
    orginTab = "privatoProspect",
    orginData ,
  } = configuration;

  const prospectModal = {
    uniqueID: "prospectModal",
    modalClass: "my-modal prospect-modal",
    dialogClassName: "modal-w",
    modalBodyClass: "my-modal-body modal-h",
    title: {
      content: "Prospect",
      class: "widget-title",
    },
    modalShow: showProspectModal,
    modalHeaderShow: true,
    backdrop: {
      enable: true,
    },
    events: {
      onHide: () => {
        console.log("multiClienteModal modal onHide");
        handleOnHideProspectModal();
      },
      onEntered: () => {
        console.log("multiClienteModal modal onEntered");
        setMountProspect(true);
        handleOnEnteredProspectModal();
      },
      onExited: () => {
        console.log("multiClienteModal modal onExited");
        setMountProspect(false);
        handleOnExitedProspectModal();
      },
      onEntering: () => {
        console.log("multiClienteModal modal onEntering");
        handleOnEnteringProspectModal();
      },
      onExiting: () => {
        console.log("multiClienteModal modal onExiting");
        handleOnExitingProspectModal();
      },
    },
  };

  useEffect(() => {
    httpGetProspectProdotto();
    httpGetProspectTipoEsiti();
  }, []);

  return (
    <MyModal configuration={prospectModal}>
      {mountProspect && <ProspectContainer orginTab = {orginTab} orginData = {orginData}/>}
    </MyModal>
  );
};

export default withErrorBoundary(ProspectModal);
