import React from "react";
import { useDispatch, useSelector } from "react-redux";
import FormFieldHandler from "../../../../CommonComponents/Forms/FormFieldHandler";
import SelectField from "../../../../CommonComponents/Forms/SelectField";
import { exposedGetState } from "../../../../Store/store";
import { reduceToOptions } from "../../../../Utils/CommonUtil";
import {
  getProspectDataById,
  updateProspectDataByProperty,
} from "../../prospectSlice";

const TipoEsitoSelectField = (props) => {
  const { formFields = new FormFieldHandler() } = props;

  const { currentInteraction = "noInteraction" } = useSelector(
    (state) => state.interaction
  );

  const { prospectTipoEsiti = [], prospectData } = useSelector(
    (state) => state.prospect
  );

  const { tipoEsito = null } = getProspectDataById(prospectData)(
    currentInteraction
  );
  const dispatch = useDispatch();

  let tipoEsitoField = {
    uniqueID: "tipoEsitoField",
    multiSelect: false,
    label: "",
    placeHolder: "Seleziona Tipo Esito",
    readonly: false,
    visible: true,
    disabled: false,
    value: tipoEsito,
    options: reduceToOptions(prospectTipoEsiti)("id", "value"),
    searchEnabled: true,
    setValue: (obj) => {
      console.log("setValue", obj);
      const { currentInteraction } = exposedGetState().interaction;
      dispatch(
        updateProspectDataByProperty({
          interactionId: currentInteraction,
          data: {
            property: "tipoEsito",
            value: obj.currentValue,
          },
        })
      );
    },
    validation: {
      externalCheck: (value) => {
        if (value && !Array.isArray(value)) {
          return true;
        }
        return false;
      },
    },
    feedback: {
      enable: true,
      component: () => <>* Esito obbligatorio</>,
    },
    form: formFields,
  };
  return <SelectField configuration={tipoEsitoField} />;
};

export default TipoEsitoSelectField;
