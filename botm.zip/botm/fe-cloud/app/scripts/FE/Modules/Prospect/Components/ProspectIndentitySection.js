import React, { useState } from "react";
import { useSelector } from "react-redux";
import { Tab, Tabs } from "react-bootstrap";
import FormFieldHandler from "../../../CommonComponents/Forms/FormFieldHandler";
import RowBluCollapse from "../../../CommonComponents/RowBluCollapse/RowBluCollapse";
import { getProspectDataById } from "../prospectSlice";
import ProspectLabelValue from "./common/ProspectLabelValue";
import BancaField from "./fields/BancaField";
import CodiceField from "./fields/CodiceField";
import CodiceFiscaleField from "./fields/CodiceFiscaleField";
import CognomeField from "./fields/CognomeField";
import NomeField from "./fields/NomeField";
import RagsocField from "./fields/RagsocField";
import InsegnaField from "./fields/InsegnaField";
import PivaField from "./fields/PivaField";
import NoteProspectField from "./fields/NoteProspectField";

const ProspectIndentitySection = (props) => {
  const { formFields = new FormFieldHandler() , tabSelection , orginData } = props;

  const [showCollapse, setShowCollapse] = useState(true);

  
  const { currentInteraction = "noInteraction" } = useSelector(
    (state) => state.interaction
  );

  const { prospectData } = useSelector((state) => state.prospect);

  const {
    cognome = "",
    nome = "",
    codFis = "",
    banca = "",
    codice = "",
    noteProspect = "",
    ragsoc = "",
    insegna = "",
    piva = ""
  } = getProspectDataById(prospectData)(currentInteraction)[orginData];

  return (
    <RowBluCollapse
      show={showCollapse}
      rowBlu={{ rowBluTitle: "Identificazione" }}
      collapse={{ collapseDefaultShow: true }}
      events={{
        handleOnIconClick: () => {
          setShowCollapse(!showCollapse);
        },
        handleOnCollapseEntered: () => {},
        handleOnCollapseExited: () => {},
      }}
    >
      <div className="d-flex flex-column">
      {tabSelection=='privatoProspect' ? (
        <>
      <ProspectLabelValue
        label="Cognome"
        value={cognome}
        field={<CognomeField formFields={formFields} orginData = {orginData} />}
      />
      <ProspectLabelValue
        label="Nome"
        value={nome}
        field={<NomeField formFields={formFields}  orginData = {orginData}/>}
      />
      <ProspectLabelValue
        label="Cod Fis"
        value={codFis}
        field={<CodiceFiscaleField formFields={formFields}  orginData = {orginData}/>}
      /></>):(<><ProspectLabelValue
        label="Rag Soc"
        value={ragsoc}
        field={<RagsocField formFields={formFields} orginData={orginData}/>}
      />
      <ProspectLabelValue
        label="Insegna"
        value={insegna}
        field={<InsegnaField formFields={formFields}  orginData = {orginData}/>}
      />
      <ProspectLabelValue
        label="P.IVa"
        value={piva}
        field={<PivaField formFields={formFields}  orginData = {orginData}/>}
      /></>)
      }
        
        <ProspectLabelValue
          label="Banca"
          value={banca}
          field={<BancaField formFields={formFields}  orginData = {orginData}/>}
        />
        <ProspectLabelValue
          label="Codice"
          value={codice}
          field={<CodiceField formFields={formFields}  orginData = {orginData}/>}
        />
        <ProspectLabelValue
          label="Note Prospect"
          value={noteProspect}
          field={<NoteProspectField formFields={formFields}  orginData = {orginData}/>}
        />
      </div>
    </RowBluCollapse>
  );
};

export default ProspectIndentitySection;
