import React from "react";
import { useDispatch, useSelector } from "react-redux";
import FormFieldHandler from "../../../../CommonComponents/Forms/FormFieldHandler";
import TextField from "../../../../CommonComponents/Forms/TextField";
import { exposedGetState } from "../../../../Store/store";
import {
  getProspectDataById,
  updateProspectDataByProperty,
} from "../../prospectSlice";

const EmailCasaField = (props) => {
  const { formFields = new FormFieldHandler(), orginData } = props;

  const { currentInteraction = "noInteraction" } = useSelector(
    (state) => state.interaction
  );

  const { prospectData } = useSelector((state) => state.prospect);

  const { emailCasa = "" } = getProspectDataById(prospectData)(
    currentInteraction,orginData
  );

  const dispatch = useDispatch();

  let emailCasaField = {
    uniqueID: "emailCasaField",
    placeHolder: "Email Casa...",
    readonly: false,
    visible: true,
    value: emailCasa,
    setValue: (obj) => {
      console.log("setValue", obj);
      const { currentInteraction } = exposedGetState().interaction;
      dispatch(
        updateProspectDataByProperty({
          interactionId: currentInteraction,
          data: {
            property: "emailCasa",
            value: obj.currentValue,
          },
          orginData : orginData
        })
      );
    },
    validation: {
      mandatory: false,
      type: "Email",
    },
    feedback: {
      enable: true,
      component: () => <>Email dovrebbe essere vaild mail id.</>,
    },
    form: formFields,
  };

  return <TextField configuration={emailCasaField} />;
};

export default EmailCasaField;
