import React from "react";
import { useDispatch, useSelector } from "react-redux";
import FormFieldHandler from "../../../../CommonComponents/Forms/FormFieldHandler";
import SelectField from "../../../../CommonComponents/Forms/SelectField";
import { exposedGetState } from "../../../../Store/store";
import { reduceToOptions } from "../../../../Utils/CommonUtil";
import {
  getProspectDataById,
  updateProspectDataByProperty,
} from "../../prospectSlice";

const NazionalitaSelectField = (props) => {
  const { formFields = new FormFieldHandler() , orginData } = props;

  const { nations = [] } = useSelector((state) => state.common);

  const { currentInteraction = "noInteraction" } = useSelector(
    (state) => state.interaction
  );

  const { prospectData } = useSelector((state) => state.prospect);

  const { nazionalita = null } = getProspectDataById(prospectData)(
    currentInteraction , orginData
  );

  const dispatch = useDispatch();

  let nazionalitaSelectField = {
    uniqueID: "nazionalitaSelectField",
    multiSelect: false,
    label: "",
    placeHolder: "Seleziona Nazionalita",
    readonly: false,
    visible: true,
    disabled: false,
    value: nazionalita,
    options: reduceToOptions(nations)("nazionalita", "nazionalita"),
    searchEnabled: true,
    setValue: (obj) => {
      console.log("setValue", obj);
      const { currentInteraction } = exposedGetState().interaction;
      dispatch(
        updateProspectDataByProperty({
          interactionId: currentInteraction,
          data: {
            property: "nazionalita",
            value: obj.currentValue,
          },
          orginData : orginData
        })
      );
    },
    form: formFields,
  };
  return <SelectField configuration={nazionalitaSelectField} />;
};

export default NazionalitaSelectField;
