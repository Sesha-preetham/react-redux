import React, { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import CheckBox from "../../../../CommonComponents/Forms/CheckBox";
import FormFieldHandler from "../../../../CommonComponents/Forms/FormFieldHandler";
import { exposedGetState } from "../../../../Store/store";
import {
  getProspectDataById,
  updateProspectDataByProperty,
} from "../../prospectSlice";

const ConsensoPrivacyField = (props) => {
  const { formFields = new FormFieldHandler() } = props;

  const { currentInteraction = "noInteraction" } = useSelector(
    (state) => state.interaction
  );

  const { prospectData } = useSelector((state) => state.prospect);

  const { consensoPrivacy = true, presaVisione = false } = getProspectDataById(
    prospectData
  )(currentInteraction);
  const dispatch = useDispatch();

  useEffect(() => {
    if (presaVisione) {
      formFields.getField("consensoPrivacyField").theField.setDisabled(true);
    }
  }, [presaVisione]);

  let consensoPrivacyField = {
    uniqueID: "consensoPrivacyField",
    label: "Consenso Privacy",
    labelClass: "consenso-privacy-label",
    readonly: false,
    visible: true,
    disabled: false,
    checked: consensoPrivacy,
    setValue: (obj) => {
      console.log("setValue", obj);
      const { currentInteraction } = exposedGetState().interaction;
      dispatch(
        updateProspectDataByProperty({
          interactionId: currentInteraction,
          data: {
            property: "consensoPrivacy",
            value: obj.currentValue,
          },
        })
      );
    },
    form: formFields,
  };

  return <CheckBox configuration={consensoPrivacyField} />;
};

export default ConsensoPrivacyField;
