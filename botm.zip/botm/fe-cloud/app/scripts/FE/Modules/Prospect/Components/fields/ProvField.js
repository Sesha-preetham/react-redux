import React from "react";
import { useDispatch, useSelector } from "react-redux";
import FormFieldHandler from "../../../../CommonComponents/Forms/FormFieldHandler";
import TextField from "../../../../CommonComponents/Forms/TextField";
import { exposedGetState } from "../../../../Store/store";
import {
  getProspectDataById,
  updateProspectDataByProperty,
} from "../../prospectSlice";

const ProvField = (props) => {
  const { formFields = new FormFieldHandler() ,orginData  } = props;

  const { currentInteraction = "noInteraction" } = useSelector(
    (state) => state.interaction
  );

  const { prospectData } = useSelector((state) => state.prospect);

  const { prov = "" } = getProspectDataById(prospectData)(currentInteraction,orginData);

  const dispatch = useDispatch();

  let provField = {
    uniqueID: "provField",
    placeHolder: "Prov...",
    readonly: false,
    visible: true,
    value: prov,
    setValue: (obj) => {
      console.log("setValue", obj);
      const { currentInteraction } = exposedGetState().interaction;
      dispatch(
        updateProspectDataByProperty({
          interactionId: currentInteraction,
          data: {
            property: "prov",
            value: obj.currentValue,
          },
          orginData : orginData
        })
      );
    },
    validation: {
      mandatory: true,
      type: "Alphanumeric",
    },
    feedback: {
      enable: true,
      component: () => <>* Prov obbligatorio.</>,
    },
    form: formFields,
  };

  return <TextField configuration={provField} />;
};

export default ProvField;
