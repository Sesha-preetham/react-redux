import React, { useState } from "react";
import { useSelector } from "react-redux";
import FormFieldHandler from "../../../CommonComponents/Forms/FormFieldHandler";
import RowBluCollapse from "../../../CommonComponents/RowBluCollapse/RowBluCollapse";
import { getProspectDataById } from "../prospectSlice";
import ProspectLabelValue from "./common/ProspectLabelValue";
import CapField from "./fields/CapField";
import CittaSelectField from "./fields/CittaSelectField";
import ProvField from "./fields/ProvField";
import StatoSelectField from "./fields/StatoSelectField";
import ViaField from "./fields/ViaField";

const ProspectDataResienzaSection = (props) => {
  const { formFields = new FormFieldHandler() , orginData  } = props;

  const [showCollapse, setShowCollapse] = useState(true);

  const { currentInteraction = "noInteraction" } = useSelector(
    (state) => state.interaction
  );

  const { prospectData } = useSelector((state) => state.prospect);

  const {
    via = "",
    citta = null,
    cap = "",
    prov = "",
    stato = null,
  } = getProspectDataById(prospectData)(currentInteraction,orginData);

  const { label: cittaLabel = "" } = citta || {};
  const { label: statoLabel = "" } = stato || {};

  return (
    <RowBluCollapse
      show={showCollapse}
      rowBlu={{ rowBluTitle: "Dati Residenza" }}
      collapse={{ collapseDefaultShow: true }}
      events={{
        handleOnIconClick: () => {
          setShowCollapse(!showCollapse);
        },
        handleOnCollapseEntered: () => {},
        handleOnCollapseExited: () => {},
      }}
    >
      <div className="d-flex flex-column">
        <ProspectLabelValue
          label="Via"
          value={via}
          field={<ViaField formFields={formFields} orginData = {orginData}/>}
        />
        <ProspectLabelValue
          label="Citta"
          value={cittaLabel}
          field={<CittaSelectField formFields={formFields} orginData = {orginData} />}
        />
        <ProspectLabelValue
          label="Cap"
          value={cap}
          field={<CapField formFields={formFields} orginData = {orginData} />}
        />
        <ProspectLabelValue
          label="Prov"
          value={prov}
          field={<ProvField formFields={formFields} orginData = {orginData}/>}
        />
        <ProspectLabelValue
          label="Stato"
          value={statoLabel}
          field={<StatoSelectField formFields={formFields} orginData = {orginData}/>}
        />
      </div>
    </RowBluCollapse>
  );
};

export default ProspectDataResienzaSection;
