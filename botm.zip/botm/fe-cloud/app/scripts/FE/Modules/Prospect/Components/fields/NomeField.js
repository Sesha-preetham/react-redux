import React from "react";
import { useDispatch, useSelector } from "react-redux";
import FormFieldHandler from "../../../../CommonComponents/Forms/FormFieldHandler";
import TextField from "../../../../CommonComponents/Forms/TextField";
import { exposedGetState } from "../../../../Store/store";
import { getProspectDataById, updateProspectDataByProperty } from "../../prospectSlice";

const NomeField = (props) => {
  const { formFields = new FormFieldHandler() ,orginData } = props;

  const { currentInteraction = "noInteraction" } = useSelector(
    (state) => state.interaction
  );

  const { prospectData } = useSelector((state) => state.prospect);

  const { nome = "" } = getProspectDataById(prospectData)(currentInteraction,orginData);
  const dispatch = useDispatch();

  let nomeField = {
    uniqueID: "nomeField",
    placeHolder: "Nome...",
    readonly: false,
    visible: true,
    value: nome,
    setValue: (obj) => {
      console.log("setValue", obj);
      const { currentInteraction } = exposedGetState().interaction;
      dispatch(
        updateProspectDataByProperty({
          interactionId: currentInteraction,
          data: {
            property: "nome",
            value: obj.currentValue,
          },
          orginData : orginData
        })
      );
    },
    validation: {
      mandatory: false,
      type: "Alphanumeric",
    },
    feedback: {
      enable: true,
      component: () => <>Nome dovrebbe essere valido alfanumerico.</>,
    },
    form: formFields,
  };

  return <TextField configuration={nomeField} />;
};

export default NomeField;
