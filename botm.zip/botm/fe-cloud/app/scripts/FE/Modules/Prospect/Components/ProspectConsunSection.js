import React, { useState } from "react";
import { useSelector } from "react-redux";
import FormFieldHandler from "../../../CommonComponents/Forms/FormFieldHandler";
import RowBluCollapse from "../../../CommonComponents/RowBluCollapse/RowBluCollapse";
import { getProspectDataById } from "../prospectSlice";
import ProspectLabelValue from "./common/ProspectLabelValue";
import ProdottoSelectField from "./fields/ProdottoSelectField";
import TipoEsitoSelectField from "./fields/TipoEsitoSelectField";

const ProspectConsunSection = (props) => {
  const { formFields = new FormFieldHandler() } = props;

  const [showCollapse, setShowCollapse] = useState(true);

  const { currentInteraction = "noInteraction" } = useSelector(
    (state) => state.interaction
  );

  const { prospectData } = useSelector((state) => state.prospect);

  const { prodotto = null, tipoEsito = null } = getProspectDataById(
    prospectData
  )(currentInteraction);

  const { label: prodottoLabel = "" } = prodotto || {};
  const { label: tipoEsitoLabel = "" } = tipoEsito || {};

  return (
    <RowBluCollapse
      show={showCollapse}
      rowBlu={{ rowBluTitle: "Consuntivazione" }}
      collapse={{ collapseDefaultShow: true }}
      events={{
        handleOnIconClick: () => {
          setShowCollapse(!showCollapse);
        },
        handleOnCollapseEntered: () => {},
        handleOnCollapseExited: () => {},
      }}
    >
      <div className="d-flex flex-column">
        <ProspectLabelValue
          label="Prodotto"
          value={prodottoLabel}
          field={<ProdottoSelectField formFields={formFields} />}
        />
        <ProspectLabelValue
          label="Tipo Esito"
          value={tipoEsitoLabel}
          field={<TipoEsitoSelectField formFields={formFields} />}
        />
      </div>
    </RowBluCollapse>
  );
};

export default ProspectConsunSection;
