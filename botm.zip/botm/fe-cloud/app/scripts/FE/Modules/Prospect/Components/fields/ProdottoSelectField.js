import React from "react";
import { useDispatch, useSelector } from "react-redux";
import FormFieldHandler from "../../../../CommonComponents/Forms/FormFieldHandler";
import SelectField from "../../../../CommonComponents/Forms/SelectField";
import { exposedGetState } from "../../../../Store/store";
import { reduceToOptions } from "../../../../Utils/CommonUtil";
import {
  getProspectDataById,
  updateProspectDataByProperty,
} from "../../prospectSlice";

const ProdottoSelectField = (props) => {
  const { formFields = new FormFieldHandler() } = props;

  const { currentInteraction = "noInteraction" } = useSelector(
    (state) => state.interaction
  );

  const { prospectProdotto = [], prospectData } = useSelector(
    (state) => state.prospect
  );

  const { prodotto = null } = getProspectDataById(prospectData)(
    currentInteraction
  );
  const dispatch = useDispatch();

  let prodottoField = {
    uniqueID: "prodottoField",
    multiSelect: false,
    label: "",
    placeHolder: "Seleziona Prodotto",
    readonly: false,
    visible: true,
    disabled: false,
    value: prodotto,
    options: reduceToOptions(prospectProdotto)("id", "value"),
    searchEnabled: true,
    setValue: (obj) => {
      console.log("setValue", obj);
      const { currentInteraction } = exposedGetState().interaction;
      dispatch(
        updateProspectDataByProperty({
          interactionId: currentInteraction,
          data: {
            property: "prodotto",
            value: obj.currentValue,
          },
        })
      );
    },
    validation: {
      externalCheck: (value) => {
        if (value && !Array.isArray(value)) {
          return true;
        }
        return false;
      },
    },
    feedback: {
      enable: true,
      component: () => <>* Prodotto obbligatorio</>,
    },
    form: formFields,
  };
  return <SelectField configuration={prodottoField} />;
};

export default ProdottoSelectField;
