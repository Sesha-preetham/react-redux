import React, { useState } from "react";
import { useSelector } from "react-redux";
import { withErrorBoundary } from "../../CommonComponents/ErrorBoundary/withErrorBoudary";
import FormFieldHandler from "../../CommonComponents/Forms/FormFieldHandler";
import ConsensoPrivacyField from "./Components/fields/ConsensoPrivacyField";
import ProspectConsensoPrivacySection from "./Components/ProspectConsensoPrivacySection";
import ProspectConsunSection from "./Components/ProspectConsunSection";
import ProspectDataResienzaSection from "./Components/ProspectDataResienzaSection";
import ProspectDatiAngraficaSection from "./Components/ProspectDatiAngraficaSection";
import ProspectIndentitySection from "./Components/ProspectIndentitySection";
import ProspectInserisciSection from "./Components/ProspectInserisciSection";
import ProspectRecapitiSection from "./Components/ProspectRecapitiSection";
import { getProspectDataById } from "./prospectSlice";
import { Tab, Tabs } from "react-bootstrap";

const ProspectSections = (props) => {

  const { formFields = new FormFieldHandler() , orginTab ,orginData } = props;

  const [tabSelection  , setTabSelection] = useState(orginTab);

  return (
    <>
      <ProspectConsunSection formFields={formFields} />
      <Tabs activeKey={tabSelection}
        onSelect={(tabKey) =>{
          setTabSelection(tabKey)
        }
        }
        /*below added for: CCCLOUD-600 prospect for not client issue 
          cause: there were two fields with same uniqueID for citta, 
          for privato form was not valid because last field for city was azienda city, now only one tab is rendered so there is only one field
        */
        mountOnEnter={true}
        unmountOnExit={true}
        >
        <Tab eventKey='privatoProspect'  title="Privato">
          <ProspectIndentitySection formFields={formFields} tabSelection={tabSelection} orginData = {orginData}/>
          <ProspectDataResienzaSection formFields={formFields}  orginData = {orginData}/>
          <ProspectRecapitiSection formFields={formFields}  orginData = {orginData}/>
          <ProspectDatiAngraficaSection formFields={formFields} />
          <ProspectInserisciSection formFields={formFields}  tabSelection={tabSelection} orginData = {orginData}/>
        </Tab>
        <Tab eventKey='aziendaProspect' title="Azienda">
          <ProspectIndentitySection formFields={formFields} tabSelection={tabSelection} orginData = {orginData}/>
          <ProspectDataResienzaSection formFields={formFields}  orginData = {orginData}/>
          <ProspectRecapitiSection formFields={formFields}  orginData = {orginData}/>
          <ProspectDatiAngraficaSection formFields={formFields}  orginData = {orginData}/>
          <ProspectInserisciSection formFields={formFields}  tabSelection={tabSelection}  orginData = {orginData}/>
        </Tab>
      </Tabs>
      
    </>
  );
};

const ProspectContainer = (props) => {
  const [formFields] = useState(new FormFieldHandler(true));

  const {orginTab,orginData}  = props; 

  const { currentInteraction = "noInteraction" } = useSelector(
    (state) => state.interaction
  );

  const { prospectData } = useSelector((state) => state.prospect);

  const { consensoPrivacy = true, presaVisione = false } = getProspectDataById(
    prospectData
  )(currentInteraction);

  return (
    <div className="d-flex flex-column prospect-container">
      <div className="d-flex justify-content-end mb-2">
        <div>
          <ConsensoPrivacyField formFields={formFields} />
        </div>
      </div>
      {consensoPrivacy &&
        (presaVisione ? (
          <ProspectSections orginTab = {orginTab} orginData = {orginData} formFields={formFields} />
        ) : (
          <ProspectConsensoPrivacySection />
        ))}
    </div>
  );
};

export default withErrorBoundary(ProspectContainer);
