import React from "react";
import { useDispatch, useSelector } from "react-redux";
import FormFieldHandler from "../../../../CommonComponents/Forms/FormFieldHandler";
import TextField from "../../../../CommonComponents/Forms/TextField";
import { exposedGetState } from "../../../../Store/store";
import {
  getProspectDataById,
  updateProspectDataByProperty,
} from "../../prospectSlice";

const CapField = (props) => {
  const { formFields = new FormFieldHandler() , orginData } = props;

  const { currentInteraction = "noInteraction" } = useSelector(
    (state) => state.interaction
  );

  const { prospectData } = useSelector((state) => state.prospect);

  const { cap = "" } = getProspectDataById(prospectData)(currentInteraction,orginData);

  const dispatch = useDispatch();

  let capField = {
    uniqueID: "capField",
    placeHolder: "Cap...",
    readonly: false,
    visible: true,
    value: cap,
    setValue: (obj) => {
      console.log("setValue", obj);
      const { currentInteraction } = exposedGetState().interaction;
      dispatch(
        updateProspectDataByProperty({
          interactionId: currentInteraction,
          data: {
            property: "cap",
            value: obj.currentValue,
          },
          orginData : orginData
        })
      );
    },
    validation: {
      mandatory: true,
      type: "Numeric",
    },
    feedback: {
      enable: true,
      component: () => <>* Cap obbligatorio.</>,
    },
    form: formFields,
  };

  return <TextField configuration={capField} />;
};

export default CapField;
