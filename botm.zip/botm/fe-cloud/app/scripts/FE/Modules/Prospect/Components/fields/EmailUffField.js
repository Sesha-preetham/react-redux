import React from "react";
import { useDispatch, useSelector } from "react-redux";
import FormFieldHandler from "../../../../CommonComponents/Forms/FormFieldHandler";
import TextField from "../../../../CommonComponents/Forms/TextField";
import { exposedGetState } from "../../../../Store/store";
import {
  getProspectDataById,
  updateProspectDataByProperty,
} from "../../prospectSlice";

const EmailUffField = (props) => {
  const { formFields = new FormFieldHandler() , orginData } = props;

  const { currentInteraction = "noInteraction" } = useSelector(
    (state) => state.interaction
  );

  const { prospectData } = useSelector((state) => state.prospect);

  const { emailUff = "" } = getProspectDataById(prospectData)(
    currentInteraction , orginData
  );

  const dispatch = useDispatch();

  let emailUffField = {
    uniqueID: "emailUffField",
    placeHolder: "Email Uff...",
    readonly: false,
    visible: true,
    value: emailUff,
    setValue: (obj) => {
      console.log("setValue", obj);
      const { currentInteraction } = exposedGetState().interaction;
      dispatch(
        updateProspectDataByProperty({
          interactionId: currentInteraction,
          data: {
            property: "emailUff",
            value: obj.currentValue,
          },
          orginData : orginData
        })
      );
    },
    validation: {
      mandatory: false,
      type: "Email",
    },
    feedback: {
      enable: true,
      component: () => <>Email Uff dovrebbe essere vaild mail id.</>,
    },
    form: formFields,
  };

  return <TextField configuration={emailUffField} />;
};

export default EmailUffField;
