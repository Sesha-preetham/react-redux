import React from "react";
import { useDispatch, useSelector } from "react-redux";
import FormFieldHandler from "../../../../CommonComponents/Forms/FormFieldHandler";
import TextField from "../../../../CommonComponents/Forms/TextField";
import { exposedGetState } from "../../../../Store/store";
import {
  getProspectDataById,
  updateProspectDataByProperty,
} from "../../prospectSlice";

const NatoIlField = (props) => {
  const { formFields = new FormFieldHandler() , orginData } = props;

  const { currentInteraction = "noInteraction" } = useSelector(
    (state) => state.interaction
  );

  const { prospectData } = useSelector((state) => state.prospect);

  const { natoIl = "" } = getProspectDataById(prospectData)(currentInteraction,orginData);

  const dispatch = useDispatch();

  let natoIlField = {
    uniqueID: "natoIlField",
    placeHolder: "DD/MM/YYYY",
    readonly: false,
    visible: true,
    value: natoIl,
    setValue: (obj) => {
      console.log("setValue", obj);
      const { currentInteraction } = exposedGetState().interaction;
      dispatch(
        updateProspectDataByProperty({
          interactionId: currentInteraction,
          data: {
            property: "natoIl",
            value: obj.currentValue,
          },
          orginData : orginData
        })
      );
    },
    validation: {
      mandatory: false,
    },
    form: formFields,
  };

  return <TextField configuration={natoIlField} />;
};

export default NatoIlField;
