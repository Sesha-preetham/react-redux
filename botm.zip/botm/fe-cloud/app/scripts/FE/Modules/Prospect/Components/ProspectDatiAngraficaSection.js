import React, { useState } from "react";
import { useSelector } from "react-redux";
import FormFieldHandler from "../../../CommonComponents/Forms/FormFieldHandler";
import RowBluCollapse from "../../../CommonComponents/RowBluCollapse/RowBluCollapse";
import { getProspectDataById } from "../prospectSlice";
import ProspectLabelValue from "./common/ProspectLabelValue";
import DACapField from "./fields/DACapField";
import DACittaSelectField from "./fields/DACittaSelectField";
import DAProvField from "./fields/DAProvField";
import DAStatoField from "./fields/DAStatoField";
import NatoIlField from "./fields/NatoIlField";
import NazionalitaSelectField from "./fields/NazionalitaSelectField";

const ProspectDatiAngraficaSection = (props) => {
  const { formFields = new FormFieldHandler() , orginData } = props;

  const [showCollapse, setShowCollapse] = useState(true);

  const { currentInteraction = "noInteraction" } = useSelector(
    (state) => state.interaction
  );

  const { prospectData } = useSelector((state) => state.prospect);

  const {
    natoIl = "",
    daCitta = null,
    daCap = "",
    daProv = "",
    nazionalita = null,
    daStato = null,
  } = getProspectDataById(prospectData)(currentInteraction,orginData);

  const { label: daCittaLabel = "" } = daCitta || {};
  const { label: nazionalitaLabel = "" } = nazionalita || {};
  const { label: daStatoLabel = "" } = daStato || {};

  return (
    <RowBluCollapse
      show={showCollapse}
      rowBlu={{ rowBluTitle: "Dati Anagrafici" }}
      collapse={{ collapseDefaultShow: true }}
      events={{
        handleOnIconClick: () => {
          setShowCollapse(!showCollapse);
        },
        handleOnCollapseEntered: () => {},
        handleOnCollapseExited: () => {},
      }}
    >
      <div className="d-flex flex-column">
        <ProspectLabelValue
          label="Nato il"
          value={natoIl}
          field={<NatoIlField formFields={formFields} orginData = {orginData}/>}
        />
        <ProspectLabelValue
          label="Citta"
          value={daCittaLabel}
          field={<DACittaSelectField formFields={formFields} orginData = {orginData} />}
        />
        <ProspectLabelValue
          label="Cap"
          value={daCap}
          field={<DACapField formFields={formFields} orginData = {orginData} />}
        />
        <ProspectLabelValue
          label="Prov"
          value={daProv}
          field={<DAProvField formFields={formFields} orginData = {orginData} />}
        />
        <ProspectLabelValue
          label="Nazionalita"
          value={nazionalitaLabel}
          field={<NazionalitaSelectField formFields={formFields} orginData = {orginData} />}
        />
        <ProspectLabelValue
          label="Stato"
          value={daStatoLabel}
          field={<DAStatoField formFields={formFields} orginData = {orginData} />}
        />
      </div>
    </RowBluCollapse>
  );
};

export default ProspectDatiAngraficaSection;
