import React from "react";
import {useSelector} from "react-redux";
import ErrorModal from "../../CommonComponents/Modal/ErrorModal";

const SessionExpiresModal = (props)=>{

    const { showSessionExpiresModal } = useSelector(
        (state) => state.common
    );

    const { profile = {} } = useSelector((state) => state.preference);
    const { systemPresences = [] } = useSelector((state) => state.common);

    let sessionExpiresAlertModal = {
        uniqueID: "sessionExpiresAlertModal",
        modalClass: "session-expires-modal error-modal",
        dialogClassName: "modal-w",
        title: {
        content: "Barra telefonica",
        class: "widget-title",
        },
        modalShow: showSessionExpiresModal,
        modalHeaderShow: true,
        backdrop: {
            enable: true,
        },
        events: {
            onHide: () => {
                console.log("sessionExpiresAlertModal modal onEntered");
            },
            onEntered: () => {
                console.log("sessionExpiresAlertModal modal onEntered");
            },
            onExited: () => {
                console.log("sessionExpiresAlertModal modal onExited");
            }
        } 
    }

    /*
    <div className="session-expires-container">
                <div className="session-expires-modal">
                    <div className="row session-expires-modal-title-container">
                        <div className="session-expires-modal-title col-10">Barra telefonica</div>
                        <div className="col-2 session-expires-modal-icon-wrapper">
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24">
                                <g fill="none" fill-rule="evenodd">
                                    <g>
                                        <g>
                                            <g>
                                                <path fill="#03C" d="M10.153 2.537c1.596-1.02 3.717-.553 4.737 1.043l7.67 12.72c.567.93.586 2.093.05 3.04l-.113.18c-.631.932-1.691 1.492-2.827 1.48H4.33c-1.215.005-2.338-.645-2.94-1.7l-.097-.19c-.419-.899-.368-1.952.147-2.81L9.11 3.58c.268-.419.624-.775 1.043-1.043zm2.74 1.796c-.651-.493-1.58-.365-2.073.287L3.14 17.35c-.179.31-.179.69 0 1l.08.121c.257.347.672.548 1.11.529h15.34c.487.021.945-.229 1.19-.65l.059-.12c.117-.29.093-.619-.069-.89L13.18 4.62c-.082-.108-.178-.205-.287-.287zm-.186 10.96c.39.39.39 1.024 0 1.414-.39.39-1.024.39-1.414 0-.39-.39-.39-1.024 0-1.414.39-.39 1.024-.39 1.414 0zM12 8l.117.007c.497.057.883.48.883.993v4c0 .552-.448 1-1 1s-1-.448-1-1V9l.007-.117c.057-.497.48-.883.993-.883z" transform="translate(-1143 -364) translate(738 348) translate(405 16)"/>
                                            </g>
                                        </g>
                                    </g>
                                </g>
                            </svg>
                        </div>
                    </div>
                    <div className="row">
                        <div className="col-12 session-expires-modal-content">
                            Sessione scaduta
                        </div>
                    </div>
                </div>
            </div>


    */

    let handleReLogin = () => {
        const { organization = {} } = profile;
        const { name: orgName } = organization;
        let toUseOrg = orgName || "";
        console.log("Org",toUseOrg);
        if(toUseOrg !== "" ){
            const loginUri = "/barratelefonicabe-web/"+toUseOrg+"/login";
            window.location.href = loginUri;
        }
    }

    // refactor this logic, now for first release with email could be ok --- need to check with voice if it close the call!
    if(showSessionExpiresModal===true){
        let availableIndex = systemPresences.findIndex(el => el.name==="OFFLINE");
        if(availableIndex!==-1){
            const{id = "" } = systemPresences[availableIndex];
            document.getElementById("softphone").contentWindow.postMessage(JSON.stringify({ type: "updateUserStatus", data:{ id: id} }),"*");
        }
        
    }

    return(
        <ErrorModal configuration={sessionExpiresAlertModal} >
            <div className="row">
                <div className="col-12 text-center">
                    <span>Sessione scaduta</span>
                </div>
                <div className="col-10 offset-1 pt-4">
                    <button
                        type="button"
                        className={`btn Rectangle-Button-Blue w-100`}
                        onClick={handleReLogin}
                    >
                        Torna a Login
                    </button>
                </div>
            </div>
        </ErrorModal>
    )
}

export default SessionExpiresModal;