import { beServiceUrls, pureCloudOrigin } from "../../Client/ClientProperties";
import HttpClient from "../../Utils/HttpClient";

export const httpPostLogout = async (request = {}) => {
  let httpClientwidget = new HttpClient();
  httpClientwidget.setUrl(beServiceUrls().logout);
  await httpClientwidget.httpPost().then((response) => {
    const { status = "", location = "" } = response;
    if (status === "OK" && location) {
      window.location.href = location;
    }
  });
};

const SessionService = () => {
  let logoutEvents = 0;
  const logoutEventListener = (event) => {
    if (event.origin !== pureCloudOrigin) return;
    let message = JSON.parse(event.data);
    if (message && message.type == "userActionSubscription") {
      if (message.data && message.data.category === "logout") {
        console.log("SessionService userActionSubscription... " + logoutEvents);
        if (logoutEvents === 0) {
          // PEF send two times the logout events
          httpPostLogout();
          logoutEvents++;
        }
      }
    }
  };

  return { logoutEventListener };
};

export const { logoutEventListener } = SessionService();
