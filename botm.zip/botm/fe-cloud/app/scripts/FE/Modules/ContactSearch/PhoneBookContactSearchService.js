import React from "react";
import { beServiceUrls, pureCloudOrigin } from "../../Client/ClientProperties";
import { customFunctionCodes } from "../../Store/commonSlice";
import { exposedDispatch, exposedGetState } from "../../Store/store";
import { getDefaultBank, isCustomFunctionAvailable, sendContactSearchOnPEF } from "../../Utils/CommonUtil";
import HttpClient from "../../Utils/HttpClient";

export const httpPostPhoneBookSearch = async (
  request = { searchvalue: undefined }
) => {
  let httpEvent = new HttpClient();
  httpEvent.setUrl(beServiceUrls().phoneBookContactSearch);
  let res = await httpEvent
    .httpPost(request)
    .then((response) => {
      const { status = "", response: contactList = [] } = response;
      let result = [];
      if (status === "OK") {
        result = contactList;
      }
      return result;
    })
    .catch((err) => {
      console.log("httpPostPhoneBookSearch ", err);
      return [];
    });
  return res;
};
const Service = () => {
  const contactSearchEventListener = (event) => {
    if (event.origin !== pureCloudOrigin) return;
    let message = JSON.parse(event.data);
    if (message && message.type == "contactSearch") {
      const { data = {} } = message;
      const { searchString } = data || {};
      if (!searchString) return;
      if(!isCustomFunctionAvailable(customFunctionCodes().phoneBookContactSearch)) return;
      // TODO aggiungere controllo su customfunction
      let bank = getDefaultBank(exposedGetState().common.banks)();
      const { abicode } = bank || {};
      httpPostPhoneBookSearch({
        abicode: abicode,
        searchvalue: searchString,
      }).then((resultList) => {
        let pefFormatList = resultList.map((c) => {
          return {
            ...c,
            type: "external",
          };
        });
        console.log("PhoneBookContactSearchService pefFormatList ", pefFormatList , resultList);
        sendContactSearchOnPEF(pefFormatList);
      });
    }
  };
  return {
    contactSearchEventListener,
  };
};

export const { contactSearchEventListener } = Service();
