import React from "react";
import StackElementWrapper from "../../Main/StackNavigation/StackElementWrapper";

const ExpandedWidgetWrapper = (props) => {
  const { elStack = "", className = "", events = {} } = props;
  const { stackHide = false } = elStack;
  const {
    handleOnStackMounted = (currentStack) => {
      console.log("StackElementWrapper handleOnStackMounted: ", currentStack);
    },
    handleOnStackUnMounted = (currentStack) => {
      console.log("StackElementWrapper handleOnStackUnMounted: ", currentStack);
    },
    handleOnStackEntered = (currentStack) => {
      console.log("StackElementWrapper handleOnStackEntered: ", currentStack);
    },
    handleOnStackExited = (currentStack) => {
      console.log("StackElementWrapper: handleOnStackExited", currentStack);
    },
  } = events;

  return (
    <StackElementWrapper
      elStack={elStack}
      events={{
        onStackMounted: handleOnStackMounted,
        onStackUnMounted: handleOnStackUnMounted,
        onStackEntered: handleOnStackEntered,
        onStackExited: handleOnStackExited,
      }}
    >
      <div
        className={`${stackHide ? "d-none" : "d-flex flex-fill section-expand"}`}
      >
        <div className="row no-gutters w-100 h-100 p-3">
          <div className="col-12 d-flex flex-column">
            <div
              className={`expand-main-container ${className} d-flex flex-column h-100`}
            >
              {props.children}
            </div>
          </div>
        </div>
      </div>
    </StackElementWrapper>
  );
};

export default ExpandedWidgetWrapper;
