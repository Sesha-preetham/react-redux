import React from "react";

const WidgetWrapper = (props) => {
  const { widgetShow = false, hidden = false , additionalClass=""} = props;
  return (
    <>
      {hidden ? (
        <div className={`widget-wrapper ${additionalClass} ${(!widgetShow?"display-none-class":"")}` }>{props.children}</div>
      ) : (
        widgetShow && props.children
      )}
    </>
  );
};

export default WidgetWrapper;
