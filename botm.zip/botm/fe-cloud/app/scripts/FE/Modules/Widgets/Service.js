import { beServiceUrls, pureCloudOrigin } from "../../Client/ClientProperties";
import { stackNavMandAuth } from "../../Main/StackNavigation/StackNavComponents";
import { stackNavPush } from "../../Main/StackNavigation/stackNavigationSlice";
import { exposedDispatch } from "../../Store/store";
import { getBTChannelOfInteraction } from "../../Utils/CommonUtil";
import HttpClient from "../../Utils/HttpClient";
import { getBTCallType } from "../Interaction/Service";
import {
  addInternalWidgetsByInteraction,
  updateInternalWidgetsByInteraction,
  loadDefaultInternalWidgets,
  removeInternalWidgetsByInteraction,
  mandatoryAuthWidgetCode,
} from "./internalWidgetsSlice";
import { updateWidgetsByCode } from "./widgetsSlice";

export const httpGetWidget = async (request = {}) => {
  const dispatch = exposedDispatch;
  let httpClientwidget = new HttpClient();
  httpClientwidget.setUrl(beServiceUrls().widgets);
  await httpClientwidget.httpGet(request).then((response) => {
    const { status = "", response: widgetsResponse = [] } = response;
    if (status == "OK") {
      dispatch(updateWidgetsByCode({ widgets: widgetsResponse }));
    }
  });
};

export const httpGetInternalWidget = async (request = {}) => {
  const dispatch = exposedDispatch;
  let httpClientwidget = new HttpClient();
  httpClientwidget.setUrl(beServiceUrls().widgets);
  await httpClientwidget.httpGet(request).then((response) => {
    const { status = "", response: widgetsResponse = [] } = response;
    if (status == "OK") {
      dispatch(
        loadDefaultInternalWidgets({ defaultInternalWidgets: widgetsResponse })
      );
    }
  });
};

export const httpGetInteractionInternalWidget = async (request = {}) => {
  let httpClientwidget = new HttpClient();
  httpClientwidget.setUrl(beServiceUrls().interactionWidgets);
  let returnData = await httpClientwidget.httpGet(request).then((response) => {
    const { status = "", response: interanlWidgetsResponse = [] } = response;
    if (status == "OK") {
      return interanlWidgetsResponse;
    }
    return [];
  });
  return returnData;
};

const internalWidgetsEventListeners = () => {
  const dispatch = exposedDispatch;
  const iwInteractionEventListener = (event) => {
    if (event.origin !== pureCloudOrigin) return;
    let message = JSON.parse(event.data);
    console.log("internalWidgetsEventListeners: ", message);
    if (message && message.type == "interactionSubscription") {
      let { data: interactionData = {} } = message;

      let { category = "", interaction = {} } = interactionData;

      switch (category) {
        case "add":
          httpGetInteractionInternalWidget({
            interactionId: interaction.id,
            queueName: interaction.queueName,
            service: interaction.attributes
              ? interaction.attributes.x_servizio
              : undefined,
          }).then((widgets) => {
            dispatch(
              addInternalWidgetsByInteraction({
                id: interaction.id,
                widgets,
              })
            );
          });
          break;
        case "change":
          break;
        case "connect":
          httpGetInteractionInternalWidget({
            interactionId: interaction.id,
            queueName: interaction.queueName,
            service: interaction.attributes
              ? interaction.attributes.x_servizio
              : undefined,
          }).then((widgets = []) => {
            dispatch(
              updateInternalWidgetsByInteraction({
                id: interaction.id,
                widgets,
              })
            );
          });
          break;
        case "disconnect":
          break;
        case "acw":
          break;
        case "deallocate":
          dispatch(
            removeInternalWidgetsByInteraction({
              id: interaction.id,
            })
          );
          break;
        default:
          console.log("No Event Matched");
      }
    }
  };

  return { iwInteractionEventListener };
};

export const { iwInteractionEventListener } = internalWidgetsEventListeners();
