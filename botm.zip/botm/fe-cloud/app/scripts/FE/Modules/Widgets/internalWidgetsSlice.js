import { createSlice } from "@reduxjs/toolkit";

const conversationButtonCodes =  [
  "spamWidget",
  "altraInfoWidget",
  "presaVeloceWidget",
  "prenotaRecallWidget",
  "attachementWidgetCode",
  "chatAutheticateWidget",
];

const internalWidgetsCodes = () => {
  return {
    privatoWidgetCode: "privatoWidget",
    aziendaWidgetCode: "aziendaWidget",
    leasingWidgetCode: "leasingWidget",
    remoteBankingWidgetCode: "remoteWidget",
    hdcWidgetCode:"hdcWidget",
    hdcConsunWidgetCode:"hdcConsunWidget",
    authenticationWidgetCode: "authenticationWidget",
    mandatoryAuthWidgetCode: "mandatoryAuthWidgetCode",
    lightAuthWidgetCode: "lightAuthenticationWidget",
    prospectWidgetCode: "prospectWidget",
    esercenteWidgetCode: "esercenteWidget",
    draftEmailWidgetCode: "draftEmailWidget",
    privatoCarteExternalLinkCode: "privatoCarteExternalLink",
    privatoSercliExternalLinkCode: "privatoSercliExternalLinkCode",
    bpaSupportInternal: "bpaSupportInternal",
    esercentePOSWidgetCode:"esercentePosWidget",
    simplifiedCosunWidgetCode:"simplifiedCosunWidget",
    auviousInternalWidgetCode: "auviousInternalWidget",
    spamWidgetCode: conversationButtonCodes[0],
    altraInfoWidgetCode: conversationButtonCodes[1],
    presaVeloceWidgetCode: conversationButtonCodes[2],
    prenotaRecallWidgetCode:  conversationButtonCodes[3],
    attachementWidgetCode: conversationButtonCodes[4],
    chatAuthenticateWidgetCode: conversationButtonCodes[5],
  };
};

export const {
  privatoWidgetCode,
  aziendaWidgetCode,
  leasingWidgetCode,
  remoteBankingWidgetCode,
  hdcWidgetCode,
  hdcConsunWidgetCode,
  authenticationWidgetCode,
  mandatoryAuthWidgetCode,
  lightAuthWidgetCode,
  prospectWidgetCode,
  spamWidgetCode,
  draftEmailWidgetCode,
  esercenteWidgetCode,
  privatoCarteExternalLinkCode,
  privatoSercliExternalLinkCode,
  bpaSupportInternal,
  altraInfoWidgetCode,
  esercentePOSWidgetCode,
  simplifiedCosunWidgetCode,
  auviousInternalWidgetCode,
  presaVeloceWidgetCode,
  prenotaRecallWidgetCode,
  attachementWidgetCode,
  chatAuthenticateWidgetCode,
} = internalWidgetsCodes();

let initialState = {
  internalWidgets: {
    noInteraction: [],
  },
};

const internalWidgetsSlice = createSlice({
  name: "internalWidgets",
  initialState,
  reducers: {
    loadDefaultInternalWidgets(state, action) {
      const { payload = {} } = action;
      const { defaultInternalWidgets = [] } = payload;
      state.internalWidgets.noInteraction.push(...defaultInternalWidgets);
    },
    addInternalWidgetsByInteraction(state, action) {
      const { payload = {} } = action;
      const { id = "noInteraction", widgets = [] } = payload;
      if (!state.internalWidgets[id]) {
        state.internalWidgets[id] = [...widgets];
      }
    },
    updateInternalWidgetsByInteraction(state, action) {
      const { payload = {} } = action;
      const { id = "noInteraction", widgets = [] } = payload;
      if (state.internalWidgets[id]) {
        let newWidgets = [];
        widgets.forEach( (widget) => {
          if(state.internalWidgets[id].findIndex(el => el.code === widget.code) === -1){
            newWidgets.push(widget);
          }
        })
        state.internalWidgets[id] = [
          ...state.internalWidgets[id],
          ...newWidgets
        ];
      }
    },
    removeInternalWidgetsByInteraction(state, action) {
      const { payload = {} } = action;
      const { id = "noInteraction", widgets = [] } = payload;
      state.internalWidgets = Object.entries(state.internalWidgets).reduce(
        (acc, [key, value]) => {
          if (key != id) {
            acc[key] = value;
          }
          return acc;
        },
        {}
      );
    },
    resetInternalWidget(state) {
      state = initialState;
    },
  },
});

export const {
  loadDefaultInternalWidgets,
  addInternalWidgetsByInteraction,
  updateInternalWidgetsByInteraction,
  removeInternalWidgetsByInteraction,
  resetInternalWidget,
} = internalWidgetsSlice.actions;

export default internalWidgetsSlice.reducer;

export const getInternalWidgetByIdAndCode = (internalWidgets = []) => {
  return (id = "", code = "") => {
    if (internalWidgets[id]) {
      let currentIndex = internalWidgets[id].findIndex(
        (currentInternalWidget) => {
          return currentInternalWidget.code === code;
        }
      );
      return currentIndex != -1 ? [true] : [false];
    }
    return [false];
  };
};

export const getAziendaWidgetCheck = (internalWidgets = []) => {
  return(id= "")=> {
    if(internalWidgets[id]){
      const aziendaWidgets = [remoteBankingWidgetCode, esercenteWidgetCode, esercentePOSWidgetCode]; 
      let currentIndex = internalWidgets[id].findIndex(
        (currentInternalWidget) => {
         return aziendaWidgets.find(value => value === currentInternalWidget.code)
        }
      );
      return currentIndex != -1 ? true : false;
    }
    else
    return false;    
    };
  };

  export const getPrivatoWidgetCheck = (internalWidgets = []) => {
    return(id= "")=> {
      if(internalWidgets[id]){
        const privatoWidget = [privatoWidgetCode]; 
        let currentIndex = internalWidgets[id].findIndex(
          (currentInternalWidget) => {
           return privatoWidget.find(value => value === currentInternalWidget.code)
          }
        );
        return currentIndex != -1 ? true : false;
      }
      else
      return false;    
      };
    };

export const getInternalWidgetConfigByIdAndCode = (internalWidgets = []) => {
  return (id = "", code = "") => {
    let widgetObject = {};
    if (internalWidgets[id]) {
      widgetObject = internalWidgets[id].find((currentInternalWidget) => {
        return currentInternalWidget.code === code;
      });
    }
    console.log("widgetObject :" + widgetObject ? widgetObject : {});
    return widgetObject ? widgetObject : {};
  };
};

export const getConversationButtonCodePresent = (internalWidgets = []) => {
  return (id = "") => {
    if (internalWidgets[id]) {
      let valuePresent = false;
      internalWidgets[id].forEach(wdiget => {
        if(conversationButtonCodes.indexOf(wdiget.code) > -1){valuePresent=true;}
      });
      return valuePresent
    }
    return false;
  };
};
