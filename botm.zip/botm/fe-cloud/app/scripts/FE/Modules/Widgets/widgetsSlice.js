import { createSlice } from "@reduxjs/toolkit";

const widgetsCodes = () => {
  return {
    softphoneCommonCode: "softphoneCommon",
    anagraficaWidgetCode: "anagraficaWidget",
    consuntivazioneWidgetCode: "consuntivazioneWidget",
    conversazioneWidgetCode: "conversationWidget",
    sospesiWidgetCode: "sospesiWidget",
    storicoConversazioneWidgetCode: "storicoConversazioneWidget",
    bpaSupportCode: "BPASupportWidget",
    queueActivityCode: "queueActivityWidget",
    abandonRecallWidgetCode: "abandonRecallWidget",
    retailDeskWidgetCode:"retailDeskWidget",
    wkscWidgetCode:"WKSCWidget",
    phoneCollectionWidgetCode:"phoneCollectionWidget",
    phoneCollectionCRMWidgetCode:"phoneCollectionCRMWidget",
    esitoWidgetCode : "esitoWidget",
    //esitoCRMCWidgetode : "esitoCRMWidget",
    auviousWidgetCode: "auviousWidget"
  };
};

export const {
  softphoneCommonCode,
  anagraficaWidgetCode,
  consuntivazioneWidgetCode,
  conversazioneWidgetCode,
  sospesiWidgetCode,
  storicoConversazioneWidgetCode,
  bpaSupportCode,
  abandonRecallWidgetCode,
  queueActivityCode,
  retailDeskWidgetCode,
  wkscWidgetCode,
  phoneCollectionWidgetCode,
  phoneCollectionCRMWidgetCode,
  esitoWidgetCode,
  //esitoCRMCWidgetode,
  auviousWidgetCode
} = widgetsCodes();

let initialState = {
  widgets: {
    [softphoneCommonCode]: {
      code: softphoneCommonCode,
      description: "string",
      main: true,
      def: true,
      menuEventState: true,
      topMenuShow: false,
    },
    [conversazioneWidgetCode]: {
      code: conversazioneWidgetCode,
      description: "string",
      main: true,
      def: true,
      menuEventState: true,
      topMenuShow: false,
    },
  },
};

const widgetSlice = createSlice({
  name: "widgets",
  initialState,
  reducers: {
    updateWidgetsByCode(state, action) {
      const { payload = {} } = action;
      const { widgets = [] } = payload;
      state.widgets = widgets.reduce(
        function (acc, obj) {
          let key = obj.code;
          acc[key] = {
            ...obj,
            menuEventState: obj.def,
            topMenuShow: obj.main && !obj.def ? true : false,
          };
          return acc;
        },
        { ...state.widgets }
      );
    },
    updateWidgetMenuEventByCode(state, action) {
      const { payload = {} } = action;
      const { widget = {} } = payload;
      const { code = "", menuEventState = true } = widget;
      if (state.widgets[code]) {
        state.widgets[code].menuEventState = menuEventState;
      }
    },

    resetWidget(state) {
      state = initialState;
    },
  },
});

export const {
  updateWidgetsByCode,
  updateWidgetMenuEventByCode,
  resetWidget,
} = widgetSlice.actions;

export default widgetSlice.reducer;

export const getDisplayDataByCode = (widgets = []) => {
  return (code = "") => {
    if (widgets[code]) {
      return [
        widgets[code].menuEventState,
        widgets[code] ? true : false,
        widgets[code].topMenuShow,
      ];
    }
    return [false, false, false, false];
  };
};

export const getMainWidgetConfigByIdAndCode = (widgets = []) => {
  return (code = "") => {
    let config = {};
    if(widgets[code] && widgets[code].widgetConfig){
      config = {...widgets[code].widgetConfig};
    }
    console.log("getMainWidgetConfigByIdAndCode :: ", config);
    return config;
  }
}