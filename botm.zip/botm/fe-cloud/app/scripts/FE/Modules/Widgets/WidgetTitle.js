import React from "react";

const WidgetTitle = (props) => {
  const { title = "", iconElement = <></> , centralElement = <></>, leftElemenet=<></>} = props;

  let iconOffset = (centralElement)?"":"offeset-5";
  let leftIconOffset = (leftElemenet)?"":"offeset-4";

  return (
    <div className="row no-gutters mb-3">
      <div className="col-6">
        <span className="widget-title">{title}</span>
        {leftElemenet && (
        <span className={`col-2${leftIconOffset} text-left`}>{leftElemenet}</span>
      )}
      </div>
      {centralElement && (
        <div className="col-5 ">{centralElement}</div>
      )}
      {iconElement && (
          <div className={`col-1 ${iconOffset} text-right`}>{iconElement}</div>
      )}
    </div>
  );
};

export default WidgetTitle;
