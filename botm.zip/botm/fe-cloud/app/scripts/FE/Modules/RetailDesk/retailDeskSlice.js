import { createSlice } from "@reduxjs/toolkit";

let initialState = {
  campagnaFilter: {},
  assegnatiFilter: {},
  statoFilter:{},
  retailDeskTableData:[],
  campagnaResponseData:{},
  assegnatiResponseData:{},
  statoResponseData:{},
  makeOutboundCall:{
    phoneNumberVal: null,
    idContattoVal: null,
  },
  showModal: false,
  rowSelectedVal: undefined,
};

const retailDeskSlice = createSlice({
  name: "retilDesk",
  initialState,
  reducers: {
    setCampagnaResponse(state, action) {
      const { payload = {} } = action;
      const { campagnaResp = {} } = payload;
      state.campagnaResponseData = campagnaResp;
    },
    setAssegnatiResponse(state, action) {
      const { payload = {} } = action;
      const { assegnatiResp = {} } = payload;
      state.assegnatiResponseData = assegnatiResp;
    },
    setStatoResponse(state, action) {
      const { payload = {} } = action;
      const { statoResp = {} } = payload;
      state.statoResponseData = statoResp;
    },
    setRetailDeskTableData(state, action) {
      const { payload = {} } = action;
      const { retailDeskTableVal = {} } = payload;
      state.retailDeskTableData = retailDeskTableVal;
    },
    setCampagnaFilter(state, action) {
      const { payload = {} } = action;
      const { campagnaValue = {} } = payload;
      state.campagnaFilter = campagnaValue;
    },
    setAssegnatiFilter(state, action) {
      const { payload = {} } = action;
      const { assegnatiValue = {} } = payload;
      state.assegnatiFilter = assegnatiValue;
    },
    setStatoFilter(state, action) {
      const { payload = {} } = action;
      const { statoValue = [] } = payload;
      state.statoFilter = statoValue;
    },
    resetRetailDeskData(state) {
      state = initialState;
    },
    updateMakeOutboundCall(state, action) {
      const { payload = {} } = action;
      const { data = {} } = payload;
      const {
        phoneVal = null,
        idVal = null,
      } = data;
      state.makeOutboundCall.phoneNumberVal = phoneVal;
      state.makeOutboundCall.idContattoVal = idVal;
    },
    setShowConfirmationModal(state, action) {
      const { payload = {} } = action;
      const { showVal = false } = payload;
      state.showModal = showVal;
    },
    setTableRowSelected(state, action) {
      const { payload = {} } = action;
      const { rowSelectedVal = undefined } = payload;
      state.rowSelectedVal = rowSelectedVal;
    }
  },
});

export const {
  setCampagnaResponse,
  setAssegnatiResponse,
  setStatoResponse,
  setCampagnaFilter,
  setAssegnatiFilter,
  setStatoFilter,
  setRetailDeskTableData,
  resetRetailDeskData,
  updateMakeOutboundCall,
  setShowConfirmationModal,
  setTableRowSelected,
} = retailDeskSlice.actions;

export default retailDeskSlice.reducer;
