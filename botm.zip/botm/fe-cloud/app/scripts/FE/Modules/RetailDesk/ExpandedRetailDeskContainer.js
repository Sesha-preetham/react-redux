import React, { useEffect, useState, useRef } from "react";
import { useDispatch, useSelector } from "react-redux";
import IconBlueClose from "../../CommonComponents/Common/Icons/IconBlueClose";
import FormFieldHandler from "../../CommonComponents/Forms/FormFieldHandler";
import SelectField from "../../CommonComponents/Forms/SelectField";
import SimpleTable from "../../CommonComponents/SimpleTable/SimpleTable";
import { stackNavPop } from "../../Main/StackNavigation/stackNavigationSlice";
import ExpandedWidgetWrapper from "../Widgets/ExpandedWidgetWrapper";
import {
  getDisplayDataByCode,
  retailDeskWidgetCode,
  updateWidgetMenuEventByCode,
} from "../Widgets/widgetsSlice";
import { setCampagnaFilter, setAssegnatiFilter, setStatoFilter, setRetailDeskTableData, setShowConfirmationModal, 
  updateMakeOutboundCall, setCampagnaResponse,  setAssegnatiResponse,  setStatoResponse, setTableRowSelected } from "./retailDeskSlice"; 
import WidgetTitle from "../Widgets/WidgetTitle";
import WidgetWrapper from "../Widgets/WidgetWrapper";
import AlertToast from "../../CommonComponents/AlertToast/AlertToast";
import {retailDeskAlertId }from "../../CommonComponents/AlertToast/AlertIdConstants";
import { globalSpinnerId, toggleSpinnerById } from "../../CommonComponents/Spinner/spinnerSlice";
import { httpGetCampagneList, httpGetAssegnatiList , httpGetStatoArr, httpPostRetailDeskList , httpPostNoteService} from "./RetailDeskService";
import { setIdSoggetto } from "../../Store/preferenceSlice";
import RetailDeskConfirmationModal from "./RetailDeskConfirmationModal";


const ExpandedRetailDeskContainer = (props) => {
  const { elStack = {} } = props;
  const [formFields] = useState(new FormFieldHandler(true));
  const { widgets } = useSelector((state) => state.widgets);
  const campagnaFilter = useSelector((state) => state.retailDesk.campagnaFilter);
  const assegnatiFilter = useSelector((state) => state.retailDesk.assegnatiFilter);
  const statoFilter = useSelector((state) => state.retailDesk.statoFilter);
  const retailDeskTableData = useSelector((state) => state.retailDesk.retailDeskTableData);
  const campagnaResponseData = useSelector((state) => state.retailDesk.campagnaResponseData);
  const assegnatiResponseData = useSelector((state) => state.retailDesk.assegnatiResponseData);
  const statoResponseData = useSelector((state) => state.retailDesk.statoResponseData);
  const rowSelectedVal = useSelector((state) => state.retailDesk.rowSelectedVal);
  const dispatch = useDispatch();

  const [retailDeskMenuShow, retailDeskShow] = getDisplayDataByCode(widgets)( retailDeskWidgetCode );

  const[disableButton , setDisableButton] =useState(true);


  useEffect(()=> {
    onMount();
  },[]);

  let onMount = async () => {
    dispatch(toggleSpinnerById(globalSpinnerId));
    if(formFields.getField("campagnaFilterId") && (campagnaFilter && Object.keys(campagnaFilter).length==0))  
    {
      await httpGetCampagneList().then((response) => {
        formFields.getField("campagnaFilterId").theField.reloadOptions(response);
        dispatch(setCampagnaResponse({campagnaResp:response}));
        formFields.getField("campagnaFilterId").theField.setValue(findTutti(response));
      })
    }
    if (formFields.getField("assegnatiFilterId") && (assegnatiFilter && Object.keys(assegnatiFilter).length==0))  {
      await httpGetAssegnatiList().then((response) => {
        formFields.getField("assegnatiFilterId").theField.reloadOptions(response);
        dispatch(setAssegnatiResponse({assegnatiResp:response}));
        formFields.getField("assegnatiFilterId").theField.setValue(findTutti(response));
      });
    }
    if (formFields.getField("statoFilterId") && (statoFilter && Object.keys(statoFilter).length==0)) {
      await httpGetStatoArr().then((response) => {
        formFields.getField("statoFilterId").theField.reloadOptions(response);
        dispatch(setStatoResponse({statoResp:response}));
        formFields.getField("statoFilterId").theField.setValue(response[0]);
      });
    }
   if (campagnaFilter && Object.keys(campagnaFilter).length!=0)
      { formFields.getField("campagnaFilterId").theField.reloadOptions(campagnaResponseData); }
   if (assegnatiFilter && Object.keys(assegnatiFilter).length!=0)
      { formFields.getField("assegnatiFilterId").theField.reloadOptions(assegnatiResponseData); }
   if (statoFilter && Object.keys(statoFilter).length!=0)
      { formFields.getField("statoFilterId").theField.reloadOptions(statoResponseData); } 
    dispatch(toggleSpinnerById(globalSpinnerId));
  };

  const findTutti = (response) =>{
    let tuttiValue ;
     response.forEach(val=>{
      if(val.label == "TUTTI")
      tuttiValue = val;
    })
    tuttiValue = tuttiValue ? tuttiValue : [];
    return tuttiValue;
  }

  
 let estraiButtonClick = () =>{
  let campagnaVal,assegnatiVal, statoVal;
  const campagnaFieldCheck = formFields.getField("campagnaFilterId");
  if(campagnaFieldCheck){
    const { value = "" } = campagnaFieldCheck.theField.getValue() || {};
    if( value !== null && value !== ""){
      campagnaVal = value;
    }
  };

  const assegnatiFieldCheck = formFields.getField("assegnatiFilterId");
  if(assegnatiFieldCheck){
    const { value = "", rlData = {} } = assegnatiFieldCheck.theField.getValue() || {};
    const { bsCode = "" } = rlData;
    if(bsCode && bsCode !== ""){
      assegnatiVal = bsCode;
    }else if( value !== null && value !== ""){
      assegnatiVal = value;
    }
  }

  const statoFieldCheck = formFields.getField("statoFilterId");
  if(statoFieldCheck){
    const { value = "" } = statoFieldCheck.theField.getValue() || {};
    if( value !== null && value !== ""){
      statoVal = value;
    }
  }

  if( campagnaVal !=="TUTTI" || assegnatiVal !=="TUTTI")
  {
  let request = {
    campaignId : campagnaVal,
    agentCode : assegnatiVal,
    state : statoVal
  }
  loadRetailDeskTableData(request);
  setDisableButton(false)
  }
  else{
  setDisableButton(true)
  }
  dispatch(setTableRowSelected({rowSelectedVal:null}));
};

 const loadRetailDeskTableData = (request) => {
   dispatch(toggleSpinnerById(globalSpinnerId));
   httpPostRetailDeskList(request).then( responseList => {
     dispatch(toggleSpinnerById(globalSpinnerId));
     let dataSet = responseList;
     if (dataSet.length > 0) {
       dataSet.forEach((val) => {
         val.clicked = false;
       });
     }
     console.log(dataSet);
     dispatch(setRetailDeskTableData({ retailDeskTableVal: dataSet }));
   });
 };


  
  let campagnaFilterField = {
    uniqueID: "campagnaFilterId",
    multiSelect: false,
    label: "",
    placeHolder: "campagna",
    readonly: false,
    visible: true,
    disabled: false,
    options: [],
    searchEnabled: true,
    value: (campagnaFilter && Object.keys(campagnaFilter).length!=0) ? campagnaFilter : {},
    setValue: (obj) => {
      dispatch(
        setCampagnaFilter({
          campagnaValue : obj.currentValue
        })
      );
      if(obj.currentValue && obj.currentValue.value !=="TUTTI")
      setDisableButton(false)
    },
    form: formFields,
    validation: {
      externalCheck: (value) => {
        if (value && !Array.isArray(value)) {
          return true;
        }
        return false;
      },
    },
    feedback: {
      enable: true,
      component: () => <>* Obbligatorio</>,
    },
  };

  
  let assegnatiFilterField = {
    uniqueID: "assegnatiFilterId",
    multiSelect: false,
    label: "",
    placeHolder: "Assegnati",
    readonly: false,
    visible: true,
    disabled: false,
    options: [],
    searchEnabled: true,
    value: (assegnatiFilter && Object.keys(assegnatiFilter).length!=0) ? assegnatiFilter : {},
    setValue: (obj) => {
      dispatch(
        setAssegnatiFilter({
          assegnatiValue : obj.currentValue
        })
      );
      if(obj.currentValue && obj.currentValue.value !=="TUTTI")
      setDisableButton(false)
    },
    form: formFields,
    validation: {
      externalCheck: (value) => {
        if (value && !Array.isArray(value)) {
          return true;
        }
        return false;
      },
    },
    feedback: {
      enable: true,
      component: () => <>* Obbligatorio</>,
    },
  };

  
  let statoFilterField = {
    uniqueID: "statoFilterId",
    multiSelect: false,
    label: "",
    placeHolder: "stato",
    readonly: false,
    visible: true,
    disabled: false,
    options: [],
    searchEnabled: true,
    value: (statoFilter && Object.keys(statoFilter).length!=0) ? statoFilter : {},
    setValue: (obj) => {
      dispatch(
        setStatoFilter({
          statoValue : obj.currentValue
        })
      );
    },
    form: formFields,
    validation: {
      externalCheck: (value) => {
        if (value && !Array.isArray(value)) {
          return true;
        }
        return false;
      },
    },
    feedback: {
      enable: true,
      component: () => <>* Obbligatorio</>,
    },
  };

  const handleOttoCifreClick =(original)=> {
    dispatch(setIdSoggetto({idSoggettoValue: original.idSoggetto}));
  };

  let checkClick = (value) =>{
    console.log(value);
    dispatch(setTableRowSelected({rowSelectedVal:value}));
  }

  let retailDeskTable = {
    uniqueID: "retailDeskTable",
    showRowBorder: true,
    rowSelected : rowSelectedVal,
    onTableRowClick : checkClick,
   // lastColumnFixed: true,
    scrollY: true,
    metaData: [
      {
        Header: "S.No",
        accessor: "sNo",
      },
      {
        id: "codice",
        Header: "Codice",
        accessor: "codice"
      },
      {
        id: "ottoCifre",
        Header: "8 cifre",
        accessor: "ottoCifre",
        Cell: (cellInfo) => {
          let { row } = cellInfo;
          let { original } = row;
          let { ottoCifre } = original
          return (
            <div className="text-left hand-cursor">
              <a onClick={ ()=>handleOttoCifreClick(original)}>
                {ottoCifre}
              </a>
            </div>
          );
        },
      },
      {
        id: "cognomeNome",
        Header: "Cognome Nome",
        accessor: "cognomeNome"
      },
      {
        id: "dataNascita",
        Header: "Data Nascita",
        accessor: "dataNascita"
      },
      {
        id: "telefono1",
        Header: "Telefono 1",
        accessor: "telefono1",
        Cell: (cellInfo) => {
          let { row } = cellInfo;
          let { original } = row;
          let { telefono1, idContatto } = original
          return (
            <div className="text-left hand-cursor">
              <a onClick={ ()=>{ telefono1 ? makeCall(telefono1,idContatto)  : {}}}>
                {telefono1}
              </a>
            </div>
          );
        },
        
      },
      {
        id: "telefono2",
        Header: "Telefono 2",
        accessor: "telefono2",
        Cell: (cellInfo) => {
          let { row } = cellInfo;
          let { original } = row;
          let { telefono2,idContatto } = original
          return (
            <div className="text-left hand-cursor">
              <a onClick={ ()=>{ telefono2 ? makeCall(telefono2,idContatto) : {}}}>
                {telefono2}
              </a>
            </div>
          );
        },
      },
      {
        id: "idContatto",
        Header: "Id Contatto",
        accessor: "idContatto"
      },
      {
        id: "note",
        Header: "Note",
        accessor: "note",
        Cell: (cellInfo) => {
          let { row } = cellInfo;
          let { original } = row;
          let { note } = original
          return (
            <div className="text-left tabella-fix-column-width">
             {note}
            </div>
          );
        },
      },
      {
        id: "dataUltimaMod",
        Header: "Data Ultima Modifica",
        accessor: "dataUltimaMod"
      },
      {
        id: "opUltimaMod",
        Header: "Op. Ultima Modifica",
        accessor: "opUltimaMod"
      },
      {
        id: "esitoAttuale",
        Header: "Esito Attuale",
        accessor: "esitoAttuale"
      },
      {
        id: "dataScadenza",
        Header: "Data Scadenza",
        accessor: "dataScadenza"
      },
      {
        id: "campagnaDisplayValue",
        Header: "Campagna",
        accessor: "campagnaDisplayValue",
        Cell: (cellInfo) => {
          let { row } = cellInfo;
          let { original } = row;
          let { campagnaDisplayValue } = original
          return (
            <div className="text-left tabella-fix-column-width">
              <div
                 dangerouslySetInnerHTML={{__html: campagnaDisplayValue || ""}}
                 />
            </div>
          );
        },
      },
    ],
    sort: [
      {
        id: "sNo",
        desc: false,
      },
    ],
    pagination: true,
    paginationOptions: {
      pageSize: 10,
    },
    data: [...retailDeskTableData],
  };

  const makeCall =(phn,id) =>{
  dispatch(setShowConfirmationModal({showVal : true}));
  dispatch(updateMakeOutboundCall({
    data:{
      phoneVal: phn,
      idVal:id,
    }
  }));
  }

  let handleOnRetailDeskStackMounted = (stack) => {
    console.log(stack);
  };

  let handleOnRetailDeskStackUnMounted = (stack) => {
    console.log(stack);
  };

  let noteButtonClick = () =>{
    if(retailDeskTableData.length!=0){
      let retailDeskTableDataCl = retailDeskTableData;
        let newArr = [];
        retailDeskTableDataCl.forEach(val =>{
            let {idContatto} = val;
            newArr.push(idContatto) ;
          });
        let request = {
          idContatto:newArr
        }

        dispatch(toggleSpinnerById(globalSpinnerId));
        httpPostNoteService(request).then(responseList => {
        dispatch(toggleSpinnerById(globalSpinnerId));

        let newArr2 = []
        retailDeskTableDataCl.forEach(getVal =>{
           let {idContatto, note , ...otherValue} = getVal
           if(responseList[idContatto]){
            note = responseList[idContatto]
           }
           newArr2.push({idContatto,note,...otherValue})
          })          
        dispatch(setRetailDeskTableData({retailDeskTableVal : newArr2}));
      });
    }
  }

  return (
    <WidgetWrapper widgetShow={retailDeskShow}>
      <ExpandedWidgetWrapper
        className={"sospesi-expand-main-container"}
        elStack={elStack}
        events={{
          handleOnStackMounted: handleOnRetailDeskStackMounted,
          handleOnStackUnMounted: handleOnRetailDeskStackUnMounted,
        }}
      >
        <WidgetTitle
          title="Retail Desk"
          iconElement={
            <IconBlueClose
              configuration={{
                onClick: (active) => {
                  dispatch(
                    updateWidgetMenuEventByCode({
                      widget: {
                        code: retailDeskWidgetCode,
                        menuEventState: !retailDeskMenuShow,
                      },
                    })
                  );
                  dispatch(stackNavPop());
                },
              }}
            />
          }
        />
        <>
         <AlertToast
              configuration={{
                unqiueID: retailDeskAlertId,
                className: "inline-toast-container",
                transition: "flip",
              }}
          />
          <div className="d-flex flex-column">
            <div className="d-flex">
              <div className="row no-gutters flex-fill">
                <div className="col-2">
                <div className="small-content-label-class">Campagna</div>
                  <SelectField configuration={campagnaFilterField} />
                </div>
                <div className="col-2 ml-2 ">
                <div className="small-content-label-class">Assegnati</div>
                  <SelectField configuration={assegnatiFilterField} />
                </div>
                <div className="col-2 ml-2 ">
                <div className="small-content-label-class">Stato</div>
                  <SelectField configuration={statoFilterField} />
                </div>
                <div className="col-2 ml-2 p-1 mt-2">
                     <button type="button" className={`btn Rectangle-Button-Blue w-100`}
                        onClick= {estraiButtonClick}>
                         Estrai
                    </button>
                    {disableButton ? <p className="text-red">*Selezionare Campagne o Assegnati</p> :<></>}
                </div>
                <div className="col-2 ml-2 p-1 mt-2">
                     <button type="button" className={`btn Rectangle-Button-Blue w-100`} onClick={noteButtonClick}>
                         Aggiorna Note
                    </button>
                </div>
              </div>
            </div>
            <div className="mt-2">
              <SimpleTable configuration={retailDeskTable} />
            </div>
            <RetailDeskConfirmationModal/>
          </div>
        </>
      </ExpandedWidgetWrapper>
    </WidgetWrapper>
  );
};

export default ExpandedRetailDeskContainer;
