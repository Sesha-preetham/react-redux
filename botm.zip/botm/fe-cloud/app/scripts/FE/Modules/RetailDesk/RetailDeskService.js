import { toast } from "react-toastify";
import { retailDeskAlertId } from "../../CommonComponents/AlertToast/AlertIdConstants";
import { beServiceUrls } from "../../Client/ClientProperties";
import { exposedDispatch,exposedGetState } from "../../Store/store";
import { reduceToOptions, getBaseErrorMessage } from "../../Utils/CommonUtil";
import HttpClient from "../../Utils/HttpClient";

  export const httpGetCampagneList = async () => {
    const dispatch = exposedDispatch;
    let httpClient = new HttpClient();
    httpClient.setUrl(beServiceUrls().getCampagnelist);
    let responseData = await httpClient.httpGet({},).then((responseVal) => {
      const { status = "",response = {} } = responseVal;
      if (status === "OK") {
        return reduceToOptions(response)("id", "description");
      }else if(status ==="KO"){
        toast.warn(getBaseErrorMessage("Warning",response), { containerId: retailDeskAlertId });
      }else{
        throw response
      }
      return [];
    }).catch((err) => {
      toast.error(getBaseErrorMessage("Error",err), { containerId: retailDeskAlertId });
      return [];
    });
    return responseData;
  };
  

  export const httpGetAssegnatiList = async() => {
    const dispatch = exposedDispatch;
    let httpClient = new HttpClient();
    httpClient.setUrl(beServiceUrls().getAgentlist);
    let responseData = await httpClient.httpGet({},).then((responseVal) => {
      const { status = "",response = {} } = responseVal;
      if (status === "OK") {
        return reduceToOptions(response)("employeeId", "name");
      }else if(status ==="KO"){
        toast.warn(getBaseErrorMessage("Warning",response), { containerId: retailDeskAlertId });
      }else{
        throw response
      }
      return [];
    }).catch((err) => {
      toast.error(getBaseErrorMessage("Error",err), { containerId: retailDeskAlertId });
      return [];
    });
    return responseData;
  };

  export const httpGetStatoArr = async() => {
    const dispatch = exposedDispatch;
    let httpClient = new HttpClient();
    httpClient.setUrl(beServiceUrls().getStatoArr);
    let responseData = await httpClient.httpGet({},).then((responseVal) => {
      const { status = "", response = [] } = responseVal;
      if (status === "OK") {        
        let obj = [];
        for (let i = 0; i < response.length; ++i){
            obj.push({"id": response[i] , "value":response[i]});
        }
        return reduceToOptions(obj)("id", "value");
      }else if(status ==="KO"){
        toast.warn(getBaseErrorMessage("Warning",response), { containerId: retailDeskAlertId });
      }else{
        throw response
      }
      return [];
    }).catch((err) => {
      toast.error(getBaseErrorMessage("Error",err), { containerId: retailDeskAlertId });
      return [];
    });
    return responseData;
  };
  

  export const httpPostRetailDeskList = async (request = {}) => {
    let httpClient = new HttpClient();
    httpClient.setUrl(beServiceUrls().postRetailDeskTableData);
    let responseData = await httpClient.httpPost(request).then((response) => {
      const { status = "", contatti = [] } = response;
      if (status === "OK") {
        return contatti;
      }else if(status ==="KO"){
        toast.warn(getBaseErrorMessage("Warning",response), { containerId: retailDeskAlertId });
      }else{
        throw response
      }
      return [];
    }).catch((err) => {
      toast.error(getBaseErrorMessage("Error",err), { containerId: retailDeskAlertId });
      return [];
    });
    return responseData;
  }


  export const httpPostNoteService = async (request = {}) => {
    let httpClient = new HttpClient();
    httpClient.setUrl(beServiceUrls().noteServiceData);
    let responseData = await httpClient.httpPost(request).then((response) => {
      const { status = "", noteMap = {} } = response;
      if (status === "OK") {
        return noteMap;
      }else if(status ==="KO"){
        toast.warn(getBaseErrorMessage("Warning",response), { containerId: retailDeskAlertId });
      }else{
        throw response
      }
      return [];
    }).catch((err) => {
      toast.error(getBaseErrorMessage("Error",err), { containerId: retailDeskAlertId });
      return [];
    });
    return responseData;
  }