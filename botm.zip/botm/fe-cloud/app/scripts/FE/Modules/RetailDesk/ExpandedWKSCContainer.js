import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { CSSTransition } from "react-transition-group";
import IconBlueClose from "../../CommonComponents/Common/Icons/IconBlueClose";
import {
  getDisplayDataByCode,
  wkscWidgetCode,
  retailDeskWidgetCode,
  getMainWidgetConfigByIdAndCode,
  updateWidgetMenuEventByCode
} from "../Widgets/widgetsSlice";
import WidgetTitle from "../Widgets/WidgetTitle";
import { getInteractionDetails } from "../../Modules/Interaction/interactionSlice";
import { stackNavPop } from "../../Main/StackNavigation/stackNavigationSlice";
import { exposedDispatch } from "../../Store/store";
import { getPrivatoDataByInteraction } from "../../Modules/Anagrafica/anagraficaSlice"; 
import { setIdSoggetto } from "../../Store/preferenceSlice";


const ExpandedWKSCContainer = (props) => {
  const { expandWKSC = false, setExpandWKSC = () => {} } = props;

  const { widgets } = useSelector((state) => state.widgets);
  const { wkscUrl , idSoggettoVal } = useSelector((state) => state.preference);
  const { currentInteraction = "noInteraction", interactions = [], } = useSelector((state) => state.interaction);
  const { anagrafica } = useSelector((state) => state.anagrafica);
  const [wkscMenuEventState, , wkscTopMenuShow] = getDisplayDataByCode(widgets)(wkscWidgetCode);
  const [ wkscWidgetURL, setWkscWidgetURL ] = useState("");

  const dispatch = exposedDispatch;  

  useEffect(() => {
    if(idSoggettoVal)
    replaceUrlData(idSoggettoVal)
    else
    setWkscWidgetURL(wkscUrl);
  }, [idSoggettoVal,wkscUrl]);


  useEffect(() => {
    const {
      data: [{ idSoggetto = "",             
        } = {},
      ] = [],
    } = getPrivatoDataByInteraction(anagrafica)(currentInteraction);
    if(idSoggetto)
    dispatch(setIdSoggetto({idSoggettoValue: idSoggetto}));
  }, [ currentInteraction, anagrafica])

  const replaceUrlData = (idSoggetto )=> {
    let newValue = wkscUrl.replace("$idSoggetto",idSoggetto);
    setWkscWidgetURL(newValue);
  }  

const closeWKSCContainer =()=>{
      dispatch(stackNavPop());
                dispatch(
                  updateWidgetMenuEventByCode({
                    widget: {
                      code: wkscWidgetCode ,
                      menuEventState: false,
                    },
                  })
                );
    }

  return (
    <>
      <CSSTransition
        in={wkscTopMenuShow}
        timeout={300}
        classNames="slide-left-toggle"
        unmountOnExit={false}
        mountOnEnter={true}
      >
        <div className="section-conversation d-flex flex-column h-100">
          <WidgetTitle
            title="WKSC"
            iconElement={
              <div className="d-flex" style={{ float: "right" }}>
                {!expandWKSC ? (
                  <IconBlueClose
                    configuration={{
                      onClick: (active) => {
                        closeWKSCContainer();
                      },
                    }}
                  />
                ) : (
                  <>
                  </>
                )}
              </div>
            }
          />
          <div className="row no-gutters h-100 purecloud-interaction-container">
            <div className="d-flex flex-row w-100">
              <div className="w-100">
                <iframe
                  id="workStationId"
                  className="w-100 purecloud-interaction h-100"
                  name="purecloud-interaction"
                  allow="camera *; microphone *; autoplay *"
                  src = {wkscWidgetURL}
                  
                ></iframe>
              </div>
            </div>
          </div>
        </div>
      </CSSTransition>
    </>
  );
};

export default ExpandedWKSCContainer;
