import React, { useEffect, useState, useRef } from "react";
import { useDispatch, useSelector } from "react-redux";
import ConfirmationModal  from "../../CommonComponents/Modal/ConfirmationModal";
import {
    retailDeskWidgetCode,
    getMainWidgetConfigByIdAndCode,
  } from "../Widgets/widgetsSlice";
import { setShowConfirmationModal } from "../RetailDesk/retailDeskSlice";
import {makeOutboundCallMethod } from "../../Utils/CommonUtil"

const RetailDeskConfirmationModal = (props) => {

    const showModal= useSelector((state) => state.retailDesk.showModal);
    const makeOutboundCall = useSelector((state) => state.retailDesk.makeOutboundCall);

    const{phoneNumberVal, idContattoVal} = makeOutboundCall;

    const { widgets } = useSelector((state) => state.widgets);
    const { outboundQueueId } = getMainWidgetConfigByIdAndCode(widgets)(retailDeskWidgetCode);
    const dispatch = useDispatch();

    let handleOnCloseConfirmationModal = ()=>{
        dispatch(setShowConfirmationModal({showVal : false}));
    }
    
    let handleOnConfirmClickModal = ()=> {
        makeOutboundCallMethod(phoneNumberVal,idContattoVal,outboundQueueId );
    }
    
    return(
        <ConfirmationModal 
        showModal={showModal}
        handleOnCloseModal={handleOnCloseConfirmationModal}
        handleOnConfirmClick={handleOnConfirmClickModal}
        modalTitle="conferma di chiamata"
        modalQuestion={`Vuoi effettuare la chiamata a ${phoneNumberVal} ?`}
    />
    );
};

export default RetailDeskConfirmationModal;