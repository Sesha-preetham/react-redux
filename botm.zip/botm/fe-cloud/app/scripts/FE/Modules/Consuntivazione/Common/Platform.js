import React, { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import FormFieldHandler from "../../../CommonComponents/Forms/FormFieldHandler";
import SelectField from "../../../CommonComponents/Forms/SelectField";
import { exposedGetState } from "../../../Store/store";
import { getConsunDataById, updateConsunDataByProperty }from "../consuntivaSlice";

const Platform = (props) => {
  const { 
    formFields = new FormFieldHandler()
  } = props;
  const dispatch = useDispatch();

  const { currentInteraction = "noInteraction" } = useSelector(
    (state) => state.interaction
  );

  const { consunData } = useSelector(
    (state) => state.consuntiva
  );

  const { platformRequired = false } = getConsunDataById(consunData)(
    currentInteraction
  );

  useEffect(() => {
      if(formFields.getField("platform")){
        let isVisible = formFields.getField("platform").theField.isVisible();
        formFields.getField("platform").theField.setVisible(platformRequired);
        // below is for triggering the validation and showing the feedback the first time the platform become visible
        if(platformRequired === true && !isVisible){
          formFields.getField("platform").theField.setValue(null);
        }
      }
  },[platformRequired]);

  let platformFieldConfigutation = {
    uniqueID: "platform",
    multiSelect: false,
    label: "",
    placeHolder: "Seleziona piattaforma",
    readonly: false,
    visible: false,
    disabled: false,
    options: [],
    searchEnabled: true,
    //value: [],
    form: formFields,
    setValue: (obj) => {
        console.log("Platform setValue ", obj);
        const { currentInteraction } = exposedGetState().interaction;
        dispatch(
            updateConsunDataByProperty({
                interactionId: currentInteraction,
                data: {
                property: "platform",
                value: obj.currentValue,
                },
            })
        );
    },
    validation: {
        externalCheck: (value) => {
            if (value && !Array.isArray(value)) {
                return true;
            }
            return false;
        },
      },
    feedback: {
        enable: true,
        component: () => <>* Piattaforma obbligatoria</>,
    },
  }

  return <SelectField configuration={platformFieldConfigutation} />;
}

export default Platform;
