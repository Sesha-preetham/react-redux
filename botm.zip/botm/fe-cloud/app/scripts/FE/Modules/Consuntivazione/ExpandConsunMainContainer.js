import React from "react";
import { useDispatch , useSelector} from "react-redux";
import IconBlueClose from "../../CommonComponents/Common/Icons/IconBlueClose";
import ExpandConsunContainer from "../Consuntivazione/ExpandConsunContainer";
import ExpandSimplifiedConsunContainer from "../Consuntivazione/ExpandSimplifiedConsunContainer";
import {
  stackExpand,
  stackNavPop,
  stackPreview,
} from "../../Main/StackNavigation/stackNavigationSlice";
import ExpandedWidgetWrapper from "../Widgets/ExpandedWidgetWrapper";
import WidgetTitle from "../Widgets/WidgetTitle";
import { getInternalWidgetByIdAndCode , simplifiedCosunWidgetCode } from "../Widgets/internalWidgetsSlice";
import {
  updateConsunLayout,
} from "./consuntivaSlice";

const ExpandConsunMainContainer = (props) => {
  const { elStack = {} } = props;
  const dispatch = useDispatch();
  const { internalWidgets } = useSelector((state) => state.internalWidgets);
  const { currentInteraction = "noInteraction"} = useSelector(
    (state) => state.interaction
  );
  const [simplifiedCosunWidgetShow] = getInternalWidgetByIdAndCode(internalWidgets)(
    currentInteraction,
    simplifiedCosunWidgetCode
  );

  let handleOnStackMounted = (stack) => {
    dispatch(updateConsunLayout(stackExpand));
  };

  let handleOnStackUnMounted = (stack) => {
    dispatch(updateConsunLayout(stackPreview));
  };

  let handleOnStackClose = () => {
    dispatch(stackNavPop());
  };

  return (
    <ExpandedWidgetWrapper
      className={"consult-expand-main-container"}
      elStack={elStack}
      events={{
        handleOnStackMounted,
        handleOnStackUnMounted,
      }}
    >
      <WidgetTitle
        title="Motivo del contatto"
        iconElement={
          <IconBlueClose
            configuration={{
              onClick: (active) => {
                handleOnStackClose();
              },
            }}
          />
        }
      />
      {simplifiedCosunWidgetShow ? <ExpandSimplifiedConsunContainer/> : <ExpandConsunContainer/>}
    </ExpandedWidgetWrapper>
  );
};

export default ExpandConsunMainContainer;
