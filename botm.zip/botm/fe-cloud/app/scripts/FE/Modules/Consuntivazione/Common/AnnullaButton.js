import React from "react";

const AnnullaButton = (props) => {
  const { handleOnClickAnnulla = () => {} } = props;

  return (
    <button
      type="button"
      className={`btn Rectangle-Button-White w-100`}
      onClick={handleOnClickAnnulla}
    >
      Annulla
    </button>
  );
};

export default AnnullaButton;
