import React from "react";
import { useDispatch } from "react-redux";
import FormFieldHandler from "../../../CommonComponents/Forms/FormFieldHandler";
import RadioButton from "../../../CommonComponents/Forms/RadioButton";
import { exposedGetState } from "../../../Store/store";
import { updateConsunDataByProperty } from "../consuntivaSlice";

const StatoContatto = (props) => {
  const { formFields = new FormFieldHandler() } = props;
  const dispatch = useDispatch();

  let statoContatto = {
    uniqueID: "statoContatto",
    label: "Stato contatto",
    validation: {
      mandatory: true,
    },
    checked: "CHIUSA",
    options: [
      {
        id: "CHIUSA",
        description: "Chiusa",
      },
      {
        id: "DA RICONTATTARE",
        description: "Da ricontattare",
      },
      {
        id: "APERTA MANUTENZIONE",
        description: "Aperta manutenzione",
      },
      {
        id: "ATTESA INFO UTENTE",
        description: "In attesa info utente",
      },
    ],
    setValue: (obj) => {
      console.log("setValue", obj);
      const { currentInteraction } = exposedGetState().interaction;
      dispatch(
        updateConsunDataByProperty({
          interactionId: currentInteraction,
          data: {
            property: "stato",
            value: obj.currentValue,
          },
        })
      );
      if (formFields.getField("numeroTicket")) {
        formFields
          .getField("numeroTicket")
          .theField.setVisible(
            obj.currentValue === "APERTA MANUTENZIONE" ? true : false
          );
      }
    },
    form: formFields,
  };

  return <RadioButton configuration={statoContatto} />;
};

export default StatoContatto;
