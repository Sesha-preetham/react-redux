import React, { useEffect} from "react";
import { useDispatch , useSelector} from "react-redux";
import FormFieldHandler from "../../../CommonComponents/Forms/FormFieldHandler";
import SelectField from "../../../CommonComponents/Forms/SelectField";
import { exposedGetState } from "../../../Store/store";
import { getInteractionDetails } from "../../Interaction/interactionSlice";
import { updateConsunDataByProperty, getConsunDataById , updateConsunDataByPropertyArray} from "../consuntivaSlice";
import { httpGetLinkedTags } from "../Service";
import {
  consunHashTagSpinnerId,
  toggleSpinnerById,
} from "../../../CommonComponents/Spinner/spinnerSlice";

const GenesysWrapUp = (props) => {
  const { formFields = new FormFieldHandler() , simplifiedConsun} = props;

  const {consunData} = exposedGetState().consuntiva;
  
 const interactionState = exposedGetState().interaction;
 const { currentInteraction } = interactionState;
 const { autoWrapupHashtag } = getConsunDataById(consunData)(currentInteraction);
  const dispatch = useDispatch();

  const onChangeLoadHashTag = (wrapupOption) => {
    const interactionState = exposedGetState().interaction;
    const { currentInteraction } = interactionState;
    const {label: wrapupName, value: wrapupcodeId } = wrapupOption.currentValue || {};
    const { queueName } = getInteractionDetails(interactionState.interactions)(currentInteraction);
    const {consunData} = exposedGetState().consuntiva;
    let { wrapUp , isDisconnected,isConsuntivaDone , autoWrapupHashtag } = getConsunDataById(consunData)(currentInteraction);
    if(simplifiedConsun  && wrapupcodeId){
      dispatch(
        updateConsunDataByProperty({
          interactionId: currentInteraction,
          data: {
            property: "allTagsSelected",
            value: true
          }
        })
      );
      if(isDisconnected == true && isConsuntivaDone == false ){
        dispatch(
          updateConsunDataByProperty({
            interactionId: currentInteraction,
            data: {
              property: "consuntivaButtonDisabled",
              value: false
            }
          })
        );
      }

    }else if(queueName && wrapupcodeId && (!wrapUp || (wrapUp.label.toUpperCase() != wrapupName.toUpperCase()))){       //CCCLOUD-255
      dispatch(toggleSpinnerById(consunHashTagSpinnerId));
      //formFields.getField("hashTag").theField.setValue([]);
      httpGetLinkedTags({
        queueName,
        wrapupcodeId
      }).then((linkedTagsOptions =[]) => {      
        if(autoWrapupHashtag.autoGenesysWrapup){
          setAutoHashTagDetails(autoWrapupHashtag.autoGenesysWrapup , wrapupcodeId);
        }
        else
          formFields.getField("hashTag").theField.setValue([]);
        if(linkedTagsOptions.length>0)
          formFields.getField("hashTag").theField.reloadOptions(linkedTagsOptions);
        dispatch(toggleSpinnerById(consunHashTagSpinnerId));
      }).catch(error => {
        dispatch(toggleSpinnerById(consunHashTagSpinnerId));
      });
    } 
  }


  const setAutoHashTagDetails = (genesysWrapupRecallVal, wrapupcodeId) => {
    const interactionState = exposedGetState().interaction;
    const { currentInteraction } = interactionState;
    const {consunData} = exposedGetState().consuntiva;
  const { autoWrapupHashtag } = getConsunDataById(consunData)(currentInteraction);
    const[objVal] =  genesysWrapupRecallVal;
    const {value, label} = objVal;
    if(wrapupcodeId && wrapupcodeId == value)
    {
  formFields.getField("hashTag").theField.setValue(autoWrapupHashtag.autoHashtag); 
    dispatch(
      updateConsunDataByProperty({
        interactionId: currentInteraction,
        data: {
          property: "tags",
          value: autoWrapupHashtag.autoHashtag
        },
      })
    );

  dispatch(
    updateConsunDataByProperty({
      interactionId:currentInteraction,
      data: {
        property: "allTagsSelected",
        value: true
      },
    })
  );
  }
  else {
  formFields.getField("hashTag").theField.setValue([]);
  dispatch(
    updateConsunDataByProperty({
      interactionId:currentInteraction,
      data: {
        property: "allTagsSelected",
        value: false
      },
    })
  );
  }
  }

  useEffect(() => {
    if(autoWrapupHashtag.autoGenesysWrapup) { 
    let wrapUp;
    [wrapUp] = autoWrapupHashtag.autoGenesysWrapup;
    console.log("wrapUp::::" + JSON.stringify(wrapUp) );
    formFields.getField("genesysWrapUp").theField.setValue(wrapUp ? wrapUp : autoWrapupHashtag.autoGenesysWrapup); 
    dispatch(
      updateConsunDataByProperty({
        interactionId: currentInteraction,
        data: {
          property: "wrapUp",
          value: wrapUp ? wrapUp : autoWrapupHashtag.autoGenesysWrapup
        },
      })
    );
    }
  }, [autoWrapupHashtag.autoGenesysWrapup]);


  let genesysWrapUp = {
    uniqueID: "genesysWrapUp",
    multiSelect: false,
    label: "",
    placeHolder: "Seleziona Genesys Wrap Up",
    readonly: false,
    visible: true,
    disabled: false,
    options: [],
    searchEnabled: true,
    setValue: (obj) => {
      console.log("setValue WRAPUP  currentValue ::::", JSON.stringify(obj.currentValue) );
      const { currentInteraction } = exposedGetState().interaction;
      onChangeLoadHashTag(obj);
      dispatch(
        updateConsunDataByProperty({
          interactionId: currentInteraction,
          data: {
            property: "wrapUp",
            value: obj.currentValue,
          },
        })
      );
    },
    form: formFields,
    validation: {
      externalCheck: (value) => {
        if (value && !Array.isArray(value)) {
          return true;
        }
        return false;
      },
    },
    feedback: {
      enable: true,
      component: () => <>* WrapUp obbligatorio</>,
    },
  };
  return <SelectField configuration={genesysWrapUp} />;
};

export default GenesysWrapUp;
