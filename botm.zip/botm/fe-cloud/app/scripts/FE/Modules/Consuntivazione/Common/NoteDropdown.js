import React, { useEffect, useState } from "react";
import FormFieldHandler from "../../../CommonComponents/Forms/FormFieldHandler";
import NoteTextArea from "./NoteTextArea";
import { useSelector } from "react-redux";
import { getConsunDataById } from "../consuntivaSlice";
import IconCaretDownFill from "../../../CommonComponents/Common/Icons/IconCaretDownFill";
import IconCaretRightFill from "../../../CommonComponents/Common/Icons/IconCaretRightFill";



const NoteDropdown = (props) => {
    const { formFields = new FormFieldHandler() } = props;

    const [ showChildren, setShowChildren ] = useState(false);


    const { currentInteraction = "noInteraction" } = useSelector(
        (state) => state.interaction
      );
    
      const { consunData } = useSelector(
        (state) => state.consuntiva
      );
    
      const { noteRequired = false, note = ""} = getConsunDataById(consunData)(
        currentInteraction
      );

      useEffect(()=>{
        console.log("NoteRequired:",noteRequired);
        setShowChildren(noteRequired);
        if(formFields.getField("note")){
          if(noteRequired === true){
            formFields.getField("note").theField.setFeedbackComponent( () => <>* Note obbligatorie.</>);
          }else{
            formFields.getField("note").theField.setFeedbackComponent( () => <></>, false);
          }
        }
      },[noteRequired]);



    return(
      <>
        <div className={`d-flex flex-row flex-fill my-1 note-dropdown`}>
          <div className="text-center">
            {(showChildren===true)
              ?<IconCaretDownFill configuration={{ className: "caret-arrow", onClick: () => { setShowChildren(!showChildren)}}} />
              :<IconCaretRightFill configuration={{ className: "caret-arrow", onClick: () => { setShowChildren(!showChildren)}}} />
            }
          </div>
          <div className="ml-2">
            <span className="note-dropdown-content-text">Note</span>
          </div>
        </div>
        {(showChildren)?
          <NoteTextArea formFields={formFields} value={note} required={noteRequired} />
        :null}
      </>
    )
}

export default NoteDropdown;