import React from "react";
import { useDispatch } from "react-redux";
import FormFieldHandler from "../../../CommonComponents/Forms/FormFieldHandler";
import TextField from "../../../CommonComponents/Forms/TextField";
import { exposedGetState } from "../../../Store/store";
import { updateConsunDataByProperty } from "../consuntivaSlice";

const NumeroTicket = (props) => {
  const { formFields = new FormFieldHandler() } = props;
  const dispatch = useDispatch();

  let numeroTicket = {
    uniqueID: "numeroTicket",
    placeHolder: "Numero ticket",
    readonly: false,
    visible: true,
    validation: {
      mandatory: true,
      type: "Alphanumeric",
    },
    setValue: (obj) => {
      console.log("setValue", obj);
      const { currentInteraction } = exposedGetState().interaction;
      dispatch(
        updateConsunDataByProperty({
          interactionId: currentInteraction,
          data: {
            property: "ticket",
            value: obj.currentValue,
          },
        })
      );
    },
    form: formFields,
    validation: {
      mandatory: true,
      type: "Alphanumeric",
    },
    feedback: {
      enable: true,
      component: () => <>* Numero ticket obbligatorio.</>,
    },
  };

  return <TextField configuration={numeroTicket} />;
};

export default NumeroTicket;
