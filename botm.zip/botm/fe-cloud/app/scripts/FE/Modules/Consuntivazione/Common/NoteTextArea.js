import React, { useEffect } from "react";
import FormFieldHandler from "../../../CommonComponents/Forms/FormFieldHandler";
import TextArea from "../../../CommonComponents/Forms/TextArea";
import { useDispatch, useSelector } from "react-redux";
import { exposedGetState } from "../../../Store/store";
import { updateConsunDataByProperty, getConsunDataById } from "../consuntivaSlice";


const NoteTextArea = (props) => {
  const { formFields = new FormFieldHandler(), required= false, value = ""} = props;
  const dispatch = useDispatch();


  const { currentInteraction = "noInteraction", interactions=[] } = useSelector(
    (state) => state.interaction
  );

  const { consunData } = useSelector(
    (state) => state.consuntiva
  );

  const { noteRequired = false } = getConsunDataById(consunData)(
    currentInteraction
  );

  useEffect(()=>{
    if(formFields.getField("note")){
      if(noteRequired === true){
        formFields.getField("note").theField.setFeedbackComponent( () => <>* Note obbligatorie.</>);
      }else{
        formFields.getField("note").theField.setFeedbackComponent( () => <></>, false);
      }
    }
  },[noteRequired]);

  let note = {
    uniqueID: "note",
    placeHolder: "Note...",
    readonly: false,
    visible: true,
    value: value,
    validation: {
      mandatory: true,
      type: "",//AlphanumPuntact
    },
    setValue: (obj) => {
      console.log("setValue", obj);
      const { currentInteraction } = exposedGetState().interaction;
      dispatch(
        updateConsunDataByProperty({
          interactionId: currentInteraction,
          data: {
            property: "note",
            value: obj.currentValue,
          },
        })
      );
    },
    form: formFields,
    feedback: {
      enable: required,
      component: () => <>* Note obbligatorie.</>,
    },
  };

  return <TextArea configuration={note} />;
};

export default NoteTextArea;
