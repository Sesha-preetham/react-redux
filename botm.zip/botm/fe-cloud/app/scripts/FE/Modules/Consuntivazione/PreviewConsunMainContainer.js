import React, { useEffect } from "react";
import {  useDispatch ,useSelector } from "react-redux";
import { CSSTransition } from "react-transition-group";
import IconExplode from "../../CommonComponents/Common/Icons/IconExplode";
import { stackNavConsun } from "../../Main/StackNavigation/StackNavComponents";
import {
  stackNavPush,
} from "../../Main/StackNavigation/stackNavigationSlice";
import {
  consuntivazioneWidgetCode,
  getDisplayDataByCode,
} from "../Widgets/widgetsSlice";
import WidgetTitle from "../Widgets/WidgetTitle";
import WidgetWrapper from "../Widgets/WidgetWrapper";
import {
  consunEventListeners,
} from "./Service";
import PreviewConsunContainer from "../Consuntivazione/PreviewConsunContainer";
import PreviewSimplifiedConsunContainer from "./PreviewSimplifiedConsunContainer";
import { withErrorBoundary } from "../../CommonComponents/ErrorBoundary/withErrorBoudary";
import { previewConsunAlertId } from "../../CommonComponents/AlertToast/AlertIdConstants";
import AlertToast from "../../CommonComponents/AlertToast/AlertToast";
import { getInternalWidgetByIdAndCode , simplifiedCosunWidgetCode } from "../Widgets/internalWidgetsSlice";

const PreviewConsunMainContainer = (props) => {
  const { widgets } = useSelector((state) => state.widgets);
  const dispatch = useDispatch();
  const { internalWidgets } = useSelector((state) => state.internalWidgets);
  const [consuntivazioneMenuShow, consuntivazioneShow] = getDisplayDataByCode(
    widgets
  )(consuntivazioneWidgetCode);

  const { currentInteraction = "noInteraction", interactions = [] } = useSelector(
    (state) => state.interaction
  );

  const [simplifiedCosunWidgetShow] = getInternalWidgetByIdAndCode(internalWidgets)(
    currentInteraction,
    simplifiedCosunWidgetCode
  );

  useEffect(() => {
    window.addEventListener("message", consunEventListeners, false);
    return () => {
      window.removeEventListener("message", consunEventListeners, false);
    };
  }, []);

 let handleOnStackExpand = () => {
    dispatch(stackNavPush(stackNavConsun));
  };

  return (
    <WidgetWrapper widgetShow={consuntivazioneShow}>
      <CSSTransition
        in={consuntivazioneMenuShow}
        timeout={300}
        classNames="slide-right-toggle"
        unmountOnExit={false}
        mountOnEnter={true}
      >
        <div className="d-flex flex-column section-consult">
          <WidgetTitle
            title="Motivo del contatto"
            iconElement={
              <IconExplode
                configuration={{
                  onClick: (active) => {
                    handleOnStackExpand();
                  },
                }}
              />
            }
          />
          <div className="d-flex flex-column">
            <AlertToast
              configuration={{
                unqiueID: previewConsunAlertId,
                className: "inline-toast-container",
                transition: "flip",
              }}
            />
        {simplifiedCosunWidgetShow ? <PreviewSimplifiedConsunContainer/> : <PreviewConsunContainer/>}
        </div>
        </div>
      </CSSTransition>
    </WidgetWrapper>
  );
};

export default withErrorBoundary(PreviewConsunMainContainer);
