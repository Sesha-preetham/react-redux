import React from "react";
import { useDispatch } from "react-redux";
import FormFieldHandler from "../../../CommonComponents/Forms/FormFieldHandler";
import SelectField from "../../../CommonComponents/Forms/SelectField";
import { exposedGetState } from "../../../Store/store";
import { getInteractionDetails } from "../../Interaction/interactionSlice";
import { updateConsunDataByProperty, getConsunDataById,updateConsunDataByPropertyArray } from "../consuntivaSlice";
import { httpGetLinkedTags } from "../Service";
import {
  consunHashTagSpinnerId,
  toggleSpinnerById,
} from "../../../CommonComponents/Spinner/spinnerSlice";
import MySpinner from "../../../CommonComponents/Spinner/MySpinner";


const HashTag = (props) => {
  const { formFields = new FormFieldHandler() } = props;
  const dispatch = useDispatch();

  let onChangeLoadHashTag = (hashtagObj = { currentValue: [] }) => {
    const interactionState = exposedGetState().interaction;
    const {consunData} = exposedGetState().consuntiva;
    const { currentInteraction } = interactionState;
    const tags = hashtagObj.currentValue || [];
    const { value: tagParentId } = (tags.length>0)?tags[tags.length-1]:{};
    const { queueName } = getInteractionDetails(interactionState.interactions)(currentInteraction);
    const { isDisconnected,isConsuntivaDone } = getConsunDataById(consunData)(currentInteraction);
    const { value: wrapupcodeId} = formFields.getField("genesysWrapUp").theField.getValue() || {};
    if(queueName && wrapupcodeId){
      dispatch(toggleSpinnerById(consunHashTagSpinnerId));
      httpGetLinkedTags({
        queueName,
        wrapupcodeId,
        tagParentId
      }).then((linkedTagsOptions =[]) => {
        formFields.getField("hashTag").theField.reloadOptions(linkedTagsOptions, true);
        dispatch(toggleSpinnerById(consunHashTagSpinnerId));
        if(linkedTagsOptions.length==0){ //CCCLOUD-159
          dispatch(
            updateConsunDataByProperty({
              interactionId:currentInteraction,
              data: {
                property: "allTagsSelected",
                value: true
              },
            })
          );
          if(isDisconnected == true && isConsuntivaDone == false ){
            dispatch(
              updateConsunDataByProperty({
                interactionId:currentInteraction,
                data: {
                  property: "consuntivaButtonDisabled",
                  value: false
                }
              })
            );
          }
      }
      else {
        dispatch(
          updateConsunDataByPropertyArray({
            interactionId: currentInteraction,
            data: [{
              property: "allTagsSelected",
              value: false
            },
            {
              property: "consuntivaButtonDisabled",
              value: true
            }
          ]
          })
        );
      }
      });
    }
  }

  let checkNoteNeeded = (hasttagOption) => {
    const interactionState = exposedGetState().interaction;
    const { currentInteraction } = interactionState;
    const tags = hasttagOption.currentValue || [];
    let isNoteRequired = false;
    tags.forEach( ( el = {} ) => {
      const { rlData = {} } = el;
      if(rlData.noteRequired === true){
        isNoteRequired = true;
      }
    });
    dispatch(
      updateConsunDataByProperty({
        interactionId: currentInteraction,
        data: {
          property: "noteRequired",
          value: isNoteRequired,
        },
      })
    );
  }

  let checkPlatformNeeded = (hasttagOption) => {
    const interactionState = exposedGetState().interaction;
    const { currentInteraction } = interactionState;
    const tags = hasttagOption.currentValue || [];
    let isPlatformRequired = false;
    tags.forEach( ( el = {} ) => {
      const { rlData = {} } = el;
      if(rlData.platformRequired === true){
        isPlatformRequired = true;
      }
    });
    if(formFields.getField("platform")){
      dispatch(
        updateConsunDataByProperty({
          interactionId: currentInteraction,
          data: {
            property: "platformRequired",
            value: isPlatformRequired,
          },
        })
      );
      console.log("Platform field", formFields.getField("platform"));
      //formFields.getField("platform").theField.setValue(null);
      /*if(!isPlatformRequired){
        formFields.getField("platform").theField.setValue([]);
      }*/
    }
  }

  let hashTag = {
    uniqueID: "hashTag",
    multiSelect: true,
    label: "",
    placeHolder: "Aggiungi hashtag",
    readonly: false,
    visible: true,
    disabled: false,
    options: [],
    searchEnabled: true,
    value: [],
    setValue: (obj) => {
      console.log("setValue", obj);
      const { currentInteraction } = exposedGetState().interaction;
      onChangeLoadHashTag(obj);
      checkPlatformNeeded(obj);
      checkNoteNeeded(obj);
      dispatch(
        updateConsunDataByProperty({
          interactionId: currentInteraction,
          data: {
            property: "tags",
            value: obj.currentValue,
          },
        })
      );
    },
    form: formFields,
    validation: {
      externalCheck: (value) => {
        if (value && Array.isArray(value) && value.length > 0) {
          return true;
        }
        return false;
      },
    },
    feedback: {
      enable: true,
      component: () => <>* Hashtag obbligatorio</>,
    },
  };

  return (<>
            <MySpinner uniqueID={consunHashTagSpinnerId} />
            <SelectField configuration={hashTag} />
          </>);
};

export default HashTag;
