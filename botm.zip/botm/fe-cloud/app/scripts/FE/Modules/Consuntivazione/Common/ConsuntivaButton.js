import React from "react";
import { useSelector } from "react-redux";
import { getConsunDataById } from "../consuntivaSlice";

const ConsuntivaButton = (props) => {
  const { handleOnClickConsuntiva = () => {} } = props;

  const { currentInteraction = "noInteraction" } = useSelector(
    (state) => state.interaction
  );
  const { consunData = {} } = useSelector((state) => state.consuntiva);

  const { consuntivaButtonDisabled = true } = getConsunDataById(consunData)(
    currentInteraction
  );

  return (
    <button
      type="button"
      className={`btn Rectangle-Button-Blue w-100`}
      onClick={handleOnClickConsuntiva}
      disabled={consuntivaButtonDisabled}
    >
      Consuntiva
    </button>
  );
};

export default ConsuntivaButton;
