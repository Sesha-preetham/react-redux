import { toast } from "react-toastify";
import { globalAlertId } from "../../CommonComponents/AlertToast/AlertIdConstants";
import { beServiceUrls, pureCloudOrigin } from "../../Client/ClientProperties";
import {
  stackExpand,
  stackPreview,
} from "../../Main/StackNavigation/stackNavigationSlice";
import { exposedDispatch,exposedGetState } from "../../Store/store";
import { reduceToOptions, getBaseErrorMessage } from "../../Utils/CommonUtil";
import HttpClient from "../../Utils/HttpClient";
import { getNotClientDataByInteraction } from "../Anagrafica/anagraficaSlice";
import {
  addConsunDataById,
  removeConsunDataById,
  updateConsunDataByProperty,getConsunDataById,
  updateConsunAutoWrapupHashtag
} from "./consuntivaSlice";


/**
 *  @deprecated CCCLOUD-254: this method have the issue that if the user insert some note on expand mode
* on do consuntiva on preview mode, "note" is "". 
* Use getConsunFieldDataByIdFromState method instead.
*/
export const getConsunFieldDataById = (type = stackPreview) => {
  return (id = "noInteraction", formFields) => {
    if (!id || !formFields || id === "noInteraction" || formFields.isEmpty())
      return;
    let wrapUp = formFields.getValue("genesysWrapUp");
    let stato = formFields.getValue("statoContatto");
    let numeroTicket = formFields.getValue("numeroTicket");
    let hashTag = formFields.getValue("hashTag");
    let note = type === stackExpand ? formFields.getValue("note") : "";
    let platform = formFields.getValue("platform");
    let returnData = {
      wrapUp,
      note,
      stato,
      tags: hashTag,
      ticket: numeroTicket,
      platform
    };
    return returnData;
  };
};

// CCCLOUD-254
export const getConsunFieldDataByIdFromState = (id = "noInteraction") => {
  if(!id || !exposedGetState().consuntiva.consunData[id]){
    return;
  }
  const {
    wrapUp,
    note,
    stato,
    tags,
    ticket,
    platform,
  } = exposedGetState().consuntiva.consunData[id];
  let returnData = {
    wrapUp,
    note,
    stato,
    tags,
    ticket,
    platform
  }
  return returnData;
}

export const httpPostEliminaSpam = async (bodyRequest = {}, params = {}) => {
  const dispatch = exposedDispatch;
  let httpClient = new HttpClient();
  httpClient.setUrl(beServiceUrls().eliminaSpamming);
  let responseData = await httpClient
    .httpPost(bodyRequest, params)
    .then((response) => {
      return response;
    })
    .catch((err) => {
      throw err;
    });
  return responseData;
};

export const getAnagraficaNotClientData = (id = "") => {
  return (consunObj = {}) => {
    if (!id || !consunObj || id === "noInteraction" || !consunObj[id]) return;
    const { data: clientData } = getNotClientDataByInteraction(consunObj)(id);
    const {
      name,
      surname,
      dataNascita,
      luogoNascita,
      citta,
      cap,
      province,
      recapitoCell,
      recapitoFisso,
      recapitoMail,
    } = clientData;
    const {
      denominazione,
      insegna,
      partitaIva,
      rifPersona,
      aziendaCitta,
      aziendaCap,
      aziendaProvincia,
      aziendaRecapitoMail,
      aziendaRecapitoCell,
      aziendaRecapitoFisso,
    } = clientData;
    let returnData = {
      privato: {
        name,
        surname,
        dataNascita,
        luogoNascita,
        citta,
        cap,
        province,
        recapitoCell,
        recapitoFisso,
        recapitoMail,
      },
      azienda: {
        denominazione,
        insegna,
        partitaIva,
        rifPersona,
        aziendaCitta,
        aziendaCap,
        aziendaProvincia,
        aziendaRecapitoMail,
        aziendaRecapitoCell,
        aziendaRecapitoFisso,
      },
    };
    return returnData;
  };
};

export const httpGetWrapupCode = async (params = {}) => {
  const dispatch = exposedDispatch;
  let httpClient = new HttpClient();
  httpClient.setUrl(beServiceUrls().getWrapupCodeById);
  console.log("httpGetWrapupCode: ", beServiceUrls().getWrapupCodeById);
  let responseData = await httpClient.httpGet({}, params).then((response) => {
    const { status = "", response: wrapUpResponse = {} } = response;
    if (status === "OK") {
      return reduceToOptions(wrapUpResponse)("id", "name");
    }
    return [];
  });
  return responseData;
};

export const httpGetPlatform = async (query = {} ) => {
  let httpClient = new HttpClient();
  httpClient.setUrl(beServiceUrls().getPlatform);
  let responseData = await httpClient.httpGet(query).then((response) => {
    const { status = "", response: platformRespoonse = [] } = response;
    if (status === "OK") {
      return reduceToOptions(platformRespoonse.filter(el => el.valid==="Y"))("id", "description");
    }
    return [];
  });
  return responseData;
}

export const httpGetTagsByOrg = async (query = {}) => {
  const dispatch = exposedDispatch;
  let httpClient = new HttpClient();
  httpClient.setUrl(beServiceUrls().getTagsByOrg);
  let responseData = await httpClient.httpGet(query).then((response) => {
    const { status = "", response: tagsRespoonse = {} } = response;
    if (status === "OK") {
      return reduceToOptions(tagsRespoonse)("id", "description");
    }
    return [];
  });
  return responseData;
};

export const httpGetLinkedTags = async (query = {}) => {
  let httpClient = new HttpClient();
  httpClient.setUrl(beServiceUrls().getLinkedTags);
  let responseData = await httpClient.httpPost(query).then((response) => {
    const { status = "", response: tagsRespoonse = [] } = response;
    if (status === "OK") {
      return reduceToOptions(tagsRespoonse)("id", "description");
    }
    return [];
  });
  return responseData;
};

export const httpGetSurveyVoice = async (params = {}) => {
  const dispatch = exposedDispatch;
  let httpClient = new HttpClient();
  httpClient.setUrl(beServiceUrls().surveyVoiceService);
  let responseData = await httpClient
    .httpGet({},params)
    .then((response) => {
      return response;
    })
    .catch((err) => {
      throw err;
    });
  return responseData;
};

export const httpPostWrapUpHashTagDetails = async (request) => {
  const dispatch = exposedDispatch;
  let httpClient = new HttpClient();
  httpClient.setUrl(beServiceUrls().getWrapUpHashTagDetails);
  await httpClient
    .httpPost(request)
    .then((response) => {
      const { status = "" } = response;
      if(status == "OK"){
        const { interactionId } = request;
        const  { wrapUpResponse = [] , hasTagResponse = []} = response;
        dispatch (updateConsunAutoWrapupHashtag({interactionId , wrapUpResponse, hasTagResponse}));
      }   
      if (status !== "OK") {
        toast.warn(getBaseErrorMessage("Warning", response), {
          containerId: globalAlertId,
        });
      }
    })
    .catch((err) => {
      toast.error(getBaseErrorMessage("Error", err), {
        containerId: globalAlertId,
      });
    });
};

export const httpPostTraceById = async (bodyRequest = {}, params = {}) => {
  const dispatch = exposedDispatch;
  let httpClient = new HttpClient();
  httpClient.setUrl(beServiceUrls().traceById);
  let responseData = await httpClient
    .httpPost(bodyRequest, params)
    .then((response) => {
      return response;
    })
    .catch((err) => {
      throw err;
    });
  return responseData;
};

const consunService = () => {
  const consunEventListeners = (event) => {
    if (event.origin !== pureCloudOrigin) return;
    let message = JSON.parse(event.data);
    console.log("consunEventListeners: ", message);
    const dispatch = exposedDispatch;
    if (message && message.type == "interactionSubscription") {
      let { data: interactionData = {} } = message;
      let { category = "", interaction = {} } = interactionData;

      switch (category) {
        case "add":
          dispatch(addConsunDataById({ interactionId: interaction.id }));
          break;
        case "change":
          break;
        case "connect":
          break;
        case "disconnect":
          const {consunData}= exposedGetState().consuntiva;//CCCLOUD-159
          const {allTagsSelected} = getConsunDataById(consunData)(interaction.id);
          dispatch(
            updateConsunDataByProperty({
              interactionId: interaction.id,
              data: {
                property: "isDisconnected",
                value: true, 
              }, 
            })
          );
          if(allTagsSelected){
            dispatch(
              updateConsunDataByProperty({
                interactionId: interaction.id,
                data: {
                  property: "consuntivaButtonDisabled",
                  value: false, 
                }, 
              })
            );
          }
          break;
        case "acw":
          break;
        case "deallocate":
          dispatch(
            removeConsunDataById({
              interactionId: interaction.id,
            })
          );
          break;
        default:
          console.log("No Event Matched");
      }
    }
  };

  return { consunEventListeners };
};

export const { consunEventListeners } = consunService();
