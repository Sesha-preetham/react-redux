import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { toast } from "react-toastify";
import { previewConsunAlertId } from "../../CommonComponents/AlertToast/AlertIdConstants";
import FormFieldHandler from "../../CommonComponents/Forms/FormFieldHandler";
import MySpinner from "../../CommonComponents/Spinner/MySpinner";
import {
  simplifiedConsunSpinnerId,
  toggleSpinnerById,
} from "../../CommonComponents/Spinner/spinnerSlice";
import {
  stackPreview,
} from "../../Main/StackNavigation/stackNavigationSlice";
import { getAbiSearchByInteraction, getNotClientDataByInteraction, getPrivatoDataByInteraction } from "../Anagrafica/anagraficaSlice";
import AnnullaButton from "./Common/AnnullaButton";
import ConsuntivaButton from "./Common/ConsuntivaButton";
import GenesysWrapUp from "./Common/GenesysWrapUp";
import {
  getConsunDataById,
  updateConsunDataById,
  updateConsunDataByPropertyArray
} from "./consuntivaSlice";
import {
  getAnagraficaNotClientData,
  //getConsunFieldDataById,
  getConsunFieldDataByIdFromState,
  httpGetPlatform,
  httpGetWrapupCode,
  httpPostTraceById,
} from "./Service";
import { getInteractionDetails } from "../Interaction/interactionSlice";
import { getBaseErrorMessage } from "../../Utils/CommonUtil";
import NoteTextArea from "./Common/NoteTextArea";
import NoteDropdown from "./Common/NoteDropdown";

const PreviewSimplifiedConsunContainer = (props) => {
  const [formFields] = useState(new FormFieldHandler(true));
  
  const { currentInteraction = "noInteraction", interactions = [] } = useSelector(
    (state) => state.interaction
  );

  const { anagrafica: anagraficaObj } = useSelector(
    (state) => state.anagrafica
  );
  const { cunsunLayoutType, consunData } = useSelector(
    (state) => state.consuntiva
  );
  const dispatch = useDispatch();
  
  useEffect(() => {
    if (cunsunLayoutType === stackPreview && !formFields.isEmpty())
      loadFieldValues();
  }, [cunsunLayoutType]);

  useEffect(() => {
    onMount();
  }, [currentInteraction]);

  let onMount = async () => {
    if (!currentInteraction || currentInteraction === "noInteraction") return;
    const { queueName } = getInteractionDetails(interactions)(currentInteraction);
    dispatch(toggleSpinnerById(simplifiedConsunSpinnerId));
    if(formFields.getField("platform")){
      httpGetPlatform({
        queueName: queueName
      }).then((response) => {
        formFields.getField("platform").theField.reloadOptions(response);
      })
    }
    if (formFields.getField("genesysWrapUp")) {
      await httpGetWrapupCode({
        interactionId: currentInteraction,
      }).then((response) => {
        formFields.getField("genesysWrapUp").theField.reloadOptions(response);
      });
    }
    /* CCCLOUD-152 - need to load tags based on wrapupcode
    if (formFields.getField("hashTag")) {
      await httpGetTagsByOrg().then((response) => {
        formFields.getField("hashTag").theField.reloadOptions(response);
      });
    }*/
    if (!formFields.isEmpty()) {
      loadFieldValues();
    }
    dispatch(toggleSpinnerById(simplifiedConsunSpinnerId));
  };

  let loadFieldValues = () => {
    let { wrapUp, note, stato, tags, ticket, platform, platformRequired } = getConsunDataById(consunData)(
      currentInteraction
    );
    formFields.getField("genesysWrapUp").theField.setValue(wrapUp);
    if(formFields.getField("note")){
      formFields.getField("note").theField.setValue(note);
    }

  };

  let handleOnClickAnnulla = () => {
    formFields.getField("genesysWrapUp").theField.setValue([]);
    if(formFields.getField("note")){
      formFields.getField("note").theField.setValue("");
    }
    dispatch(updateConsunDataById({ interactionId: currentInteraction }));
  };

  let handleOnClickConsuntiva = () => {
    if (!currentInteraction || currentInteraction === "noInteraction") {
      toast.warn("No Interacion selected", {
        containerId: previewConsunAlertId,
      });
      return;
    }
    if (formFields.isFormValid()) {
      /*let { wrapUp, note, stato, tags, ticket, platform } = getConsunFieldDataById(
        cunsunLayoutType
      )(currentInteraction, formFields);*/
      let { wrapUp, note, stato, tags, ticket, platform } = getConsunFieldDataByIdFromState(currentInteraction);
      let { value: wrapUpId, label: wrapUpCode } = wrapUp || {};
      let { value: platformId } = platform || {};
      let requestData = {
        wrapUpId,
        wrapUpCode,
        note,
        stato,
        platformId,
        tags: tags.reduce((acc, obj) => {
          acc.push(obj.rlData);
          return acc;
        }, []),
        ticket,
      };

      const { intxId } = getInteractionDetails(interactions)(currentInteraction);
      requestData = {
        ...requestData,
        intxId: intxId
      };

      const { clientToggle } = getNotClientDataByInteraction(anagraficaObj)(
        currentInteraction
      );
      if (!clientToggle) {
        const { data: clientData } = getNotClientDataByInteraction(
          anagraficaObj
        )(currentInteraction);
        const { surname, denominazione } = clientData;
        if (!surname && !denominazione) {
          toast.warn("Cognome o Denominazione sono obbligatori!", {
            containerId: previewConsunAlertId,
          });
          return;
        }
        const { privato = {}, azienda = {} } = getAnagraficaNotClientData(
          currentInteraction
        )(anagraficaObj);
        requestData = {
          ...requestData,
          notClient: {
            ...privato,
            ...azienda,
          },
        };
      }else{
        const { data: privatoClients = []} =  getPrivatoDataByInteraction(anagraficaObj)(currentInteraction);
        const abisearch = getAbiSearchByInteraction(anagraficaObj)(currentInteraction);
        const [{ idSoggetto: idSoggettoSurvey } = {} ] = privatoClients;
        if(idSoggettoSurvey){
          requestData = {
            ...requestData,
            idSoggettoSurvey,
            abiSurvey: abisearch
          };
        }
      }
      dispatch(toggleSpinnerById(simplifiedConsunSpinnerId));
      httpPostTraceById(requestData, {
        interactionId: currentInteraction,
      })
        .then((response) => {
          dispatch(toggleSpinnerById(simplifiedConsunSpinnerId));
          const { status = "" } = response;
          if (status === "OK") {
            handleOnClickAnnulla();
            dispatch(
              updateConsunDataByPropertyArray({
                interactionId: currentInteraction,
                data: [{
                  property: "consuntivaButtonDisabled",
                  value: true,
                },  
                {
                  property:"isConsuntivaDone",
                  value:true,
                }
              ]
              })
            );
            toast.success("Success", { containerId: previewConsunAlertId });
          } else {
            toast.warn(getBaseErrorMessage("Warning",response), { containerId: previewConsunAlertId });
          }
        })
        .catch((err) => {
          dispatch(toggleSpinnerById(simplifiedConsunSpinnerId));
          toast.error(getBaseErrorMessage("Error",err), { containerId: previewConsunAlertId });
        });
    }
  };

  return (
        <>
          
            <div className="flex-fill mb-3">
              <GenesysWrapUp formFields={formFields} simplifiedConsun={true}/>
            </div>
            <div className="flex-fill mb-3">
              <NoteDropdown formFields={formFields} />
            </div>
            <MySpinner uniqueID={simplifiedConsunSpinnerId} />
            <div className="d-flex flex-row flex-fill">
              <div className="w-50 pr-2">
                <AnnullaButton handleOnClickAnnulla={handleOnClickAnnulla} />
              </div>
              <div className="w-50 pl-2">
                <ConsuntivaButton
                  handleOnClickConsuntiva={handleOnClickConsuntiva}
                />
              </div>
            </div>
          
        </>
  );
};

export default PreviewSimplifiedConsunContainer;
