import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { toast } from "react-toastify";
import { globalAlertId } from "../../CommonComponents/AlertToast/AlertIdConstants";
import FormFieldHandler from "../../CommonComponents/Forms/FormFieldHandler";
import {
  globalSpinnerId,
  toggleSpinnerById,
} from "../../CommonComponents/Spinner/spinnerSlice";
import {
  stackExpand,
  stackNavPop,
  stackPreview,
} from "../../Main/StackNavigation/stackNavigationSlice";
import { getAbiSearchByInteraction, getNotClientDataByInteraction, getPrivatoDataByInteraction } from "../Anagrafica/anagraficaSlice";
import AnnullaButton from "./Common/AnnullaButton";
import ConsuntivaButton from "./Common/ConsuntivaButton";
import GenesysWrapUp from "./Common/GenesysWrapUp";
import NoteTextArea from "./Common/NoteTextArea";
import {
  getConsunDataById,
  updateConsunDataById,
  updateConsunLayout,
  updateConsunDataByPropertyArray,
} from "./consuntivaSlice";
import {
  getAnagraficaNotClientData,
  //getConsunFieldDataById,
  getConsunFieldDataByIdFromState,
  httpGetPlatform,
  httpGetWrapupCode,
  httpPostTraceById,
} from "./Service";
import { getInteractionDetails } from "../Interaction/interactionSlice";
import { getBaseErrorMessage } from "../../Utils/CommonUtil";

const ExpandSimplifiedConsunContainer = (props) => {
  const [formFields] = useState(new FormFieldHandler(true));

  const { currentInteraction = "noInteraction", interactions=[] } = useSelector(
    (state) => state.interaction
  );

  const { anagrafica: anagraficaObj } = useSelector(
    (state) => state.anagrafica
  );
  const { cunsunLayoutType, consunData } = useSelector(
    (state) => state.consuntiva
  );

  const dispatch = useDispatch();

  useEffect(() => {
    if (cunsunLayoutType === stackExpand && !formFields.isEmpty())
      loadFieldValues();
  }, [cunsunLayoutType]);

  useEffect(() => {
    onMount();
  }, [currentInteraction]);

  const { platformRequired = false, noteRequired = false } = getConsunDataById(consunData)(
    currentInteraction
  );

  useEffect(()=>{
    if(noteRequired === true){
      formFields.getField("note").theField.setFeedbackComponent( () => <>* Note obbligatorie.</>);
    }else{
      formFields.getField("note").theField.setFeedbackComponent( () => <></>, false);
    }
  },[noteRequired]);

  let onMount = async () => {
    if (!currentInteraction || currentInteraction === "noInteraction") return;
    const { queueName } = getInteractionDetails(interactions)(currentInteraction);
    dispatch(toggleSpinnerById(globalSpinnerId));
    if(formFields.getField("platform")){
      await httpGetPlatform({
        queueName: queueName
      }).then((response) => {
        formFields.getField("platform").theField.reloadOptions(response);
      })
    }
    if (formFields.getField("genesysWrapUp")) {
      await httpGetWrapupCode({
        interactionId: currentInteraction,
      }).then((response) => {
        formFields.getField("genesysWrapUp").theField.reloadOptions(response);
      });
    }
    /* CCCLOUD-152 - need to load tags based on wrapupcode
    if (formFields.getField("hashTag")) {
      await httpGetTagsByOrg().then((response) => {
        formFields.getField("hashTag").theField.reloadOptions(response);
      });
    }
    */
    if (!formFields.isEmpty()) {
      loadFieldValues();
    }
    dispatch(toggleSpinnerById(globalSpinnerId));
  };

  let loadFieldValues = () => {
    let { wrapUp, note, stato, tags, ticket, platform } = getConsunDataById(consunData)(
      currentInteraction
    );
    formFields.getField("genesysWrapUp").theField.setValue(wrapUp);
    formFields.getField("note").theField.setValue(note);
  };

  let handleOnClickAnnulla = () => {
    formFields.getField("genesysWrapUp").theField.setValue([]);
    formFields.getField("note").theField.setValue("");
    dispatch(updateConsunDataById({ interactionId: currentInteraction }));
  };

  let handleOnClickConsuntiva = () => {
    if (!currentInteraction || currentInteraction === "noInteraction") {
      toast.warn("No Interacion selected", {
        containerId: globalAlertId,
      });
      return;
    }
    if (formFields.isFormValid()) {
      /*let { wrapUp, note, stato, tags, ticket, platform } = getConsunFieldDataById(
        cunsunLayoutType
      )(currentInteraction, formFields);*/
      let { wrapUp, note, stato, tags, ticket, platform } = getConsunFieldDataByIdFromState(currentInteraction);
      let { value: wrapUpId, label: wrapUpCode } = wrapUp || {};
      let { value: platformId } = platform || {};

      let requestData = {
        wrapUpId,
        wrapUpCode,
        platformId,
        note,
        stato,
        tags: tags.reduce((acc, obj) => {
          acc.push(obj.rlData);
          return acc;
        }, []),
        ticket,
      };

      const { intxId } = getInteractionDetails(interactions)(currentInteraction);
      requestData = {
        ...requestData,
        intxId: intxId
      };

      const { clientToggle } = getNotClientDataByInteraction(anagraficaObj)(
        currentInteraction
      );
      if (!clientToggle) {
        const { data: clientData } = getNotClientDataByInteraction(
          anagraficaObj
        )(currentInteraction);
        const { surname, denominazione } = clientData;
        if (!surname && !denominazione) {
          toast.warn("Cognome o Denominazione sono obbligatori!", {
            containerId: globalAlertId,
          });
          return;
        }
        const { privato = {}, azienda = {} } = getAnagraficaNotClientData(
          currentInteraction
        )(anagraficaObj);
        requestData = {
          ...requestData,
          notClient: {
            ...privato,
            ...azienda,
          },
        };
      }else{
        const { data: privatoClients = []} =  getPrivatoDataByInteraction(anagraficaObj)(currentInteraction);
        const abisearch = getAbiSearchByInteraction(anagraficaObj)(currentInteraction);
        const [{ idSoggetto: idSoggettoSurvey } = {} ] = privatoClients;
        if(idSoggettoSurvey){
          requestData = {
            ...requestData,
            idSoggettoSurvey,
            abiSurvey: abisearch
          };
        }
      }
      dispatch(toggleSpinnerById(globalSpinnerId));
      httpPostTraceById(requestData, {
        interactionId: currentInteraction,
      })
        .then((response) => {
          dispatch(toggleSpinnerById(globalSpinnerId));
          const { status = "" } = response;
          if (status === "OK") {
            handleOnClickAnnulla();
            dispatch(
              updateConsunDataByPropertyArray({
                interactionId: currentInteraction,
                data: [{
                  property: "consuntivaButtonDisabled",
                  value: true,
                },
                {
                  property:"isConsuntivaDone",
                  value:true,
                }
              ]
              })
            );
            toast.success("Success", { containerId: globalAlertId });
          } else {
            toast.warn(getBaseErrorMessage("Warning",response), { containerId: globalAlertId });
          }
        })
        .catch((err) => {
          dispatch(toggleSpinnerById(globalSpinnerId));
          toast.error(getBaseErrorMessage("Error",err), { containerId: globalAlertId });
        });
    }
  };

  let handleOnStackClose = () => {
    dispatch(stackNavPop());
  };

  return (
    <>
      <div className="d-flex flex-column h-100">
        <div className="d-flex flex-row mb-3">
          <div className="d-flex flex-column w-50">
            <div className="mb-3">
              <span className="content-label">Genesys Warp up</span>
            </div>
            <div className="w-75">
              <GenesysWrapUp formFields={formFields}  simplifiedConsun={true}/>
            </div>
          </div>
        </div>
        <div className="d-flex flex-row mb-3">
          <div className="d-flex flex-column w-50">
            <div className="mb-3">
              <span className="content-label">Note</span>
            </div>
            <div className="w-75">
              <NoteTextArea layout={"expand"} formFields={formFields} />
            </div>
          </div>
        </div>
        <div className="d-flex justify-content-center flex-row mt-auto">
          <div className="w-25 pr-2">
            <AnnullaButton handleOnClickAnnulla={handleOnClickAnnulla} />
          </div>
          <div className="w-25 pl-2">
            <ConsuntivaButton
              handleOnClickConsuntiva={handleOnClickConsuntiva}
            />
          </div>
        </div>
      </div>
    </>
  );
};

export default ExpandSimplifiedConsunContainer;
