import { createSlice } from "@reduxjs/toolkit";
import { stackPreview } from "../../Main/StackNavigation/stackNavigationSlice";

let initialState = {
  cunsunLayoutType: stackPreview,
  consunData: {
    noInteraction: {
      wrapUp: null,
      note: "",
      stato: "CHIUSA",
      tags: [],
      ticket: "",
      consuntivaButtonDisabled: true,
      platform: null,
      platformRequired: false,
      noteRequired: false,
      isDisconnected: false,//CCCLOUD-159
      isConsuntivaDone: false,
      allTagsSelected:false,
      callingList: "",
      prefix: "",
      phoneNumber: "",
      prenatoRecallButtonDisabled:false,
      disconnectTimeoutId:null,
      autoWrapupHashtag:{
        autoGenesysWrapup: "",
        autoHashtag:"",
      },
      disableSurveyVoiceIcon :false,
    },
  },
};

const consuntivaSlice = createSlice({
  name: "consuntiva",
  initialState,
  reducers: {
    updateConsunLayout(state, action) {
      const { payload = "" } = action;
      state.cunsunLayoutType = payload;
    },
    addConsunDataById(state, action) {
      const { payload = {} } = action;
      const { interactionId = "noInteraction" } = payload;
      if (!interactionId) return;
      if (!state.consunData[interactionId])
        state.consunData[interactionId] = initialState.consunData.noInteraction;
    },
    updateConsunDataById(state, action) {
      const { payload = {} } = action;
      const { interactionId = "noInteraction", data = {} } = payload;
      if (!interactionId || !state.consunData[interactionId]) return;
      const {
        wrapUp = null,
        note = "",
        stato = "CHIUSA",
        tags = [],
        ticket = "",
      } = data;
      state.consunData[interactionId].wrapUp = wrapUp;
      state.consunData[interactionId].note = note;
      state.consunData[interactionId].stato = stato;
      state.consunData[interactionId].tags = tags;
      state.consunData[interactionId].ticket = ticket;
    },
    updateConsunDataByProperty(state, action) {
      const { payload = {} } = action;
      const { interactionId = "noInteraction", data = {} } = payload;
      if (!interactionId) return;
      const { property, value } = data;
      if (!property || value === undefined || !state.consunData[interactionId]) return;
      if (property === "tags") {
        state.consunData[interactionId][property] = [...value];
      } else {
        state.consunData[interactionId][property] = value;
      }
    },
    updateConsunDataByPropertyArray(state, action) {   //CCCLOUD-159
      const { payload = {} } = action;
      const { interactionId = "noInteraction", data  } = payload;
      if (!interactionId) return;
      for(var i=0; i<data.length; i++){
      const{property,value} = data[i];
       if (!property || value === undefined || !state.consunData[interactionId]) return;
       if (property === "tags") {
         state.consunData[interactionId][property] = [...value];
       } else {
         state.consunData[interactionId][property] = value;
       }
     };     
    },
    removeConsunDataById(state, action) {
      const { payload = {} } = action;
      const { interactionId = "noInteraction" } = payload;
      if (!interactionId || interactionId === "noInteraction" || !state.consunData[interactionId]) return;
      state.consunData = Object.entries(state.consunData).reduce(
        (acc, [key, value]) => {
          if (key != interactionId) {
            acc[key] = value;
          }
          return acc;
        },
        {}
      );
    },
    resetConsunData(state) {
      state = initialState;
    },
    updateConsunAutoWrapupHashtag(state,action) {
      const { payload = {} } = action;
      const { interactionId = "noInteraction", wrapUpResponse = [], hasTagResponse = []} = payload;
      if (!interactionId || !state.consunData[interactionId]) return;
      state.consunData[interactionId].autoWrapupHashtag.autoGenesysWrapup = wrapUpResponse ? wrapUpResponse : [];
      state.consunData[interactionId].autoWrapupHashtag.autoHashtag = hasTagResponse ? hasTagResponse : [];
  },
  },
});

export const {
  updateConsunLayout,
  updateConsunDataById,
  addConsunDataById,
  updateConsunDataByProperty,
  updateConsunDataByPropertyArray,
  removeConsunDataById,
  resetConsunData,
  updateConsunAutoWrapupHashtag,
} = consuntivaSlice.actions;

export const getConsunDataById = (consunData) => {
  return (id = "noInteraction") => {
    if (consunData[id]) {
      return consunData[id];
    }
    return initialState.consunData.noInteraction;
  };
};

export default consuntivaSlice.reducer;
