import React from "react";
import { useSelector } from "react-redux";
import { CSSTransition } from "react-transition-group";
import { pureCloudEmbeddedUrl } from "../../Client/ClientProperties";
import { withErrorBoundary } from "../../CommonComponents/ErrorBoundary/withErrorBoudary";
import {
  getDisplayDataByCode,
  softphoneCommonCode,
} from "../Widgets/widgetsSlice";
import SurveyDisconnectButton from "./SurveyDisconnectButton";

const Container = (props) => {
  const { widgets } = useSelector((state) => state.widgets);
  const [softphoneMenuShow] = getDisplayDataByCode(widgets)(
    softphoneCommonCode
  );

  const { language } = useSelector((state) => state.preference);

  return (
    <CSSTransition
      in={softphoneMenuShow}
      timeout={300}
      classNames="slide-left-toggle"
      unmountOnExit={false}
      mountOnEnter={true}
    >
      <div className="softphone shadow-sm">
        <div className="row no-gutters h-100">
          <div className="col-12 d-flex flex-column">
            <div className="row no-gutters">
              <div className="col-12">
                <SurveyDisconnectButton />
                {language && (
                  <iframe
                    id="softphone"
                    allow="camera *; microphone *"
                    src={`${pureCloudEmbeddedUrl}&languagePreference=${language}`}
                  ></iframe>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </CSSTransition>
  );
};

export default withErrorBoundary(Container);
