import React, { useEffect, useState } from "react";
import { useSelector } from "react-redux";
import { toast } from "react-toastify";
import { pureCloudOrigin } from "../../Client/ClientProperties";
import { globalAlertId } from "../../CommonComponents/AlertToast/AlertIdConstants";
import IconPhone from "../../CommonComponents/Common/Icons/IconPhone";
import {
  globalSpinnerId,
  toggleSpinnerById,
} from "../../CommonComponents/Spinner/spinnerSlice";
import { exposedDispatch } from "../../Store/store";
import {
  getBaseErrorMessage,
  getBTChannelOfInteraction,
} from "../../Utils/CommonUtil";
import {
  getConsunDataById,
  updateConsunDataByProperty,
} from "../Consuntivazione/consuntivaSlice";
import { httpGetSurveyVoice } from "../Consuntivazione/Service";
import { getInteractionDetails } from "../Interaction/interactionSlice";

const SurveyDisconnectButton = () => {
  const { currentInteraction = "noInteraction", interactions = [] } =
    useSelector((state) => state.interaction);

  const { consunData } = useSelector((state) => state.consuntiva);

  const { disableSurveyVoiceIcon = false } =
    getConsunDataById(consunData)(currentInteraction);

  const { attributes = {}, isConnected } =
    getInteractionDetails(interactions)(currentInteraction);

  const checkSurveyVoiceEnable =
    attributes.sondaggio == "true" &&
    getBTChannelOfInteraction(
      getInteractionDetails(interactions)(currentInteraction)
    ) === "VOICE";

  const [pefMenuStatusClosed, setPefMenuStatusClosed] = useState(true);

  const menuStatusChangeEventListener = (event) => {
    if (event.origin !== pureCloudOrigin) return;
    let message = JSON.parse(event.data);
    if (message && message.type == "customAction") {
      console.log("menuStatusChangeEventListener: ", message);
      const { category, open = false} = message.data;
      if(category === "menuStatusState" ){
        setPefMenuStatusClosed(!open);
      }
    }
  }

  useEffect(() => {
    window.addEventListener("message", menuStatusChangeEventListener, false);
    return () => {
      window.removeEventListener("message", menuStatusChangeEventListener, false);
    };
  }, []);

  const handleOnCallIconClick = () => {
    const dispatch = exposedDispatch;
    dispatch(toggleSpinnerById(globalSpinnerId));
    httpGetSurveyVoice({
      interactionId: currentInteraction,
    })
      .then((response = {}) => {
        dispatch(toggleSpinnerById(globalSpinnerId));
        const { status = "" } = response;
        if (status === "OK") {
          toast.success("Success", { containerId: globalAlertId });
          dispatch(
            updateConsunDataByProperty({
              interactionId: currentInteraction,
              data: {
                property: "disableSurveyVoiceIcon",
                value: true,
              },
            })
          );
        } else {
          toast.warn(getBaseErrorMessage("Warning", response), {
            containerId: globalAlertId,
          });
          dispatch(
            updateConsunDataByProperty({
              interactionId: currentInteraction,
              data: {
                property: "disableSurveyVoiceIcon",
                value: false,
              },
            })
          );
        }
      })
      .catch((err = {}) => {
        dispatch(toggleSpinnerById(globalSpinnerId));
        toast.error(getBaseErrorMessage("Error", err), {
          containerId: globalAlertId,
        });

        dispatch(
          updateConsunDataByProperty({
            interactionId: currentInteraction,
            data: {
              property: "disableSurveyVoiceIcon",
              value: false,
            },
          })
        );
      });
  };
  return (
    <>
      {checkSurveyVoiceEnable && pefMenuStatusClosed ? (
        <IconPhone
          configuration={{
            uniqueID: "surveyDisconnectIcon",
            disable: disableSurveyVoiceIcon || !isConnected,
            onClick: (active) => {
              handleOnCallIconClick();
            },
          }}
        />
      ) : (
        <></>
      )}
    </>
  );
};

export default SurveyDisconnectButton;
