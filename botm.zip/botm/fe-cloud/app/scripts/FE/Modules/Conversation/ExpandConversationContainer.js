import React from "react";
import { useDispatch } from "react-redux";
import IconBlueClose from "../../CommonComponents/Common/Icons/IconBlueClose";
import { withErrorBoundary } from "../../CommonComponents/ErrorBoundary/withErrorBoudary";
import { stackNavConversation } from "../../Main/StackNavigation/StackNavComponents";
import { stackNavToggle } from "../../Main/StackNavigation/stackNavigationSlice";
import ExpandedWidgetWrapper from "../Widgets/ExpandedWidgetWrapper";
import WidgetTitle from "../Widgets/WidgetTitle";

const ExpandConversationContainer = (props) => {
  const { elStack = {} } = props;
  const dispatch = useDispatch();

  let handleOnStackMounted = (stack) => {};

  let handleOnStackUnMounted = (stack) => {};

  let handleOnStackClose = () => {
    dispatch(stackNavToggle(stackNavConversation));
  };

  return (
    <ExpandedWidgetWrapper
      className={""}
      elStack={elStack}
      events={{
        handleOnStackMounted,
        handleOnStackUnMounted,
      }}
    >
      <WidgetTitle
        title="Conversazione"
        iconElement={
          <IconBlueClose
            configuration={{
              onClick: (active) => {
                handleOnStackClose();
              },
            }}
          />
        }
      />
      <div className="d-flex flex-column h-100">
        <div className="row no-gutters h-100">
          <iframe
            className="w-100 purecloud-interaction"
            name="purecloud-interaction-expanded"
            allow="camera *; microphone *; autoplay *"
            src="https://apps.mypurecloud.de/crm/interaction.html"
          ></iframe>
        </div>
      </div>
    </ExpandedWidgetWrapper>
  );
};

export default withErrorBoundary(ExpandConversationContainer);
