import React from "react";
import {  useDispatch, useSelector } from "react-redux";
import { toast } from "react-toastify";
import { beServiceUrls } from "../../../Client/ClientProperties";
import { globalAlertId } from "../../../CommonComponents/AlertToast/AlertIdConstants";
import { globalSpinnerId, toggleSpinnerById } from "../../../CommonComponents/Spinner/spinnerSlice";
import { getAniFromInteraction, getBaseErrorMessage } from "../../../Utils/CommonUtil";
import HttpClient from "../../../Utils/HttpClient";
import { getPrivatoDataByInteraction } from "../../Anagrafica/anagraficaSlice";
import { getInteractionDetails } from "../../Interaction/interactionSlice";
import {
  getInternalWidgetConfigByIdAndCode,
  presaVeloceWidgetCode,
} from "../../Widgets/internalWidgetsSlice";

const PresaVeloceButton = () => {
  const { currentInteraction = "noInteraction", interactions = [] } =
    useSelector((state) => state.interaction);

  const { anagrafica= {}} = useSelector((state)=> state.anagrafica);
  
  const interaction = getInteractionDetails(interactions)(currentInteraction);
  
   const { queueName, ani, isConnected, intxId } = interaction;

  const { internalWidgets } = useSelector((state) => state.internalWidgets);

  const { widgetConfig = {} } = getInternalWidgetConfigByIdAndCode(
    internalWidgets
  )(currentInteraction, presaVeloceWidgetCode);


  const { selectedIbCode = {} } = getPrivatoDataByInteraction(anagrafica)(
    currentInteraction
  );

  const dispatch = useDispatch();

  const httpPostPresaVeloce = async (request) => {
    let httpClient = new HttpClient();
    httpClient.setUrl(beServiceUrls().presaveloce);
    dispatch(toggleSpinnerById(globalSpinnerId));
    await httpClient
      .httpPost(request)
      .then((response) => {
        dispatch(toggleSpinnerById(globalSpinnerId));
        const { status = "" } = response;
        if (status !== "OK") {
          toast.warn(getBaseErrorMessage("Warning", response), {
            containerId: globalAlertId,
          });
        }
      })
      .catch((err) => {
        dispatch(toggleSpinnerById(globalSpinnerId));
        toast.error(getBaseErrorMessage("Error", err), {
          containerId: globalAlertId,
        });
      });
  }

  const handlePresaVeloceClick = async () => {
      const { data = [] } = widgetConfig || {};
      let queueConfigObj = data.find( (el = {}) => queueName == el.queueName);
      const { contactListId } = queueConfigObj || {};

      const { value: ibCode } = selectedIbCode || {};

      console.log("handlePresaVeloceClick --->", widgetConfig, contactListId, ibCode);
      if(contactListId){
        httpPostPresaVeloce({
            intxId: intxId,
            phoneNumber: getAniFromInteraction(interaction),
            contactListId: contactListId,
            queueName: queueName,
            conversationId: currentInteraction,
            ibCode: ibCode,
            connected: isConnected
        })
      }

  };

  return (
    <div>
      <button
        type="button"
        className={`btn Rectangle-Button-Blue my-1 mx-1`}
        onClick={handlePresaVeloceClick}
      >
        Presa veloce
      </button>
    </div>
  );
};

export default PresaVeloceButton;
