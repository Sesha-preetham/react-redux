import React, {useState} from "react";
import IconCaretDownFill from "../../../CommonComponents/Common/Icons/IconCaretDownFill";
import IconCaretRightFill from "../../../CommonComponents/Common/Icons/IconCaretRightFill";

const ConversationDropdown = (props) => {
  const { className = "", title = "" } = props;

  const [ showChildren, setShowChildren ] = useState(false);

  return (
    <>
      <div className={`d-flex flex-row flex-fill my-1 ${className}`}>
        <div className="text-right w-100 pr-1 pt-1">
          {(showChildren===true)
            ?<IconCaretDownFill configuration={{ className: "caret-arrow", onClick: () => { setShowChildren(!showChildren)}}} />
            :<IconCaretRightFill configuration={{ className: "caret-arrow", onClick: () => { setShowChildren(!showChildren)}}} />
          }
        </div>
      </div>
      {(showChildren)?props.children:null}
    </>
  );
};

export default ConversationDropdown;
