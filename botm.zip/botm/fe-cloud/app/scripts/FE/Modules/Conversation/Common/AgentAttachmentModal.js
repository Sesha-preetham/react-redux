import React , { useState, useEffect, useRef } from "react";
import { Row, Col } from "react-bootstrap";
import { toast } from "react-toastify";
import {  useSelector  } from "react-redux";
import MyModal from "../../../CommonComponents/Modal/MyModal";
import {
  agentAttachmentModalSpinnerId,
  toggleSpinnerById,
} from "../../../CommonComponents/Spinner/spinnerSlice";
import MySpinner from "../../../CommonComponents/Spinner/MySpinner";
import { beServiceUrls } from "../../../Client/ClientProperties";
import { getBaseErrorMessage } from "../../../Utils/CommonUtil";
import HttpClient from "../../../Utils/HttpClient";
import { exposedDispatch, exposedGetState } from "../../../Store/store";
import AlertToast from "../../../CommonComponents/AlertToast/AlertToast";
import SimpleTable from "../../../CommonComponents/SimpleTable/SimpleTable";
import AgentFileUploadClear from "./AgentFileUploadClear";
import { withErrorBoundary } from "../../../CommonComponents/ErrorBoundary/withErrorBoudary";

const AgentAttachmentModal = ({showAgentAttachmentModal = false , handleOnCloseModal = () => {}, disableAddAttachmentButton = false }) => {

  
  const { currentInteraction = "noInteraction" } =  useSelector((state) => state.interaction);
  const [tableData , setTableData]= useState([]);

  const currentInteractionRef = useRef();
  currentInteractionRef.current = currentInteraction;

const agentAttachmentModal = {
    uniqueID: "agentAttachmentModal",
    modalClass: "authentication-info my-modal",
    dialogClassName: "modal-w",
    title: {
      content: "Allegati",
      class: "widget-title"
    },
    modalShow: showAgentAttachmentModal,
    modalHeaderShow: true,
    backdrop: {
      enable: true
    },
    events: {
      onHide: () => {
       console.log("Close AgentAttachment Modal ");
       handleOnCloseModal(false);
      },
      onEntered: () => {
         onMount();
        console.log("multiClienteModal modal onEntered");
      },
      onExited: () => {
        handleOnCloseModal(false);
        console.log("Exit AgentAttachment Modal");
      }
    }
  };

 
  let onMount = () => {
    httpGetAttachmentTableData({ interactionId:  currentInteractionRef.current, })
  };

   const httpGetAttachmentTableData = async (params = {}) => {
    const dispatch = exposedDispatch;
    let httpClient = new HttpClient();
    dispatch(toggleSpinnerById(agentAttachmentModalSpinnerId));
    httpClient.setUrl(beServiceUrls().getAttachmentTableData);
    console.log("getAttachmentTableData::::: ", beServiceUrls().getAttachmentTableData);
    await httpClient.httpGet({}, params).then((response) => {
      const { status = "", attachmentList = [] } = response;
      dispatch(toggleSpinnerById(agentAttachmentModalSpinnerId));
      if (status === "OK") {
        setTableData(attachmentList);
      }
      if (status !== "OK") {
        toast.warn(getBaseErrorMessage("Warning", response), {
          containerId: "AgentAttachmentModalAlertId",
        });   
      }
    }).catch((err) => {
      dispatch(toggleSpinnerById(agentAttachmentModalSpinnerId));
      toast.error(getBaseErrorMessage("Error", err), {
        containerId: "AgentAttachmentModalAlertId",
      });
    });
  };

 
  const agentAttachmentTableData = {
    uniqueID: "agentAttachmentTableData",
    pagination: true,
    paginationOptions: {
      pageSize: 5,
    },
    metaData: [
      {
        Header: "Nome file",
        accessor: "name",
      },
      {
        Header: "Data ora",
        accessor: "insertedDate",
      },
      {
        Header: "Caricato da.",
        accessor: "insertedBy",
      },
      {
        Header: " ",
        accessor: (rowData, metaInd) => {
          return renderDownloadButton(rowData, metaInd);
      },
      }
    ],
    data: tableData ? tableData : [],
    events: {},
  };

 const renderDownloadButton = (rowData, metaInd) => {
    return (
      <div>  
      <Col xs={4} sm={4} md={4}>
         <button
            type="button"
            className={`btn Rectangle-Button-Blue w-300`}
            onClick = { () => handleOnDownload(rowData, metaInd)}
         >
        Download
       </button>
      </Col> 
      </div>
    );
  };

const handleOnDownload = (rowData, metaInd) => {
console.log("rowData:::" + rowData + "metaInd::::" + metaInd );
httpGetFileDownloadOperation({attachmentId: rowData.id, }, rowData.name);
};


const httpGetFileDownloadOperation = async (params = {},fileName) => {
  const dispatch = exposedDispatch;
  let httpClient = new HttpClient();
  httpClient.setUrl(beServiceUrls().downloadAttachmentFileData);
  console.log("downloadAttachmentFileData::::: ", beServiceUrls().downloadAttachmentFileData);
  await httpClient.httpGetFile({}, params).then((response) => { 
    let succcessData = response;
    const blob = new Blob([succcessData.data]);
    const blobUrl = URL.createObjectURL(blob);
    // START DUMMY LINK FOR DOWNLOAD ACTION
    const link = document.createElement("a");
    link.href = blobUrl;
    link.setAttribute("download",fileName);
    document.body.appendChild(link);
    link.click();
    link.parentNode.removeChild(link);
    toast.success("Download success", { containerId: "AgentAttachmentModalAlertId" });
  }).catch((err) => {
    toast.error(getBaseErrorMessage("Error", err), {
      containerId: "AgentAttachmentModalAlertId",
    });
  });
};


const handleUploadFile = async(file) => {
  let formData = new FormData();
  let returnValue;
   if (file) {
    console.log("Upload Filename::::" + file.name + " Upload FileSize::::" + file.size);
     formData.append("file", file);
     returnValue =  await httpGetFileUploadOperation(formData,{interactionId:  currentInteractionRef.current,});   
  };
   return returnValue;
}

const httpGetFileUploadOperation = async (request, params = {}) => {
const dispatch = exposedDispatch;
let httpClient = new HttpClient();
let checkFileUpload;
dispatch(toggleSpinnerById(agentAttachmentModalSpinnerId));
httpClient.setUrl(beServiceUrls().uploadAttachmentFileData);
console.log("uploadAttachmentFileData::::: ", beServiceUrls().uploadAttachmentFileData);
await httpClient.httpPostFile(request,params).then((response) => {   
  const { status = "" } = response;
  dispatch(toggleSpinnerById(agentAttachmentModalSpinnerId));
  if (status === "OK") {
    toast.success("File Upload Success", { containerId: "AgentAttachmentModalAlertId" });
     checkFileUpload = true;
  }
  if (status !== "OK") {
    toast.warn(getBaseErrorMessage("Warning", response), {
      containerId: "AgentAttachmentModalAlertId",
    });   
     checkFileUpload = false;
  }
  onMount();
}).catch((err) => {
  dispatch(toggleSpinnerById(agentAttachmentModalSpinnerId));
  toast.error(getBaseErrorMessage("Error", err), {
    containerId: "AgentAttachmentModalAlertId",
  });
   checkFileUpload = false;
});
return checkFileUpload;
};



  return (
    <div>
       <MyModal configuration={agentAttachmentModal}>
       <MySpinner uniqueID={agentAttachmentModalSpinnerId} type="agentAttachmentModalSpinner" />
       <>
       <div className="d-flex justify-content-center">
        <div className="w-100">
          <AlertToast
            configuration={{
              unqiueID: "AgentAttachmentModalAlertId",
              className: "inline-toast-container",
              transition: "flip",
            }}
          />
        </div>
      </div>
        <div className="d-flex flex-row mt-auto">
      <div className="w-100 pl-2">
      <AgentFileUploadClear 
      mimeType={"*"} 
      events={{onFileUpload:handleUploadFile}}
      disableButton={disableAddAttachmentButton}
      />
      </div>

      </div>

      <div className="d-flex">
      <div className="w-100 p-3">
      <SimpleTable configuration={agentAttachmentTableData} />
      </div>
      </div>
      </>
    </MyModal> 
    </div>
  );
};

export default withErrorBoundary(AgentAttachmentModal);
