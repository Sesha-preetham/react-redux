import React, { useEffect, useRef, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { CSSTransition } from "react-transition-group";
import IconBlueClose from "../../CommonComponents/Common/Icons/IconBlueClose";
import IconExplode from "../../CommonComponents/Common/Icons/IconExplode";
import IconPhone from "../../CommonComponents/Common/Icons/IconPhone";
import { toast } from "react-toastify";
import { globalAlertId } from "../../CommonComponents/AlertToast/AlertIdConstants";
import {
  conversazioneWidgetCode,
  getDisplayDataByCode,
} from "../Widgets/widgetsSlice";
import WidgetTitle from "../Widgets/WidgetTitle";
import WidgetWrapper from "../Widgets/WidgetWrapper";
import {
  getInteractionDetails,
  getNotificationDetails,
  updateInteractionProperty,
  updateNotificationProperty,
} from "../Interaction/interactionSlice";
import PresaVeloceButton from "./Common/PresaVeloceButton";
import ConversationDropdown from "./Common/ConversationDropDown";
import PrenotaRecallModal from "./Common/PrenotaRecallModal";
import {
  httpPostEliminaSpam,
  httpGetSurveyVoice,
} from "../Consuntivazione/Service";
import {
  getInternalWidgetByIdAndCode,
  getConversationButtonCodePresent,
  spamWidgetCode,
  altraInfoWidgetCode,
  presaVeloceWidgetCode,
  prenotaRecallWidgetCode,
  attachementWidgetCode,
  getInternalWidgetConfigByIdAndCode,
  chatAuthenticateWidgetCode,
} from "../Widgets/internalWidgetsSlice";
import {
  globalSpinnerId,
  toggleSpinnerById,
} from "../../CommonComponents/Spinner/spinnerSlice";
import {
  getBaseErrorMessage,
  getBTChannelOfInteraction,
  isCustomFunctionAvailable,
  getChatChannel,
} from "../../Utils/CommonUtil";
import {
  getBTCallType,
  httpPostChatMessage,
  httpChatAuthenticate,
  httpPostCallbackDisconnect,
} from "../Interaction/Service";
import { customFunctionCodes } from "../../Store/commonSlice";
import {
  getConsunDataById,
  updateConsunDataByProperty,
} from "../Consuntivazione/consuntivaSlice";
import ConversationNotification from "./Common/ConversationNotification";
import { exposedDispatch } from "../../Store/store";
import AgentAttachmentModal from "./Common/AgentAttachmentModal";
import {
  updateAutenticaButtonStateByInteraction,
  getAuthenticationDataByInteraction,
} from "../Authentication/authenticationSlice";
import IconChevron from "../../CommonComponents/Common/Icons/IconChevron";

const SimpleConversationContainer = (props) => {
  const {
    expandConversation = false,
    setExpandConversation = () => {},
    onExpand = () => {},
  } = props;

  const { widgets } = useSelector((state) => state.widgets);
  const { authentication } = useSelector((state) => state.authentication);

  const [conversazioneMenuShow, conversazioneShow] = getDisplayDataByCode(
    widgets
  )(conversazioneWidgetCode);

  const { internalWidgets } = useSelector((state) => state.internalWidgets);
  const { consunData } = useSelector((state) => state.consuntiva);

  const {
    currentInteraction = "noInteraction",
    interactions = [],
    notifications = [],
  } = useSelector((state) => state.interaction);

  const [spamMenuShow] = getInternalWidgetByIdAndCode(internalWidgets)(
    currentInteraction,
    spamWidgetCode
  );

  const [altraInfoShow] = getInternalWidgetByIdAndCode(internalWidgets)(
    currentInteraction,
    altraInfoWidgetCode
  );

  const [presaVeloceShowWidget] = getInternalWidgetByIdAndCode(internalWidgets)(
    currentInteraction,
    presaVeloceWidgetCode
  );

  const [agentChatAttachmentShowWidget] = getInternalWidgetByIdAndCode(
    internalWidgets
  )(currentInteraction, attachementWidgetCode);

  const { widgetConfig: widgetConfig } = getInternalWidgetConfigByIdAndCode(
    internalWidgets
  )(currentInteraction, attachementWidgetCode);

  const { attachmentDisableChannel } = widgetConfig || {
    attachmentDisableChannel: [],
  };

  const attachmentDisableChannelValue =
    agentChatAttachmentShowWidget &&
    attachmentDisableChannel.indexOf(
      getChatChannel(getInteractionDetails(interactions)(currentInteraction))
    ) > -1;

  const agentChatAttachmentWidgetShow =
    agentChatAttachmentShowWidget &&
    getBTCallType(getInteractionDetails(interactions)(currentInteraction)) ===
      "INBOUND" &&
    getBTChannelOfInteraction(
      getInteractionDetails(interactions)(currentInteraction)
    ) === "CHAT";

  let { prenatoRecallButtonDisabled = false, disableSurveyVoiceIcon = false } =
    getConsunDataById(consunData)(currentInteraction);

  const [prenotaRecallShowWidget] = getInternalWidgetByIdAndCode(
    internalWidgets
  )(currentInteraction, prenotaRecallWidgetCode);

  const [chatAuthenticateShow] = getInternalWidgetByIdAndCode(internalWidgets)(
    currentInteraction,
    chatAuthenticateWidgetCode
  );

  const prenotaRecallWidgetShow =
    prenotaRecallShowWidget &&
    getBTCallType(getInteractionDetails(interactions)(currentInteraction)) ===
      "INBOUND" &&
    getBTChannelOfInteraction(
      getInteractionDetails(interactions)(currentInteraction)
    ) === "VOICE";

  const presaVeloceShow =
    presaVeloceShowWidget &&
    isCustomFunctionAvailable(customFunctionCodes().presaVeloceAction) &&
    getBTCallType(getInteractionDetails(interactions)(currentInteraction)) ===
      "INBOUND";

  const {
    state,
    isEmail,
    isChat,
    isDisconnected,
    intxId,
    showMailFormAlert = false,
    attributes = {},
    isMessage,
    isConnected,
    hideCoversationContent = false,
  } = getInteractionDetails(interactions)(currentInteraction);

  const checkSurveyVoiceEnable =
    attributes.sondaggio == "true" &&
    //getBTCallType(getInteractionDetails(interactions)(currentInteraction)) ==="INBOUND" &&
    getBTChannelOfInteraction(
      getInteractionDetails(interactions)(currentInteraction)
    ) === "VOICE";

  const chatAuthenticateWidgetShow =
    chatAuthenticateShow && attributes["context.authenticated"] != "true";
  getBTCallType(getInteractionDetails(interactions)(currentInteraction)) ===
    "INBOUND" &&
    getBTChannelOfInteraction(
      getInteractionDetails(interactions)(currentInteraction)
    ) === "CHAT";

  const { disableAutenticaButton = false } =
    getAuthenticationDataByInteraction(authentication)(currentInteraction);

  
  const endCallbackWidgetShow =
    getBTCallType(getInteractionDetails(interactions)(currentInteraction)) ===
      "CALLBACK" &&
    getBTChannelOfInteraction(
      getInteractionDetails(interactions)(currentInteraction)
    ) === "VOICE" &&
    isConnected;

  const arrowMenuShow =
    getConversationButtonCodePresent(internalWidgets)(currentInteraction) ||
    endCallbackWidgetShow;

  const {
    read = false,
    data: notificationData = [],
    showPopover = false,
  } = getNotificationDetails(notifications)(currentInteraction);

  const [label, setLabel] = useState("No value");
  const [disableButton, setDisableButton] = useState(true);
  const [disableAltraInfoButton, setDisableAltraInfoButton] = useState(true);
  const [disableAddAttachment, setDisableAddAttachment] = useState(true);
  const [showPrenataRecallModal, setShowPrenataRecallModal] = useState(false);
  const [showAgentAttachmentModal, setShowAgentAttachmentModal] =
    useState(false);
  const [notificationDataAvailable, isNotifificationDataAvailable] =
    useState(false);

  const dispatch = useDispatch();

  useEffect(() => {
    if (notificationData.length > 0) {
      isNotifificationDataAvailable(true);
    } else {
      isNotifificationDataAvailable(false);
    }
  }, [currentInteraction, notificationData]);

  useEffect(() => {
    if (isEmail && !isDisconnected) {
      console.log(state);
      setLabel(currentInteraction);
      setDisableButton(false);
    } else {
      setDisableButton(true);
      setLabel("No value");
    }
    if (isChat && !isDisconnected) {
      setDisableAddAttachment(false);
      setDisableAltraInfoButton(false);
    } else {
      setDisableAddAttachment(true);
      setDisableAltraInfoButton(true);
      if (
        typeof isChat != "undefined" &&
        typeof isDisconnected != "undefined"
      ) {
        dispatch(
          updateAutenticaButtonStateByInteraction({
            interactionId: currentInteraction,
            value: true,
          })
        );
      }
    }
  }, [state]);

  const chatAuthenticateButtonClick = async () => {
    let status = await httpChatAuthenticate({
      conversationId: currentInteraction,
      messageText: "CL_AUTHENTICATE",
      category: attributes["context.category"],
    });
    if (status == "OK")
      dispatch(
        updateAutenticaButtonStateByInteraction({
          interactionId: currentInteraction,
          value: true,
        })
      );
  };

  const handlePrenotaRecallClick = () => {
    setShowPrenataRecallModal(true);
  };

  const handleOnCloseModal = () => {
    setShowPrenataRecallModal(false);
  };

  const handleAgentAttachmentButtonClick = () => {
    setShowAgentAttachmentModal(true);
  };

  const handleOnCloseAttachmentModal = () => {
    setShowAgentAttachmentModal(false);
  };

  const handleEndCallbackButtonClick = () => {
    httpPostCallbackDisconnect(currentInteraction);
  };

  let eliminaSpamming = () => {
    let requestData = {
      intxId: intxId,
    };
    dispatch(toggleSpinnerById(globalSpinnerId));
    httpPostEliminaSpam(requestData, {
      interactionId: currentInteraction,
    })
      .then((response = {}) => {
        dispatch(toggleSpinnerById(globalSpinnerId));
        const { status = "" } = response;
        if (status === "OK") {
          toast.success("Success", { containerId: globalAlertId });
        } else {
          toast.warn(getBaseErrorMessage("Warning", response), {
            containerId: globalAlertId,
          });
        }
      })
      .catch((err = {}) => {
        dispatch(toggleSpinnerById(globalSpinnerId));
        toast.error(getBaseErrorMessage("Error", err), {
          containerId: globalAlertId,
        });
      });
  };

  let altraInfo = () => {
    httpPostChatMessage({
      conversationId: currentInteraction,
      defaultMessage: "CHAT_INFO",
      category: attributes["context.category"],
    });
  };

  return (
    <WidgetWrapper widgetShow={conversazioneShow}>
      <CSSTransition
        in={conversazioneMenuShow}
        timeout={300}
        classNames="slide-left-toggle"
        unmountOnExit={false}
        mountOnEnter={true}
      >
        <div
          className={`section-conversation d-flex flex-column ${
            !hideCoversationContent ? "h-100" : ""
          }`}
        >
          <WidgetTitle
            title="Conversazione"
            iconElement={
              <div className="d-flex" style={{ float: "right" }}>
                {notificationDataAvailable ? (
                  <ConversationNotification />
                ) : (
                  <></>
                )}
                {
                  <IconChevron
                    configuration={{
                      className: "simple-conversation-chevron",
                      open: !hideCoversationContent,
                      onClick: (active) => {
                        exposedDispatch(
                          updateInteractionProperty({
                            id: currentInteraction,
                            property: "hideCoversationContent",
                            value: !hideCoversationContent,
                          })
                        );
                      },
                    }}
                  />
                }
                {expandConversation ? (
                  <IconBlueClose
                    configuration={{
                      onClick: (active) => {
                        setExpandConversation(!expandConversation);
                        exposedDispatch(
                          updateNotificationProperty({
                            id: currentInteraction,
                            property: "showPopover",
                            value: false,
                          })
                        );
                      },
                    }}
                  />
                ) : (
                  <IconExplode
                    configuration={{
                      onClick: (active) => {
                        setExpandConversation(!expandConversation);
                        exposedDispatch(
                          updateNotificationProperty({
                            id: currentInteraction,
                            property: "showPopover",
                            value: false,
                          })
                        );
                        onExpand();
                      },
                    }}
                  />
                )}
              </div>
            }
          />
          {showMailFormAlert === true && (
            <div className="row no-gutters mb-3 purecloud-interaction-mailform-alert">
              <span className="purecloud-interaction-mailform-alert-text">
                {
                  "ATTENZIONE! Mail da form, indirizzi non corrispondono, contattare il coordinamento."
                }
              </span>
            </div>
          )}
          <div
            className={`row no-gutters h-100 purecloud-interaction-container ${
              hideCoversationContent ? "display-none-class" : ""
            }`}
          >
            {state === window.BTFEDictionary["disconnected"] && (
              <div className="wrapup-hider" />
            )}
            <div className="d-flex flex-row w-100">
              <div>
                <WidgetWrapper widgetShow={arrowMenuShow}>
                  <ConversationDropdown
                    className={`conversation-prefiew-section-1`}
                  >
                    <div className="d-flex flex-column w-100">
                      <WidgetWrapper widgetShow={spamMenuShow}>
                        <div>
                          <button
                            type="button"
                            className={`btn Rectangle-Button-Blue my-1 mx-1`}
                            onClick={eliminaSpamming}
                            disabled={disableButton}
                          >
                            Spam
                          </button>
                        </div>
                      </WidgetWrapper>
                      <WidgetWrapper widgetShow={altraInfoShow}>
                        <div>
                          <button
                            type="button"
                            className={`btn Rectangle-Button-Blue my-1 mx-1`}
                            onClick={altraInfo}
                            disabled={disableAltraInfoButton}
                          >
                            Altra Info
                          </button>
                        </div>
                      </WidgetWrapper>
                      <WidgetWrapper widgetShow={presaVeloceShow}>
                        <PresaVeloceButton />
                      </WidgetWrapper>
                      <WidgetWrapper widgetShow={prenotaRecallWidgetShow}>
                        <button
                          type="button"
                          className={`btn Rectangle-Button-Blue my-1 mx-1`}
                          onClick={handlePrenotaRecallClick}
                          disabled={prenatoRecallButtonDisabled}
                        >
                          Prenota Recall
                        </button>
                        <PrenotaRecallModal
                          showPrenataRecallModal={showPrenataRecallModal}
                          handleOnCloseModal={handleOnCloseModal}
                        />
                      </WidgetWrapper>
                      <WidgetWrapper widgetShow={chatAuthenticateWidgetShow}>
                        <button
                          type="button"
                          className={`btn Rectangle-Button-Blue my-1 mx-1`}
                          onClick={chatAuthenticateButtonClick}
                          disabled={disableAutenticaButton}
                        >
                          Autentica
                        </button>
                      </WidgetWrapper>
                      <WidgetWrapper widgetShow={agentChatAttachmentWidgetShow}>
                        <button
                          type="button"
                          className={`btn Rectangle-Button-Blue my-1 mx-1`}
                          onClick={handleAgentAttachmentButtonClick}
                          disabled={attachmentDisableChannelValue}
                        >
                          Allegati
                        </button>
                        <AgentAttachmentModal
                          showAgentAttachmentModal={showAgentAttachmentModal}
                          handleOnCloseModal={handleOnCloseAttachmentModal}
                          disableAddAttachmentButton={disableAddAttachment}
                        />
                      </WidgetWrapper>
                      <WidgetWrapper widgetShow={endCallbackWidgetShow}>
                        <button
                          type="button"
                          className={`btn Rectangle-Button-Blue my-1 mx-1`}
                          onClick={handleEndCallbackButtonClick}
                        >
                          Chiudi callback
                        </button>
                      </WidgetWrapper>
                    </div>
                  </ConversationDropdown>
                </WidgetWrapper>
              </div>
              <div className="w-100">
                <iframe
                  className="w-100 purecloud-interaction h-100"
                  name="purecloud-interaction"
                  allow="camera *; microphone *; autoplay *"
                  src={`https://apps.mypurecloud.de/crm/interaction.html`}
                ></iframe>
              </div>
            </div>
          </div>
        </div>
      </CSSTransition>
    </WidgetWrapper>
  );
};

export default SimpleConversationContainer;
