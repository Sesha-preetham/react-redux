import React from "react";
import { Row, Col } from "react-bootstrap";

class AgentFileUploadClear extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      fileName: "",
      fileSize: "",
      realFileSize : 0,
    };
  }

  onClick = (event) => {
    event.target.value = null;
  };

  onChange = async(event) => {
    let target = event.target;
    let file = target.files[0];
    if (file) {
      let fileSize = file.size;
      this.setState({
        fileName: file.name,
        realFileSize: file.size,
      });
      if (fileSize < 1024) {
        this.setState({
          fileSize: fileSize + " Bytes"
        });
      } else if (fileSize >= 1024 && fileSize < 1048576) {
        this.setState({
          fileSize: (fileSize / 1024).toFixed(1) + " KB"
        });
      } else if (fileSize >= 1048576) {
        this.setState({
          fileSize: (fileSize / 1048576).toFixed(1) + " MB"
        });
      }

      // TRIGGER EXTERNAL EVENT
      const { events } = this.props;
      if (events) {
      const {onFileUpload} = events;
      if(onFileUpload) {
      let resp =  await onFileUpload(file);
      if(!resp){
        this.handleFileClearOperation();
      }
    }
      }
   
    } else {
      this.setState({
        fileName: "",
        fileSize: "",
        realFileSize: 0,
      });
    }

  };


 handleFileClearOperation = () => {
    const file = document.getElementById("fileUpload");
    file.value ="";
    this.setState({
     fileName: "",
     fileSize: "",
     realFileSize: 0
   });
console.log("FILE Upload Clear")    
 }

  render() {
    const { fileName, fileSize} = this.state; //, toolTipConfiguration 
    const { mimeType } = this.props;

    return (
      <Row className="show-grid file-upload-container">
      <input
            type="file"
            name="fileUpload"
            id="fileUpload"
            style={{ display: 'none' }}
            accept={mimeType ? mimeType : ""}
            onChange={this.onChange}
            onClick ={this.onClick}
            disabled = {this.props.disableButton}
          />
        
        <Col xs={4} sm={4} md={4}>
           <label
              htmlFor="fileUpload"
              type="button"
              className={ this.props.disableButton ? `btn Rectangle-Button-White w-100` : `btn Rectangle-Button-Blue w-100`}
            >
            Aggiungi allegato
            </label>   
        </Col>
    
      
        <Col className="file-size" xs={8} sm={8} md={8}>
          {fileName !== "" && (
            <span>{`${fileName} (${fileSize})`}</span>
          )}
        </Col>
    
      </Row>
    );
  }
}

export default AgentFileUploadClear;
