import React from "react";
import { useDispatch, useSelector } from "react-redux";
import { CSSTransition } from "react-transition-group";
import IconExplode from "../../CommonComponents/Common/Icons/IconExplode";
import { stackNavConversation } from "../../Main/StackNavigation/StackNavComponents";
import {
  stackNavEnableByHide,
  stackNavToggle,
} from "../../Main/StackNavigation/stackNavigationSlice";
import {
  conversazioneWidgetCode,
  getDisplayDataByCode,
} from "../Widgets/widgetsSlice";
import WidgetTitle from "../Widgets/WidgetTitle";
import WidgetWrapper from "../Widgets/WidgetWrapper";

const PreviewConversationContainer = (props) => {
  const { widgets } = useSelector((state) => state.widgets);
  const dispatch = useDispatch();
  const [conversazioneMenuShow, conversazioneShow] = getDisplayDataByCode(
    widgets
  )(conversazioneWidgetCode);

  let handleOnStackExpand = () => {
    dispatch(stackNavToggle(stackNavConversation));
    dispatch(stackNavEnableByHide(stackNavConversation));
  };

  return (
    <WidgetWrapper widgetShow={conversazioneShow}>
      <CSSTransition
        in={conversazioneMenuShow}
        timeout={300}
        classNames="slide-left-toggle"
        unmountOnExit={false}
        mountOnEnter={true}
      >
        <div className="section-conversation d-flex flex-column h-100">
          <WidgetTitle
            title="Conversazione"
            iconElement={
              <IconExplode
                configuration={{
                  onClick: (active) => {
                    handleOnStackExpand();
                  },
                }}
              />
            }
          />
          <div className="row no-gutters h-100">
            <iframe
              className="w-100 purecloud-interaction"
              name="purecloud-interaction"
              allow="camera *; microphone *; autoplay *"
              src="https://apps.mypurecloud.de/crm/interaction.html"
            ></iframe>
          </div>
        </div>
      </CSSTransition>
    </WidgetWrapper>
  );
};

export default PreviewConversationContainer;
