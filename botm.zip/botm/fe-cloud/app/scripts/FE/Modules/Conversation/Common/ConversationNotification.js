import React, { useEffect, useState } from "react";
import { Card } from "react-bootstrap";
import { useSelector } from "react-redux";
import IconAlertSolid from "../../../CommonComponents/Common/Icons/IconAlertSolid";
import MyPopover from "../../../CommonComponents/Popover/MyPopover";
import { exposedDispatch } from "../../../Store/store";
import {
  getNotificationDetails,
  updateNotificationProperty,
} from "../../Interaction/interactionSlice";

const ConversationNotification = (props) => {
  const { currentInteraction = "noInteraction", notifications = [] } =
    useSelector((state) => state.interaction);

  const {
    read = false,
    data: notificationData = [],
    showPopover = false,
  } = getNotificationDetails(notifications)(currentInteraction);

  const [dataAvailable, isDataAvailable] = useState(false);

  useEffect(() => {
    if (notificationData.length > 0) {
      isDataAvailable(true);
    }
  }, [notificationData]);

  const iconAlertConfiguration = {
    className: dataAvailable && !read ? "alert-data" : "",
    onClick: () => {
      exposedDispatch(
        updateNotificationProperty({
          id: currentInteraction,
          property: "showPopover",
          value: !showPopover,
        })
      );
      if (!read) {
        exposedDispatch(
          updateNotificationProperty({
            id: currentInteraction,
            property: "read",
            value: true,
          })
        );
      }
    },
  };

  const popoverConfiguration = {
    uniqueID: "conversationNotificationPopover",
    popoverShow: showPopover,
    popoverPlacement: "left-start",
    overlayTriggerElement: (
      <IconAlertSolid configuration={iconAlertConfiguration} />
    ),
  };

  const renderCard = (element) => {
    const { title = "Notifica", text } = element;
    if (!text) return <></>;
    return (
      <Card className="notification-card">
        <Card.Header className="notification-card-header">{title}</Card.Header>
        <Card.Body className="notification-card-body">
          <Card.Text className="notification-card-text">{text}</Card.Text>
        </Card.Body>
      </Card>
    );
  };

  return (
    <div className="pr-1 conversation-notification">
      <MyPopover configuration={popoverConfiguration}>
        <div className=" conversation-notification-card-container">
          {notificationData.map((el) => renderCard(el))}
        </div>
      </MyPopover>
    </div>
  );
};

export default ConversationNotification;
