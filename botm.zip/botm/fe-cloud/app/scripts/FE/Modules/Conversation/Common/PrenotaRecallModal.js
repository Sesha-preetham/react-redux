import React, { useState, useEffect } from "react";
import { toast } from "react-toastify";
import { useDispatch, useSelector } from "react-redux";
import MyModal from "../../../CommonComponents/Modal/MyModal";
import FormFieldHandler from "../../../CommonComponents/Forms/FormFieldHandler";
import SelectField from "../../../CommonComponents/Forms/SelectField";
import TextField from "../../../CommonComponents/Forms/TextField";

import { beServiceUrls } from "../../../Client/ClientProperties";
import {
  globalAlertId,
  prenotaRecallAletrId,
} from "../../../CommonComponents/AlertToast/AlertIdConstants";
import {
  globalSpinnerId,
  toggleSpinnerById,
} from "../../../CommonComponents/Spinner/spinnerSlice";
import {
  getAniFromInteraction,
  getBaseErrorMessage,
} from "../../../Utils/CommonUtil";
import HttpClient from "../../../Utils/HttpClient";
import { reduceToOptions } from "../../../Utils/CommonUtil";
import { exposedDispatch, exposedGetState } from "../../../Store/store";
import { getInteractionDetails } from "../../Interaction/interactionSlice";
import { getPrivatoDataByInteraction } from "../../Anagrafica/anagraficaSlice";
import AlertToast from "../../../CommonComponents/AlertToast/AlertToast";

import {
  getConsunDataById,
  updateConsunDataByProperty,
} from "../../Consuntivazione/consuntivaSlice";
import { httpPostWrapUpHashTagDetails } from "../../Consuntivazione/Service";
import { autoWrapRecall } from "../../../Utils/CommonConstantUtil";

const PrenotaRecallModal = ({
  showPrenataRecallModal = false,
  handleOnCloseModal = () => {},
}) => {
  const [changePhoneNumber, setChangePhoneNumber] = useState(false);
  const [recallButtonDisabled, setRecallButtonDisabled] = useState(false);

  const [formFields] = useState(new FormFieldHandler(true));

  const { currentInteraction = "noInteraction", interactions = [] } =
    useSelector((state) => state.interaction);

  const { consunData } = useSelector((state) => state.consuntiva);
  const { anagrafica } = useSelector((state) => state.anagrafica);

  const { selectedIbCode = {} } =
    getPrivatoDataByInteraction(anagrafica)(currentInteraction);
  const { value: ibCode } = selectedIbCode || {};

  const interaction = getInteractionDetails(interactions)(currentInteraction);
  const { ani, intxId, queueName = undefined } = interaction;

  const dispatch = useDispatch();

  const handleChangePhoneNumberClick = async () => {
    onMount();
    setChangePhoneNumber(true);
    setRecallButtonDisabled(true);
  };

  const handleBackButtonClick = async () => {
    setChangePhoneNumber(false);
    setRecallButtonDisabled(false);
  };

  const handleRecallButtonClick = () => {
    let { callingList, prefix, phoneNumberField } =
      getConsunDataById(consunData)(currentInteraction);

    const destructurePrefix = (prefix) => {
      if (prefix) {
        const [obj] = prefix || {};
        const { value } = obj || [];
        return value;
      } else return "";
    };

    const destructureCallingList = (callingList) => {
      if (callingList) {
        const [value] = callingList.value || [];
        return value;
      } else return "";
    };

    let phoneNumberData = changePhoneNumber
      ? destructurePrefix(prefix) + phoneNumberField
      : getAniFromInteraction(interaction);
    let callingListData = callingList
      ? destructureCallingList(callingList)
      : "";

    const request = {
      conversationId: currentInteraction,
      intxId: intxId,
      phoneNumber: phoneNumberData,
      contactListId: callingListData,
      ibCode: ibCode,
    };
    httpPostInsertCampaignContact(request);
  };

  const httpPostInsertCampaignContact = async (request) => {
    let httpClient = new HttpClient();
    httpClient.setUrl(beServiceUrls().insertcampaigncontact);
    await httpClient
      .httpPost(request)
      .then((response) => {
        const { status = "" } = response;
        if (status == "OK") {
          dispatch(
            updateConsunDataByProperty({
              interactionId: currentInteraction,
              data: {
                property: "prenatoRecallButtonDisabled",
                value: true,
              },
            })
          );
          setChangePhoneNumber(false);
          handleOnCloseModal(false);

          const wrapperRequest = {
            interactionId: currentInteraction,
            queueName,
            wrapupFunction: autoWrapRecall,
          };
          httpPostWrapUpHashTagDetails(wrapperRequest);
          toast.success("Recall Success", { containerId: globalAlertId });
        }
        if (status !== "OK") {
          toast.warn(getBaseErrorMessage("Warning", response), {
            containerId: prenotaRecallAletrId,
          });
        }
      })
      .catch((err) => {
        toast.error(getBaseErrorMessage("Error", err), {
          containerId: prenotaRecallAletrId,
        });
      });
  };

  const recallInfoModal = {
    uniqueID: "recallInfoModal",
    modalClass: "authentication-info my-modal",
    dialogClassName: "modal-w",
    title: {
      content: "Prenota Recall",
      class: "widget-title",
    },
    modalShow: showPrenataRecallModal,
    modalHeaderShow: true,
    backdrop: {
      enable: true,
    },
    events: {
      onHide: () => {
        console.log("Close PrenotaRecall Modal ");
        handleOnCloseModal(false);
      },
      onEntered: () => {
        onMount();
        setChangePhoneNumber(false);
        console.log("multiClienteModal modal onEntered");
      },
      onExited: () => {
        setChangePhoneNumber(false);
        handleOnCloseModal(false);
        console.log("Exit PrenotaRecall Modal");
      },
    },
  };

  let convertMap = (response) => {
    let comboValue = [];
    response.forEach((val) => {
      comboValue.push({ key: val, value: val });
    });
    return comboValue;
  };

  let convertMapTo = (response) => {
    let comboValue = [];
    let values;
    response.forEach((val) => {
      const keys = Object.keys(val);
      values = val[keys];
      console.log("Keys : " + keys + "VALUE:  " + values);
      comboValue.push({ key: keys, value: values });
    });
    return comboValue;
  };

  let onMount = async () => {
    if (!currentInteraction || currentInteraction === "noInteraction") return;
    // dispatch(toggleSpinnerById(consunSpinnerId));
    if (formFields.getField("callingListConfig")) {
      await httpGetCallingList().then((response) => {
        const callList = convertMapTo(response);
        formFields
          .getField("callingListConfig")
          .theField.reloadOptions(reduceToOptions(callList)("key", "value"));
      });
    }
    if (formFields.getField("prefixConfig")) {
      await httpGetPrefix().then((response) => {
        const prefixList = convertMap(response);
        formFields
          .getField("prefixConfig")
          .theField.reloadOptions(reduceToOptions(prefixList)("key", "value"));
      });
    }
    if (!formFields.isEmpty()) {
      loadFieldValues();
    }
    //dispatch(toggleSpinnerById(consunSpinnerId));
  };

  let loadFieldValues = () => {
    let { callingList, prefix, phoneNumber } =
      getConsunDataById(consunData)(currentInteraction);
    formFields.getField("callingListConfig").theField.setValue(callingList);

    if (changePhoneNumber) {
      formFields.getField("prefixConfig").theField.setValue(prefix);
      formFields.getField("phoneNumberField").theField.setValue(phoneNumber);
    }
  };

  const httpGetCallingList = async (params = {}) => {
    const dispatch = exposedDispatch;
    let httpClient = new HttpClient();
    httpClient.setUrl(beServiceUrls().getServiceRecallContactList);
    console.log(
      "httpGetCallingList: ",
      beServiceUrls().getServiceRecallContactList
    );
    let responseData = await httpClient.httpGet({}, params).then((response) => {
      const { status = "", response: callingListResponse = [] } = response;
      if (status === "OK") {
        return callingListResponse;
      }
      return [];
    });
    return responseData;
  };

  const httpGetPrefix = async (params = {}) => {
    const dispatch = exposedDispatch;
    let httpClient = new HttpClient();
    httpClient.setUrl(beServiceUrls().getPrefixlist);
    console.log("httpGetPrefix: ", beServiceUrls().getPrefixlist);
    let responseData = await httpClient.httpGet({}, params).then((response) => {
      const { status = "", response: prefixResponse = [] } = response;
      if (status === "OK") {
        return prefixResponse;
      }
      return [];
    });
    return responseData;
  };

  let callingListConfig = {
    uniqueID: "callingListConfig",
    multiSelect: false,
    label: "",
    placeHolder: "Seleziona Calling List",
    readonly: false,
    visible: true,
    disabled: false,
    options: [],
    searchEnabled: true,
    setValue: (obj) => {
      console.log("calling list: ", obj);
      const { currentInteraction } = exposedGetState().interaction;
      dispatch(
        updateConsunDataByProperty({
          interactionId: currentInteraction,
          data: {
            property: "callingList",
            value: obj.currentValue,
          },
        })
      );
    },
    form: formFields,
    validation: false,
  };

  let prefixConfig = {
    uniqueID: "prefixConfig",
    multiSelect: false,
    label: "",
    placeHolder: "Prefix",
    readonly: false,
    visible: true,
    disabled: false,
    value: [
      { label: "+39", rlData: { key: "+39", value: "+39" }, value: "+39" },
    ],
    options: [],
    searchEnabled: true,
    setValue: (obj) => {
      console.log("calling list: ", obj);
      const { currentInteraction } = exposedGetState().interaction;
      dispatch(
        updateConsunDataByProperty({
          interactionId: currentInteraction,
          data: {
            property: "prefix",
            value: obj.currentValue,
          },
        })
      );
    },
    form: formFields,
    validation: false,
  };

  let aniNumberField = {
    uniqueID: "aniPhoneNumberField",
    placeHolder: "Ani Phone Number...",
    readonly: true,
    visible: true,
    disabled: true,
    value: ani ? getAniFromInteraction(interaction) : "",
    form: formFields,
  };

  const handleOnChange = (obj) => {
    /^\d+$/.test(obj.currentValue) && obj.currentValue.length < 20
      ? setRecallButtonDisabled(false)
      : setRecallButtonDisabled(true);
  };

  let phoneNumberField = {
    uniqueID: "phoneNumberField",
    placeHolder: "Phone Number...",
    readonly: false,
    visible: true,
    value: "",
    setValue: (obj) => {
      console.log("setValue", obj);
      const { currentInteraction } = exposedGetState().interaction;
      handleOnChange(obj);
      dispatch(
        updateConsunDataByProperty({
          interactionId: currentInteraction,
          data: {
            property: "phoneNumberField",
            value: obj.currentValue,
          },
        })
      );
    },
    validation: {
      mandatory: false,
      maxLen: 20,
      type: "Numeric",
    },
    feedback: {
      enable: true,
      component: () => <>Phone è numerico.</>,
    },
    form: formFields,
  };

  return (
    <div>
      <MyModal configuration={recallInfoModal}>
        <div className="d-flex justify-content-center">
          <div className="w-100">
            <AlertToast
              configuration={{
                unqiueID: prenotaRecallAletrId,
                className: "inline-toast-container",
                transition: "flip",
              }}
            />
          </div>
        </div>
        <div className="mt-auto mb-auto">
          <div className="d-flex flex-column">
            <SelectField configuration={callingListConfig} />
          </div>
          {!changePhoneNumber && (
            <div className="d-flex flex-column">
              <TextField configuration={aniNumberField} />
            </div>
          )}
        </div>

        {changePhoneNumber && (
          <div className="d-flex justify-content-center flex-row mt-auto">
            <div className="w-25 d-flex flex-column mr-1">
              <SelectField configuration={prefixConfig} />
            </div>
            <div className="w-75 d-flex flex-column ml-1">
              <TextField configuration={phoneNumberField} />
            </div>
          </div>
        )}

        <div className="d-flex justify-content-center flex-row mt-auto">
          {changePhoneNumber && ( //btn Rectangle-Button-Blue my-1 mx-1
            <div className="w-25 pl-2">
              <button
                type="button"
                className={`btn Rectangle-Button-Blue w-100`}
                onClick={handleBackButtonClick}
              >
                Back
              </button>
            </div>
          )}

          {!changePhoneNumber && (
            <div className="w-50 pl-2">
              <button
                type="button"
                // disabled={disableChangePhoneNumberButton}
                className={`btn Rectangle-Button-Blue w-100`}
                onClick={handleChangePhoneNumberClick}
              >
                Change PhoneNumber
              </button>
            </div>
          )}

          <div className="w-25 pl-2">
            <button
              type="button"
              className={`btn Rectangle-Button-Blue w-100`}
              onClick={handleRecallButtonClick}
              disabled={recallButtonDisabled}
            >
              Recall
            </button>
          </div>
        </div>
      </MyModal>
    </div>
  );
};

export default PrenotaRecallModal;
