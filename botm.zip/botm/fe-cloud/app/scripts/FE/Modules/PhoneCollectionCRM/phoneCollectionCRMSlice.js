import { createSlice } from "@reduxjs/toolkit";
import { stackPreview } from "../../Main/StackNavigation/stackNavigationSlice";
import { getEndOfDayDate, getStartOfDayDate } from "../../Utils/DateUtils";

let defaultEsitoDataObjects = {
   esitoInteractionVal: {
     esitoSetAssistenza: {},
     esitoContactSelected: {},
     esitoSetNoteCRM: "",
     esitoDueDateVal:new Date(),
     esitoContactSelectedObj: {},
     //esitoDateParam:{},

     dateFromNumDaysBlockPhoneVal: getStartOfDayDate(),
     checkBlockPhoneVal: false,
     dateFromNumDaysContrCredVal: getStartOfDayDate(),
     checkContrCredVal: false,
     dateFromNumDaysNewRecipientVal: getStartOfDayDate(),
     checkNewRecipientVal: false,
     actionEndDateVal: getStartOfDayDate(),
     checkactionEndDateVal: false,

     isDisconnectedEsito: false,
     esitoWidgetDone: false,
   },
};


let initialState = {
  phoneCollectionLayoutType: stackPreview,
  assegnatiCDRResponseData:{},
  pcAgentResponseData:{},
  bancaResponseData:{},
  statoResponseData:{},

  assegnatiCDRSelectedData:{},
  pcAgentSelectedData:{},
  bancaSelectedData:{},
  statoSelectedData:{},
  dueDateSelectedDate:null,

  phoneCollectionTableData:[],

  esitoModalData:{
    showEsitoModal:false,
  },

  clickValueToEsito:{
    selectedSoggettoId:"",
    selectedPegId: "",
    selectedCurrentEsito: "",
    selectedSectionId:"",
    selectedRuleId:"",
    selectedAbi:"",
    selectedStato:"",
  },

  makeOutboundCall:{
    phoneNumberVal: null,
    passAttributes: {},
  },
  showModal: false,
  esitoObjects: {
  noInteraction: { ...defaultEsitoDataObjects },
},
};


const phoneCollectionCRMSlice = createSlice({
  name: "phoneCollectionCRM",
  initialState,
  reducers: {
    addInteractionToEsito(state, action) {
      const { payload = {} } = action;
      const { id = "noInteraction" } = payload;
      if (!id) return;
      if (!state.esitoObjects[id]) {
        state.esitoObjects[id] = { ...defaultEsitoDataObjects };
      }
    },
    removeInteractionFromEsito(state, action) {
      const { payload = {} } = action;
      const { id = "noInteraction" } = payload;
      if (!id || id === "noInteraction") return;
      state.esitoObjects = Object.entries(state.esitoObjects).reduce(
        (acc, [key, value]) => {
          if (key != id) {
            acc[key] = value;
          }
          return acc;
        },
        {}
      );
    },
    updatePhoneCollectionLayout(state, action) {
      const { payload = "" } = action;
      state.phoneCollectionLayoutType = payload;
    },
    setAssegnatiCDRResponse(state,action){
      const { payload = {} } = action;
      const { assegnatiCDRResp = {} } = payload;
      state.assegnatiCDRResponseData = assegnatiCDRResp;
    },
    setPCAgentResponse(state,action){
      const { payload = {} } = action;
      const { pcAgentResp = {} } = payload;
      state.pcAgentResponseData = pcAgentResp;
    },
    setBancaResponse(state,action){
      const { payload = {} } = action;
      const { bancaResp = {} } = payload;
      state.bancaResponseData = bancaResp;
    },
    setStatoResponse(state,action){
      const { payload = {} } = action;
      const { statoResp = {} } = payload;
      state.statoResponseData = statoResp;
    },
    

    setAssegnatiCDRFilter(state, action) {
      const { payload = {} } = action;
      const { assegnatiCDRfilter = {} } = payload;
      state.assegnatiCDRSelectedData = assegnatiCDRfilter;
    },
    setPCAgentFilter(state, action) {
      const { payload = {} } = action;
      const { pcAgentfilter = {} } = payload;
      state.pcAgentSelectedData = pcAgentfilter;
    },
    setBancaFilter(state, action) {
      const { payload = {} } = action;
      const { bancaSelected = {} } = payload;
      state.bancaSelectedData = bancaSelected;
    },
    setStatoFilter(state, action) {
      const { payload = {} } = action;
      const { statoSelected = {} } = payload;
      state.statoSelectedData = statoSelected;
    },
    setDueDatePhoneCollection(state, action) {
      const { payload = {} } = action;
      const { dueDateVal = {} } = payload;
      state.dueDateSelectedDate = dueDateVal;
    },
    setPhoneCollectionTable(state, action) {
      const { payload = {} } = action;
      const { phoneCollectionValue = [] } = payload;
      state.phoneCollectionTableData = phoneCollectionValue;
    },

    setShowEsitoModal(state, action) {
      const { payload = {} } = action;
      const { showVal = false } = payload;
      state.esitoModalData.showEsitoModal = showVal;
    },
    setClickValueToEsito(state, action){
      const { payload = {} } = action;
      const { selectedPegIdVal="", selectedCurrentEsitoVal="", selectedSectionIdVal="", selectedRuleIdVal="", selectedAbiVal ="", selectedStatoVal = "", selectedSoggettoIdVal = "" } = payload;
      state.clickValueToEsito.selectedPegId = selectedPegIdVal;
      state.clickValueToEsito.selectedCurrentEsito = selectedCurrentEsitoVal;
      state.clickValueToEsito.selectedSectionId = selectedSectionIdVal;
      state.clickValueToEsito.selectedRuleId = selectedRuleIdVal;
      state.clickValueToEsito.selectedAbi = selectedAbiVal;
      state.clickValueToEsito.selectedStato = selectedStatoVal;
      state.clickValueToEsito.selectedSoggettoId = selectedSoggettoIdVal;
    },

    esitoSetBlockPhoneVal(state, action){
      const { payload = {} } = action;
      const { interactionId = "noInteraction",selectedBlockPhoneVal= null} = payload;
      state.esitoObjects[interactionId].esitoInteractionVal.dateFromNumDaysBlockPhoneVal = selectedBlockPhoneVal;
      state.esitoObjects[interactionId].esitoInteractionVal.checkBlockPhoneVal = true;
    },
    checkBlockPhoneValSet(state,action){
      const { payload = {} } = action;
      const {interactionId = "noInteraction", setCheckBlockPhoneVal= false} = payload;
      state.esitoObjects[interactionId].esitoInteractionVal.checkBlockPhoneVal = setCheckBlockPhoneVal;
    },
    esitoSetContrCredVal(state, action){
      const { payload = {} } = action;
      const { interactionId = "noInteraction",selectedCredVal= null } = payload;
      state.esitoObjects[interactionId].esitoInteractionVal.dateFromNumDaysContrCredVal = selectedCredVal;
      state.esitoObjects[interactionId].esitoInteractionVal.checkContrCredVal = true;
    },
    checkContrCredValSet(state,action){
      const { payload = {} } = action;
      const { interactionId = "noInteraction",setCheckContrCredVal= false} = payload;
      state.esitoObjects[interactionId].esitoInteractionVal.checkContrCredVal = setCheckContrCredVal;
    },
    esitoSetRecipientVal(state, action){
      const { payload = {} } = action;
      const {interactionId = "noInteraction", selectedRecipientVal=null} = payload;
      state.esitoObjects[interactionId].esitoInteractionVal.dateFromNumDaysNewRecipientVal = selectedRecipientVal;
      state.esitoObjects[interactionId].esitoInteractionVal.checkNewRecipientVal = true;
    },
    checkNewRecipientValSet(state,action){
      const { payload = {} } = action;
      const {interactionId = "noInteraction", setCheckNewRecipientVal = false} = payload;
      state.esitoObjects[interactionId].esitoInteractionVal.checkNewRecipientVal = setCheckNewRecipientVal;
    },
    esitoSetEndDateVal(state, action){
      const { payload = {} } = action;
      const {interactionId = "noInteraction", selectedEndDateVal=null} = payload;
      state.esitoObjects[interactionId].esitoInteractionVal.actionEndDateVal = selectedEndDateVal;
      state.esitoObjects[interactionId].esitoInteractionVal.checkactionEndDateVal = true;
    },
    checkactionEndDateValSet(state,action){
      const { payload = {} } = action;
      const {interactionId = "noInteraction", setCheckactionEndDateVal= false} = payload;
      state.esitoObjects[interactionId].esitoInteractionVal.checkactionEndDateVal = setCheckactionEndDateVal;
    },

    esitoSetAssistenzaVal(state, action){
      const { payload = {} } = action;
      const {interactionId = "noInteraction",  selectedAssistenzaVal={}} = payload;
      if (!state.esitoObjects[interactionId]) return;
      state.esitoObjects[interactionId].esitoInteractionVal.esitoSetAssistenza = selectedAssistenzaVal;
    },
    esitoSetContactCenterVal(state, action) {
      const { payload = {} } = action;
      const { interactionId = "noInteraction", esitoSelectVal = {} ,esitoSetSelectedObj = {}, esitoDateParamVal = {} } = payload;
      if (!state.esitoObjects[interactionId]) return;
      state.esitoObjects[interactionId].esitoInteractionVal.esitoContactSelected = esitoSelectVal;
      state.esitoObjects[interactionId].esitoInteractionVal.esitoContactSelectedObj = esitoSetSelectedObj;
      state.esitoObjects[interactionId].esitoInteractionVal.esitoDateParam = esitoDateParamVal;
    },
    esitoSetNoteCRMVal(state, action){
      const { payload = {} } = action;
      const {interactionId = "noInteraction",  selectedNoteCRM=""} = payload;
      if (!state.esitoObjects[interactionId]) return;
      state.esitoObjects[interactionId].esitoInteractionVal.esitoSetNoteCRM = selectedNoteCRM;
    },
    setDueDateEsito(state, action){
      const { payload = {} } = action;
      const {interactionId = "noInteraction",  dueDateSet=null} = payload;
      if (!state.esitoObjects[interactionId]) return;
      state.esitoObjects[interactionId].esitoInteractionVal.esitoDueDateVal = dueDateSet;
    },
    

    disconnectEsitoInteraction(state, action){
      const { payload = {} } = action;
      const {interactionId = "noInteraction",  isDisconnected=false} = payload;
      if (!state.esitoObjects[interactionId]) return;
      state.esitoObjects[interactionId].esitoInteractionVal.isDisconnectedEsito = isDisconnected;
    },

    setEsitoWidgetDone(state, action){
      const { payload = {} } = action;
      const {interactionId = "noInteraction",  isAggiornaSuccess=false} = payload;
      if (!state.esitoObjects[interactionId]) return;
      state.esitoObjects[interactionId].esitoInteractionVal.esitoWidgetDone = isAggiornaSuccess;
    },
    
    resetPhoneCollectionData(state) {
      state = initialState;
    },
    updateMakeOutboundCall(state, action) {
      const { payload = {} } = action;
      const { data = {} } = payload;
      const {
        phoneVal = null,
        passObjVal = {},
      } = data;
      state.makeOutboundCall.phoneNumberVal = phoneVal;
      state.makeOutboundCall.passAttributes = passObjVal;
    },
    setShowConfirmationModal(state, action) {
      const { payload = {} } = action;
      const { showVal = false } = payload;
      state.showModal = showVal;
    },

  },
});

export const {
  updatePhoneCollectionLayout,
  setAssegnatiCDRResponse,
  setPCAgentResponse,
  setBancaResponse,
  setStatoResponse,

  setAssegnatiCDRFilter,
  setPCAgentFilter,
  setBancaFilter,
  setStatoFilter,
  setDueDatePhoneCollection,

  setPhoneCollectionTable,
  setShowEsitoModal,
  setClickValueToEsito,

  addInteractionToEsito,
  removeInteractionFromEsito,

  esitoSetBlockPhoneVal,
  esitoSetContrCredVal,
  esitoSetRecipientVal,
  esitoSetEndDateVal,

  checkBlockPhoneValSet,
  checkContrCredValSet,
  checkNewRecipientValSet,
  checkactionEndDateValSet,

  disconnectEsitoInteraction,
  setEsitoWidgetDone,
  esitoSetAssistenzaVal,
  esitoSetContactCenterVal,
  esitoSetNoteCRMVal,
  setDueDateEsito,

  resetPhoneCollectionData,
  updateMakeOutboundCall,
  setShowConfirmationModal,
} = phoneCollectionCRMSlice.actions;

export default phoneCollectionCRMSlice.reducer;


export const getEsitoDataByInteraction = (esitoObjects) => {
  return (id = "noInteraction") => {
    if (esitoObjects[id]) {
      return { ...esitoObjects[id].esitoInteractionVal };
    }
    return {};
  };
};
