import React, { useEffect, useState, useRef } from "react";
import { useDispatch, useSelector } from "react-redux";
import FormFieldHandler from "../../../CommonComponents/Forms/FormFieldHandler";
import SelectField from "../../../CommonComponents/Forms/SelectField";
import TextField from "../../../CommonComponents/Forms/TextField";
import DateField from "../../../CommonComponents/Forms/DateField";
import { toast } from "react-toastify";

import {
  getDisplayDataByCode,
  esitoWidgetCode,
} from "../../Widgets/widgetsSlice";

import WidgetWrapper from "../../Widgets/WidgetWrapper";
import AlertToast from "../../../CommonComponents/AlertToast/AlertToast";
import {esitoCRMComponentAlertId, phoneCollectionCRMAlertId }from "../../../CommonComponents/AlertToast/AlertIdConstants";
import { toggleSpinnerById, esitoCRMSpinnerId } from "../../../CommonComponents/Spinner/spinnerSlice";
import {
  stackExpand,
  stackNavPop,
  stackPreview,
} from "../../../Main/StackNavigation/stackNavigationSlice";
import { reduceToOptions, getBaseErrorMessage } from "../../../Utils/CommonUtil";

import { getInteractionDetails } from "../../../Modules/Interaction/interactionSlice";

import {
  setShowEsitoModal,
  esitoSetAssistenzaVal,
  esitoSetContactCenterVal,
  esitoSetNoteCRMVal,
  setDueDateEsito,
  getEsitoDataByInteraction,
  setEsitoWidgetDone,
  setPhoneCollectionTable,
} from "../../PhoneCollectionCRM/phoneCollectionCRMSlice";
import {
  httpGetEsitoContact,
  httpGetAssistenza,
  httpPostAggiornaService,
  httpPostTraceService,
  httpPostTakeUpdateNotesService,
} from "../../PhoneCollectionCRM/PhoneCollectionCRMService";
import EsitoCRMDateComponent from "./EsitoCRMDateComponent";
import MySpinner from "../../../CommonComponents/Spinner/MySpinner";



const EsitoCRMWidgetMain = (props) => {

  let { type , currentInteraction } = props

  const currentInteractionRef = useRef();
  currentInteractionRef.current = currentInteraction;

  const [formFields] = useState(new FormFieldHandler(true));
  const { widgets } = useSelector((state) => state.widgets);

  const { esitoObjects={}  }  = useSelector((state) => state.phoneCollectionCRM);

  const {interactions = [],} = useSelector((state) => state.interaction);
  
  const { attributes = {}, intxId } = getInteractionDetails(interactions)( currentInteractionRef.current);

  const {
    selectedPegId = "",
    selectedCurrentEsito = "",
    selectedSectionId = "",
    selectedRuleId = "",
    selectedAbi = "",
    selectedStato = "",
    selectedSoggettoId = "",
  } = useSelector((state) => state.phoneCollectionCRM.clickValueToEsito);

  const phoneCollectionLayoutType = useSelector((state) => state.phoneCollectionCRM.phoneCollectionLayoutType);
  const phoneCollectionTableData = useSelector((state) => state.phoneCollectionCRM.phoneCollectionTableData);

  const {
    esitoSetAssistenza = {},
    esitoContactSelected = {},
    esitoSetNoteCRM = "",
    esitoDueDateVal = new Date(),
    esitoContactSelectedObj = {},

    dateFromNumDaysBlockPhoneVal = null,
    checkBlockPhoneVal = false,
    dateFromNumDaysContrCredVal = null,
    checkContrCredVal = false,
    dateFromNumDaysNewRecipientVal = null,
    checkNewRecipientVal = false,
    actionEndDateVal = null,
    checkactionEndDateVal = false,

    isDisconnectedEsito = false,
    esitoWidgetDone = false,
  } = getEsitoDataByInteraction(esitoObjects)(currentInteractionRef.current);

  
  const dispatch = useDispatch();

  const [esitoComponentMenuShow, esitoComponentShow] = getDisplayDataByCode(widgets)( esitoWidgetCode );

  const [ showEsitoDates, setShowEsitoDates ] = useState(false);

  const [esitoDateParamState, setEsitoDateParamState] = useState({
    blockPhoneVisible:false,
    blockPhoneEditable:false,
    blockPhoneMaxDate: null,

    blockContrCredVisible:  false,
    blockContrCredEditable: false,
    blockContrCredMaxDate:  null,

    newRecipientVisible:  false,
    newRecipientEditable: false,
    newRecipientMaxDate:  null,

    actionEndDateVisible:  false,
    actionEndDateEditable: false,
    actionEndDateMaxDate:  null,
  });


  useEffect(()=> {
    onMount();
  },[currentInteractionRef.current, phoneCollectionLayoutType,type, attributes["abicode"]]);



  let onMount = async () => {
    const { attributes = {} } = getInteractionDetails(interactions)( currentInteractionRef.current);
    let abiVal = null;
    if (type == "Modal") abiVal = selectedAbi;
    else abiVal = attributes["abicode"];

    if(formFields.getField("esitoContactFilterField")){
      dispatch(toggleSpinnerById(esitoCRMSpinnerId[type]));
      await httpGetEsitoContact({ abi: abiVal, subsystem:"CRM" }, type).then((response) => {
        formFields
          .getField("esitoContactFilterField")
          .theField.reloadOptions(response);
        dispatch(toggleSpinnerById(esitoCRMSpinnerId[type]));
      }).catch((err) => {
        toast.error(getBaseErrorMessage("Error",err), { containerId: esitoCRMComponentAlertId[type] });
        dispatch(toggleSpinnerById(esitoCRMSpinnerId[type]));
      });
    }

    if(formFields.getField("assistenzaFilterField")){
      dispatch(toggleSpinnerById(esitoCRMSpinnerId[type]));
      await httpGetAssistenza({ abi: abiVal, subsystem:"CRM" }, type).then((response) => {
        formFields
          .getField("assistenzaFilterField")
          .theField.reloadOptions(response);
        dispatch(toggleSpinnerById(esitoCRMSpinnerId[type]));
      }).catch((err) => {
        toast.error(getBaseErrorMessage("Error",err), { containerId: esitoCRMComponentAlertId[type] });
        dispatch(toggleSpinnerById(esitoCRMSpinnerId[type]));
      });
    }
    loadFieldValues();
  };


  const loadFieldValues = () =>{
    const {
      esitoSetAssistenza = {},
      esitoSetNoteCRM = "",
      esitoDueDateVal ,
      esitoContactSelectedObj = {},
    } = getEsitoDataByInteraction(esitoObjects)(currentInteractionRef.current);
    if (formFields.getField("esitoContactFilterField"))
      formFields
        .getField("esitoContactFilterField")
        .theField.setValue(esitoContactSelectedObj || {});
    if (formFields.getField("assistenzaFilterField"))
      formFields
        .getField("assistenzaFilterField")
        .theField.setValue(esitoSetAssistenza || {});
    if (formFields.getField("noteTextField"))
      formFields
        .getField("noteTextField")
        .theField.setValue(esitoSetNoteCRM || "");
    if (formFields.getField("dueDateConfigurationField"))
      formFields
        .getField("dueDateConfigurationField")
        .theField.setValue(esitoDueDateVal || new Date());
  }

  let handleOnAggiornaClick = async() =>{
    dispatch(toggleSpinnerById(esitoCRMSpinnerId[type]));
    // dispatch(
    //   setEsitoWidgetDone({
    //     interactionId: currentInteractionRef.current,
    //     isAggiornaSuccess: true
    //   })
    // );
    let request={};
    const {value: esitoAssistenza = {}} = esitoSetAssistenza ;
    const {actionCode: actionCodeVal = {} } =  esitoContactSelected ;

    if(type == "Modal"){
    request = {
      abi: selectedAbi,
      pegId: selectedPegId, 
      esito: selectedCurrentEsito, 
      esitoCodeBarraTelefonica: esitoAssistenza,
      actionCode: actionCodeVal,
      ruleId: selectedRuleId, 
      sectionId: selectedSectionId,
      note: esitoSetNoteCRM,
      dateFromNumDaysBlockPhone: dateFromNumDaysBlockPhoneVal,
      dateFromNumDaysContrCred: dateFromNumDaysContrCredVal,
      dateFromNumDaysNewRecipient: dateFromNumDaysNewRecipientVal,
      actionEndDate: actionEndDateVal,
      dueDate: esitoDueDateVal,
      subsystem:"CRM",
      stato: selectedStato,
      idSoggetto : selectedSoggettoId,
    };
    }
    else{

      request = {
        intxId:intxId,
        abi: attributes["abicode"],
        pegId: attributes["idpeg"], 
        notificationId: attributes["idnotifica"], 
        esitoCodeBarraTelefonica: esitoAssistenza,
        actionCode: actionCodeVal,
        ruleId: attributes["ruleid"], 
        sectionId: attributes["sectionid"],
        note: esitoSetNoteCRM,
        dueDate: esitoDueDateVal,
        dateFromNumDaysBlockPhone: dateFromNumDaysBlockPhoneVal,
        dateFromNumDaysContrCred: dateFromNumDaysContrCredVal,
        dateFromNumDaysNewRecipient: dateFromNumDaysNewRecipientVal,
        actionEndDate: actionEndDateVal,
        subsystem:"CRM",
        stato: attributes["stato"],
        idSoggetto : attributes["idsoggetto"],
      };

    }

    await httpPostAggiornaService(request, type).then((response) => {
      const {status = ""} = response;
      if(status == "OK"){
        if(type =="Modal"){
        dispatch(setShowEsitoModal({showVal : false}));
        toast.success("Aggiorna Success", {containerId: phoneCollectionCRMAlertId});
      }
       if(type =="Widget"){
        let requestData = {
          intxId: intxId,
          wrapUpCode: esitoAssistenza,
          subsystem:"CRM",
        };
        httpPostTraceService(  requestData, {
          interactionId: currentInteractionRef.current,
        }, type).then((response) => {
          const {status = ""} = response;
          if(status == "OK"){
          dispatch(
            setEsitoWidgetDone({
              interactionId: currentInteractionRef.current,
              isAggiornaSuccess: true
            })
          );
          toast.success("Aggiorna Success", {containerId: esitoCRMComponentAlertId[type]});
          }
        })
      }
      // Code to get the id for service
      getUpdatedNoteForAllPegId();
    }
    else{
      dispatch(
        setEsitoWidgetDone({
          interactionId: currentInteractionRef.current,
          isAggiornaSuccess: false
        })
      );
    }
    dispatch(toggleSpinnerById(esitoCRMSpinnerId[type]));
    }).catch((err) => {
      //toast.error(getBaseErrorMessage("Error",err), { containerId: esitoCRMComponentAlertId[type] });
      dispatch(
        setEsitoWidgetDone({
          interactionId: currentInteractionRef.current,
          isAggiornaSuccess: false
        })
      );
      dispatch(toggleSpinnerById(esitoCRMSpinnerId[type]));
    });
  }

  const getUpdatedNoteForAllPegId  = async () =>{
    if(phoneCollectionTableData.length>0){
      let idArr = [];
      phoneCollectionTableData.map((val)=>{
        let{idPEG,idSoggetto} = val;
        idArr = [...idArr,{pegId : idPEG, idSoggetto: idSoggetto}]
      });
      let request = {
        subsystem:"CRM",
        noteReq : idArr
      }
      await httpPostTakeUpdateNotesService(request, type).then((response) => {
        if(response.length>0){
          updateNoteOnPhoneCollectionTableData(response);
        }
      })
    }
  }

  const updateNoteOnPhoneCollectionTableData = (data)=>{
    let finalTable = []
    if(phoneCollectionTableData.length>0){
      phoneCollectionTableData.map((item)=>{
        let {idPEG: mainIdPeg , idSoggetto : mainIdSoggetto} = item
        let upd;
        data.map((val)=>{
          let{idPEG: updatePeg, idSoggetto: updateSoggetto , note: updateNote} = val;
          if(mainIdPeg == updatePeg &&  mainIdSoggetto==updateSoggetto){
            upd = updateNote
          }
        })
        finalTable =[...finalTable ,  {...item , note : upd ? upd : null}]
      })

    }
    console.log("finalTableVal..." + finalTable)
    dispatch(setPhoneCollectionTable({phoneCollectionValue : finalTable}));
  }

  const dateCalculatorEsito = (params) =>{

    let{
      numDaysBlockPhone= null,
      maxNumberDaysPhone= null,
      numDaysBlockContrCred= null,
      maxNumberDaysContrCred=null,
      numDaysNewRecipient= null,
      maxNumberDaysNewRecipient= null,
      actionEndDate= null,
      maxActionEndDate= null,
    } = params

    let blockPhoneValues = dateCheck(numDaysBlockPhone,maxNumberDaysPhone);
    let blockContrCredValues = dateCheck(numDaysBlockContrCred,maxNumberDaysContrCred);
    let newRecipientValues = dateCheck(numDaysNewRecipient,maxNumberDaysNewRecipient);
    let actionEndDateValues = dateCheck(actionEndDate,maxActionEndDate);

    setEsitoDateParamState({
      blockPhoneVisible:  blockPhoneValues.visible,
      blockPhoneEditable: blockPhoneValues.editVal,
      blockPhoneMaxDate:  parseInt(blockPhoneValues.maxDayVal),

      blockContrCredVisible:  blockContrCredValues.visible,
      blockContrCredEditable: blockContrCredValues.editVal,
      blockContrCredMaxDate:  parseInt(blockContrCredValues.maxDayVal),

      newRecipientVisible:  newRecipientValues.visible,
      newRecipientEditable: newRecipientValues.editVal,
      newRecipientMaxDate:  parseInt(newRecipientValues.maxDayVal),

      actionEndDateVisible:  actionEndDateValues.visible,
      actionEndDateEditable: actionEndDateValues.editVal,
      actionEndDateMaxDate:  parseInt(actionEndDateValues.maxDayVal),
    })


  }


  const dateCheck = (editable, days ) =>{
    if(editable == null){
      return ({visible :false, editVal:false, maxDayVal: null })
    }
    else if(editable=="manual"){
      return({visible: true, editVal: true, maxDayVal: days })
    }
    else{
      return({visible: true, editVal: false, maxDayVal: editable })
    }
  }




  let esitoContactFilterField = {
    uniqueID: "esitoContactFilterField",
    multiSelect: false,
    label: "",
    placeHolder: "Esito",
    readonly: false,
    visible: true,
    disabled: false,
    options: [],
    searchEnabled: true,
    value: (esitoContactSelectedObj && Object.keys(esitoContactSelectedObj).length!=0 && type =="Widget") ? esitoContactSelectedObj : {},
    setValue: (obj) => {
      if (obj.currentValue) {
        let { rlData } = obj.currentValue;
        if (rlData) {
          let {params={}} = rlData;
          setShowEsitoDates(true);
          dateCalculatorEsito(params);
          dispatch(
            esitoSetContactCenterVal({
              interactionId: currentInteractionRef.current,
              esitoSelectVal: rlData,
              esitoDateParamVal: params,
              esitoSetSelectedObj : obj.currentValue,
            })
          );
        }
      }
    },
    form: formFields,
    validation: {
      externalCheck: (value) => {
        if (value && !Array.isArray(value)) {
          return true;
        }
        return false;
      },
    },
    feedback: {
      enable: true,
      component: () => <>* Obbligatorio</>,
    },
  };
  
  let assistenzaFilterField = {
    uniqueID: "assistenzaFilterField",
    multiSelect: false,
    label: "",
    placeHolder: "assistenza",
    readonly: false,
    visible: true,
    disabled: false,
    options: [],
    searchEnabled: true,
    value: (esitoSetAssistenza && Object.keys(esitoSetAssistenza).length!=0 && type =="Widget") ? esitoSetAssistenza : {},
    setValue: (obj) => {
      let val = obj.currentValue
      if(Object.keys(val).length!=0)
      dispatch(
        esitoSetAssistenzaVal({
          interactionId: currentInteractionRef.current,
          selectedAssistenzaVal : obj.currentValue
        })
      );
    },
    form: formFields,
    validation: {
      externalCheck: (value) => {
        if (value && !Array.isArray(value)) {
          return true;
        }
        return false;
      },
    },
    feedback: {
      enable: true,
      component: () => <>* Obbligatorio</>,
    },
  };
  

  let noteTextField = {
    uniqueID: "noteTextField",
    placeHolder: "Inserisci nota",
    readonly: false,
    visible: true,
    value: (esitoSetNoteCRM && esitoSetNoteCRM.length!=0 && type =="Widget") ? esitoSetNoteCRM : "",
    validation: {
      mandatory: false,
      type: "Alphanumeric",
    },    
    setValue: (value) => {
        const { currentValue = "" } = value;
        if(currentValue.length>0)
        dispatch(
          esitoSetNoteCRMVal({
            interactionId: currentInteractionRef.current,
            selectedNoteCRM : currentValue
          })
        );
      },
    form: formFields,
  };

  const dueDateConfigurationField = {
    uniqueID: "dueDateConfigurationField",
    value: esitoDueDateVal ? new Date(esitoDueDateVal) : new Date(),
    form: formFields,
    format:"dd/MM/yyyy",
    showTime: false,
    setValue: (value) => {
      const { currentValue } = value;
        dispatch(
          setDueDateEsito({
            interactionId: currentInteractionRef.current,
            dueDateSet: currentValue,
          })
        );
    },
  };


  return (
    <WidgetWrapper widgetShow={esitoComponentShow}>
      <>
      <MySpinner uniqueID={esitoCRMSpinnerId[type]}  type="global"/>
        <AlertToast
          configuration={{
            unqiueID: esitoCRMComponentAlertId[type],
            className: "inline-toast-container",
            transition: "flip",
          }}
        />

        {phoneCollectionLayoutType == stackExpand ? (
          <div className="d-flex flex-column h-100">
            <div className="d-flex flex-row mb-3">
              <div className="d-flex flex-column w-50">
                <div className="small-content-label-class">Assistenza</div>
                <div className="flex-fill w-75">
                  <SelectField configuration={assistenzaFilterField} />
                </div>
              </div>
              <div className="d-flex flex-column w-50">
                <div className="small-content-label-class">
                  Esito Contact Center
                </div>
                <div className="flex-fill w-75 ">
                  <SelectField configuration={esitoContactFilterField} />
                </div>
              </div>
              <div className="d-flex flex-column w-50">
                <div className="small-content-label-class">Note CC e CRM</div>
                <div className="flex-fill w-75">
                  <TextField configuration={noteTextField} />
                </div>
              </div>
              <div className="d-flex flex-column w-50">
                <div className="small-content-label-class">Due Date</div>
                <div className="flex-fill w-75">
                    <DateField configuration={dueDateConfigurationField} />
                </div>
              </div>
            </div>
            {showEsitoDates && (
              <EsitoCRMDateComponent
                componentType={props.type}
                currentInteraction={currentInteractionRef.current}
                esitoDateParameters={esitoDateParamState}
              />
            )}
            <div className="d-flex justify-content-center flex-row ">
              <div className="w-25 pr-2">
                <button
                  type="button"
                  className={`btn Rectangle-Button-Blue w-100`}
                  disabled={
                    !(
                      esitoSetAssistenza &&
                      esitoContactSelectedObj &&
                      checkBlockPhoneVal &&
                      checkContrCredVal &&
                      checkNewRecipientVal &&
                      checkactionEndDateVal &&
                      (type == "Widget" ? isDisconnectedEsito : true) &&
                      !esitoWidgetDone
                      //(type == "Widget" ? !esitoWidgetDone : true)
                    )
                  }
                  onClick={handleOnAggiornaClick}
                >
                  Aggiorna
                </button>
              </div>
            </div>
          </div>
        ) : (
          <div className="d-flex flex-column h-100">
            <div className="small-content-label-class">Assistenza</div>
            <div className="flex-fill mb-3">
              <SelectField configuration={assistenzaFilterField} />
            </div>
            <div className="small-content-label-class">
              Esito Contact Center
            </div>
            <div className="flex-fill  mb-3 ">
              <SelectField configuration={esitoContactFilterField} />
            </div>
            <div className="small-content-label-class">Note CC e CRM</div>
            <div className="flex-fill mb-3">
              <TextField configuration={noteTextField} />
            </div>
            <div className="small-content-label-class">Due Date</div>
            <div className="flex-fill mb-3">
                <DateField configuration={dueDateConfigurationField} />
            </div>

          {showEsitoDates && (
              <EsitoCRMDateComponent
                componentType={props.type}
                currentInteraction={currentInteractionRef.current}
                esitoDateParameters={esitoDateParamState}
              />
            )}
            <div className="d-flex justify-content-center flex-row  flex-fill">
              <div className="w-50 pr-2">
                <button
                  type="button"
                  className={`btn Rectangle-Button-Blue w-100`}
                  disabled={
                    !(
                      esitoSetAssistenza &&
                      esitoContactSelectedObj &&
                      checkBlockPhoneVal &&
                      checkContrCredVal &&
                      checkNewRecipientVal &&
                      checkactionEndDateVal &&
                      (type == "Widget" ? isDisconnectedEsito : true) &&
                      //!esitoWidgetDone
                      (type == "Widget" ? !esitoWidgetDone : (type=="Modal" && true))
                    )
                  }
                  onClick={handleOnAggiornaClick}
                >
                  Aggiorna
                </button>
              </div>
            </div>
          </div>
        )}
      </>
    </WidgetWrapper>
  );
};

export default EsitoCRMWidgetMain;
