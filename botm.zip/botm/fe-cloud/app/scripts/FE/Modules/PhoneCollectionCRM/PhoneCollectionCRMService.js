import { toast } from "react-toastify";
import { phoneCollectionCRMAlertId, esitoCRMComponentAlertId } from "../../CommonComponents/AlertToast/AlertIdConstants";
import { beServiceUrls } from "../../Client/ClientProperties";
import { exposedDispatch,exposedGetState } from "../../Store/store";
import { reduceToOptions, getBaseErrorMessage } from "../../Utils/CommonUtil";
import HttpClient from "../../Utils/HttpClient";


export const httpPostPhoneCollectionTable = async (request = {}) => {
  let httpClient = new HttpClient();
  httpClient.setUrl(beServiceUrls().pcEstrai);
  let responseData = await httpClient.httpPost(request).then((responseVal) => {
    const { status = "", response = [] } = responseVal;
    if (status === "OK") {        
      return response;
    }else if(status ==="KO"){
      toast.warn(getBaseErrorMessage("Warning",responseVal), { containerId: phoneCollectionCRMAlertId });
    }else{
      throw responseVal
    }
    return [];
  }).catch((err) => {
    toast.error(getBaseErrorMessage("Error",err), { containerId: phoneCollectionCRMAlertId });
    return [];
  });
  return responseData;
}
 

  export const httpPostStatoList = async (request = {}) => {
    let httpClient = new HttpClient();
    httpClient.setUrl(beServiceUrls().postStato);
    let responseData = await httpClient.httpPost(request).then((responseVal) => {
      const { status = "", response = [] } = responseVal;
      if (status === "OK") {        
        let obj = [];
        for (let i = 0; i < response.length; ++i){
            obj.push({"id": response[i] , "value":response[i]});
        }
        return reduceToOptions(obj)("id", "value");
      }else if(status ==="KO"){
        toast.warn(getBaseErrorMessage("Warning",responseVal), { containerId: phoneCollectionCRMAlertId });
      }else{
        throw responseVal
      }
      return [];
    }).catch((err) => {
      toast.error(getBaseErrorMessage("Error",err), { containerId: phoneCollectionCRMAlertId });
      return [];
    });
    return responseData;
  }

  export const httpGetPcAgentList = async() => {
    const dispatch = exposedDispatch;
    let httpClient = new HttpClient();
    httpClient.setUrl(beServiceUrls().getPcAgentList);
    let responseData = await httpClient.httpGet({},).then((responseVal) => {
      const { status = "",response = {} } = responseVal;
      if (status === "OK") {
        return reduceToOptions(response)("employeeId", "name");
      }else if(status ==="KO"){
        toast.warn(getBaseErrorMessage("Warning",responseVal), { containerId: phoneCollectionCRMAlertId });
      }else{
        throw responseVal
      }
      return [];
    }).catch((err) => {
      toast.error(getBaseErrorMessage("Error",err), { containerId: phoneCollectionCRMAlertId });
      return [];
    });
    return responseData;
  };

  export const httpPostNoteList = async (request = {}) => {
    let httpClient = new HttpClient();
    httpClient.setUrl(beServiceUrls().noteColumnPopup);
    let responseData = await httpClient.httpPost(request).then((responseVal) => {
      const { status = "", response = [] } = responseVal;
      if (status === "OK") {
        return responseVal;
      }else if(status ==="KO"){
        toast.warn(getBaseErrorMessage("Warning",responseVal), { containerId: phoneCollectionCRMAlertId });
      }else{
        throw responseVal
      }
      return [];
    }).catch((err) => {
      toast.error(getBaseErrorMessage("Error",err), { containerId: phoneCollectionCRMAlertId });
      return [];
    });
    return responseData;
  }
  

  export const httpGetAssegnatiCDRArr = async(request = {}) => {
    const dispatch = exposedDispatch;
    let httpClient = new HttpClient();
    httpClient.setUrl(beServiceUrls().getAssegnatiAlCDR);
    let responseData = await httpClient.httpGet(request, {}).then((responseVal) => {
      const { status = "", response = [] } = responseVal;
      if (status === "OK") {        
        let obj = [];
        for (let i = 0; i < response.length; ++i){
            obj.push({"id": response[i] , "value":response[i]});
        }
        return reduceToOptions(obj)("id", "value");
      }else if(status ==="KO"){
        toast.warn(getBaseErrorMessage("Warning",responseVal), { containerId: phoneCollectionCRMAlertId });
      }else{
        throw responseVal
      }
      return [];
    }).catch((err) => {
      toast.error(getBaseErrorMessage("Error",err), { containerId: phoneCollectionCRMAlertId });
      return [];
    });
    return responseData;
  };

  
  export const httpGetStatoArr = async() => {
    const dispatch = exposedDispatch;
    let httpClient = new HttpClient();
    httpClient.setUrl(beServiceUrls().getStatoArr);
    let responseData = await httpClient.httpGet({},).then((responseVal) => {
      const { status = "", response = [] } = responseVal;
      if (status === "OK") {        
        let obj = [];
        for (let i = 0; i < response.length; ++i){
            obj.push({"id": response[i] , "value":response[i]});
        }
        return reduceToOptions(obj)("id", "value");
      }else if(status ==="KO"){
        toast.warn(getBaseErrorMessage("Warning",responseVal), { containerId: phoneCollectionCRMAlertId });
      }else{
        throw responseVal
      }
      return [];
    }).catch((err) => {
      toast.error(getBaseErrorMessage("Error",err), { containerId: phoneCollectionCRMAlertId });
      return [];
    });
    return responseData;
  };

  export const httpPostSendEmailCRM = async (request = {}) => {
    let httpClient = new HttpClient();
    httpClient.setUrl(beServiceUrls().sendEmail);
     await httpClient.httpPost(request).then((responseVal) => {
      const { status = "", response = [] } = responseVal;
      if (status === "OK") {        
        toast.success("Draft creata", {containerId: phoneCollectionCRMAlertId,});
      }else if(status ==="KO"){
        toast.warn(getBaseErrorMessage("Warning",responseVal), { containerId: phoneCollectionCRMAlertId });
      }else{
        throw responseVal
      }
    }).catch((err) => {
      toast.error(getBaseErrorMessage("Error",err), { containerId: phoneCollectionCRMAlertId });
    });
  }


  ///////////////////////////////////// ESITO COMPONENT

  
  export const httpGetAssistenza = async (request = {}, type) => {
    let httpClient = new HttpClient();
    httpClient.setUrl(beServiceUrls().assistenza);
    let responseData = await httpClient.httpPost(request).then((responseVal) => {
      const { status = "", response = [] } = responseVal;
      if (status === "OK") {        
        let obj = [];
        for (let i = 0; i < response.length; ++i){
            obj.push({"id": response[i] , "value":response[i]});
        }
        return reduceToOptions(obj)("id", "value");
      }else if(status ==="KO"){
        toast.warn(getBaseErrorMessage("Warning",responseVal), { containerId: esitoCRMComponentAlertId[type] });
      }else{
        throw responseVal
      }
      return [];
    }).catch((err) => {
      toast.error(getBaseErrorMessage("Error",err), { containerId: esitoCRMComponentAlertId[type] });
      return [];
    });
    return responseData;
  }


  export const httpGetEsitoContact = async (request = {}, type) => {
    let httpClient = new HttpClient();
    httpClient.setUrl(beServiceUrls().getEsitoVal);
    let responseData = await httpClient.httpPost(request).then((responseVal) => {
      const { status = "", response = [] } = responseVal;
      if (status === "OK") {        
        return reduceToOptions(response)("actionCode", "actionDesc");
      }else if(status ==="KO"){
        toast.warn(getBaseErrorMessage("Warning",responseVal), { containerId: esitoCRMComponentAlertId[type] });
      }else{
        throw responseVal
      }
      return [];
    }).catch((err) => {
      toast.error(getBaseErrorMessage("Error",err), { containerId: esitoCRMComponentAlertId[type] });
      return [];
    });
    return responseData;
  }


  export const httpPostAggiornaService = async (request = {}, type) => {
    let httpClient = new HttpClient();
    httpClient.setUrl(beServiceUrls().aggiorna);
    let responseData = await httpClient.httpPost(request).then((responseVal) => {
      const { status = ""} = responseVal;
      if (status == "OK") {        
        return responseVal
      }else if(status ==="KO"){
        toast.warn(getBaseErrorMessage("Warning",responseVal), { containerId: esitoCRMComponentAlertId[type] });
      }else{
        throw responseVal
      }
      return [];
    }).catch((err) => {
      toast.error(getBaseErrorMessage("Error",err), { containerId: esitoCRMComponentAlertId[type] });
      return [];
    });
    return responseData;
  }
  
  export const httpPostTraceService = async (bodyRequest = {}, params = {}, type) => {
    const dispatch = exposedDispatch;
    let httpClient = new HttpClient();
    httpClient.setUrl(beServiceUrls().esitoTrace);
    let responseData = await httpClient
      .httpPost(bodyRequest, params)
      .then((response) => {
        const { status = ""} = response;
            if (status == "OK") {
              return response        
            }else if(status ==="KO"){
              toast.warn(getBaseErrorMessage("Warning",response), { containerId: esitoCRMComponentAlertId[type] });
            }else{
              throw response
            }
      })
      .catch((err) => {
        toast.error(getBaseErrorMessage("Error",err), { containerId: esitoCRMComponentAlertId[type] });
        return [];
      });
      return responseData;
  };

  export const httpPostTakeUpdateNotesService = async (request = {}, type) => {
    let httpClient = new HttpClient();
    httpClient.setUrl(beServiceUrls().aggiornaNote);
    let responseData = await httpClient.httpPost(request).then((responseVal) => {
      const { status = "", response = []} = responseVal;
      if (status == "OK") {        
        return response
      }else if(status ==="KO"){
        toast.warn(getBaseErrorMessage("Warning",responseVal), { containerId: esitoCRMComponentAlertId[type] });
      }else{
        throw responseVal
      }
      return [];
    }).catch((err) => {
      toast.error(getBaseErrorMessage("Error",err), { containerId: esitoCRMComponentAlertId[type] });
      return [];
    });
    return responseData;
  }
