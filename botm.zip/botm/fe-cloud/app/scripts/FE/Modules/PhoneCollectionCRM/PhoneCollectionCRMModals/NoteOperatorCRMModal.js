import React from "react";
import MyModal from "../../../CommonComponents/Modal/MyModal";
import { v4 as uuidv4 } from "uuid";
import SimpleTable from "../../../CommonComponents/SimpleTable/SimpleTable";

const NoteOperatorCRMModal = (props) => {

  const {
    showModal = false,
    handleOnCloseModal = () => {},
    tableData = []
    } = props;

    const noteOperatorModal = {
        uniqueID: uuidv4(),
        modalClass: "my-modal prospect-modal",
        modalBodyClass: "my-modal-body modal-h",
        dialogClassName: "modal-w",
        title: {
          content: "NOTA OPERATORE DATA",
          class: "widget-title",
        },
        modalShow: showModal,
        modalHeaderShow: true,
        backdrop: {
          enable: true,
        },
        events: {
          onHide: () => {
            handleOnCloseModal(false);
          },
          onEntered: () => {
            console.log("Confirmation modal onEntered");
          },
          onExited: () => {
            console.log("Confirmation modal onExited");
          },
        },
      };

      let noteOperatorTable = {
        uniqueID: "noteOperatorTable",
        globalSearch: {
          show: true,
          placeholder: "Search…",
          width: "30%",
        },
        metaData: [
          {
            Header: "S.No",
            accessor: "sNo",

          },
          {
            id: "operatore",
            Header: "Operatore",
            accessor: "operatore",


          },
          {
            id: "creationDate",
            Header: "Creation Date",
            accessor: "creationDate",
  

          },
          {
            id: "note",
            Header: "Note",
            accessor: "note",
          }, 
        ],
        sort: [
          {
            id: "sNo",
            desc: false,
          },
        ],
        pagination: true,
        showTotalCount: true,
        paginationOptions: {
          pageSize: 5,
        },
        data: [...tableData],
      };

    return (
      <MyModal configuration={noteOperatorModal}>
          <div className="d-flex mt-2">
            <div className="w-100">
              <SimpleTable configuration={noteOperatorTable} />
            </div>
          </div>   
      </MyModal>
    );
}

export default NoteOperatorCRMModal;