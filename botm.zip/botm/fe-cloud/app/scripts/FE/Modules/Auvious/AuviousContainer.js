import React, { useEffect, useState } from "react";
import { useSelector } from "react-redux";
import { CSSTransition } from "react-transition-group";
import IconBlueClose from "../../CommonComponents/Common/Icons/IconBlueClose";
import IconExplode from "../../CommonComponents/Common/Icons/IconExplode";
import {
  auviousInternalWidgetCode,
  getInternalWidgetByIdAndCode,
} from "../Widgets/internalWidgetsSlice";
import WidgetTitle from "../Widgets/WidgetTitle";
import WidgetWrapper from "../Widgets/WidgetWrapper";

export const AuviousInternalContainer = (props = {}) => {
  const { expandConfig = {}, additionalClass = "" } = props;
  const { expand = false, setExpand = () => {}, onExpand = () => {}} = expandConfig;
  const [auviousIframeSrc, setAuviousIframeSrc] = useState(
    "https://auvious.video/welcome?pcEnvironment=mypurecloud.de&lang=en-us&aid=470c208e-5c25-42bd-a626-9b1f720b9788"
  );

  //const auviousIframeSrc = "https://auvious.video/welcome?pcEnvironment=mypurecloud.de&lang=en-us&aid=470c208e-5c25-42bd-a626-9b1f720b9788";

  const { currentInteraction = "noInteraction" } = useSelector(
    (state) => state.interaction
  );

  const { internalWidgets } = useSelector((state) => state.internalWidgets);

  const [auviousInternalWidgetShow] = getInternalWidgetByIdAndCode(
    internalWidgets
  )(currentInteraction, auviousInternalWidgetCode);

  useEffect(() => {
    if (auviousInternalWidgetShow) {
      let url =
        "https://auvious.video/welcome?pcEnvironment=mypurecloud.de&lang=en-us&aid=470c208e-5c25-42bd-a626-9b1f720b9788";
      if (currentInteraction !== "noInteraction") {
        url = `https://auvious.video/welcome?cid=${currentInteraction}&pcEnvironment=mypurecloud.de&lang=en-us&aid=470c208e-5c25-42bd-a626-9b1f720b9788&cdestination=interaction-widget`;
      }
      setAuviousIframeSrc(url);
    }
  }, [currentInteraction]);

  return (
    <WidgetWrapper
      widgetShow={auviousInternalWidgetShow}
      hidden={true}
      additionalClass={`w-100 ${additionalClass}`}
    >
      <CSSTransition
        in={true}
        timeout={300}
        classNames="slide-left-toggle"
        unmountOnExit={false}
        mountOnEnter={true}
      >
        <div className="section-conversation d-flex flex-column h-100">
          <WidgetTitle
            title="Auvious"
            iconElement={
              expand ? (
                <IconBlueClose
                  configuration={{
                    onClick: (active) => {
                      setExpand(!expand);
                    },
                  }}
                />
              ) : (
                <IconExplode
                  configuration={{
                    onClick: (active) => {
                      setExpand(!expand);
                      onExpand();
                    },
                  }}
                />
              )
            }
          />
          <div className="auvious-frame-container h-100 ">
            <iframe
              name="auvious-frame"
              allow="camera *; microphone *; autoplay *, fullscreen *"
              className="w-100 auvious-frame h-100"
              src={auviousIframeSrc}
            />
          </div>
        </div>
      </CSSTransition>
    </WidgetWrapper>
  );
};
