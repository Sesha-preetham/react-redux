import React from "react";

const SupportDetails = (props ) => {

    const {
        employee = {}
    } = props;

    const {
        employeeCode,
        ntcode,
        name,
        surname,
        cdr,
        office,
        phoneNumber,
        externalNumber
    } = employee;

    return (
        <div className="bpasupport-details-container d-flex flex-row flex-wrap">
            <BpaSupportLabel label="Codice Dipendente">
                <span>{employeeCode}</span>
            </BpaSupportLabel>
            <BpaSupportLabel label="Codice NT">
                <span>{ntcode}</span>
            </BpaSupportLabel>
            <BpaSupportLabel label="Nome">
                <span>{name}</span>
            </BpaSupportLabel>
            <BpaSupportLabel label="Cognome">
                <span>{surname}</span>
            </BpaSupportLabel>
            <BpaSupportLabel label="CDR">
                <span>{cdr}</span>
            </BpaSupportLabel>
            <BpaSupportLabel label="Ufficio">
                <span>{office}</span>
            </BpaSupportLabel>
            <BpaSupportLabel label="Cellulare">
                <span>{phoneNumber}</span>
            </BpaSupportLabel>
            <BpaSupportLabel label="Num. Esterno">
                <span>{externalNumber}</span>
            </BpaSupportLabel>
        </div>
    );
}

const BpaSupportLabel = ( props ) => {
    const { label = "", additionalClass =""} = props;
    return(
        <div className={`bpasupport-details-field my-2 ${additionalClass}`}>
            <div className={`bpasupport-details-title`}>{label}</div>
            <div className={`bpasupport-details-text`}>{props.children}</div>
        </div>
    );
}

export default SupportDetails;