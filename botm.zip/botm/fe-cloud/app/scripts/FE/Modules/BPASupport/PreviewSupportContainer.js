import React, { useEffect, useState } from "react";
import { useSelector } from "react-redux";
import { getEmployeeDataByInteraction } from "../Anagrafica/anagraficaSlice";
import { bpaSupportInternal } from "../Widgets/internalWidgetsSlice";
import {
  bpaSupportCode,
  getDisplayDataByCode,
  getMainWidgetConfigByIdAndCode,
} from "../Widgets/widgetsSlice";
import WidgetTitle from "../Widgets/WidgetTitle";
import WidgetWrapper from "../Widgets/WidgetWrapper";
import SupportDetails from "./SupportDetails";
import SupportTicket from "./SupportTicket";

const PreviewSupportContainer = (props) => {
  const { widgets } = useSelector((state) => state.widgets);

  const { currentInteraction = "noInteraction" } = useSelector(
    (state) => state.interaction
  );

  const { anagrafica = {} } = useSelector((state) => state.anagrafica);

  const { environment = "PRO" } = useSelector((state) => state.preference);

  const [baseHDAUrl, setBaseHDAUrl] = useState();

  const [bpaSupportMenuShow, bpaSupportShow] =
    getDisplayDataByCode(widgets)(bpaSupportCode);

  const { baseUrl = {}, filters = [] } =
    getMainWidgetConfigByIdAndCode(widgets)(bpaSupportCode);

  const { data: employeeArray = [] } =
    getEmployeeDataByInteraction(anagrafica)(currentInteraction);

  const employee = employeeArray.length > 0 ? employeeArray[0] : {};

  const { ntcode } = employee;

  useEffect(()=> {
    setBaseHDAUrl(baseUrl[environment]);
    console.log("PreviewSupportContainer setBaseHDAUrl :: ", baseUrl, environment, baseUrl[environment]);
  },[baseUrl, environment]);

  return (
    <WidgetWrapper widgetShow={bpaSupportShow}>
      <div className="preview-bpasupport-container d-flex flex-column">
        <WidgetTitle title="Supporto" />
          <SupportDetails employee={employee} />
          <SupportTicket
            environment={environment}
            baseUrl={baseHDAUrl}
            filters={filters}
            code={ntcode}
          />
      </div>
    </WidgetWrapper>
  );
};

export default PreviewSupportContainer;
