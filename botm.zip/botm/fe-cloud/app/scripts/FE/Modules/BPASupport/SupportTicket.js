import React from "react";
import { useSelector } from "react-redux";

const SupportTicket = (props = {}) => {
  const { baseUrl = "", filters = [], code, environment } = props;

  const { currentInteraction = "noInteraction" } = useSelector(
    (state) => state.interaction
  );

  const getHDAUrl = () => {
    //let url = `https://servicemanagement.${env}services.h2obanking.eu/HDAPortal/#/WSCView/Detail/$entity=Incident`;
    let url = baseUrl;
    let newFilters = [...filters];
    if (code && code !== "") {
      let contCodeObj = {
        property: "ContCode",
        op: "eq",
        value: code,
      };
      newFilters.push(contCodeObj);
    }
    let solIndex = newFilters.findIndex((el) => el.property === "Solution");
    if (solIndex !== -1) {
      let newObj = { ...newFilters[solIndex] };
      newObj.value = `${newFilters[solIndex].value} - ${currentInteraction}`;
      newFilters[solIndex]=newObj;
    }
    /*let filtersStr = `[`;
    for(let i = 0 ; i < newFilters.length; i++){
      let o = newFilters[i];
      if(!o) continue;
      filtersStr = `${filtersStr} { `;
      for(let k in o){
        filtersStr = `${filtersStr} ${k}: "${o[k]}",  `;
      }
      filtersStr = `${filtersStr} } `
      if(i < newFilters.length-1){
        filtersStr = `${filtersStr}, `
      }
    }
    filtersStr = filtersStr + `]`;
    */
    let filtersStr = JSON.stringify(newFilters);
    url = `${url}&filter=${encodeURIComponent(filtersStr)}`;
    console.log("Support ticket hda url :: ", baseUrl, url, filtersStr);
    return url;
  };

  const handleOpenBarraTicket = () => {
    let url = getHDAUrl();
    window.open(url);
  };

  const handleOpenTicketHDA = () => {
    let envEnd = environment === "PRO" ? "" : ".pre";
    let url = `https://servicemanagement${envEnd}.services.h2obanking.eu/HDAPortal/#/Admin/ServiceCatalog/QuickCreate`;
    window.open(url);
  };

  return (
    <div className="bpasupport-ticket mt-2 w-100 ">
      <button
        type="button"
        className={`btn bpasupport-ticket-btn mr-2`}
        onClick={handleOpenBarraTicket}
        disabled={currentInteraction === "noInteraction"}
      >
        Apri barra telefonica HDA
      </button>
      <button
        type="button"
        className={`btn bpasupport-ticket-btn`}
        onClick={handleOpenTicketHDA}
        disabled={currentInteraction === "noInteraction"}
      >
        Apri ticket HDA
      </button>
    </div>
  );
};

export default SupportTicket;
