import React from "react";
import { Route, Switch, useRouteMatch } from "react-router-dom";
import StackView from "../Main/StackNavigation/StackView";

const RouteContainer = () => {
  let match = useRouteMatch();
  return (
    <Switch>
      <Route path={`${match.path}/`} component={StackView} />
    </Switch>
  );
};

export default RouteContainer;
