import { createSlice } from "@reduxjs/toolkit";

let initialState = {
    channel: {

    },
    topics: [],
    queueActivity: []
}

const notificationSlice = createSlice({
    name: "pureCloudNotification",
    initialState,
    reducers: {
        setNotificationChannel(state, action){
            const { payload = {} } = action;
            const { channel = {}} = payload;
            state.channel = channel;
        },
        addNotificationTopics(state, action){
            const { payload = {} } = action;
            const { topics = []} = payload;
            let topicsToSet = [...state.topics];
            topics.map(el => {
                let i = topicsToSet.findIndex(t => t.id === el.id);
                if(i === -1){
                    topicsToSet.push(el);
                }
            });
            state.topics = topicsToSet;
        },
        updateQueueActivity(state,action){
            const { payload = {} } = action;
            const { value = {}, queue } = payload;
            let newQv = {
                queue: queue,
                ...value
            };
            let newQueueActivityList = [...state.queueActivity];
            let queueValueIndex = newQueueActivityList.findIndex(el => el.queue === queue);
            if(queueValueIndex === -1){
                newQueueActivityList.push(newQv);
            }else{
                newQueueActivityList[queueValueIndex] = newQv;
            }
            state.queueActivity = newQueueActivityList;
        }
    }
});

export const defaultQueueActivityObj = {
    oAlerting: 0,
    oWaiting: 0,
    oInteracting: 0,
    onQueueIdle: 0,
    offQueue: 0
};

export const {
    setNotificationChannel,
    addNotificationTopics,
    updateQueueActivity
} = notificationSlice.actions;

export default notificationSlice.reducer;
