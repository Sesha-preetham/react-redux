import { combineReducers } from "@reduxjs/toolkit";
import spinnerReducer from "../CommonComponents/Spinner/spinnerSlice";
import stackNavigationReducer from "../Main/StackNavigation/stackNavigationSlice";
import anagraficaReducer from "../Modules/Anagrafica/anagraficaSlice";
import lightAuthenticationReducer from "../Modules/LightAuthentication/lightAuthenticationSlice";
import consuntivaReducer from "../Modules/Consuntivazione/consuntivaSlice";
import interactionReducer from "../Modules/Interaction/interactionSlice";
import internalWidgetsReducer from "../Modules/Widgets/internalWidgetsSlice";
import purecloudNotificationSlice from "./purecloudNotificationSlice";
import widgetsReducer from "../Modules/Widgets/widgetsSlice";
import commonReducer from "./commonSlice";
import preferenceReducer from "./preferenceSlice";
import prospectReducer from "../Modules/Prospect/prospectSlice";
import authenticationReducer from "../Modules/Authentication/authenticationSlice";
import sosposeSlice from "../Modules/Sospesi/sosposeSlice";
import abandonRecallSlice from "../Modules/AbandonRecall/abandonRecallSlice";
import retailDeskReducer from "../Modules/RetailDesk/retailDeskSlice";
import phoneCollectionSlice from "../Modules/PhoneCollection/phoneCollectionSlice";
import phoneCollectionCRMSlice from "../Modules/PhoneCollectionCRM/phoneCollectionCRMSlice";
import hdcConsunReducer from "../Modules/Anagrafica/Components/HDCWidget/HDCConsunSlice";

const rootReducer = combineReducers({
  spinner: spinnerReducer,
  preference: preferenceReducer,
  widgets: widgetsReducer,
  anagrafica: anagraficaReducer,
  lightAuthentication: lightAuthenticationReducer,
  common: commonReducer,
  internalWidgets: internalWidgetsReducer,
  stackNavigation: stackNavigationReducer,
  interaction: interactionReducer,
  consuntiva: consuntivaReducer,
  purecloudNotification: purecloudNotificationSlice,
  prospect: prospectReducer,
  authentication: authenticationReducer,
  abandonRecall: abandonRecallSlice,
  retailDesk: retailDeskReducer,
  sospesi: sosposeSlice,
  phoneCollection:phoneCollectionSlice,
  phoneCollectionCRM:phoneCollectionCRMSlice,
  hdcConsun : hdcConsunReducer
});

export default rootReducer;
