import { configureStore } from "@reduxjs/toolkit";

import { isMock } from "../Client/ClientProperties";
import rootReducer from "./rootReducer";

const store = configureStore({ reducer: rootReducer });

if (isMock && module.hot) {
  module.hot.accept("./rootReducer", async () => {
    const newRootReducer = await import("./rootReducer");
    store.replaceReducer(newRootReducer);
  });
}

export default store;

export const { dispatch: exposedDispatch, getState: exposedGetState } = store;
