import { createSlice } from "@reduxjs/toolkit";
import dictionaries from "../Utils/dictionary/dictionary";

window.BTFEDictionary = dictionaries["it"]; // default dictionary

let initialState = {
  profile: {
    id: "",
    nickName: "",
    name: "",
    title: "",
    imageUri: "",
    chatDisturboTimeout : 0,
    timeoutMap: {},
    organization: {},
    authFlow: undefined,
    barraDivisionId: undefined
  },
  userStatus: "",
  language: "it-IT",
  wkscUrl:"",
  idSoggettoVal: null
};

const preferenceSlice = createSlice({
  name: "preference",
  initialState,
  reducers: {
    setCurrentProfile(state, action) {
      const { payload = {} } = action;
      const { profile = {} } = payload;
      const {
        nickName = "",
        name = "",
        title = "",
        id = "",
        imageUri = "",
        organization = {},
        chatDisturboTimeout = 0,
        timeoutMap = {},
        language = "it-IT",
        environment,
        authFlow,
        barraDivisionId
      } = profile;

      state.profile.id = id;
      state.profile.nickName = nickName;
      state.profile.name = name;
      state.profile.title = title;
      state.profile.imageUri = imageUri;
      state.profile.organization = organization;
      state.profile.chatDisturboTimeout = chatDisturboTimeout;
      state.profile.timeoutMap = timeoutMap;
      state.profile.authFlow=authFlow;
      state.profile.barraDivisionId=barraDivisionId;
      state.environment = environment;
      state.language=language;
      let locale = language || "it-IT";
      locale = locale.split("-")[0];
      window.BTFEDictionary = dictionaries[locale];
    },
    resetProfile(state, action) {
      state.profile = initialState.profile;
    },
    setUserStatus(state, action) {
      const { payload = {} } = action;
      const { data = {} } = payload;
      const { status = "" } = data;
      const myStatus = status.toLowerCase().split(" ").join("-");
      state.userStatus = myStatus;
    },
    setWKSCUrl(state, action) {
      const { payload = {} } = action;
      const { wkscUrlVal = "" } = payload;
      state.wkscUrl = wkscUrlVal;
    },
    setIdSoggetto(state, action) {
      const { payload = {} } = action;
      const { idSoggettoValue = "" } = payload;
      state.idSoggettoVal = idSoggettoValue;
    }
  },
});

export const {
  setCurrentProfile,
  resetProfile,
  setUserStatus,
  setWKSCUrl,
  setIdSoggetto,
} = preferenceSlice.actions;

export default preferenceSlice.reducer;
