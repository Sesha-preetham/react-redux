import { createSlice } from "@reduxjs/toolkit";

let initialState = {
  showSessionExpiresModal: false,
  banks: [],
  /* STE: channels and callTypes will be replaced by BE call of andrea
          but I add also default values because PEF events arrive before http call (try to refresh the page)
  */
  channels: {
    voice: "VOICE",
    email: "EMAIL",
    chat: "CHAT",
    messages: "MESSAGES"
  },
  callTypes: {
    callback: "CALLBACK",
    internal: "INTERNAL",
    outbound: "OUTBOUND",
    inbound: "INBOUND"
  },
  systemPresences: [],
  organizationPresences: [],
  cities: [],
  nations: [],
  grantedCustomFunction: [],
};

const commonSlice = createSlice({
  name: "common",
  initialState,
  reducers: {
    setShowSessionExpires(state, action) {
      const { payload = {} } = action;
      const { show = false } = payload;
      state.showSessionExpiresModal = show;
    },
    setBanks(state, action) {
      const { payload = {} } = action;
      const { banks = [] } = payload;
      state.banks = banks;
    },
    setChannelsAndCallTypes(state, action) {
      const { payload = {} } = action;
      const { channelsCallTypes = {} } = payload;
      const { channels = {}, callTypes = {} } = channelsCallTypes;
      state.channels = channels;
      state.callTypes = callTypes;
    },
    setSystemPresences(state, action) {
      const { payload = {} } = action;
      const { systemPresences = {} } = payload;
      state.systemPresences = systemPresences;
    },
    setOrganizationPresences(state,action){
      const { payload = {} } = action;
      const { presences = [] } = payload;
      state.organizationPresences = presences;
    },
    setCities(state, action) {
      const { payload = {} } = action;
      const { cities = [] } = payload;
      state.cities = cities;
    },
    setNations(state, action) {
      const { payload = {} } = action;
      const { nations = [] } = payload;
      state.nations = nations;
    },
    setGrantedCustomFunction(state, action) {
      const { payload = {} } = action;
      const { grantsList = [] } = payload;
      state.grantedCustomFunction = [...grantsList];
    },
  },
});

export const {
  setShowSessionExpires,
  setBanks,
  setChannelsAndCallTypes,
  setOrganizationPresences,
  setSystemPresences,
  setCities,
  setNations,
  setGrantedCustomFunction,
} = commonSlice.actions;

export default commonSlice.reducer;

export const customFunctionCodes = () => {
  return {
    disableSearchWithoutInteraction: "DISABLE_SEARCH_WITHOUT_INTERACTION",
    playGeolocalizationMessage: "PLAY_GEOLOCALIZATION_MESSAGE",
    presaVeloceAction: "PRESA_VELOCE",
    purecloudNotification: "PURECLOUD_NOTIFICATION",
    phoneBookContactSearch: "PHONEBOOK_CONTACTSEARCH",
    disableTransferAutoTrace: "DISABLE_TRANSFER_AUTOTRACE"
  };
};
