import React from "react";
import { Form } from "react-bootstrap";
import Select from "react-select";
import { v4 as uuidv4 } from "uuid";

const basicCustomStyles = {
  control: (provided, state) => {
    return {
      ...provided,
      borderRadius: "4px",
      border: state.isFocused ? "solid 1.5px #0033cc" : "solid 1.5px #b4bcc1",
      backgroundColor: "#ffffff",
      boxShadow: "transparent",
      ":hover": {
        border: state.isFocused ? "solid 1.5px #0033cc" : "solid 1.5px #b4bcc1",
        boxShadow: "transparent",
      },
    };
  },
  indicatorSeparator: (provided, state) => {
    return {
      ...provided,
      backgroundColor: state.isFocused ? "#0033cc" : "#b4bcc1",
    };
  },
  placeholder: (provided, state) => {
    return {
      ...provided,
      color: "#0033cc",
      fontSize: "14px",
      fontFamily: "Lato-Regular",
      letterSpacing: "normal",
    };
  },
  singleValue: (provided, state) => {
    return {
      ...provided,
      color: "#0033cc",
      fontSize: "14px",
      fontFamily: "Lato-Regular",
      letterSpacing: "normal",
    };
  },
  multiValue: (provided, state) => {
    return {
      ...provided,
      borderRadius: "16px",
      backgroundColor: "#f2f5fc",
    };
  },
  multiValueLabel: (provided, state) => {
    return {
      ...provided,
      color: "#1b1b1b",
      fontSize: "14px",
      fontFamily: "Lato-Regular",
      letterSpacing: "normal",
    };
  },
  multiValueRemove: (provided, state) => {
    return {
      ...provided,
      color: "#b4bcc1",
      ":hover": {
        color: "#4d606f",
        backgroundColor: "transparent",
      },
    };
  },
  dropdownIndicator: (provided, state) => {
    return {
      ...provided,
      color: state.isFocused ? "#0033cc" : "#b4bcc1",
      ":hover": {
        color: state.isFocused ? "#00269a" : "#1b1b1b",
      },
    };
  },
  option: (provided, state) => {
    return {
      ...provided,
      borderRadius: "4px",
      backgroundColor: state.isSelected ? "#d9e1f8" : "#ffffff",
      color: "#1b1b1b",
      fontSize: "12px",
      fontFamily: "Lato-Regular",
      letterSpacing: "normal",
      ":hover": {
        backgroundColor: state.isSelected ? "#d9e1f8" : "#f2f5fc",
        color: "#1b1b1b",
      },
    };
  },
};

class SelectField extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      internalState: {},
    };
  }

  componentDidMount() {
    const { configuration = {} } = this.props;
    const {
      uniqueID = uuidv4(),
      multiSelect = false,
      closeOnSelect = true,
      label = "",
      placeHolder = "",
      readonly = false,
      visible = true,
      disabled = false,
      validation = {},
      value = null,
      options = [],
      searchEnabled = false,
      setValue = (obj) => {
        console.log("setValue", obj);
      },
      additionalClass = "",
      feedback = {},
      description = {},
      form = undefined,
      customStyles = basicCustomStyles,
    } = configuration;

    const {
      externalCheck = (value) => {
        return true;
      },
    } = validation;

    const {
      enable: tempDescEnable = false,
      component: TempDescComponent = (props) => {
        return <></>;
      },
    } = description;

    const {
      enable = false,
      component = (props) => {
        return <></>;
      },
    } = feedback;

    const useObject = {
      label,
      placeHolder,
      uniqueID,
      multiSelect,
      closeOnSelect,
      validation: {
        externalCheck,
      },
      value,
      setValue,
      valid: true,
      visible,
      additionalClass,
      readonly,
      disabled,
      feedback: {
        enable,
        component,
      },
      description: {
        enable: tempDescEnable,
        component: TempDescComponent,
      },
      options,
      searchEnabled,
      form,
      customStyles,
    };
    if (form) form.addField(this, useObject);
    this.setInternalState(useObject, () => {
      this.setValue(value);
    });    
  }

  setInternalState = (useObject, callBack = () => {}) => {
    this.setState((prevState) => {
      return {
        internalState: {
          ...prevState.internalState,
          ...useObject,
        },
      };
    }, callBack);
  };

  getOption = (currentValue) => {
    let { options = [] } = this.state.internalState;
    return options.find((option) => {
      option.value === currentValue.value;
    });
  };

  setReadonly = (newReadonly) => {
    let { uniqueID, readonly, valid, form } = this.state.internalState;
    readonly = b;
    if (newReadonly) {
      valid = newReadonly;
    } else {
      valid = false;
      if (form) form.cleanCachedField(obj.uniqueID);
    }
    this.setInternalState(
      {
        readonly,
        valid,
      },
      () => {
        this.doThrowSetValue();
      }
    );
  };

  isReadonly = () => {
    let { readonly } = this.state.internalState;
    return readonly;
  };

  setVisible = (newVisible) => {
    let { internalState } = this.state;
    let obj = { ...internalState };
    obj.visible = newVisible;
    if (newVisible) {
      obj.valid = true;
    } else {
      obj.valid = false;
      if (obj.form) obj.form.cleanCachedField(obj.uniqueID);
    }
    this.setInternalState(obj, () => {
      this.doThrowSetValue();
    });
  };

  isVisible = () => {
    let { visible } = this.state.internalState;
    return visible;
  };

  getValue = () => {
    let { value } = this.state.internalState;
    return value;
  };

  setValue = (value) => {
    const { uniqueID, setValue, form } = this.state.internalState;
    if (uniqueID) {
      this.setInternalState({
        value,
      });
      let refreshObject = {
        uniqueID,
        currentValue: value,
        valid: this.internalValidate(value),
      };
      if (setValue) setValue(refreshObject);
      if (form) form.validationResult(refreshObject);
    }
  };

  currentRefreshObject = () => {
    const { uniqueID, value, valid } = this.state.internalState;
    let refreshObject = {
      uniqueID,
      currentValue: value,
      valid,
    };
    return refreshObject;
  };

  doThrowSetValue = () => {
    const { setValue, form } = this.state.internalState;
    let refreshObject = this.currentRefreshObject();
    setValue(refreshObject);
    if (form) form.validationResult(refreshObject);
  };

  isValid = () => {
    let { value } = this.state.internalState;
    this.internalValidate(value);
    let { valid } = this.state.internalState;
    return valid;
  };

  shouldValidate = (e) => {
    let { validation } = this.state.internalState;
    return validation && this.isVisible() && !this.isReadonly();
  };

  internalValidate = (value) => {
    let { validation, readonly, visible, valid } = this.state.internalState;
    let { externalCheck } = validation;
    if (this.shouldValidate())
      valid = !readonly && visible && externalCheck(value);
    //this.doThrowSetValue(); // Callback to the parent
    this.setInternalState({ valid });
    return valid;
  };

  reloadOptions = (newOptions = [], keepValueIfEmpty = false) => {
    this.setInternalState({
      options: [...newOptions],
    });
    if(!keepValueIfEmpty){
      if (newOptions.length === 0) {
        this.setInternalState({
          value: {},
        });
      }
    }
  };

  handleOnChange = (currentValue, actionMeta) => {
    this.setInternalState({
      value: currentValue,
    });
    const { uniqueID, valid, setValue, form } = this.state.internalState;
    let refreshObject = {
      uniqueID,
      currentValue: currentValue,
      valid: this.internalValidate(currentValue),
    };
    setValue(refreshObject);
    if (form) form.validationResult(refreshObject);
  };

  render() {
    const { internalState = {} } = this.state;
    const {
      uniqueID = uuidv4(),
      multiSelect,
      closeOnSelect,
      label = "",
      placeHolder = "",
      readonly = false,
      visible = true,
      disabled = false,
      value = null,
      options = [],
      searchEnabled = false,
      additionalClass = "",
      feedback = {},
      description = {},
      customStyles = basicCustomStyles,
      valid = true,
    } = internalState;

    const {
      enable: descEnable = false,
      component: DescComponent = (props) => {
        return <></>;
      },
    } = description;

    const {
      enable: feedbackEnable = false,
      component: FeedbackComponent = (props) => {
        return <></>;
      },
    } = feedback;

    let reactSelectReplaceComponents = {};

    if (multiSelect) {
      reactSelectReplaceComponents.DropdownIndicator = () => {
        return null;
      };
      reactSelectReplaceComponents.IndicatorSeparator = () => {
        return null;
      };
    }

    return (
      <>
        {visible && (
          <Form.Group className={additionalClass} controlId={uniqueID}>
            {label && <Form.Label>{label}</Form.Label>}
            <Select
              inputId={uniqueID}
              styles={customStyles}
              isMulti={multiSelect}
              options={options}
              value={value}
              disabled={disabled}
              closeMenuOnSelect={closeOnSelect}
              placeholder={placeHolder}
              components={reactSelectReplaceComponents}
              onChange={this.handleOnChange}
              isSearchable={searchEnabled}
            />
            {descEnable && (
              <Form.Text muted>
                <DescComponent />
              </Form.Text>
            )}
            {feedbackEnable && (
              <Form.Control.Feedback
                type={valid ? "valid" : "invalid"}
                className={valid ? "" : "d-block"}
              >
                <FeedbackComponent />
              </Form.Control.Feedback>
            )}
          </Form.Group>
        )}
      </>
    );
  }
}

export default SelectField;
