import React from "react";
import { Form } from "react-bootstrap";
import { v4 as uuidv4 } from "uuid";

class CheckBox extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      internalState: {},
    };
  }
  setInternalState = (useObject, callBack = () => {}) => {
    this.setState((prevState) => {
      return {
        internalState: {
          ...prevState.internalState,
          ...useObject,
        },
      };
    }, callBack);
  };

  componentDidMount() {
    const { configuration = {} } = this.props;
    const {
      uniqueID = uuidv4(),
      label = "",
      labelClass = "",
      readonly = false,
      visible = true,
      disabled = false,
      additionalValidation = () => {
        return true;
      },
      value = "",
      setValue = (obj) => {
        console.log("setValue", obj);
      },
      checked = false,
      description = {},
      feedback = {},
      classForCheckBox = "",
      form = undefined,
    } = configuration;

    const {
      enable = false,
      component = (props) => {
        return <></>;
      },
    } = feedback;

    const {
      enable: tempDescEnable = false,
      component: TempDescComponent = (props) => {
        return <></>;
      },
    } = description;

    const useObject = {
      label,
      labelClass,
      uniqueID,
      value,
      setValue,
      valid: true,
      visible,
      additionalValidation,
      readonly,
      disabled,
      checked,
      feedback: {
        enable,
        component,
      },
      description: {
        enable: tempDescEnable,
        component: TempDescComponent,
      },
      classForCheckBox,
      form,
    };
    if (form) form.addField(this, useObject);
    this.setInternalState(useObject, () => {
      this.doThrowSetValue();
    });
  }

  setDisabled = (newDisabled) => {
    let obj = { ...this.state.internalState };
    obj.disabled = newDisabled;
    if (newDisabled) {
      obj.valid = true;
    } else {
      obj.valid = false;
      if (obj.form) obj.form.cleanCachedField(obj.uniqueID);
    }
    this.setInternalState(obj, () => {
      this.doThrowSetValue();
    });
  };

  setReadonly = (newReadyonly) => {
    let obj = { ...this.state.internalState };
    obj.readonly = newReadyonly;
    if (newReadyonly) {
      obj.valid = true;
    } else {
      obj.valid = false;
      if (obj.form) obj.form.cleanCachedField(obj.uniqueID);
    }
    this.setInternalState(obj, () => {
      this.doThrowSetValue();
    });
  };

  setVisible = (newVisible) => {
    let obj = { ...this.state.internalState };
    obj.visible = newVisible;
    if (!newVisible) {
      obj.valid = true;
    } else {
      obj.valid = false;
    }
    this.setInternalState(obj, () => {
      this.doThrowSetValue();
    });
  };

  setValue = (currentValue) => {
    this.setInternalState(
      {
        checked: currentValue,
      },
      () => {
        this.doThrowSetValue();
      }
    );
  };

  getValue = () => {
    let { checked } = this.state.internalState;
    return checked;
  };
  isValid = () => {
    let { additionalValidation } = this.state.internalState;
    return additionalValidation(checked);
  };

  currentRefreshObject = () => {
    let { uniqueID, checked, valid } = this.state.internalState;
    let refreshObject = {
      uniqueID: uniqueID,
      currentValue: checked,
      valid: valid,
    };
    return refreshObject;
  };

  doThrowSetValue = () => {
    let { setValue } = this.state.internalState;
    let refreshObject = this.currentRefreshObject();
    setValue(refreshObject);
  };

  isVisible = () => {
    let { visible } = this.state.internalState;
    if (visible) {
      return visible;
    } else {
      return false;
    }
  };

  isReadonly = () => {
    let { readonly } = this.state.internalState;
    if (readonly) {
      return readonly;
    } else {
      return false;
    }
  };

  isDisabled = () => {
    let { disabled } = this.state.internalState;
    if (disabled) {
      return disabled;
    } else {
      return false;
    }
  };

  handleOnChange = (event) => {
    let checked = event.currentTarget.checked;
    this.setInternalState(
      {
        checked,
      },
      this.doThrowSetValue
    );
  };

  render() {
    let {
      uniqueID = uuidv4(),
      label = "",
      labelClass = "",
      readonly = false,
      visible = true,
      disabled = false,
      valid = true,
      checked = false,
      description = {},
      feedback = {},
      classForCheckBox = "",
    } = this.state.internalState;

    let {
      enable: descEnable = false,
      component: DescComponent = (props) => {
        return <></>;
      },
    } = description;

    let {
      enable: feedbackEnable = false,
      component: FeedbackComponent = (props) => {
        return <></>;
      },
    } = feedback;
    return (
      <>
        {visible && (
          <Form.Check
            className={classForCheckBox}
            type="checkbox"
            id={uniqueID}
          >
            <Form.Check.Input
              type="checkbox"
              checked={checked}
              onChange={this.handleOnChange}
              disabled={disabled}
              readOnly={readonly}
            />
            {label && (
              <Form.Check.Label className={labelClass}>
                {label}
              </Form.Check.Label>
            )}
            {descEnable && (
              <Form.Text muted>
                <DescComponent />
              </Form.Text>
            )}
            {feedbackEnable && (
              <Form.Control.Feedback
                type={valid ? "valid" : "invalid"}
                className={valid ? "" : "d-block"}
              >
                <FeedbackComponent />
              </Form.Control.Feedback>
            )}
          </Form.Check>
        )}
      </>
    );
  }
}

export default CheckBox;
