import React from "react";
import { Form } from "react-bootstrap";
import { v4 as uuidv4 } from "uuid";

class RadioButton extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      internalState: {},
    };
  }

  setInternalState = (useObject, callBack = () => {}) => {
    this.setState((prevState) => {
      return {
        internalState: {
          ...prevState.internalState,
          ...useObject,
        },
      };
    }, callBack);
  };

  componentDidMount() {
    const { configuration = {} } = this.props;
    const {
      uniqueID = uuidv4(),
      label = "",
      readonly = false,
      visible = true,
      disabled = false,
      additionalValidation = () => {
        return true;
      },
      value = "",
      setValue = (obj) => {
        console.log("setValue", obj);
      },
      checked = "",
      description = {},
      feedback = {},
      validation = {},
      options = [],
      classForRadio = "",
      form = undefined,
    } = configuration;

    const {
      enable = false,
      component = (props) => {
        return <></>;
      },
    } = feedback;

    const {
      enable: tempDescEnable = false,
      component: TempDescComponent = (props) => {
        return <></>;
      },
    } = description;

    const { mandatory = false } = validation;

    const useObject = {
      label,
      uniqueID,
      value,
      setValue,
      valid: true,
      visible,
      additionalValidation,
      readonly,
      disabled,
      checked,
      feedback: {
        enable,
        component,
      },
      description: {
        enable: tempDescEnable,
        component: TempDescComponent,
      },
      validation: {
        mandatory,
      },
      options,
      classForRadio,
      form,
    };
    if (form) form.addField(this, useObject);
    this.setInternalState(useObject, () => {
      this.doThrowSetValue();
    });
  }

  setDisabled = (newDisabled) => {
    let obj = this.state.internalState;
    obj.disabled = newDisabled;
    if (newDisabled) {
      obj.valid = true;
    } else {
      obj.valid = false;
      if (obj.form) obj.form.cleanCachedField(obj.uniqueID);
    }
    this.setInternalState(obj, () => {
      this.doThrowSetValue();
    });
  };
  setReadonly = (newReadyonly) => {
    let obj = this.state.internalState;
    obj.readonly = newReadyonly;
    if (newReadyonly) {
      obj.valid = true;
    } else {
      obj.valid = false;
      if (obj.form) obj.form.cleanCachedField(obj.uniqueID);
    }
    this.setInternalState(obj, () => {
      this.doThrowSetValue();
    });
  };
  setVisible = (newVisible) => {
    let obj = this.state.internalState;
    obj.visible = newVisible;
    if (!newVisible) {
      obj.valid = true;
    } else {
      obj.valid = false;
    }
    this.setInternalState(obj, () => {
      this.doThrowSetValue();
    });
  };
  setValue = (currentValue) => {
    this.setInternalState(
      {
        checked: currentValue,
      },
      () => {
        this.doThrowSetValue();
      }
    );
  };
  getValue = () => {
    let { checked } = this.state.internalState;
    return checked;
  };
  isValid = () => {
    let { checked } = this.state.internalState;
    let { valid } = this.internalValidate(checked);
    return valid;
  };

  shouldValidate = () => {
    let { feedback } = this.state.internalState;
    let { enable: feedbackEnable } = feedback;
    return feedbackEnable && this.isVisible() && !isReadonly();
  };

  internalValidate = (targetValue) => {
    let currentValid = true;
    let {
      checked,
      valid,
      validation,
      additionalValidation,
    } = this.state.internalState;
    let { mandatory } = validation;

    if (this.shouldValidate()) {
      if (
        mandatory === true &&
        (!targetValue || "" === targetValue || targetValue.length === 0)
      ) {
        currentValid = false;
      }
    }
    checked = targetValue;
    currentValid = currentValid && additionalValidation(checked);
    valid = currentValid;
    this.setInternalState(
      {
        valid,
        checked,
      },
      () => {
        this.doThrowSetValue();
      }
    );
    return { valid, checked };
  };

  isVisible = () => {
    let { visible } = this.state.internalState;
    if (visible) {
      return visible;
    } else {
      return false;
    }
  };

  isReadonly = () => {
    let { readonly } = this.state.internalState;
    if (readonly) {
      return readonly;
    } else {
      return false;
    }
  };

  isDisabled = () => {
    let { disabled } = this.state.internalState;
    if (disabled) {
      return disabled;
    } else {
      return false;
    }
  };

  reloadOptions = (newOptions) => {
    var obj = this.state.internalState;
    obj.options = newOptions;
    this.setInternalState(obj);
  };

  currentRefreshObject = () => {
    let { uniqueID, checked, valid } = this.state.internalState;
    let refreshObject = {
      uniqueID: uniqueID,
      currentValue: checked,
      valid: valid,
    };
    return refreshObject;
  };

  doThrowSetValue = () => {
    let { setValue } = this.state.internalState;
    let refreshObject = this.currentRefreshObject();
    setValue(refreshObject);
  };

  handleOnChange = (event) => {
    let currentValue = event.currentTarget.value;
    this.internalValidate(currentValue);
  };

  render() {
    let {
      uniqueID = uuidv4(),
      readonly = false,
      visible = true,
      disabled = false,
      valid = true,
      checked = "",
      description = {},
      feedback = {},
      options = [],
      classForRadio = "",
    } = this.state.internalState;

    let {
      enable: descEnable = false,
      component: DescComponent = (props) => {
        return <></>;
      },
    } = description;

    let {
      enable: feedbackEnable = false,
      component: FeedbackComponent = (props) => {
        return <></>;
      },
    } = feedback;

    return (
      <>
        {visible && (
          <Form.Group className={classForRadio} controlId={uniqueID}>
            {options.map((currentOption, currentIndex) => {
              return (
                <Form.Check key={uuidv4()} type="radio" inline>
                  <Form.Check.Input
                    type="radio"
                    id={currentOption.id}
                    checked={checked == currentOption.id}
                    onChange={this.handleOnChange}
                    disabled={disabled}
                    readOnly={readonly}
                    value={currentOption.id}
                  />
                  <Form.Check.Label>
                    {currentOption.description}
                  </Form.Check.Label>
                </Form.Check>
              );
            })}
            {descEnable && (
              <Form.Text muted>
                <DescComponent />
              </Form.Text>
            )}
            {feedbackEnable && (
              <Form.Control.Feedback
                type={valid ? "valid" : "invalid"}
                className={valid ? "" : "d-block"}
              >
                <FeedbackComponent />
              </Form.Control.Feedback>
            )}
          </Form.Group>
        )}
      </>
    );
  }
}

export default RadioButton;
