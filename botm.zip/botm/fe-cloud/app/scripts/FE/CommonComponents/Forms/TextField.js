import React from "react";
import { Form } from "react-bootstrap";
import { v4 as uuidv4 } from "uuid";

class TextField extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      internalState: {},
    };
  }

  setInternalState = (useObject, callBack = () => {}) => {
    this.setState((prevState) => {
      return {
        internalState: {
          ...prevState.internalState,
          ...useObject,
        },
      };
    }, callBack);
  };

  componentDidMount() {
    const { configuration = {} } = this.props;
    const {
      uniqueID = uuidv4(),
      label = "",
      placeHolder = "",
      readonly = false,
      visible = true,
      disabled = false,
      controlType = "text",
      additionalValidation = () => {
        return true;
      },
      validation = {},
      value = "",
      setValue = (obj) => {
        console.log("setValue", obj);
      },
      callBackOnKeyUp = (event, refreshObject) => {
        console.log("callBackOnKeyUp", refreshObject);
      },

      additionalClass = "",
      feedback = {},
      description = {},
      form = undefined,
    } = configuration;

    const {
      mandatory = false,
      minLen = -1,
      maxLen = -1,
      type = null,
    } = validation;

    const {
      enable: tempDescEnable = false,
      component: TempDescComponent = (props) => {
        return <></>;
      },
    } = description;

    const {
      enable = false,
      component = (props) => {
        return <></>;
      },
    } = feedback;

    const useObject = {
      label,
      placeHolder,
      uniqueID,
      validation: {
        mandatory,
        minLen,
        maxLen,
        type,
      },
      type: controlType,
      value,
      setValue,
      callBackOnKeyUp,
      valid: true,
      visible,
      additionalValidation,
      additionalClass,
      readonly,
      disabled,
      feedback: {
        enable,
        component,
      },
      description: {
        enable: tempDescEnable,
        component: TempDescComponent,
      },
      form,
    };
    if (form) form.addField(this, useObject);
    this.setInternalState(useObject, () => {
      this.doThrowSetValue();
    });
  }

  setDisabled = (newDisabled, throwSetValue = true) => {
    let { internalState } = this.state;
    let obj = { ...internalState };
    obj.disabled = newDisabled;
    if (newDisabled) {
      obj.valid = true;
    } else {
      obj.valid = false;
      if (obj.form) obj.form.cleanCachedField(obj.uniqueID);
    }
    this.setInternalState(obj, () => {
      if(throwSetValue)
        this.doThrowSetValue();
    });
  };

  setReadonly = (newReadonly) => {
    let { internalState } = this.state;
    let obj = { ...internalState };
    obj.readonly = newReadonly;
    if (newReadonly) {
      obj.valid = true;
    } else {
      obj.valid = false;
      if (obj.form) obj.form.cleanCachedField(obj.uniqueID);
    }
    this.setInternalState(obj, () => {
      this.doThrowSetValue();
    });
  };

  setVisible = (newVisible) => {
    let { internalState } = this.state;
    let obj = { ...internalState };
    obj.visible = newVisible;
    if (newVisible) {
      obj.valid = true;
    } else {
      obj.valid = false;
      if (obj.form) obj.form.cleanCachedField(obj.uniqueID);
    }
    this.setInternalState(obj, () => {
      this.doThrowSetValue();
    });
  };
  setValue = (currentValue) => {
    this.internalValidate(currentValue);
  };
  setFeedbackComponent = (newFeedback) => {
    let { internalState } = this.state;
    let obj = { ...internalState };
    obj.feedback.enable = true;
    obj.feedback.component = newFeedback;
    obj.valid = false;
    this.setInternalState(obj);
  };
  getValue = () => {
    let { internalState } = this.state;
    let { value } = internalState;
    return value;
  };

  shouldValidate = () => {
    let { internalState } = this.state;
    let { feedback = {} } = internalState;
    let { enable = false } = feedback;
    return enable && this.isVisible() && !this.isReadonly();
  };

  isVisible = () => {
    let { internalState } = this.state;
    let { visible } = internalState;
    if (visible) {
      return visible;
    } else {
      return false;
    }
  };

  isReadonly = () => {
    let { internalState } = this.state;
    let { readonly } = internalState;
    if (readonly) {
      return readonly;
    } else {
      return false;
    }
  };

  isDisabled = () => {
    let { internalState } = this.state;
    let { disabled } = internalState;
    if (disabled) {
      return disabled;
    } else {
      return false;
    }
  };

  isValid = () => {
    let { internalState } = this.state;
    let { value, valid } = internalState;
    let ret = false;
    if (this.shouldValidate()) {
      this.internalValidate(value);
      ret = valid;
    } else {
      ret = true;
    }
    return ret;
  };

  currentRefreshObject = () => {
    let { internalState } = this.state;
    let { uniqueID, value, valid } = internalState;
    let refreshObject = {
      uniqueID,
      currentValue: value,
      valid,
    };
    return refreshObject;
  };

  doThrowSetValue = () => {
    let { internalState } = this.state;
    let { form, setValue } = internalState;
    let refreshObject = this.currentRefreshObject();
    if (setValue) {
      setValue(refreshObject);
    }
    if (form) form.validationResult(refreshObject);
  };

  internalValidate = (currentValue) => {
    let { internalState } = this.state;
    let { valid, additionalValidation, value, form } = internalState;
    valid = true;
    let toValidate = this.shouldValidate();
    if (toValidate) {
      let { validation } = internalState;
      let { mandatory, minLen, maxLen, type } = validation;
      if (minLen !== -1) {
        if (currentValue.length < Number(minLen)) {
          valid = false;
        }
      }
      if (maxLen !== -1) {
        if (currentValue.length > Number(maxLen)) {
          valid = false;
        }
      }
      if (
        mandatory === true &&
        (!currentValue || "" === currentValue || currentValue.length === 0)
      ) {
        valid = false;
      }
      let value2 = currentValue;
      if (type) {
        let regex;
        if (type.indexOf("Alphanumeric") > -1) {
          regex = /^[a-zA-Z0-9\s]+$/i;
        }
        if (type.indexOf("AlphanumPuntact") > -1) {
          regex = /^[a-zA-Z0-9\u00C4\u00CB\u00EF\u00EB\u00F6\u00E4\u00DC\00D6\u00C0-\u00C1-\u00C9\u00CC-\u00CD\u00D2-\u00D3\u00D9-\u00DA\u00E0-\u00E1\u00E8-\u00E9\u00EC-\u00ED\u00F2-\u00F3-\u0027\u00F9-\u00FA-+%\,\.\s]+$/i;
        }
        if (type.indexOf("Alphabetic") > -1) {
          regex = /^[a-zA-Z\s]+$/i;
        }
        if (type.indexOf("Numeric") > -1) {
          regex = /^[0-9]+$/i;
        }
        if (type.indexOf("Email") > -1) {
          regex = /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/i;
        }
        if (regex && !regex.test(value2)) {
          if ("" !== value2) {
            valid = false;
          }
        }
      }

      if (valid) {
        let myValue = currentValue;
        valid = additionalValidation(myValue, form);
      }
      valid = valid;
    }
    value = currentValue;
    this.setInternalState(
      {
        value,
        valid,
      },
      () => {
        this.doThrowSetValue();
      }
    );
  };

  handleOnChange = (event) => {
    this.internalValidate(event.currentTarget.value);
  };

  handleOnKeyUp = (event) => {
    let currentValue = event.currentTarget.value;
    let { internalState } = this.state;
    let { value } = internalState;
    this.internalValidate(currentValue);
    value = currentValue;
    this.doThrowSetValue();
    this.onKeyUpCallBack(event);
    this.setInternalState({
      value,
    });
  };

  onKeyUpCallBack = (event) => {
    let { internalState } = this.state;
    let { callBackOnKeyUp } = internalState;
    let refreshObject = this.currentRefreshObject();
    callBackOnKeyUp(event, refreshObject);
  };
  render() {
    let { internalState } = this.state;
    let {
      uniqueID = uuidv4(),
      label = "",
      placeHolder = "",
      readonly = false,
      visible = true,
      disabled = false,
      additionalClass = "",
      valid = true,
      type = "text",
      description = {},
      feedback = {},
      value = "",
    } = internalState;
    let {
      enable: descEnable = false,
      component: DescComponent = (props) => {
        return <></>;
      },
    } = description;

    let {
      enable: feedbackEnable = false,
      component: FeedbackComponent = (props) => {
        return <></>;
      },
    } = feedback;

    return (
      <>
        {visible && (
          <Form.Group
            className={`my-text-field ${additionalClass}`}
            controlId={uniqueID}
          >
            {label && <Form.Label>{label}</Form.Label>}
            <Form.Control
              type={type}
              autoComplete={"none"}
              placeholder={placeHolder}
              onChange={this.handleOnChange}
              onKeyUp={this.handleOnKeyUp}
              readOnly={readonly}
              disabled={disabled}
              value={value}
            />
            {descEnable && (
              <Form.Text muted>
                <DescComponent />
              </Form.Text>
            )}
            {feedbackEnable && (
              <Form.Control.Feedback
                type={valid ? "valid" : "invalid"}
                className={valid ? "" : "d-block"}
              >
                <FeedbackComponent />
              </Form.Control.Feedback>
            )}
          </Form.Group>
        )}
      </>
    );
  }
}

export default TextField;
