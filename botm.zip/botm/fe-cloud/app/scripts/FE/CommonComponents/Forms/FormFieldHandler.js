import { Map } from "immutable";
import { v4 as uuidv4 } from "uuid";

class FormFieldHandler {
  #fieldList = Map();
  uniqueID = uuidv4();

  constructor(onReplaceAndAdd = false) {
    const isReplaceAndAdd = onReplaceAndAdd;
    this.getIsReplaceAndAdd = () => {
      return isReplaceAndAdd;
    };
  }

  getFormUniqueID = () => {
    return this.uniqueID;
  }

  clearFields = () => {
    this.#fieldList = this.#fieldList.clear();
  };

  getFields = () => {
    return this.#fieldList.toJS();
  };

  addField = (field, configuration) => {
    if (!field || !configuration) {
      console.warn(
        "[FormFieldHandler]Mandatory parameter on addField not provided!"
      );
      throw "[FormFieldHandler]Mandatory parameter on addField not provided!";
    }
    if (
      configuration.uniqueID &&
      !this.#fieldList.has(configuration.uniqueID)
    ) {
      this.#fieldList = this.#fieldList.set(configuration.uniqueID, {
        theField: field,
        configuration: configuration,
        validationResult: undefined,
      });
    } else {
      console.warn(
        "[FormFieldHandler]field alreeady present in the form! " +
          configuration.uniqueID
      );
      if (this.getIsReplaceAndAdd()) {
          this.removeField(configuration.uniqueID);
          this.addField(field, configuration);
      } 
    }
  };

  removeField = (uniqueID) => {
    if (this.#fieldList.has(uniqueID)) {
      this.#fieldList = this.#fieldList.delete(uniqueID);
    }
  };

  validationResult = (validation) => {
    let currentField = this.getField(validation.uniqueID);
    if (!currentField) {
      console.warn(
        "[FormFieldHandler]Field " + currentField.uniqueID + " not registered!"
      );
      throw (
        "[FormFieldHandler]Field " + currentField.uniqueID + " not registered!"
      );
    }
    currentField.validationResult = validation;
    this.#fieldList = this.#fieldList.set(currentField.uniqueID, currentField);
  };

  cleanCachedField = (uniqueID) => {
    let currentField = this.getField(uniqueID);
    if (!currentField) {
      console.warn("[FormFieldHandler]Field " + uniqueID + " not registered!");
      throw "[FormFieldHandler]Field " + uniqueID + " not registered!";
    }
    currentField.validationResult = undefined;
    this.#fieldList = this.#fieldList.set(currentField.uniqueID, currentField);
  };

  shouldValidate = (field) => {
    return field.theField.shouldValidate();
  };

  isFormValid = () => {
    let validForm = true;
    this.#fieldList.entrySeq().forEach(([uniqueID, currentField]) => {
      if (currentField.validationResult) {
        if (
          this.shouldValidate(currentField) &&
          !currentField.validationResult.valid &&
          validForm
        ) {
          validForm = false;
        } else {
          if (
            this.shouldValidate(currentField) &&
            !currentField.theField.isValid() &&
            validForm
          ) {
            validForm = false;
          }
        }
      }
    });
    return validForm;
  };

  getField = (uniqueID) => {
    console.log(
      "[FormFieldHandler]Field " + uniqueID + " getField!",
      this.#fieldList.get(uniqueID)
    );
    return this.#fieldList.get(uniqueID);
  };

  getValue = (uniqueID) => {
    try {
      let field = this.getField(uniqueID);
      return field.theField.getValue();
    } catch (err) {
      console.log("getValue " + err);
    }
  };

  isEmpty = () => {
    return this.#fieldList.isEmpty()
  }
}

export default FormFieldHandler;
