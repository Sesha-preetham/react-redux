import React from "react";
import { v4 as uuidv4 } from "uuid";
import DatePicker from "react-datepicker";
import { Form } from "react-bootstrap";
//import "react-datepicker/dist/react-datepicker.css";

class DateField extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      internalState: {},
    };
  }

  setInternalState = (useObject, callBack = () => {}) => {
    this.setState((prevState) => {
      return {
        internalState: {
          ...prevState.internalState,
          ...useObject,
        },
      };
    }, callBack);
  };

  componentDidMount() {
    const { configuration = {} } = this.props;
    const {
      uniqueID = uuidv4(),
      placeholder,
      format = "dd/MM/yyyy HH:mm:ss",
      events = {},
      value = new Date(),
      clearable = false,
      closeOnScroll = false,
      setValue = () => {},
      validation = {
        mandatory: true,
      },
      additionalValidation = () => {},
      closeOnSelect = true,
      pickerClassName = "btdatepicker",
      valid,
      calendarClassName,
      feedback = {},
      showTime = true,
      disabled = false,
      visible = true,
      timeInputLabel = "Ora:",
      timeInputFormat="HH:mm",
      form,
    } = configuration;

    const {
      enable = false,
      component = (props) => {
        return <></>;
      },
    } = feedback;

    const useObject = {
      uniqueID,
      clearable,
      placeholder,
      closeOnScroll,
      setValue,
      additionalValidation,
      closeOnSelect,
      pickerClassName,
      calendarClassName,
      showTime,
      validation,
      value,
      valid,
      feedback: {
        enable,
        component,
      },
      timeInputLabel,
      timeInputFormat,
      disabled,
      visible,
      format,
      form,
    };
    if (form) form.addField(this, useObject);
    this.setInternalState(useObject, () => {
      this.doThrowSetValue();
    });
  }

  shouldValidate = () => {
    let { feedback } = this.state.internalState;
    let { enable: feedbackEnable } = feedback;
    return feedbackEnable && this.isVisible();
  };

  isVisible = () => {
    let { visible } = this.state.internalState;
    if (visible) {
      return visible;
    } else {
      return false;
    }
  };
  setVisible = (newVisible) => {
    let obj = this.state.internalState;
    obj.visible = newVisible;
    if (!newVisible) {
      obj.valid = true;
    } else {
      obj.valid = false;
    }
    this.setInternalState(obj, () => {
      this.doThrowSetValue();
    });
  };
  setValue = (currentValue) => {
    this.setInternalState(
      {
        value: currentValue,
      },
      () => {
        this.doThrowSetValue();
      }
    );
  };
  getValue = () => {
    let { value } = this.state.internalState;
    return value;
  };
  setDisabled = (newDisabled) => {
    let obj = this.state.internalState;
    obj.disabled = newDisabled;
    if (newDisabled) {
      obj.valid = true;
    } else {
      obj.valid = false;
      if (obj.form) obj.form.cleanCachedField(obj.uniqueID);
    }
    this.setInternalState(obj, () => {
      this.doThrowSetValue();
    });
  };

  isDisabled = () => {
    let { disabled } = this.state.internalState;
    if (disabled) {
      return disabled;
    } else {
      return false;
    }
  };

  currentRefreshObject = () => {
    let { uniqueID, value, valid } = this.state.internalState;
    let refreshObject = {
      uniqueID: uniqueID,
      currentValue: value,
      valid: valid,
    };
    return refreshObject;
  };

  doThrowSetValue = () => {
    let { setValue } = this.state.internalState;
    let refreshObject = this.currentRefreshObject();
    setValue(refreshObject);
  };

  handleOnChange = (currentValue) => {
    this.internalValidate(currentValue);
  };

  internalValidate = (targetValue) => {
    let currentValid = true;
    let { value, valid, validation, additionalValidation } =
      this.state.internalState;
    let { mandatory } = validation;

    if (this.shouldValidate()) {
      if (
        mandatory === true &&
        (!targetValue || "" === targetValue || targetValue.length === 0)
      ) {
        currentValid = false;
      }
    }
    value = targetValue;
    currentValid = currentValid && additionalValidation(value);
    valid = currentValid;
    this.setInternalState(
      {
        valid,
        value,
      },
      () => {
        this.doThrowSetValue();
      }
    );
    return { valid, value };
  };

  isValid = () => {
    let { value } = this.state.internalState;
    let { valid } = this.internalValidate(value);
    return valid;
  };

  render() {
    const {
      value,
      format,
      clearable,
      closeOnScroll,
      closeOnSelect,
      calendarClassName,
      pickerClassName,
      showTime,
      valid,
      visible,
      timeInputLabel,
      timeInputFormat,
      disabled,
      placeholder,
      feedback = {},
    } = this.state.internalState;

    let {
      enable: feedbackEnable = false,
      component: FeedbackComponent = (props) => {
        return <></>;
      },
    } = feedback;

    return (
      <>
        {visible && (
          <div className="date-field-container">
            <DatePicker
              selected={value}
              onChange={this.handleOnChange}
              className={pickerClassName}
              isClearable={clearable}
              closeOnScroll={closeOnScroll}
              calendarClassName={calendarClassName}
              showTimeInput={showTime}
              timeInputLabel={timeInputLabel}
              timeFormat={timeInputFormat}
              locale={"it-IT"}
              disabled={disabled}
              placeholderText={placeholder}
              showYearDropdown={true}
              shouldCloseOnSelect={closeOnSelect}
              dateFormat={format}
            />
            {feedbackEnable && (
              <Form.Control.Feedback
                type={valid ? "valid" : "invalid"}
                className={valid ? "" : "d-block"}
              >
                <FeedbackComponent />
              </Form.Control.Feedback>
            )}
          </div>
        )}
      </>
    );
  }
}

export default DateField;
