import React from "react";
import { Form } from "react-bootstrap";
import { v4 as uuidv4 } from "uuid";

class ToggleSwitch extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      internalState: {},
    };
  }

  componentDidMount() {
    const { configuration = {} } = this.props;
    const {
      uniqueID = uuidv4(),
      activeDesc = "",
      deactiveDesc = "",
      setValue = () => {},
      valid = true,
      disabled = false,
      visible = true,
      form = undefined,
      checked = false,
      readonly = false,
      additionalClass = "",
    } = configuration;
    let useObject = {
      uniqueID,
      activeDesc,
      deactiveDesc,
      setValue,
      valid,
      disabled,
      visible,
      form,
      checked,
      readonly,
      additionalClass,
    };
    if (form) form.addField(this, useObject);
    this.setInternalState(useObject);
  }

  setInternalState = (obj, callBack = () => {}) => {
    this.setState((prevState) => {
      return {
        internalState: {
          ...prevState.internalState,
          ...obj,
        },
      };
    }, callBack);
  };

  setReadonly = (b) => {
    let obj = this.state.internalState;
    obj.readonly = b;
    this.setInternalState(obj);
  };

  isReadonly = () => {
    const { readonly = false } = this.state.internalState;
    return readonly;
  };

  setVisible = (b) => {
    let obj = this.state.internalState;
    obj.visible = b;
    this.setInternalState(obj);
  };

  isVisible = () => {
    const { visible = true } = this.state.internalState;
    return visible;
  };

  getValue = () => {
    const { checked } = this.state.internalState;
    return checked;
  };

  setValue = (value) => {
    let obj = this.state.internalState;
    obj.checked = value;
    this.setInternalState(obj);
  };

  isValid = () => {
    const { valid = true } = this.state.internalState;
    return valid;
  };

  onChange = (event) => {
    const { checked } = event.currentTarget;
    let obj = this.state.internalState;
    const { setValue: parentCallBack, uniqueID } = obj;
    if (parentCallBack) {
      parentCallBack({
        uniqueID: uniqueID,
        currentValue: checked,
      });
    }
    obj.checked = checked;
    this.setInternalState(obj);
  };

  render() {
    const {
      visible,
      checked,
      activeDesc,
      deactiveDesc,
      disabled,
      uniqueID,
      additionalClass = "",
    } = this.state.internalState;
    return (
      <Form className={`my-toggle-switch ${additionalClass}`}>
        {visible && (
          <Form.Check
            disabled={disabled}
            type="switch"
            id={uniqueID}
            checked={checked}
            onChange={this.onChange}
            label={checked ? activeDesc : deactiveDesc}
          ></Form.Check>
        )}
      </Form>
    );
  }
}

export default ToggleSwitch;
