import { useRef, useState } from "react";

const useAsyncReference = (value, isProp = false) => {
  const ref = useRef(value);
  const [, forceRender] = useState(false);

  const updateState = (newValue) => {
    if (!Object.is(ref.current, newValue)) {
      ref.current = newValue;
      forceRender((s) => !s);
    }
  };

  if (isProp) {
    ref.current = value;
    return [ref];
  }

  return [ref, updateState];
};

export default useAsyncReference;
