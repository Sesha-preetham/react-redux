import React from "react";

const IconNotificationSolid = (props) => {
  const { configuration = {} } = props;
  const {
    active = false,
    activeClass = "",
    inActiveClass = "",
    className = "",
    onClick = () => {},
  } = configuration;

  let handleOnClickIcon = () => {
    onClick(!active);
  };

  return (
    <svg
      className={`${className} ${active ? activeClass : inActiveClass}`}
      onClick={() => {
        handleOnClickIcon();
      }}
      width="24px"
      height="24px"
      viewBox="0 0 24 24"
      version="1.1"
      xmlns="http://www.w3.org/2000/svg"
    >
      <g fill="none" fillRule="evenodd">
        <g>
          <path
            fill="#0033CC"
            className="icon-notification-path"
            d="M20.52 15.21l-1.8-1.81V8.94c.05-3.425-2.435-6.361-5.82-6.88-3.69-.486-7.076 2.112-7.562 5.802-.038.288-.057.578-.058.868v4.67l-1.8 1.81c-.635.646-.627 1.684.02 2.32.304.299.713.468 1.14.47H8v.34c.097 2.114 1.886 3.75 4 3.66 2.114.09 3.903-1.546 4-3.66V18h3.36c.906-.005 1.636-.743 1.63-1.65-.002-.426-.17-.836-.47-1.14zM14 18.34c-.115 1-.997 1.73-2 1.66-1.003.07-1.885-.66-2-1.66V18h4v.34z"
          />
        </g>
      </g>
    </svg>
  );
};

export default IconNotificationSolid;
