import React from "react";

const IconRightArrowBlue = (props) => {
  const { configuration = {} } = props;
  const {
    active = false,
    activeClass = "",
    inActiveClass = "",
    className = "",
    onClick = () => {},
  } = configuration;

  let handleOnClickIcon = () => {
    onClick(!active);
  };

  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      xmlnsXlink="http://www.w3.org/1999/xlink"
      width="24px"
      height="24px"
      viewBox="0 0 24 24"
      version="1.1"
      className={`${className} ${active ? activeClass : inActiveClass}`}
      onClick={() => {
        handleOnClickIcon();
      }}
    >
      <g
        id="Symbols"
        stroke="none"
        strokeWidth="1"
        fill="none"
        fillRule="evenodd"
      >
        <g id="Icon-/-arrow-/-right-/-blu">
          <polygon
            id="24pt-Bounding-Box"
            opacity="0"
            fillRule="nonzero"
            points="0 0 24 0 24 24 0 24"
          />
          <path
            d="M10.0057983,17.0158132 L10.0057982,17.0158132 C9.73999523,17.0173333 9.48451723,16.9129835 9.29579823,16.7257965 L9.29579825,16.7257965 C8.90367625,16.3368765 8.90108025,15.7037165 9.28999988,15.3115965 C9.29192472,15.3096558 9.29385751,15.307723 9.2957982,15.3057982 L12.6057982,12.0157982 L9.4257982,8.70579821 L9.42579822,8.70579823 C9.03807422,8.31576123 9.03807422,7.68583823 9.42579819,7.29579823 L9.42579816,7.29579826 C9.81471816,6.90367626 10.4478782,6.90108026 10.8399982,7.28999987 C10.8419388,7.29192471 10.8438716,7.2938575 10.8457965,7.29579819 L14.7057965,11.2957982 L14.7057965,11.2957982 C15.0869395,11.6846422 15.0869395,12.3069582 14.7057965,12.6957982 L10.7057965,16.6957982 L10.7057965,16.6957982 C10.5245015,16.8915842 10.2724785,17.0067952 10.0057965,17.0158132 L10.0057983,17.0158132 Z"
            id="Fill"
            fill="#0033CC"
          />
        </g>
      </g>
    </svg>
  );
};

export default IconRightArrowBlue;
