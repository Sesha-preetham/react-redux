import React from "react";

const IconOptions = (props) => {
  const { configuration = {} } = props;
  const {
    active = false,
    activeClass = "",
    inActiveClass = "",
    className = "",
    onClick = () => {},
  } = configuration;

  let handleOnClickIcon = () => {
    onClick(!active);
  };

  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      className={`${className} ${active ? activeClass : inActiveClass}`}
      onClick={() => {
        handleOnClickIcon();
      }}
    >
      <g fill="none" fillRule="evenodd">
        <g>
          <g>
            <g>
              <path
                fill="#03C"
                d="M13.414 10.586c.781.78.781 2.047 0 2.828-.78.781-2.047.781-2.828 0-.781-.78-.781-2.047 0-2.828.78-.781 2.047-.781 2.828 0zm7 0c.781.78.781 2.047 0 2.828-.78.781-2.047.781-2.828 0-.781-.78-.781-2.047 0-2.828.78-.781 2.047-.781 2.828 0zm-14 0c.781.78.781 2.047 0 2.828-.78.781-2.047.781-2.828 0-.781-.78-.781-2.047 0-2.828.78-.781 2.047-.781 2.828 0z"
                transform="translate(-1836 -332) translate(1813 244) translate(23 88) rotate(-90 12 12)"
              />
            </g>
          </g>
        </g>
      </g>
    </svg>
  );
};

export default IconOptions;
