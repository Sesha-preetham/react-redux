import React from "react";

const IconBlueClose = (props) => {
  const { configuration = {} } = props;
  const {
    active = false,
    activeClass = "",
    inActiveClass = "",
    className = "",
    onClick = () => {},
  } = configuration;

  let handleOnClickIcon = () => {
    onClick(!active);
  };

  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      className={`icon-blue-close hand-cursor ${className} ${
        active ? activeClass : inActiveClass
      }`}
      onClick={() => {
        handleOnClickIcon();
      }}
    >
      <g fill="none" fillRule="evenodd">
        <g>
          <g>
            <path
              fill="#03C"
              d="M13.416 12.004l4.3-4.29c.392-.392.392-1.028 0-1.42-.392-.392-1.028-.392-1.42 0l-4.29 4.3-4.29-4.3c-.392-.392-1.028-.392-1.42 0-.392.392-.392 1.028 0 1.42l4.3 4.29-4.3 4.29c-.392.389-.395 1.022-.006 1.414l.006.006c.389.392 1.022.395 1.414.006l.006-.006 4.29-4.3 4.29 4.3c.389.392 1.022.395 1.414.006l.006-.006c.392-.389.395-1.022.006-1.414l-.006-.006-4.3-4.29z"
              transform="translate(-1864 -91) translate(1864 91)"
            />
          </g>
        </g>
      </g>
    </svg>
  );
};

export default IconBlueClose;
