import React from "react";
import { v4 as uuidv4 } from "uuid";

const IconPhone = (props) => {
  const { configuration = {} } = props;
  const {
    uniqueID = uuidv4(),
    active = false,
    disable = false,
    onClick = () => {}
  } = configuration;

  let handleOnClickIcon = () => {
    if (!disable) onClick(!active);
  };

  return (
    <>
      <svg
        id={uniqueID}
        className={!disable ? "hand-cursor" : "hand-cursor-not-allowed"}
        width="42"
        height="35"
        xmlns="http://www.w3.org/2000/svg"
        xmlnsXlink="http://www.w3.org/1999/xlink"
        overflow="hidden"
        onClick={() => {
          handleOnClickIcon();
        }}
      >
        <defs>
          <clipPath id="clip0">
            <path
              d="M43 304 85 304 85 339 43 339Z"
              fillRule="evenodd"
              clipRule="evenodd"
            />
          </clipPath>
          <image
            width="42"
            height="35"
            xlinkHref="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACoAAAAjCAMAAADVEmihAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAC6UExURQAAAAAA/wAAgAAA/wCA/wBVqgBAvwAzzAArqgAr1QAktgBJ2wBAvxw5xhVAvxI3thEzuxAwvw88ww02vA02yQw9wgw6xQozwhM5vRM5xhI3vxI3yBI1wQ81ww86xQ02ww00xA05xhE0vxE5xhE3whA1xRA5wQ43xBE3xBE2wBE2xBA5whA4ww83xQ02wxA4xBA3xRA2wg84xA42ww42xA44wQ43xRA4whA3ww82xA84wg84xA84wg83wwwIAtYAAAA+dFJOUwABAgICAwQFBgYHBwgJDA4PEBETExUWGRsbHBwdIiMmJygsLS4wMTg8PT0/QEZMTk9QVllaW1xgYWNkZGVm3y+pKAAAAAlwSFlzAAAOwwAADsMBx2+oZAAAAVxJREFUOE/tlNl2gjAURZkpRMJQBUGLZRCKCJRBQbT//1vVGhWQWn3wrfs1e90VyDkXezZ4L+iwAU6QFN0DRRJtGydohuV4AAYtAOA5lqGbMk4ynABFSb5CEqHAMeTFJRgeKiNNn15haKoCAUMgEcNpDr6O3yzbcTs4tmXqQ8jRp7EEIyjj2dz/CJcdwsD33nVFOI8lWTh6mwdRnHymbZI4WnimClnyaOIUJ2qWH6VZXqxaFHmWRr6liRx1vAFO8ZJuB3G2LqsO5TqLA1uXwEmlgTxxwiQvN/W2Rb0p8yR0JjJA34XTA3nqLtOiqndfLXZ1VaRLdyoPOuqq2iLlzLZa/au96l3/9fZruY3X+isDxiUD9yfrkFfV9Bb7vKKYnjnl9QXl9acF+szzg/4WGI0WHLo11M1fumU0u7UfC6CiagaqaYNuYx/ZAw9slz23dlbbPIBWXwd0+CQw7BumZYj9bNApswAAAABJRU5ErkJggg=="
            preserveAspectRatio="none"
            id="img1"
          ></image>
          <clipPath id="clip2">
            <path
              d="M0 0 42 0 42 35 0 35Z"
              fillRule="evenodd"
              clipRule="evenodd"
            />
          </clipPath>
          <clipPath id="clip3">
            <path
              d="M74.4617 321.212 63.7395 331.87 53.0816 321.147 63.8038 310.489Z"
              fillRule="evenodd"
              clipRule="evenodd"
            />
          </clipPath>
          <clipPath id="clip4">
            <path
              d="M74.4617 321.212 63.7395 331.87 53.0816 321.147 63.8038 310.489Z"
              fillRule="evenodd"
              clipRule="evenodd"
            />
          </clipPath>
          <clipPath id="clip5">
            <path
              d="M74.4617 321.212 63.7395 331.87 53.0816 321.147 63.8038 310.489Z"
              fillRule="evenodd"
              clipRule="evenodd"
            />
          </clipPath>
        </defs>
        <g clipPath="url(#clip0)" transform="translate(-43 -304)">
          <g clipPath="url(#clip2)" transform="translate(43 304)">
            <use width="100%" height="100%" xlinkHref="#img1"></use>
          </g>
          <path
            d="M51 313.51C51 312.676 51.6761 312 52.5101 312L75.4899 312C76.3239 312 77 312.676 77 313.51L77 329.49C77 330.324 76.3239 331 75.4899 331L52.5101 331C51.6761 331 51 330.324 51 329.49Z"
            fill={!disable ? "#0033cc" : "#4d79ff"}
            fillRule="evenodd"
          />
          <g clipPath="url(#clip3)">
            <g clipPath="url(#clip4)">
              <g clipPath="url(#clip5)">
                <path
                  d="M66.8417 322.302C66.8412 322.48 66.9074 322.659 67.0407 322.793 67.1739 322.927 67.3519 322.994 67.53 322.995L70.5923 322.993C70.7705 322.993 70.9488 322.927 71.0717 322.805 71.1946 322.683 71.2731 322.494 71.2736 322.316L71.2746 321.982 66.8427 321.968 66.8417 322.302Z"
                  fill="#FFFFFF"
                />
                <path
                  d="M60.6777 320.591C60.678 320.502 60.7228 320.413 60.7787 320.358 60.8345 320.302 60.9237 320.258 61.0128 320.258L66.5249 320.264C66.614 320.264 66.7029 320.309 66.7584 320.364 66.814 320.42 66.8582 320.51 66.858 320.599L66.8448 321.278 71.2767 321.291C71.2776 321.002 71.2784 320.734 71.2789 320.556 71.2914 320.122 71.1478 319.71 70.8593 319.397 70.3932 318.861 69.7929 318.503 69.1591 318.2 68.5696 317.965 67.9465 317.807 67.3233 317.694 65.0419 317.23 62.7035 317.179 60.4196 317.561 60.0297 317.616 59.6508 317.704 59.2719 317.814 58.4359 318.09 57.6441 318.477 56.963 319.066 56.5053 319.454 56.2474 320.043 56.2679 320.645L56.2661 321.246 60.6868 321.27 60.6777 320.591Z"
                  fill="#FFFFFF"
                />
                <path
                  d="M56.9402 322.952 60.0136 322.961C60.1918 322.962 60.3701 322.895 60.5042 322.762 60.6382 322.629 60.7055 322.451 60.7061 322.273L60.696 321.927 56.2641 321.914 56.263 322.248C56.2625 322.426 56.3288 322.605 56.462 322.739 56.5952 322.873 56.762 322.951 56.9402 322.952Z"
                  fill="#FFFFFF"
                />
              </g>
            </g>
          </g>
          <path
            d="M60 326.6 62.4282 326.6 62.4282 324 65.5718 324 65.5718 326.6 68 326.6 64 329Z"
            fill="#FFFFFF"
            fillRule="evenodd"
          />
        </g>
      </svg>
    </>
  );
};

export default IconPhone;
