import React from "react";

const HorizontalLine = (props) => {
  return (
    <div className="row no-gutters">
      <div className="col-12 Line" />
    </div>
  );
};

export default HorizontalLine;
