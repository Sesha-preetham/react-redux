import React from "react";

const IconAlertSolid = (props = {}) => {
  const { configuration = {} } = props;
  const {
    active = false,
    activeClass = "",
    inActiveClass = "",
    className = "",
    onClick = () => {},
  } = configuration;

  let handleOnClickIcon = () => {
    onClick(!active);
  };

  return (
    <svg
      className={`${className} ${active ? activeClass : inActiveClass} hand-cursor`}
      onClick={() => {
        handleOnClickIcon();
      }}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
    >
      <g fill="none" fill-rule="evenodd">
        <g>
          <path
            fill="#03C"
            className="icon-alert-solid-path"
            d="M22.56 16.3L14.89 3.58c-1.02-1.596-3.141-2.063-4.737-1.043-.42.268-.775.624-1.043 1.043L1.44 16.3c-.551.92-.57 2.063-.05 3 .602 1.055 1.725 1.705 2.94 1.7h15.34c1.206.013 2.328-.62 2.94-1.66.536-.947.517-2.11-.05-3.04zM12 17c-.552 0-1-.448-1-1s.448-1 1-1 1 .448 1 1-.448 1-1 1zm1-4c0 .552-.448 1-1 1s-1-.448-1-1V9c0-.552.448-1 1-1s1 .448 1 1v4z"
          />
        </g>
      </g>
    </svg>
  );
};

export default IconAlertSolid;
