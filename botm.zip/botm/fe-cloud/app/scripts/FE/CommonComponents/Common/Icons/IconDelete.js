import React from "react";

const IconDelete = (props) => {
  const { configuration = {} } = props;
  const {
    active = false,
    activeClass = "",
    inActiveClass = "",
    className = "",
    onClick = () => {},
  } = configuration;

  let handleOnClickIcon = () => {
    onClick(!active);
  };

  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="17"
      height="17"
      viewBox="0 0 17 17"
      className={`${className} ${active ? activeClass : inActiveClass}`}
      onClick={() => {
        handleOnClickIcon();
      }}
    >
      <g fill="none" fillRule="evenodd">
        <g>
          <g>
            <path
              fill="#03C"
              d="M9.562 1.417c.945-.032 1.737.706 1.771 1.65V4.25h3.542c.391 0 .708.317.708.708 0 .392-.317.709-.708.709h-.708v7.791c0 1.174-.952 2.125-2.125 2.125H4.958c-1.173 0-2.125-.951-2.125-2.125V5.667h-.708c-.391 0-.708-.317-.708-.709 0-.39.317-.708.708-.708h3.542V3.067c.034-.944.826-1.682 1.77-1.65zm3.188 4.25h-8.5v7.791l.006.096c.047.346.344.613.702.613h7.084c.39 0 .708-.317.708-.709V5.667zM6.375 7.792c.391 0 .708.317.708.708v2.833c0 .392-.317.709-.708.709l-.096-.007c-.346-.047-.612-.343-.612-.702V8.5c0-.391.317-.708.708-.708zm4.25 0c.391 0 .708.317.708.708v2.833c0 .392-.317.709-.708.709l-.096-.007c-.346-.047-.612-.343-.612-.702V8.5c0-.391.317-.708.708-.708zM9.562 2.833H7.438c-.206 0-.355.12-.355.234V4.25h2.834V3.067c0-.113-.15-.234-.354-.234z"
              transform="translate(-1071 -597) translate(1071 597)"
            />
          </g>
        </g>
      </g>
    </svg>
  );
};

export default IconDelete;
