import React from "react";

const IconLeftArrowGrey = (props) => {
  const { configuration = {} } = props;
  const {
    active = false,
    activeClass = "",
    inActiveClass = "",
    className = "",
    onClick = () => {},
  } = configuration;

  let handleOnClickIcon = () => {
    onClick(!active);
  };

  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      className={`${className} ${active ? activeClass : inActiveClass}`}
      onClick={() => {
        handleOnClickIcon();
      }}
    >
      <g fill="none" fillRule="evenodd">
        <g>
          <path
            fill="#B4BCC1"
            d="M13.36 17c-.272-.001-.532-.113-.72-.31l-3.86-4c-.381-.389-.381-1.011 0-1.4l4-4c.392-.392 1.028-.392 1.42 0 .392.392.392 1.028 0 1.42L10.9 12l3.18 3.3c.388.39.388 1.02 0 1.41-.191.19-.45.294-.72.29z"
          />
        </g>
      </g>
    </svg>
  );
};

export default IconLeftArrowGrey;
