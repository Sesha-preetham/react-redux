import React from "react";

const IconMoreInfo = (props) => {
  const { configuration = {} } = props;
  const {
    active = false,
    activeClass = "",
    inActiveClass = "",
    className = "",
    onClick = () => {},
  } = configuration;

  let handleOnClickIcon = () => {
    onClick(!active);
  };

  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="17"
      height="17"
      viewBox="0 0 17 17"
      className={`${className} ${active ? activeClass : inActiveClass}`}
      onClick={() => {
        handleOnClickIcon();
      }}
    >
      <g fill="none" fillRule="evenodd">
        <g>
          <g>
            <path
              fill="#1B1B1B"
              d="M9.502 7.498c.553.554.553 1.45 0 2.004-.554.553-1.45.553-2.004 0-.553-.553-.553-1.45 0-2.004.553-.553 1.45-.553 2.004 0zm4.958 0c.553.554.553 1.45 0 2.004-.553.553-1.45.553-2.003 0-.554-.553-.554-1.45 0-2.004.553-.553 1.45-.553 2.003 0zm-9.917 0c.554.554.554 1.45 0 2.004-.553.553-1.45.553-2.003 0-.553-.553-.553-1.45 0-2.004.553-.553 1.45-.553 2.003 0z"
              transform="translate(-147 -3) translate(147 3)"
            />
          </g>
        </g>
      </g>
    </svg>
  );
};

export default IconMoreInfo;
