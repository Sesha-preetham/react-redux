import React from "react";

const IconChevron = (props) => {
  const { configuration = {} } = props;
  const {
    open = false,
    active = false,
    activeClass = "",
    inActiveClass = "",
    className = "",
    onClick = () => {},
  } = configuration;

  let handleOnClickIcon = () => {
    onClick(!active);
  };

  return open ? (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="19"
      height="19"
      viewBox="0 0 19 19"
      className={`bi bi-chevron-open hand-cursor ${className} ${
        active ? activeClass : inActiveClass
      }`}
      onClick={() => {
        handleOnClickIcon();
      }}
    >
      <g fill="none" fill-rule="evenodd">
        <g>
          <path
            fill="#03C"
            d="M8.993 12.485l-4.75-3.959c-.336-.28-.382-.78-.103-1.116.28-.337.78-.383 1.117-.103L9.5 10.854l4.243-3.42c.34-.276.838-.224 1.114.115.293.33.264.83-.062 1.121l-.046.038-4.75 3.824c-.147.1-.322.147-.499.135-.185 0-.364-.064-.507-.182z"
            transform="rotate(-180 9.508 9.896)"
          />
        </g>
      </g>
    </svg>
  ) : (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="19"
      height="19"
      viewBox="0 0 19 19"
      className={`bi bi-chevron-close hand-cursor ${className} ${
        active ? activeClass : inActiveClass
      }`}
      onClick={() => {
        handleOnClickIcon();
      }}
    >
      <g fill="none" fill-rule="evenodd">
        <g>
          <path
            fill="#03C"
            d="M8.993 12.485l-4.75-3.959c-.336-.28-.382-.78-.103-1.116.28-.337.78-.383 1.117-.103L9.5 10.854l4.243-3.42c.34-.276.838-.224 1.114.115.293.33.264.83-.062 1.121l-.046.038-4.75 3.824c-.147.1-.322.147-.499.135-.185 0-.364-.064-.507-.182z"
          />
        </g>
      </g>
    </svg>
  );
};

export default IconChevron;
