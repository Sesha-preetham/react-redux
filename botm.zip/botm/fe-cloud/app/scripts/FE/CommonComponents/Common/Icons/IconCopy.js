import React from "react";

const IconCopy = (props) => {
  const { configuration = {} } = props;
  const {
    active = false,
    activeClass = "",
    inActiveClass = "",
    className = "",
    onClick = () => {},
  } = configuration;

  let handleOnClickIcon = () => {
    onClick(!active);
  };

  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="19"
      height="17"
      viewBox="0 0 19 17"
      className={`${className} hand-cursor ${active ? activeClass : inActiveClass}`}
      onClick={() => {
        handleOnClickIcon();
      }}
    >
      <g fill="none" fillRule="evenodd">
        <g>
          <g>
            <path
              fill="#03C"
              d="M9.761 2.125c1.166.004 2.11.848 2.114 1.891l-.001 2.359h2.376c1.312 0 2.375.951 2.375 2.125v4.25c0 1.174-1.063 2.125-2.375 2.125H9.5c-1.257 0-2.286-.874-2.37-1.98l-.005-.145-.001-2.126-2.635.001c-1.166-.004-2.11-.848-2.114-1.891V4.016c.004-1.043.948-1.887 2.114-1.891H9.76zm4.489 5.667H9.5c-.4 0-.732.266-.784.612l-.008.096v4.25c0 .391.355.708.792.708h4.75c.437 0 .792-.317.792-.708V8.5c0-.391-.355-.708-.792-.708zm-4.489-4.25H4.49c-.293 0-.53.212-.53.474v4.718c0 .262.237.474.53.474h2.635l.001-.708c0-1.174 1.063-2.125 2.375-2.125h.791V4.016c0-.262-.237-.474-.53-.474z"
              transform="translate(-1035 -597) translate(1035 597)"
            />
          </g>
        </g>
      </g>
    </svg>
  );
};

export default IconCopy;
