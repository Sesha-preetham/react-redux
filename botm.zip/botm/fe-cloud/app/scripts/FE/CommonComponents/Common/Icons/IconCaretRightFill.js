import React from "react";

const IconCaretRightFill = (props) => {
  const { configuration = {} } = props;
  const {
    active = false,
    activeClass = "",
    inActiveClass = "",
    className = "",
    onClick = () => {},
  } = configuration;

  let handleOnClickIcon = () => {
    onClick(!active);
  };

  return (
    <svg 
        width="16" 
        height="16" 
        viewBox="0 0 24 24" 
        version="1.1" 
        xmlns="http://www.w3.org/2000/svg" 
        className={`bi bi-caret-right-fill ${className} ${
            active ? activeClass : inActiveClass
        }`}
        onClick={() => {
            handleOnClickIcon();
        }}
    >
        <title>Icon / accordion / arrow right</title>
        <g id="Symbols" stroke="none" strokeWidth="1" fill="none" fillRule="evenodd">
            <g id="Icon-/-accordion-/-arrow-right">
                <polygon id="24pt-Bounding-Box" opacity="0" fillRule="nonzero" transform="translate(12.000000, 12.000000) rotate(180.000000) translate(-12.000000, -12.000000) " points="-1.77635684e-15 1.77635684e-15 24 1.77635684e-15 24 24 -1.77635684e-15 24"></polygon>
                <path d="M10.46,18.0000076 L10.4600001,18.0000076 C10.1459681,17.9981519 9.83586806,17.929998 9.55000106,17.8 L9.55000105,17.8 C8.91856305,17.521671 8.50803105,16.900012 8.50000098,16.21 L8.50000098,7.78999999 L8.50000098,7.79000614 C8.50803109,7.09999414 8.91855798,6.47833614 9.54999098,6.20000614 L9.54999103,6.20000612 C10.275805,5.85717212 11.133561,5.95808512 11.759991,6.46000612 L16.859991,10.6700061 L16.859991,10.6700061 C17.59453,11.2547761 17.715941,12.3242861 17.131171,13.0588261 C17.0512957,13.1591591 16.960324,13.2501311 16.859991,13.3300061 L11.759991,17.5400061 L11.759991,17.5400061 C11.392371,17.8381321 10.933302,18.0005721 10.459991,18.0000076 L10.46,18.0000076 Z" id="Fill" fill="#0033CC"></path>
            </g>
        </g>
    </svg>
  );
};

export default IconCaretRightFill;
