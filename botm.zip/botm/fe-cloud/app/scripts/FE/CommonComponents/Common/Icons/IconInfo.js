import React from "react";

const IconInfo = (props) => {
  const { configuration = {} } = props;
  const {
    className = "",
    onClick = () => {},
  } = configuration;

  let handleOnClickIcon = () => {
    onClick();
  };

  return (
    <svg xmlns="http://www.w3.org/2000/svg" 
      width="17" 
      height="17" 
      viewBox="0 0 17 17"
      role="button"
      className={`icon-info ${className}`}
      onClick={() => {
        handleOnClickIcon();
      }}
    >
        <g fill="none" fillRule="evenodd">
            <g>
                <g>
                    <g>
                        <g>
                            <path fill="#03C" d="M8.5 1.417l.239.004c3.801.125 6.844 3.247 6.844 7.079l-.004.239c-.125 3.801-3.247 6.844-7.079 6.844-3.912 0-7.083-3.171-7.083-7.083 0-3.912 3.171-7.083 7.083-7.083zm0 1.416c-3.13 0-5.667 2.537-5.667 5.667S5.37 14.167 8.5 14.167l.217-.004c3.03-.115 5.45-2.606 5.45-5.663l-.004-.217c-.115-3.03-2.606-5.45-5.663-5.45zm0 4.25l.096.007c.346.047.612.343.612.702v3.541c0 .392-.317.709-.708.709-.391 0-.708-.317-.708-.709V7.792l.006-.096c.047-.346.343-.613.702-.613zM9 5.166c.277.276.277.725 0 1.002-.276.276-.724.276-1 0-.277-.277-.277-.726 0-1.002.276-.277.724-.277 1 0z" transform="translate(-1439 -248) translate(1297 77) translate(16 104) translate(126 67)"/>
                        </g>
                    </g>
                </g>
            </g>
        </g>
    </svg>
  );
};

export default IconInfo;
