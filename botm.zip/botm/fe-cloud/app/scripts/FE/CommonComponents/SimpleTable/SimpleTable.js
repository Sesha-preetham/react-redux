import React, { useEffect, useMemo, useState } from "react";
import {
  usePagination,
  useSortBy,
  useTable,
  useGlobalFilter,
} from "react-table";
import { v4 as uuidv4 } from "uuid";
import IconSortDown from "../Common/Icons/IconSortDown";
import IconSortUp from "../Common/Icons/IconSortUp";
import SimplePagination from "./SimplePagination";
import SimpleGlobalFilter from "./Common/SimpleGlobalFilter";

const SimpleTable = (props) => {
  const [internalState, setInternalState] = useState({});

  const [tableData, setTableData] = useState([]);
  const [rowSelectedVal, setRowSelectedVal] = useState();

  const {
    lastColumnFixed = false,
    showRowBorder = false,
    rowSelected = undefined,
    onTableRowClick =()=>{},
    scrollX = false,
    scrollY = false,
    pagination = false,
    showTotalCount = false,
    globalSearch = {
      show: false,
      width: "50%",
      placeholder: "Search...",
    },
    autoResetPage = true,
    autoResetFilters = true,
  } = internalState;

  const { configuration = {} } = props;
  const { paginationOptions = {}, metaData = [] } = configuration;

  useEffect(() => {
    const { configuration } = props;
    const {
      uniqueID = uuidv4(),
      metaData = [],
      data = [],
      sort = [],
      pagination = false,
      showTotalCount = false,
      events = {},
      lastColumnFixed = false,
      showRowBorder = false,
      rowSelected = undefined,
      onTableRowClick =()=>{},
      scrollX = false,
      scrollY = false,
      autoResetPage,
      autoResetFilters,
      globalSearch = {
        show: false,
        width: "50%",
        placeholder: "Search...",
      },
    } = configuration;
    setInternalState({
      uniqueID,
      metaData,
      data,
      sort,
      pagination,
      showTotalCount,
      showRowBorder,
      rowSelected,
      onTableRowClick,
      events,
      lastColumnFixed,
      scrollX,
      scrollY,
      globalSearch,
      autoResetPage,
      autoResetFilters,
    });
    setTableData(data);
  }, []);

  //update columns if parent change the configuration
  useEffect(() => {
    setInternalState((prevState) => {
      return {
        ...prevState,
        metaData,
      };
    });
  }, [metaData]);

  //refresh table data at each component update
  useEffect(() => {
    const { configuration } = props;
    const { data ,showRowBorder, rowSelected  } = configuration;
    setTableData(data);
    if(showRowBorder)
    setRowSelectedVal(rowSelected);
  });

  const currentColumns = useMemo(() => {
    const { metaData = [] } = internalState;
    return [...metaData];
  });

  const currentRowSelected = useMemo(() => {
    if(showRowBorder){
    return rowSelectedVal;
    }
  });

  /*const currentData = useMemo(() => {
    const { data = [] } = internalState;
    return [...data];
  });*/
  const currentData = useMemo(() => {
    return [...tableData];
  });

  const currentSortBy = useMemo(() => {
    const { sort = [] } = internalState;
    return [...sort];
  });

  const currentEvents = useMemo(() => {
    const { events = {} } = internalState;
    return { ...events };
  });

  return (
    <ReactTable
      lastColumnFixed={lastColumnFixed}
      rowSelected = {currentRowSelected}
      showRowBorder = {showRowBorder}
      onTableRowClick ={onTableRowClick}
      columns={currentColumns}
      data={currentData}
      sort={currentSortBy}
      pagination={pagination}
      showTotalCount = {showTotalCount}
      paginationOptions={paginationOptions}
      autoResetPage={autoResetPage}
      autoResetFilters={autoResetFilters}
      events={currentEvents}
      scrollX={scrollX}
      scrollY={scrollY}
      globalSearch={globalSearch}
    />
  );
};

export default SimpleTable;

const ReactTable = (props) => {


  const {
    columns = [],
    data = [],
    sort = [],
    pagination = false,
    showTotalCount = false,
    paginationOptions = {},
    events = {},
    lastColumnFixed = false,
    showRowBorder = false,
    rowSelected = undefined,
    onTableRowClick =()=>{},
    scrollX = false,
    scrollY = false,
    globalSearch = {},
    autoResetPage,
    autoResetFilters
  } = props;

  let columnsLength = columns.length;

  let tableInstance = useTable(
    {
      showTotalCount,
      columns,
      data,
      initialState: { sortBy: [...sort], ...paginationOptions },
      autoResetPage,
      autoResetFilters,
    },
    useGlobalFilter,
    useSortBy,
    usePagination
  );

  let onRowClick = (rowData) => {
    const { onRowClick } = events;
    if (onRowClick) {
      //callback call to parent
      onRowClick({ ...rowData });
    }
    if(showRowBorder){
      console.log(rowData.index);
      onTableRowClick(rowData.index);
      }
  };

  const {
    getTableProps,
    getTableBodyProps,
    headerGroups,
    prepareRow,
    state,
    preGlobalFilteredRows,
    setGlobalFilter,
  } = tableInstance;

  let tableRows = pagination ? tableInstance.page : tableInstance.rows;

  return (
    tableInstance && (
      <div className="d-flex flex-column">
        <SimpleGlobalFilter
          globalSearch={globalSearch}
          preGlobalFilteredRows={preGlobalFilteredRows}
          globalFilter={state.globalFilter}
          setGlobalFilter={setGlobalFilter}
        />
        <div
          className={`flex-fill ${scrollX ? "overflow-x" : ""} ${
            scrollY ? "overflow-y" : ""
          }`}
        >
          <table {...getTableProps()} className="tabella">
            <thead className="tabella-head">
              {headerGroups.map((headerGroup) => (
                <tr
                  {...headerGroup.getHeaderGroupProps()}
                  className="tabella-head-row"
                >
                  {headerGroup.headers.map((column, index) => (
                    <th
                      {...column.getHeaderProps(column.getSortByToggleProps())}
                      className={`tabella-head-row-cell ${
                        lastColumnFixed && index === columnsLength - 1
                          ? "tabella-last-sticky-cell tabella-last-cell-position odd"
                          : ""
                      }`}
                    >
                      <div className="d-flex">
                        {column.render("Header")}
                        {column.accessor && (
                          <div className="tabella-head-sort ml-2">
                            {column.isSorted ? (
                              column.isSortedDesc ? (
                                <IconSortUp />
                              ) : (
                                <IconSortDown />
                              )
                            ) : (
                              ""
                            )}
                          </div>
                        )}
                      </div>
                    </th>
                  ))}
                </tr>
              ))}
            </thead>
            <tbody {...getTableBodyProps()} className="tabella-body">
              {tableRows.map((row, rowIndex) => {
                prepareRow(row);
                return (
                  <tr
                    {...row.getRowProps()}
                    className={`tabella-body-row 
                    ${
                      showRowBorder && (
                      (typeof(rowSelected) != 'undefined' &&   rowSelected == rowIndex ) ? "active"  
                      : ""                        
                      )
                    }
                    
                    ${
                      rowIndex % 2 == 0 ? "even" : "odd"
                    }`}
                    onClick={() => onRowClick(row)}
                  >
                    {row.cells.map((cell, index) => {
                      return (
                        <td
                          {...cell.getCellProps()}
                          className={`tabella-body-row-cell ${
                            lastColumnFixed && index === columnsLength - 1
                              ? rowIndex % 2 == 0
                                ? "tabella-last-sticky-cell tabella-last-cell-position tabella-last-cell-shadow even"
                                : "tabella-last-sticky-cell tabella-last-cell-position tabella-last-cell-shadow odd"
                              : ""
                          }`}
                        >
                          {cell.render("Cell")}
                        </td>
                      );
                    })}
                  </tr>
                );
              })}
              {tableRows.length === 0 && (
                <tr className="tabella-body-row text-center">
                  <td colSpan={columns.length}>No Records</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
        {pagination && <SimplePagination tableInstance={tableInstance} />}
      </div>
    )
  );
};
