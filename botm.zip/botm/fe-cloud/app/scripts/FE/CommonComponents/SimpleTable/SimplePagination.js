import React, { useEffect, useState } from "react";
import { v4 as uuidv4 } from "uuid";
import IconLeftArrowBlue from "../Common/Icons/IconLeftArrowBlue";
import IconLeftArrowGrey from "../Common/Icons/IconLeftArrowGrey";
import IconMoreInfo from "../Common/Icons/IconMoreInfo";

const SimplePagination = (props) => {
  const [pagesToShow, setPagesToShow] = useState([]);
  const [simplePageIndex, setSimplePageIndex] = useState(1);
  const { tableInstance = {} } = props;
  const {
    canPreviousPage = false,
    canNextPage = false,
    pageOptions = [],
    pageCount = 0,
    gotoPage = (event) => {
      console.log(event);
    },
    nextPage = (event) => {
      console.log(event);
    },
    previousPage = (event) => {
      console.log(event);
    },
    setPageSize = (event) => {
      console.log(event);
    },
    pageIndex = 0,
    rows = [],
    autoResetPage = true,
    showTotalCount = false,
    page,
    state,
  } = tableInstance;

  useEffect(() => {
    updatePagesToShow(pageIndex + 1);
  }, []);

  
  // update page each time table rows change
  useEffect(() => {
    console.log("rows changed ->  pageIndex, simplePageIndex ", pageIndex, simplePageIndex, tableInstance);
    if(autoResetPage === true){ 
      updatePagesToShow(pageIndex + 1);
    }else if (rows.length === 0){ 
      updatePagesToShow(1);
      gotoPage(0);
    }else{
      updatePagesToShow(simplePageIndex);
    }
  }, [rows]);
  

  let updatePagesToShow = (currentPage) => {
    currentPage = currentPage || 1;
    let totalPages = pageCount;
    const noOfpages = 4;

    let startPage;
    if (totalPages <= noOfpages) {
      startPage = 1;
    } else {
      if (currentPage <= 2) {
        startPage = 1;
      } else if (currentPage + 2 >= totalPages) {
        startPage = totalPages + 1 - noOfpages;
      } else {
        startPage = currentPage - 1;
      }
    }

    let currentPagesToShow = [];
    for (let i = 0; i < noOfpages; i++) {
      if (startPage + i <= totalPages) {
        currentPagesToShow.push(startPage + i);
      }
    }
    setPagesToShow(currentPagesToShow);
    setSimplePageIndex(currentPage);
  };

 const getStartCount = ( index, size ) => {
    let count = (index-1) *size
    return count ;
  };

 const  getEndCount = (page, limit) => {
    let endCount = page * limit;
    endCount = endCount > rows.length ? rows.length : endCount;
    return endCount;
  };

  return (
    pageCount > 0 && (
      <>
      <div className="d-flex flex-row  mt-3 tabella-pagination">
      {showTotalCount && state.pageSize ? (
            <div className="d-flex col-5" >
               <span className="show">
                {
                  // ADDED TABLE COUNT LOGIC BY SESHA
                "Viewing " + 
                (getStartCount( simplePageIndex, state.pageSize ) + 1) + 
                " - "  + 
                getEndCount(simplePageIndex, state.pageSize) + 
                " of "+ 
                rows.length + 
                " elements"}
              </span> 
            </div>
          ) : null}

        <div className= {`d-flex col ${showTotalCount ? ` ` : `justify-content-center`} `} >
          <span className="left-arrow">
            {canPreviousPage ? (
              <IconLeftArrowBlue
                configuration={{
                  onClick: () => {
                    previousPage();
                    updatePagesToShow(simplePageIndex - 1);
                  },
                }}
              />
            ) : (
              <IconLeftArrowGrey />
            )}
          </span>
          <div className="tabella-page-text mt-1">
            {pagesToShow.map(
              (currentPage, currentPageIndex, currentPageArray) => {
                let currentPageArraylength = currentPageArray.length;
                let showMoreIconBefore = false;
                let showMoreIconAfter = false;
                if (currentPageIndex === 0 && currentPageArray[0] > 2) {
                  showMoreIconBefore = true;
                }
                if (
                  currentPageIndex === currentPageArraylength - 1 &&
                  currentPageArray[currentPageArraylength - 1] < pageCount - 1
                ) {
                  showMoreIconAfter = true;
                }

                return (
                  <>
                    {showMoreIconBefore && (
                      <>
                        <span
                          key={uuidv4()}
                          className="p-2"
                          onClick={() => {
                            gotoPage(0);
                            updatePagesToShow(1);
                          }}
                        >
                          {1}
                        </span>
                        <span className="p-2">
                          <IconMoreInfo />
                        </span>
                      </>
                    )}
                    <span
                      key={uuidv4()}
                      className={`p-2 ${
                        simplePageIndex === currentPage ? "active" : ""
                      }`}
                      onClick={() => {
                        gotoPage(currentPage - 1);
                        updatePagesToShow(currentPage);
                      }}
                    >
                      {currentPage}
                    </span>
                    {showMoreIconAfter && (
                      <>
                        <span className="p-2">
                          <IconMoreInfo />
                        </span>
                        <span
                          key={uuidv4()}
                          className="p-2"
                          onClick={() => {
                            gotoPage(pageCount - 1);
                            updatePagesToShow(pageCount);
                          }}
                        >
                          {pageCount}
                        </span>
                      </>
                    )}
                  </>
                );
              }
            )}
          </div>
          <span className="right-arrow">
            {canNextPage ? (
              <IconLeftArrowBlue
                configuration={{
                  onClick: () => {
                    nextPage();
                    updatePagesToShow(simplePageIndex + 1);
                  },
                }}
              />
            ) : (
              <IconLeftArrowGrey />
            )}
          </span>
        </div>
      </div>
      </>
    )
  );
};

export default SimplePagination;
