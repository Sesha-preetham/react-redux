import React from "react";
import { useAsyncDebounce } from "react-table";
import TextField from "../../Forms/TextField";

const SimpleGlobalFilter = (props) => {
  const {
    globalSearch,
    preGlobalFilteredRows,
    globalFilter,
    setGlobalFilter,
  } = props;
  const {
    show: globalSeachShow = false,
    width = "50%",
    placeholder = "Search...",
  } = globalSearch;
  const onChange = useAsyncDebounce((value) => {
    setGlobalFilter(value || undefined);
  }, 200);

  let globalSearchField = {
    uniqueID: "globalSearch",
    placeHolder: placeholder,
    readonly: false,
    visible: true,
    validation: {
      mandatory: true,
      type: "Alphanumeric",
    },
    setValue: (obj) => {
      onChange(obj.currentValue);
    },
  };

  return (
    globalSeachShow && (
      <div style={{ width: width }}>
        <TextField configuration={globalSearchField} />
      </div>
    )
  );
};

export default SimpleGlobalFilter;
