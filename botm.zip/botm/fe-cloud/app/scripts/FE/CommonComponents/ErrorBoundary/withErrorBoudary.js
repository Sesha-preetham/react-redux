import React from "react";
import { isMock } from "../../Client/ClientProperties";
import { httpPostErrorLog } from "../../Utils/CommonUtil";

export function withErrorBoundary(WrapperComponent) {
  class ComponentWithErrorBoundary extends React.Component {
    constructor(props) {
      super(props);
      this.state = {
        error: null,
        errorInfo: null,
      };
    }

    componentDidCatch(error, errorInfo) {
      // Catch errors in any components below and re-render with error message
      this.setState({
        error: error,
        errorInfo: errorInfo,
      });

      httpPostErrorLog({
        type: "ErrorBoundary",
        errCode: "999",
        errMsg: error.toString(),
        errStack: errorInfo.componentStack,
      });
      // You can also log error messages to an error reporting service here
    }

    render() {
      if (this.state.errorInfo) {
        // Error path
        return (
          <div className="Toastify m-2">
            <div className="Toastify__toast-container Toastify__toast-container--top-right inline-toast-container">
              <div className="Toastify__toast Toastify__toast--error">
                <div role="alert" className="Toastify__toast-body">
                  <div className="d-flex flex-column">
                    <div className="flex-fill my-2">
                      Oops. Something went wrong!
                    </div>
                    {isMock && (
                      <div className="flex-fill my-2">
                        <details style={{ whiteSpace: "pre-wrap" }}>
                          {this.state.error && this.state.error.toString()}
                          <br />
                          {this.state.errorInfo.componentStack}
                        </details>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </div>
          </div>
        );
      }
      // Normally, just render wrapper component
      return <WrapperComponent {...this.props} />;
    }
  }
  return ComponentWithErrorBoundary;
}
