import React from "react";
import MyCollapse from "../Collapse/MyCollapse";
import IconCaretDownFill from "../Common/Icons/IconCaretDownFill";
import IconCaretRightFill from "../Common/Icons/IconCaretRightFill";

const RowBluCollapse = (props) => {
  const { show = false, rowBlu = {}, collapse = {}, events = {} } = props;

  const { rowBluClassName = "", rowBluTitle = "" } = rowBlu;
  const { collapseDefaultShow = true } = collapse;
  const {
    handleOnIconClick = () => {},
    handleOnCollapseEntered = () => {},
    handleOnCollapseExited = () => {},
  } = events;

  return (
    <>
      <div
        className={`d-flex flex-row flex-fill my-1 row-blu ${rowBluClassName}`}
      >
        <div className="text-center">
          {show ? (
            <IconCaretDownFill
              configuration={{
                className: "row-blu-arrow",
                onClick: () => {
                  handleOnIconClick();
                },
              }}
            />
          ) : (
            <IconCaretRightFill
              configuration={{
                className: "row-blu-arrow",
                onClick: () => {
                  handleOnIconClick();
                },
              }}
            />
          )}
        </div>
        <div className="ml-2">
          <span className="arow-blu-text">{rowBluTitle}</span>
        </div>
      </div>
      <MyCollapse
        configuration={{
          collapseShow: show,
          defaultShow: collapseDefaultShow,
          events: {
            onEntered: handleOnCollapseEntered,
            onExited: handleOnCollapseExited,
          },
        }}
      >
        {props.children}
      </MyCollapse>
    </>
  );
};

export default RowBluCollapse;
