const alertIds = {
  globalAlertId: "global",
  previewConsunAlertId: "previewConsun",
  sospesiAlertId: "sospesiAlertId",
  authenticationAlertId: "authenticationAlertId",
  prospectModalAlertId: "prospectModalAlertId",
  prenotaRecallAletrId: "prenotaRecallAletrId",
  retailDeskAlertId:"retailDeskAlertId",
  phoneCollectionAlertId:"phoneCollectionAlertId",
  esitoComponentAlertId:{"Modal":"esitoComponentAlertModal", "Widget":"esitoComponentAlertWidget"},
  phoneCollectionCRMAlertId:"phoneCollectionCRMAlertId",
  esitoCRMComponentAlertId:{"Modal":"esitoCRMComponentAlertModal", "Widget":"esitoCRMComponentAlertWidget"},
  hdcWidgetAlertId:"hdcWidgetAlertId"
};

export const {
  globalAlertId,
  previewConsunAlertId,
  hdcWidgetAlertId,
  sospesiAlertId,
  authenticationAlertId,
  prospectModalAlertId,
  prenotaRecallAletrId,
  retailDeskAlertId,
  phoneCollectionAlertId,
  esitoComponentAlertId,
  phoneCollectionCRMAlertId,
  esitoCRMComponentAlertId,
} = alertIds;
