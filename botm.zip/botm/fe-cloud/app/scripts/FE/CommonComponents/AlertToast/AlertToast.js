import React from "react";
import { Bounce, Flip, Slide, ToastContainer } from "react-toastify";
import { v4 as uuidv4 } from "uuid";
import IconTransparentClose from "../Common/Icons/IconTransparentClose";

// toast("Wow so easy !", { containerId: globalAlertId });
// toast.info("Info", { containerId: globalAlertId });
// toast.success("Success", { containerId: globalAlertId });
// toast.warn("Warning", { containerId: globalAlertId });
// toast.error("Error", { containerId: globalAlertId });

const AlertToast = (props) => {
  const { configuration = {} } = props;
  const {
    className = "",
    unqiueID = uuidv4(),
    position = "top-right",
    hideProgressBar = false,
    pauseOnHover = true,
    pauseOnFocusLoss = false,
    closeOnClick = true,
    transition = "bounce",
  } = configuration;

  return (
    <ToastContainer
      className={className}
      containerId={unqiueID}
      enableMultiContainer
      autoClose={10000}
      limit={2}
      draggable={false}
      newestOnTop={false}
      closeButton={<IconTransparentClose />}
      transition={
        transition === "flip" ? Flip : transition === "bounce" ? Bounce : Slide
      }
      position={position}
      hideProgressBar={hideProgressBar}
      pauseOnHover={pauseOnHover}
      pauseOnFocusLoss={pauseOnFocusLoss}
      closeOnClick={closeOnClick}
    />
  );
};

export default AlertToast;
