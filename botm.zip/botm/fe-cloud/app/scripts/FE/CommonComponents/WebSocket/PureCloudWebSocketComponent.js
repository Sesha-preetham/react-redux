import React, { useEffect, useRef, useState } from "react";
import { useSelector } from "react-redux";
import { eventEmitter } from "../../../App";


const PureCloudWebSocketComponent = (props = {}) => {
    
    const webSocket = useRef();

    const { channel = {} } = useSelector(state => state.purecloudNotification);
    const { connectUri } = channel;
    const [wsPing, setWsPing] = useState();

    const handleOnOpen = (event) => {
        console.log("PureCloudWebSocketComponent onOpen ", event);
    }

    const handleOnClose = (event) => {
        console.log("PureCloudWebSocketComponent onClose ", event);
    }

    const handleOnMessage = (event) => {
        console.log("PureCloudWebSocketComponent onMessage ", event);
        const message = JSON.parse(event.data);
        if(!message) return;
        const { topicName = "", eventBody = {}} = message;
        if(topicName){
            eventEmitter.emit(topicName, eventBody);
        }
    }

    const handleOnError = (event) => {
        console.log("PureCloudWebSocketComponent onError ", event);
    }

    useEffect(() => {
        return () => {
            const ws = webSocket.current;
            if(ws){
                ws.close();
                if(wsPing){
                    clearInterval(wsPing);
                }
            }
        }
    },[])

    useEffect(()=>{
        if(!connectUri || connectUri === "") return;
        webSocket.current = new WebSocket(connectUri);
        const ws = webSocket.current;
        ws.onopen = handleOnOpen;
        ws.onclose = handleOnClose;
        ws.onmessage = handleOnMessage;
        ws.onerror = handleOnError;
        let wsPing = setInterval(() => {
            if(webSocket.current){
                // https://developer.genesys.cloud/api/rest/v2/notifications/notification_service#websocket-manual-health-check
                webSocket.current.send('{"message":"ping"}'); 
            }
        },120000);
        setWsPing(wsPing);

    },[connectUri]);

    return (
        <></>
    )
}

export default PureCloudWebSocketComponent;