class EventEmitter {
  constructor() {
    this.events = {};
  }

  subscribe(eventName, callback, additionalDataObj) {
    if (!this.events[eventName]) {
      this.events[eventName] = [];
    }
    const subscpritionObj = {
      callback: callback,
      additionalDataObj: additionalDataObj
    };
    this.events[eventName].push(subscpritionObj);
    return {
      unsubscribe: () => {
        if (this.events[eventName]) {
          this.events[eventName].splice(
            this.events[eventName].indexOf(subscpritionObj),
            1
          );
        }
      },
    };
  }

  emit(eventName, data) {
    if (this.events[eventName]) {
      this.events[eventName].forEach((subscprition) => {
        const { callback = () => {}, additionalDataObj = {}} = subscprition
        callback(data,additionalDataObj);
      });
    }
  }
}

export default EventEmitter;