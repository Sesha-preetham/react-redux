import React from "react";
import { Modal, Container } from "react-bootstrap";
import { v4 as uuidv4 } from "uuid";

const ErrorModal = (props) => {
  const { configuration = {} } = props;
  const {
    uniqueID = uuidv4(),
    title = {},
    modalShow = false,
    modalHeaderShow= true,
    modalClass = "",
    modalBodyClass = "",
    dialogClassName = "",
    backdrop = {},
    events = {},
  } = configuration;

  const { content: titleContent = "", class: titleClass = "" } = title;
  const {
    enable: backdropEnable = false,
    class: backdropClass = "",
  } = backdrop;
  const {
    onHide = () => {},
    onEntered = () => {},
    onExited = () => {},
  } = events;
  return (
    <Modal
      id={uniqueID}
      show={modalShow}
      onHide={onHide}
      onEntered={onEntered}
      onExited={onExited}
      className={modalClass ? modalClass : "error-modal"}
      backdrop={backdropEnable}
      backdropClassName={backdropClass ? backdropClass : ""}
      dialogClassName={dialogClassName}
    >
      <Modal.Header closeButton hidden={!modalHeaderShow}>
        <Modal.Title className={titleClass ? titleClass : "error-modal-title"}>
          {titleContent}
        </Modal.Title>
      </Modal.Header>
      <Modal.Body className={modalBodyClass ? modalBodyClass : "error-modal-body"}>
        <Container fluid={true}>{props.children}</Container>
      </Modal.Body>
    </Modal>
  );
};

export default ErrorModal;
