import { current } from "@reduxjs/toolkit";
import React, { useEffect, useState } from "react";
import { httpPostCreateEmail } from "../../Modules/Interaction/Service";
import { setInteractionLightAuthenticationData } from "../../Modules/LightAuthentication/lightAuthenticationSlice";
import { exposedDispatch } from "../../Store/store";
import { httpGetMemberQueues, placeCall } from "../../Utils/CommonUtil";
import FormFieldHandler from "../Forms/FormFieldHandler";
import SelectField from "../Forms/SelectField";
import TextField from "../Forms/TextField";
import useAsyncReference from "../Hooks/useAsyncReference";
import MySpinner from "../Spinner/MySpinner";
import {
  clickToDialModalSpinnerId,
  toggleSpinnerById,
} from "../Spinner/spinnerSlice";
import MyModal from "./MyModal";

const ClickToDialModal = (props = {}) => {
  const { configuration = {} } = props;
  const {
    showModal = false,
    classes = {},
    events = {},
    dialOptions = {},
    queueSelection = true,
    filterQueueList = (rlData, channelType) => {
      return true;
    },
    getDefaultQueue = (options) => {
      options.find((el) => el.value === queueId);
    },
    channelSelection = true,
    changeContact = true,
  } = configuration;

  const { modalClass = "", dialogClassName = "" } = classes;

  const {
    handleOnCloseModal = () => {},
    handleOnConfirmationModal = () => {},
  } = events;

  const {
    type = "call", // call, email, sms,
    number, // phone number
    address, // email address
    queueId,
    attributes = {},
  } = dialOptions;

  const [form] = useState(new FormFieldHandler(true));
  const [contact, setContact] = useState({
    call: number || "",
    email: address || "",
    sms: number || "",
  });

  const [queue, setQueue] = useState(queueId);
  const [channelRef, setChannel] = useAsyncReference(type, !channelSelection);
  const [queueList, setQueueList] = useState([]);

  const modalConfiguration = {
    modalShow: showModal,
    modalClass: `my-modal ${modalClass}`,
    dialogClassName: `modal-w ${dialogClassName}`,
    title: {
      content: "Creazione interazione",
      class: "widget-title",
    },
    modalHeaderShow: true,
    backdrop: {
      enable: "static",
    },
    events: {
      onHide: () => {
        resetContact();
        handleOnCloseModal(false);
      },
      onEntered: () => {
        console.log("Confirmation modal onEntered");
        if (queueSelection) {
          exposedDispatch(toggleSpinnerById(clickToDialModalSpinnerId));
          httpGetMemberQueues({
            type: "OUTBOUND",
          })
            .then((queueList = []) => {
              let options = queueList.map((q) => {
                return {
                  label: q.pureCloudName,
                  value: q.pureCloudId,
                  rlData: q,
                };
              });
              setQueueList(options);
              exposedDispatch(toggleSpinnerById(clickToDialModalSpinnerId));
            })
            .catch((e) => {
              exposedDispatch(toggleSpinnerById(clickToDialModalSpinnerId));
            });
        }
        let contact = number ? number : address ? address : null;
        form.getField("contactField").theField.setValue(contact);
      },
      onExited: () => {
        resetContact();
        console.log("Confirmation modal onExited");
      },
    },
  };

  const resetContact = () => {
    setContact({
      call: "",
      email: "",
      sms: "",
    });
  };

  useEffect(() => {
    let options = queueList.filter((value) => {
      const { rlData = {}} = value;
      let btChannel =
        channelRef.current === "call"
          ? window.BTFEDictionary["voice"]
          : channelRef.current === "email"
          ? window.BTFEDictionary["email"]
          : undefined;
      let isValid = false;
      if(btChannel){
        const { channels = []} = rlData;
        if(channels.find(v => v === btChannel)){
          isValid = true;
        }
      }
      return isValid && filterQueueList(rlData, channelRef.current);
    });
    if(form.getField("queueField")){
      form.getField("queueField").theField.reloadOptions(options);
      let defaultQueueOption = getDefaultQueue(options);
      if (defaultQueueOption) {
        form.getField("queueField").theField.setValue(defaultQueueOption);
      }
    }
  }, [channelRef.current, queueList]);

  useEffect(() => {
    if (form.getField("contactField")) {
      form
        .getField("contactField")
        .theField.setValue(contact[channelRef.current]);
    }
  }, [channelRef.current]);

  const getConfirmationQuestionFromType = (type) => {
    if (type === "call") {
      return `Vuoi effettuare la chiamata a`;
    } else if (type === "email") {
      return `Vuoi inviare email a `;
    } else if (type === "sms") {
      return `Vuoi inviare sms a`;
    }
  };

  const clickToDial = () => {
    const contact = form.getValue("contactField");
    if (channelRef.current === "email") {
      httpPostCreateEmail({
        direction: "OUTBOUND",
        queueId: queue,
        toAddress: contact,
        toName: contact,
        attributes,
      });
    } else {
      placeCall({
        //number: channelRef.current !== "email" ? contact : undefined,
        //address: channelRef.current === "email" ? contact : undefined,
        number: contact,
        type: channelRef.current,
        autoPlace: true,
        queueId: queue,
        attributes,
      });
    }
  };

  const getChannelLabelByType = (type) => {
    let labels = {
      call: "Voce",
      email: "Email",
      sms: "Sms",
    };
    return labels[type];
  };

  const channelFieldConfiguration = {
    uniqueID: "channelField",
    multiSelect: false,
    label: "",
    placeHolder: "Seleziona il canale",
    readonly: false,
    visible: true,
    disabled: false,
    options: [
      {
        label: getChannelLabelByType("call"),
        value: "call",
      },
      {
        label: getChannelLabelByType("email"),
        value: "email",
      },
    ],
    value: {
      label: getChannelLabelByType(type),
      value: type,
    },
    searchEnabled: true,
    setValue: (obj) => {
      const { currentValue = {} } = obj || {};
      const { value } = currentValue || {};
      setChannel(value);
      console.log("setValue", obj);
    },
    form: form,
  };

  const isConfermaButtonDisabled = () => {
    return contact[channelRef.current] === "" || !queue || !channelRef.current;
  };

  const queueFieldConfiguration = {
    uniqueID: "queueField",
    multiSelect: false,
    label: "",
    placeHolder: "Seleziona la coda",
    readonly: false,
    visible: true,
    disabled: false,
    options: [],
    searchEnabled: true,
    setValue: (obj) => {
      const { currentValue = {} } = obj || {};
      const { value } = currentValue || {};
      setQueue(value);
      console.log("setValue", obj);
    },
    form: form,
  };

  const contactFieldConfiguration = {
    uniqueID: "contactField",
    placeHolder: "Inserisci recapito",
    value: contact[type],
    readonly: false,
    disabled: !changeContact,
    form: form,
    validation: {
      mandatory: true,
    },
    setValue: (value) => {
      const { currentValue = "" } = value;
      setContact((prevState) => {
        let newState = { ...prevState };
        newState[channelRef.current] = currentValue;
        return newState;
      });
    },
    feedback: {
      enable: true,
      component: () => <>* campo obbligatorio</>,
    },
  };

  return (
    <MyModal configuration={modalConfiguration}>
      <>
        <MySpinner uniqueID={clickToDialModalSpinnerId} type={"global"} />
        <div className="clicktodial-container">
          <div className="row justify-content-center">
            {channelSelection && (
              <div className="queue-select-container col-6">
                <div className="small-content-label-class">Canale</div>
                <SelectField configuration={channelFieldConfiguration} />
              </div>
            )}
            {queueSelection && (
              <div className="queue-select-container col-6">
                <div className="small-content-label-class">Coda</div>
                <SelectField configuration={queueFieldConfiguration} />
              </div>
            )}
          </div>
          <div className="d-flex justify-content-center flex-row mb-2">
            <span className="pt-1 pr-1">
              {getConfirmationQuestionFromType(channelRef.current)}
            </span>
            <TextField configuration={contactFieldConfiguration} />
            <span className="pt-1 pl-1">?</span>
          </div>
          <div className="d-flex justify-content-center flex-row mt-2 mb-2">
            <div className="w-80 pl-2">
              <button
                type="button"
                className={`btn Rectangle-Button-Blue w-100`}
                onClick={() => {
                  clickToDial();
                  handleOnConfirmationModal();
                }}
                disabled={isConfermaButtonDisabled()}
              >
                Conferma
              </button>
            </div>
            <div className="w-80 pl-2">
              <button
                type="button"
                className={`btn Rectangle-Button-White w-100`}
                onClick={() => {
                  handleOnCloseModal(false);
                }}
              >
                Annulla
              </button>
            </div>
          </div>
        </div>
      </>
    </MyModal>
  );
};

export default ClickToDialModal;
