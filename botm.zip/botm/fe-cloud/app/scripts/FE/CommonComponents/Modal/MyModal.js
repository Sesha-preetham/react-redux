import React from "react";
import { Modal, Container } from "react-bootstrap";
import { v4 as uuidv4 } from "uuid";

const MyModal = (props) => {
  const { configuration = {} } = props;
  const {
    uniqueID = uuidv4(),
    title = {},
    modalShow = false,
    modalHeaderShow = true,
    modalClass = "",
    modalBodyClass = "",
    dialogClassName = "",
    backdrop = {},
    events = {},
  } = configuration;

  const { content: titleContent = "", class: titleClass = "" } = title;
  const {
    enable: backdropEnable = false,
    class: backdropClass = "",
  } = backdrop;
  const {
    onHide = () => {},
    onEntered = () => {},
    onExited = () => {},
    onEntering = () => {},
    onExiting = () => {},
  } = events;
  return (
    <Modal
      id={uniqueID}
      show={modalShow}
      onHide={onHide}
      onEntering={onEntering}
      onExiting={onExiting}
      onEntered={onEntered}
      onExited={onExited}
      className={modalClass ? modalClass : "my-modal"}
      backdrop={backdropEnable}
      backdropClassName={backdropClass ? backdropClass : ""}
      dialogClassName={dialogClassName}
    >
      <Modal.Header closeButton hidden={!modalHeaderShow}>
        <Modal.Title className={titleClass ? titleClass : "my-modal-title"}>
          {titleContent}
        </Modal.Title>
      </Modal.Header>
      <Modal.Body className={modalBodyClass ? modalBodyClass : "my-modal-body"}>
        <Container fluid={true}>{props.children}</Container>
      </Modal.Body>
    </Modal>
  );
};

export default MyModal;
