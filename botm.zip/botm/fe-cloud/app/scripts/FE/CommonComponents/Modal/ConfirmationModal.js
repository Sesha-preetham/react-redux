import React from "react";
import MyModal from "./MyModal";
import { v4 as uuidv4 } from "uuid";

const ConfirmationModal = (props) => {

  const {
    showModal = false,
    handleOnCloseModal = () => {},
    handleOnConfirmClick= () =>{},
    modalTitle,
    modalQuestion
    } = props;

    const confirmationModel = {
        uniqueID: uuidv4(),
        modalClass: " my-modal", //multi-cliente-modal
        dialogClassName: "modal-w",
        title: {
          content: modalTitle,
          class: "widget-title",
        },
        modalShow: showModal,
        modalHeaderShow: true,
        backdrop: {
          enable: true,
        },
        events: {
          onHide: () => {
            handleOnCloseModal(false);
          },
          onEntered: () => {
            console.log("Confirmation modal onEntered");
          },
          onExited: () => {
            console.log("Confirmation modal onExited");
          },
        },
      };

    return (
      <MyModal configuration={confirmationModel}>
        <div className="mt-auto mb-4" >
          <div className="d-flex justify-content-center flex-row mt-auto">
          {modalQuestion}
          </div>
          </div>
          <div className="mt-2 mb-2" >
          <div className="d-flex justify-content-center flex-row mt-auto">
            <div className="w-80 pl-2">
              <button
                type="button"
                className={`btn Rectangle-Button-Blue w-100`}
                onClick={()=>{handleOnConfirmClick()
                  handleOnCloseModal(false)}}
              >
                Conferma
              </button>
            </div>
            <div className="w-80 pl-2">
              <button
                type="button"
                className={`btn Rectangle-Button-White w-100`}
                onClick={()=>{handleOnCloseModal(false)}}
                >
                Cancel
              </button>
            </div>
          </div>
          </div>
      </MyModal>
    );
}

export default ConfirmationModal;