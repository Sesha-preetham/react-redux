import React from "react";
import { OverlayTrigger, Popover, Button } from "react-bootstrap";
import { v4 as uuidv4 } from "uuid";

const MyPopover = (props) => {
  const { configuration = {} } = props;
  const {
    uniqueID = uuidv4(),
    title = {},
    popoverShow = false,
    popoverHeaderShow = false,
    popoverClass = "",
    popoverContentClass = "",
    popoverPlacement = "auto",
    events = {},
    overlayTriggerElement = <Button variant="success">Click me to see</Button>,
  } = configuration;

  const { content: titleContent = "", class: titleClass = "" } = title;

  const {
    onHide = () => {},
    onEntered = () => {},
    onExited = () => {},
  } = events;

  return (
    <OverlayTrigger
      placement={popoverPlacement}
      onHide={onHide}
      onEntered={onEntered}
      onExited={onExited}
      show={popoverShow}
      overlay={
        <Popover className={popoverClass} id={uniqueID}>
          {popoverHeaderShow && (
            <Popover.Title className={titleClass}>{titleContent}</Popover.Title>
          )}
          <Popover.Content className={popoverContentClass}>
            {props.children}
          </Popover.Content>
        </Popover>
      }
    >
      {overlayTriggerElement}
    </OverlayTrigger>
  );
};

export default MyPopover;
