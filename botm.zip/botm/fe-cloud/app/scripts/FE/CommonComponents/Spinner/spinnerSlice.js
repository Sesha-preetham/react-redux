import { createSlice } from "@reduxjs/toolkit";

const SpinnerIds = {
  globalSpinnerId: "globalSpinnerId",
  consunSpinnerId: "consunSpinnerId",
  simplifiedConsunSpinnerId : "simplifiedConsunSpinnerId",
  sospesoModalSpinnerId: "sospesoModalSpinnerId",
  authenticationSpinnerId: "authenticationSpinnerId",
  prospectModalSpinnerId: "prospectModalSpinnerId",
  consunHashTagSpinnerId: "consunHashTagSpinnerId",
  clickToDialModalSpinnerId: "clickToDialModalSpinnerId",
  agentAttachmentModalSpinnerId:"agentAttachmentModalSpinnerId",
  phoneCollectionPEGSpinnerId : "phoneCollectionPEGSpinnerId",
  esitoSpinnerId : {"Modal":"esitoSpinnerModal","Widget":"esitoSpinnerWidget"},
  phoneCollectionCRMSpinnerId : "phoneCollectionCRMSpinnerId",
  esitoCRMSpinnerId : {"Modal":"esitoSpinnerModal","Widget":"esitoSpinnerWidget"},
  hdcConsunWidgetSpinnerId:"hdcConsunWidgetSpinnerId"
};

export const {
  globalSpinnerId,
  consunSpinnerId,
  sospesoModalSpinnerId,
  authenticationSpinnerId,
  prospectModalSpinnerId,
  clickToDialModalSpinnerId,
  consunHashTagSpinnerId,
  agentAttachmentModalSpinnerId,
  esitoSpinnerId,
  esitoCRMSpinnerId,
  hdcConsunWidgetSpinnerId,
  phoneCollectionPEGSpinnerId,
  phoneCollectionCRMSpinnerId,
} = SpinnerIds;

let initialState = {
  spinners: [
    {
      spinnerId: globalSpinnerId,
      spinnerShow: false,
    },
  ],
};

const spinnerSlice = createSlice({
  name: "spinner",
  initialState,
  reducers: {
    spinnerPush(state, action) {
      const { payload = "" } = action;
      if (!payload) return;
      let isAvail = state.spinners.findIndex((elSpinner) => {
        return elSpinner.spinnerId === payload;
      });
      if (isAvail === -1) {
        state.spinners.push({
          spinnerId: payload,
          spinnerShow: false,
        });
      }
    },
    toggleSpinnerById(state, action) {
      const { payload = "" } = action;
      if (!payload) return;
      let foundIndex = state.spinners.findIndex((elSpinner) => {
        return elSpinner.spinnerId === payload;
      });
      if (foundIndex !== -1) {
        state.spinners[foundIndex].spinnerShow = !state.spinners[foundIndex]
          .spinnerShow;
      }
    },
    spinnerDeleteById(state, action) {
      const { payload = "" } = action;
      if (!payload) return;
      let foundIndex = state.spinners.findIndex((elSpinner) => {
        return elSpinner.spinnerId === payload;
      });
      if (foundIndex !== -1) {
        state.spinners.splice(foundIndex, 1);
      }
    },
    spinnerReset(state) {
      state = initialState;
    },
  },
});

export const showSpinnerById = (spinners = []) => {
  return (id = "") => {
    if (!id) return [false];
    let foundIndex = spinners.findIndex((elSpinner) => {
      return elSpinner.spinnerId === id;
    });
    if (foundIndex !== -1) {
      return [spinners[foundIndex].spinnerShow];
    }
    return [false];
  };
};

export const {
  spinnerDeleteById,
  spinnerPush,
  toggleSpinnerById,
  spinnerReset,
} = spinnerSlice.actions;

export default spinnerSlice.reducer;
