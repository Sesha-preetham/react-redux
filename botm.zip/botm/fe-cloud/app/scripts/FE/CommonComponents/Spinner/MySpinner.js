import { css } from "@emotion/react";
import React, { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import CircleLoader from "react-spinners/CircleLoader";
import { v4 as uuidv4 } from "uuid";
import {
  showSpinnerById,
  spinnerDeleteById,
  spinnerPush,
} from "./spinnerSlice";

const override = css`
  display: block;
  margin: 0 auto;
  border-color: red;
`;

const MySpinner = ({ uniqueID = uuidv4(), type = "" }) => {
  const { spinners = [] } = useSelector((state) => state.spinner);
  const dispatch = useDispatch();
  const [showSpinner] = showSpinnerById(spinners)(uniqueID);

  useEffect(() => {
    dispatch(spinnerPush(uniqueID));
    return () => {
      dispatch(spinnerDeleteById(uniqueID));
    };
  }, []);
  return (
    <div id={uniqueID}>
      {showSpinner &&
        (type === "global" ? (
          <div className="loader-container loader-section">
            <div className="loader">
              <CircleLoader
                color={"#0035AF"}
                loading={true}
                css={override}
                size={96}
              />
            </div>
          </div>
        ) : (
          <div className="row no-gutters">
            <div className="col-12">
              <div className="loader-container loader-section-inline">
                <div className="loader">
                  <CircleLoader
                    color={"#0035AF"}
                    loading={true}
                    css={override}
                    size={56}
                  />
                </div>
              </div>
            </div>
          </div>
        ))}
    </div>
  );
};

export default MySpinner;
