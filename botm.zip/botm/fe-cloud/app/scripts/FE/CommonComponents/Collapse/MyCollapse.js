import React from "react";
import { Collapse } from "react-bootstrap";
import { v4 as uuidv4 } from "uuid";

const MyCollapse = (props) => {
  const { configuration = {} } = props;
  const {
    uniqueID = uuidv4(),
    defaultShow = false,
    collapseShow = false,
    collapseClass = "",
    events = {},
  } = configuration;

  const { onEntered = () => {}, onExited = () => {} } = events;
  return (
    <Collapse
      id={uniqueID}
      appear={defaultShow}
      in={collapseShow}
      onEntered={onEntered}
      onExited={onExited}
      className={collapseClass ? collapseClass : ""}
      mountOnEnter={true}
    >
      <div className={`m-2 my-collapse`}>{props.children}</div>
    </Collapse>
  );
};

export default MyCollapse;
