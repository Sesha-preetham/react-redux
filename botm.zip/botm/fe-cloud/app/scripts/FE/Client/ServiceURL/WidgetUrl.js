const WidgetsUrls = {
    widgets: "/barratelefonicabe-web/service/widgets",
    interactionWidgets: "/barratelefonicabe-web/service/widgets/interaction",
  };
  
  export default WidgetsUrls;