const InteractionsUrls = {
  getMissingInteractions: "/barratelefonicabe-web/service/getmissinginteraction",
  startGeolocalizationFlow: "/barratelefonicabe-web/service/startgeolocalizationflow",
  updatecampaigncontact: "/barratelefonicabe-web/service/updatecampaigncontact",
  insertcampaigncontact: "/barratelefonicabe-web/service/insertcampaigncontact",
  sendChatMessage: "/barratelefonicabe-web/service/chat/message",
  chatCheckClientMessage: "/barratelefonicabe-web/service/chat/clientmessagecheck",
  getAttachmentTableData:"/barratelefonicabe-web/service/getAttachmentList/:interactionId",
  downloadAttachmentFileData:"/barratelefonicabe-web/service/downloadFile/:attachmentId",
  uploadAttachmentFileData:"/barratelefonicabe-web/service/uploadFile/:interactionId",
  createEmail: "/barratelefonicabe-web/service/email/create",
  callbackDisconnect: "/barratelefonicabe-web/service/callback/:conversationId/disconnect"
};

export default InteractionsUrls;
