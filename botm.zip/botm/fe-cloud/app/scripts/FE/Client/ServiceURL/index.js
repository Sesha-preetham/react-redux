import AuthenticationUrl from "./AuthenticationUrl";
import CommonUrls from "./CommonURl";
import ConsunUrl from "./ConsunUrl";
import InitUrls from "./InitUrl";
import InteractionsUrls from "./InteractionsUrl";
import ProspectUrls from "./ProspectUrl";
import SospesiUrls from "./SospesiUrls";
import UserSearchUrls from "./UserSearchUrls";
import notificationUrls from "./NotificationUrl";
import WidgetsUrls from "./WidgetUrl";
import PureCloudAnalyticsUrls from "./PureCloudAnalyticsUrls";
import DrafEmailUrls from "./DraftEmailUrl";
import AbandonRecallUrls from "./AbandonRecallUrls";
import RetailDeskUrls from "./RetailDeskUrl";
import PhoneCollectionUrl from "./PhoneCollectionUrl";
import HDCConsunUrls from "./HDCConsunUrl";

const concatUrlBaseWithRestUrls = (urlBase, urlsObject) => {
  let immutableUrlsObject = { ...urlsObject };
  for (let url in immutableUrlsObject) {
    immutableUrlsObject[url] = urlBase + immutableUrlsObject[url];
  }
  return immutableUrlsObject;
};

const BEUrls = (urlBase) => {
  const urlsListObject = {
    ...InitUrls,
    ...CommonUrls,
    ...SospesiUrls,
    ...UserSearchUrls,
    ...WidgetsUrls,
    ...InteractionsUrls,
    ...notificationUrls,
    ...PureCloudAnalyticsUrls,
    ...ConsunUrl,
    ...AuthenticationUrl,
    ...ProspectUrls,
    ...DrafEmailUrls,
    ...AbandonRecallUrls,
    ...RetailDeskUrls,
    ...PhoneCollectionUrl,
    ...HDCConsunUrls,
  };

  return {
    ...concatUrlBaseWithRestUrls(urlBase, urlsListObject),
  };
};

export default BEUrls;
