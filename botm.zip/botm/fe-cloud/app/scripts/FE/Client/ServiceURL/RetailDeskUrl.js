const RetailDeskUrls = {
    getCampagnelist: "/barratelefonicabe-web/service/rdCampagne",
    getAgentlist: "/barratelefonicabe-web/service/rdAgentList",
    getStatoArr: "/barratelefonicabe-web/service/rdStato",
    postRetailDeskTableData: "/barratelefonicabe-web/service/rdContattiDetail",
    noteServiceData: "/barratelefonicabe-web/service/rdContattiAggiornaNote",
  };
  
  export default RetailDeskUrls;
  