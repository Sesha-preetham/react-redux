const HDCConsunUrls = {
    queueAnomalia: "/barratelefonicabe-web/service/queueAnomalia",
    categorizationList: "/barratelefonicabe-web/service/categorizationList",
    createIncident: "/barratelefonicabe-web/service/createIncident",
    hdcTrace:"/barratelefonicabe-web/service/interaction/:interactionId/hdc/trace",
    hdcBanksUrl:"/barratelefonicabe-web/service/hdcbanks",
  };
  
  export default HDCConsunUrls;
  