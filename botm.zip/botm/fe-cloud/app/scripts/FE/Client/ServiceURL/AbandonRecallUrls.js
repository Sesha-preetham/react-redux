const AbandonRecallUrls = {
    getAbandonRecallList: "/barratelefonicabe-web/service/abandonrecall/list",
    traceAbandonRecallState: "/barratelefonicabe-web/service/abandonrecall/trace"
};
export default AbandonRecallUrls;