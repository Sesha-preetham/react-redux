const PhoneCollectionUrl = {
    getAssegnatiAlCDR: "/barratelefonicabe-web/service/pc/assegnatiAlCDR",
    getPcAgentList: "/barratelefonicabe-web/service/pc/agentList",
    postStato: "/barratelefonicabe-web/service/pc/stato",
    pcEstrai : "/barratelefonicabe-web/service/pc/estrai",
    sendEmail: "/barratelefonicabe-web/service/email/draftPhoneCollection",
    aggiornaNote: "/barratelefonicabe-web/service/pc/aggiornaNote",
    noteColumnPopup : "/barratelefonicabe-web/service/pc/noteColumnPopup",
    
    assistenza : "/barratelefonicabe-web/service/pc/assistenza",
    getEsitoVal : "/barratelefonicabe-web/service/pc/esitoContactCenter",
    
    aggiorna : "/barratelefonicabe-web/service/pc/aggiorna",
    esitoTrace:"/barratelefonicabe-web/service/interaction/:interactionId/phonecollection/trace"
  };
  
  export default PhoneCollectionUrl;