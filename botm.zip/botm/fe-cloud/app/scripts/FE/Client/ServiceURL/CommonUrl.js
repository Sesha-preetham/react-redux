const CommonUrls = {
  visiblebanks: "/barratelefonicabe-web/service/visiblebanks",
  clientsearchtype: "/barratelefonicabe-web/service/anagrafica/clientsearchtype",
  getAgents: "/barratelefonicabe-web/service/agents",
  channelsandcalltypes: "/barratelefonicabe-web/service/channelsandcalltypes",
  systemPresences: "/barratelefonicabe-web/service/systempresences",
  organizationPresences: "/barratelefonicabe-web/service/organizazionpresences",
  errorLog: "/barratelefonicabe-web/service/errorlog",
  event: "/barratelefonicabe-web/service/event",
  cities: "/barratelefonicabe-web/service/anagrafica/cities",
  nations: "/barratelefonicabe-web/service/anagrafica/nations",
  customFunctionUserGranted: "/barratelefonicabe-web/service/customfunction/user/grants"
};

export default CommonUrls;
