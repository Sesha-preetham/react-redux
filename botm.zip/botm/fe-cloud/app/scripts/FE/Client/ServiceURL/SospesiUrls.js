const SospesiUrls = {
    getSospesiList: "/barratelefonicabe-web/service/sospesi/getall",
    updateSospeso: "/barratelefonicabe-web/service/sospesi/update",
    getSospesiCount: "/barratelefonicabe-web/service/sospesi/count",
    getSospesiRecapito: "/barratelefonicabe-web/service/sospesi/getrecapito"
};
  
export default SospesiUrls;