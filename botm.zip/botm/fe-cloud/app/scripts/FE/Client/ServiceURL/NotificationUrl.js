const notificationUrls = {
  getMemberQueues: "/barratelefonicabe-web/service/getmemberqueues",
  notificationChannelCreate:
    "/barratelefonicabe-web/service/notification/createchannel",
  notificationSubscribe:
    "/barratelefonicabe-web/service/notification/subscribe",
};

export default notificationUrls;
