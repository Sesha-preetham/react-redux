const InitUrls = {
  authenticate: "/authenticate",
  preference: "/barratelefonicabe-web/service/preference",
  logout: "/barratelefonicabe-web/logout"
};

export default InitUrls;
