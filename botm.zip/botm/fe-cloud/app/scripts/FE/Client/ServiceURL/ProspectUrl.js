const ProspectUrls = {
  prospectProdotto: "/barratelefonicabe-web/service/anagrafica/prospect/products",
  prospectTipoEsiti: "/barratelefonicabe-web/service/anagrafica/prospect/esiti",
  prospectInserisci: "/barratelefonicabe-web/service/anagrafica/prospect/inserisci",
};

export default ProspectUrls;
