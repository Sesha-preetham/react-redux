const DraftEmailUrl = {
    draftPrivato: "/barratelefonicabe-web/service/email/draftPrivato",
    draftMailRemote: "/barratelefonicabe-web/service/email/draftRemoteBanking",
    draftMailEsercente: "/barratelefonicabe-web/service/email/draftEsercente"
};
  
export default DraftEmailUrl;