const PureCloudAnalyticsUrls = {
    analyticsQueueObservation: "/barratelefonicabe-web/service/pcanalytics/queueobservations"
}

export default PureCloudAnalyticsUrls;
