const ConsunUrl = {
    getWrapupCodeById: "/barratelefonicabe-web/service/interaction/:interactionId/getwrapupcode",
    getTagsByOrg: "/barratelefonicabe-web/service/tags",
    getLinkedTags: "/barratelefonicabe-web/service/linkedtags",
    getPlatform: "/barratelefonicabe-web/service/platform",
    disconnect: "/barratelefonicabe-web/service/interaction/:interactionId/trace/disconnect",
    traceById: "/barratelefonicabe-web/service/interaction/:interactionId/trace",
    eliminaSpamming: "/barratelefonicabe-web/service/interaction/:interactionId/spam",
    insertInteraction: "/barratelefonicabe-web/service/interaction/:interactionId/trace/insertinteraction",
    getIntxId: "/barratelefonicabe-web/service/interaction/:interactionId/trace/getintxid",
    presaveloce: "/barratelefonicabe-web/service/interaction/presaveloce",
    getContactlist: "/barratelefonicabe-web/service/contactlist",
    getServiceRecallContactList: "/barratelefonicabe-web/service/recallservicecontactlist",
    getPrefixlist: "/barratelefonicabe-web/service/anagrafica/getAllNationData",
    getWrapUpHashTagDetails: "/barratelefonicabe-web/service/interaction/getWrapUpHashTagDetails",
    insertAutoTrace:"/barratelefonicabe-web/service/interaction/:interactionId/transfer/trace",
    autoCompleteACWTrace:"/barratelefonicabe-web/service/interaction/:interactionId/acw/trace",
    surveyVoiceService:"/barratelefonicabe-web/service/transfertoivr/:interactionId",

  };
  
  export default ConsunUrl;
  