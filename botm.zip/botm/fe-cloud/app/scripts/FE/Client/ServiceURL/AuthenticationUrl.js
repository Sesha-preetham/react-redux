const AuthenticationUrls = {
    authenticationInfo: "/barratelefonicabe-web/service/auth/authenticationInfo",
    authValidateCodice: "/barratelefonicabe-web/service/auth/validateCodice",
    authValidatePin: "/barratelefonicabe-web/service/auth/validatePin",
    authValidatePwd: "/barratelefonicabe-web/service/auth/validatePwd",
    authValidateToken: "/barratelefonicabe-web/service/auth/validateToken",
    authValidateSms: "/barratelefonicabe-web/service/auth/validateSms",
    authValidateTokenForNewAuth: "/barratelefonicabe-web/service/auth/validateTokenForNewAuth",
    authSendSmsOtpRequest: "/barratelefonicabe-web/service/auth/sendSmsOtpRequest",
    authValidateSmsOtpRequest: "/barratelefonicabe-web/service/auth/validateSmsOtp",
    authChangePin: "/barratelefonicabe-web/service/auth/changepin",
    authUpdateState: "/barratelefonicabe-web/service/auth/authenticationstate",
    authV2Init: "/barratelefonicabe-web/service/auth/v2/init",
    authV2Validate: "/barratelefonicabe-web/service/auth/v2/validate",
    authV3Init: "/barratelefonicabe-web/service/auth/v3/init",
    authV3Validate: "/barratelefonicabe-web/service/auth/v3/validate",
    authV3Federation: "/barratelefonicabe-web/service/auth/v3/federation"
}

export default AuthenticationUrls;