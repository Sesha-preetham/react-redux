const UserSearchUrls = {
    clientsearch: "/barratelefonicabe-web/service/anagrafica/clientsearch",
    lightAuthenticationSearch: "/barratelefonicabe-web/service/anagrafica/lightAuthenticationSearch",
    clientCarte: "/barratelefonicabe-web/service/anagrafica/carte",
    clientStoricoCarte: "/barratelefonicabe-web/service/anagrafica/storicocarte",
    clientConti: "/barratelefonicabe-web/service/anagrafica/conti",
    getLastClientSearch: "/barratelefonicabe-web/service/anagrafica/lastclientsearch",
    clientPrivatoSearch:"/barratelefonicabe-web/service/anagrafica/trace/privato",
    clientEsercenteSearch:"/barratelefonicabe-web/service/anagrafica/trace/esercente",
    traceRemoteAnagrafica:"/barratelefonicabe-web/service/anagrafica/trace/remote",
    getClientMessages: "/barratelefonicabe-web/service/anagrafica/clientwarningmessage",
    posTmlSearch: "/barratelefonicabe-web/service/anagrafica/posCommissione",
    posCommissioni:"/barratelefonicabe-web/service/anagrafica/posCommissioneDettaglio",
    phoneBookContactSearch: "/barratelefonicabe-web/service/anagrafica/contactsearch/phonebook"
}
export default UserSearchUrls;
