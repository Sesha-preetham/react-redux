import BEUrls from "./ServiceURL/index";

export const isMock = false;

export const urlBase = isMock ? "http://localhost:8090" : "";
export const serviceUrls = BEUrls(urlBase);

export const pureCloudOrigin = "https://apps.mypurecloud.de";

export const parentDomain = window.location.origin;

/*export const pureCloudEmbeddedUrl = isMock
  ? `${pureCloudOrigin}/crm/index.html?crm=framework-local-secure&parentDomain=${parentDomain}`
  : `${pureCloudOrigin}/crm/embeddableFramework.html?parentDomain=${parentDomain}`;
*/
export const pureCloudEmbeddedUrl = `${pureCloudOrigin}/crm/embeddableFramework.html?parentDomain=${parentDomain}`;

export function beServiceUrls() {
  return serviceUrls;
}
