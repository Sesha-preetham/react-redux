import React, { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { withErrorBoundary } from "../../CommonComponents/ErrorBoundary/withErrorBoudary";
import AbandonRecallConfirmationModal from "../../Modules/AbandonRecall/AbandonRecallConfirmationModal";
import ExpandAbanonRecallContainer from "../../Modules/AbandonRecall/ExpandAbandonRecallContainer";
import QueueActivityManager from "../../Modules/QueueActivity/QueueActivityManager";
import SospesiCounter from "../../Modules/Sospesi/SospesiCounter";
import { httpGetSospesiCount } from "../../Modules/Sospesi/SospesiService";
import {
  getDisplayDataByCode,
  sospesiWidgetCode,
  updateWidgetMenuEventByCode,
  queueActivityCode,
  wkscWidgetCode,
  retailDeskWidgetCode,
  abandonRecallWidgetCode,
  phoneCollectionWidgetCode,
  phoneCollectionCRMWidgetCode,
} from "../../Modules/Widgets/widgetsSlice";
import WidgetWrapper from "../../Modules/Widgets/WidgetWrapper";
import {
  stackNavSospesi,
  stackNavQueueActivity,
  stackNavAbandonRecall,
  stackNavRetailDesk,
  stackNavPhoneCollection,
  stackNavWKSC,
  stackNavPhoneCollectionCRM,
} from "../StackNavigation/StackNavComponents";
import {
  stackNavPop,
  stackNavPush,
} from "../StackNavigation/stackNavigationSlice";

const TopMenuBar = (props) => {
  const dispatch = useDispatch();
  const { widgets = {} } = useSelector((state) => state.widgets);

  const [sospesiMenuEventState, , sospesiTopMenuShow] =
    getDisplayDataByCode(widgets)(sospesiWidgetCode);

  const [retailDeskMenuEventState, , retailDeskTopMenuShow] =
    getDisplayDataByCode(widgets)(retailDeskWidgetCode);

  const [wkscMenuEventState, , wkscTopMenuShow] =
    getDisplayDataByCode(widgets)(wkscWidgetCode);

  const [queueActivityEventState, , queueActivityMenuShow] =
    getDisplayDataByCode(widgets)(queueActivityCode);

  const [abandonRecallEventState, , abandonRecallMenuShow] =
    getDisplayDataByCode(widgets)(abandonRecallWidgetCode);

  const [phoneCollectionMenuEventState, , phoneCollectionTopMenuShow] =
    getDisplayDataByCode(widgets)(phoneCollectionWidgetCode);

  const [phoneCollectionCRMMenuEventState, , phoneCollectionCRMTopMenuShow] =
    getDisplayDataByCode(widgets)(phoneCollectionCRMWidgetCode);

  let handleOnClickShowContainer = (
    widgetCode = "",
    menuEventState = false
  ) => {
    dispatch(
      updateWidgetMenuEventByCode({
        widget: {
          code: widgetCode,
          menuEventState: !menuEventState,
        },
      })
    );
  };

  let handleOnClickStackNav = (stackCode = "", menuEventState = false) => {
    if (!menuEventState) {
      dispatch(stackNavPush(stackCode));
    } else {
      dispatch(stackNavPop(stackCode));
    }
  };

  

  return (
    <>
      <div className="top-menubar d-flex flex-row flex-wrap">
        <WidgetWrapper widgetShow={sospesiTopMenuShow}>
          <div
            className={`my-top-menubar-item ${
              sospesiMenuEventState ? "item-active" : ""
            }`}
            onClick={() => {
              dispatch(stackNavPop());
              if (wkscTopMenuShow) {
                dispatch(
                  updateWidgetMenuEventByCode({
                    widget: {
                      code: wkscWidgetCode ? wkscWidgetCode : "",
                      menuEventState: false,
                    },
                  })
                );
              }
              if (retailDeskTopMenuShow) {
                dispatch(
                  updateWidgetMenuEventByCode({
                    widget: {
                      code: retailDeskWidgetCode ? retailDeskWidgetCode : "",
                      menuEventState: false,
                    },
                  })
                );
              }
              if(phoneCollectionTopMenuShow){
                dispatch(
                  updateWidgetMenuEventByCode({
                    widget: {
                      code: phoneCollectionWidgetCode ? phoneCollectionWidgetCode : "",
                      menuEventState: false,
                    },
                  })
                );
              }
              if(phoneCollectionCRMTopMenuShow){
                dispatch(
                  updateWidgetMenuEventByCode({
                    widget: {
                      code: phoneCollectionCRMWidgetCode ? phoneCollectionCRMWidgetCode : "",
                      menuEventState: false,
                    },
                  })
                );
              }
              handleOnClickShowContainer(
                sospesiWidgetCode,
                sospesiMenuEventState
              );
              handleOnClickStackNav(stackNavSospesi, sospesiMenuEventState);
            }}
          >
            <span className={`my-top-menubar-nav `}>
              Sospesi{" "}
              <SospesiCounter className={"my-top-menubar-counter"} />
            </span>
          </div>
        </WidgetWrapper>
        <WidgetWrapper widgetShow={phoneCollectionCRMTopMenuShow}>
          <div
            className={`my-top-menubar-item ${
              phoneCollectionCRMMenuEventState ? "item-active" : ""
            }`} style={{width:175}}
            onClick={() => {
              dispatch(stackNavPop());
              if(wkscTopMenuShow){
                dispatch(
                  updateWidgetMenuEventByCode({
                    widget: {
                      code: wkscWidgetCode ? wkscWidgetCode : "",
                      menuEventState: false,
                    },
                  })
                );
              }
              if(retailDeskTopMenuShow){
                dispatch(
                  updateWidgetMenuEventByCode({
                    widget: {
                      code: retailDeskWidgetCode ? retailDeskWidgetCode : "",
                      menuEventState: false,
                    },
                  })
                );
              }
              if(sospesiTopMenuShow){
                dispatch(
                  updateWidgetMenuEventByCode({
                    widget: {
                      code: sospesiWidgetCode ? sospesiWidgetCode : "",
                      menuEventState: false,
                    },
                  })
                );
              }
              if(phoneCollectionTopMenuShow){
                dispatch(
                  updateWidgetMenuEventByCode({
                    widget: {
                      code: phoneCollectionWidgetCode ? phoneCollectionWidgetCode : "",
                      menuEventState: false,
                    },
                  })
                );
              }
              handleOnClickShowContainer(
                phoneCollectionCRMWidgetCode,
                phoneCollectionCRMMenuEventState
              );
              handleOnClickStackNav(stackNavPhoneCollectionCRM, phoneCollectionCRMMenuEventState);
            }}
          >
            <span className={`my-top-menubar-nav `}style={{width:125}}>Phone Collection CRM</span>
          </div>
        </WidgetWrapper>
        <WidgetWrapper widgetShow={phoneCollectionTopMenuShow}>
          <div
            className={`my-top-menubar-item ${
              phoneCollectionMenuEventState ? "item-active" : ""
            }`} style={{width:125}}
            onClick={() => {
              dispatch(stackNavPop());
              if(wkscTopMenuShow){
                dispatch(
                  updateWidgetMenuEventByCode({
                    widget: {
                      code: wkscWidgetCode ? wkscWidgetCode : "",
                      menuEventState: false,
                    },
                  })
                );
              }
              if(retailDeskTopMenuShow){
                dispatch(
                  updateWidgetMenuEventByCode({
                    widget: {
                      code: retailDeskWidgetCode ? retailDeskWidgetCode : "",
                      menuEventState: false,
                    },
                  })
                );
              }
              if(sospesiTopMenuShow){
                dispatch(
                  updateWidgetMenuEventByCode({
                    widget: {
                      code: sospesiWidgetCode ? sospesiWidgetCode : "",
                      menuEventState: false,
                    },
                  })
                );
              }
              if(phoneCollectionCRMTopMenuShow){
                dispatch(
                  updateWidgetMenuEventByCode({
                    widget: {
                      code: phoneCollectionCRMWidgetCode ? phoneCollectionCRMWidgetCode : "",
                      menuEventState: false,
                    },
                  })
                );
              }

              handleOnClickShowContainer(
                phoneCollectionWidgetCode,
                phoneCollectionMenuEventState
              );
              handleOnClickStackNav(stackNavPhoneCollection, phoneCollectionMenuEventState);
            }}
          >
            <span className={`my-top-menubar-nav `}style={{width:125}}>Phone Collection</span>
          </div>
        </WidgetWrapper>
        <WidgetWrapper widgetShow={queueActivityMenuShow}>
          <div
            className={`my-top-menubar-item ${
              queueActivityEventState ? "item-active" : ""
            }`}
            onClick={() => {
              handleOnClickShowContainer(
                queueActivityCode,
                queueActivityEventState
              );
              handleOnClickStackNav(
                stackNavQueueActivity,
                queueActivityEventState
              );
            }}
          >
            <QueueActivityManager />
            <span className={`my-top-menubar-nav `}>Monitoraggio Code</span>
          </div>
        </WidgetWrapper>
        <WidgetWrapper widgetShow={abandonRecallMenuShow}>
          <AbandonRecallConfirmationModal />
          <div
            className={`my-top-menubar-item ${
              abandonRecallEventState ? "item-active" : ""
            }`}
            onClick={() => {
              handleOnClickShowContainer(
                abandonRecallWidgetCode,
                abandonRecallEventState
              );
              handleOnClickStackNav(
                stackNavAbandonRecall,
                abandonRecallEventState
              );
            }}
          >
            <span className={`my-top-menubar-nav `}>Gestione Abbandonate</span>
          </div>
        </WidgetWrapper>
        <WidgetWrapper widgetShow={retailDeskTopMenuShow}>
          <div
            className={`my-top-menubar-item ${
              retailDeskMenuEventState ? "item-active" : ""
            }`}
            onClick={() => {
              dispatch(stackNavPop());
              if (wkscTopMenuShow) {
                dispatch(
                  updateWidgetMenuEventByCode({
                    widget: {
                      code: wkscWidgetCode ? wkscWidgetCode : "",
                      menuEventState: false,
                    },
                  })
                );
              }
              if (sospesiTopMenuShow) {
                dispatch(
                  updateWidgetMenuEventByCode({
                    widget: {
                      code: sospesiWidgetCode ? sospesiWidgetCode : "",
                      menuEventState: false,
                    },
                  })
                );
              }
              if(phoneCollectionTopMenuShow){
                dispatch(
                  updateWidgetMenuEventByCode({
                    widget: {
                      code: phoneCollectionWidgetCode ? phoneCollectionWidgetCode : "",
                      menuEventState: false,
                    },
                  })
                );
              }
              if(phoneCollectionCRMTopMenuShow){
                dispatch(
                  updateWidgetMenuEventByCode({
                    widget: {
                      code: phoneCollectionCRMWidgetCode ? phoneCollectionCRMWidgetCode : "",
                      menuEventState: false,
                    },
                  })
                );
              }
              handleOnClickShowContainer(
                retailDeskWidgetCode,
                retailDeskMenuEventState
              );
              handleOnClickStackNav(
                stackNavRetailDesk,
                retailDeskMenuEventState
              );
            }}
          >
            <span className={`my-top-menubar-nav `}>Retail Desk</span>
          </div>
        </WidgetWrapper>
        <WidgetWrapper widgetShow={wkscTopMenuShow}>
          <div
            className={`my-top-menubar-item ${
              wkscMenuEventState ? "item-active" : ""
            }`}
            onClick={() => {
              dispatch(stackNavPop());
              if (retailDeskTopMenuShow) {
                dispatch(
                  updateWidgetMenuEventByCode({
                    widget: {
                      code: retailDeskWidgetCode ? retailDeskWidgetCode : "",
                      menuEventState: false,
                    },
                  })
                );
              }
              if (sospesiTopMenuShow) {
                dispatch(
                  updateWidgetMenuEventByCode({
                    widget: {
                      code: sospesiWidgetCode ? sospesiWidgetCode : "",
                      menuEventState: false,
                    },
                  })
                );
              }
              if(phoneCollectionTopMenuShow){
                dispatch(
                  updateWidgetMenuEventByCode({
                    widget: {
                      code: phoneCollectionWidgetCode ? phoneCollectionWidgetCode : "",
                      menuEventState: false,
                    },
                  })
                );
              }
              if(phoneCollectionCRMTopMenuShow){
                dispatch(
                  updateWidgetMenuEventByCode({
                    widget: {
                      code: phoneCollectionCRMWidgetCode ? phoneCollectionCRMWidgetCode : "",
                      menuEventState: false,
                    },
                  })
                );
              }
              handleOnClickShowContainer(wkscWidgetCode, wkscMenuEventState);
            }}
          >
            <span className={`my-top-menubar-nav `}>WKSC</span>
          </div>
        </WidgetWrapper>
      </div>
    </>
  );
};

export default withErrorBoundary(TopMenuBar);
