import React from "react";
import { useDispatch, useSelector } from "react-redux";
import {
  anagraficaWidgetCode,
  consuntivazioneWidgetCode,
  conversazioneWidgetCode,
  getDisplayDataByCode,
  softphoneCommonCode,
  updateWidgetMenuEventByCode,
} from "../../Modules/Widgets/widgetsSlice";
import WidgetWrapper from "../../Modules/Widgets/WidgetWrapper";

const LeftSideBar = (props) => {
  const dispatch = useDispatch();
  const { widgets } = useSelector((state) => state.widgets);

  const [softphoneMenuShow] = getDisplayDataByCode(widgets)(
    softphoneCommonCode
  );
  const [anagraficaMenuShow, anagraficaShow] = getDisplayDataByCode(widgets)(
    anagraficaWidgetCode
  );
  const [consuntivazioneMenuShow, consuntivazioneShow] = getDisplayDataByCode(
    widgets
  )(consuntivazioneWidgetCode);
  const [conversazioneMenuShow, conversazioneShow] = getDisplayDataByCode(
    widgets
  )(conversazioneWidgetCode);

  let handleOnClickShowContainer = (
    widgetCode = "",
    menuEventState = false
  ) => {
    dispatch(
      updateWidgetMenuEventByCode({
        widget: {
          code: widgetCode,
          menuEventState: !menuEventState,
        },
      })
    );
  };

  return (
    <>
      <div className="right-sidebar shadow-sm">
        <div
          className="my-sidebar-item"
          onClick={() => {
            handleOnClickShowContainer(softphoneCommonCode, softphoneMenuShow);
          }}
        >
          <svg
            xmlns="http://www.w3.org/2000/svg"
            width="16"
            height="16"
            fill="currentColor"
            className={`bi bi-chevron-double-left my-sidebar-icon ${
              softphoneMenuShow ? "" : "softphone-rotate"
            }`}
            viewBox="0 0 16 16"
          >
            <path
              fillRule="evenodd"
              d="M8.354 1.646a.5.5 0 0 1 0 .708L2.707 8l5.647 5.646a.5.5 0 0 1-.708.708l-6-6a.5.5 0 0 1 0-.708l6-6a.5.5 0 0 1 .708 0z"
            />
            <path
              fillRule="evenodd"
              d="M12.354 1.646a.5.5 0 0 1 0 .708L6.707 8l5.647 5.646a.5.5 0 0 1-.708.708l-6-6a.5.5 0 0 1 0-.708l6-6a.5.5 0 0 1 .708 0z"
            />
          </svg>
        </div>

        <div className="my-sidebar-item">
          <svg
            xmlns="http://www.w3.org/2000/svg"
            width="16"
            height="16"
            fill="currentColor"
            className={`bi bi-grid-fill my-sidebar-icon my-sidebar-active`}
            viewBox="0 0 16 16"
          >
            <path d="M1 2.5A1.5 1.5 0 0 1 2.5 1h3A1.5 1.5 0 0 1 7 2.5v3A1.5 1.5 0 0 1 5.5 7h-3A1.5 1.5 0 0 1 1 5.5v-3zm8 0A1.5 1.5 0 0 1 10.5 1h3A1.5 1.5 0 0 1 15 2.5v3A1.5 1.5 0 0 1 13.5 7h-3A1.5 1.5 0 0 1 9 5.5v-3zm-8 8A1.5 1.5 0 0 1 2.5 9h3A1.5 1.5 0 0 1 7 10.5v3A1.5 1.5 0 0 1 5.5 15h-3A1.5 1.5 0 0 1 1 13.5v-3zm8 0A1.5 1.5 0 0 1 10.5 9h3a1.5 1.5 0 0 1 1.5 1.5v3a1.5 1.5 0 0 1-1.5 1.5h-3A1.5 1.5 0 0 1 9 13.5v-3z" />
          </svg>
        </div>
        <WidgetWrapper widgetShow={anagraficaShow}>
          <div
            className="my-sidebar-item"
            onClick={() => {
              handleOnClickShowContainer(
                anagraficaWidgetCode,
                anagraficaMenuShow
              );
            }}
          >
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="16"
              height="16"
              fill="currentColor"
              className={`bi bi-person-lines-fill my-sidebar-icon ${
                anagraficaMenuShow ? "my-sidebar-active" : ""
              }`}
              viewBox="0 0 16 16"
            >
              <path d="M6 8a3 3 0 1 0 0-6 3 3 0 0 0 0 6zm-5 6s-1 0-1-1 1-4 6-4 6 3 6 4-1 1-1 1H1zM11 3.5a.5.5 0 0 1 .5-.5h4a.5.5 0 0 1 0 1h-4a.5.5 0 0 1-.5-.5zm.5 2.5a.5.5 0 0 0 0 1h4a.5.5 0 0 0 0-1h-4zm2 3a.5.5 0 0 0 0 1h2a.5.5 0 0 0 0-1h-2zm0 3a.5.5 0 0 0 0 1h2a.5.5 0 0 0 0-1h-2z" />
            </svg>
          </div>
        </WidgetWrapper>
        <WidgetWrapper widgetShow={consuntivazioneShow}>
          <div
            className="my-sidebar-item"
            onClick={() => {
              handleOnClickShowContainer(
                consuntivazioneWidgetCode,
                consuntivazioneMenuShow
              );
            }}
          >
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="16"
              height="16"
              fill="currentColor"
              className={`bi bi-layers-fill my-sidebar-icon ${
                consuntivazioneMenuShow ? "my-sidebar-active" : ""
              }`}
              viewBox="0 0 16 16"
            >
              <path d="M7.765 1.559a.5.5 0 0 1 .47 0l7.5 4a.5.5 0 0 1 0 .882l-7.5 4a.5.5 0 0 1-.47 0l-7.5-4a.5.5 0 0 1 0-.882l7.5-4z" />
              <path d="M2.125 8.567l-1.86.992a.5.5 0 0 0 0 .882l7.5 4a.5.5 0 0 0 .47 0l7.5-4a.5.5 0 0 0 0-.882l-1.86-.992-5.17 2.756a1.5 1.5 0 0 1-1.41 0l-5.17-2.756z" />
            </svg>
          </div>
        </WidgetWrapper>
        <WidgetWrapper widgetShow={conversazioneShow}>
          <div
            className="my-sidebar-item"
            onClick={() => {
              handleOnClickShowContainer(
                conversazioneWidgetCode,
                conversazioneMenuShow
              );
            }}
          >
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="16"
              height="16"
              fill="currentColor"
              className={`bi bi-file-richtext-fill my-sidebar-icon ${
                conversazioneMenuShow ? "my-sidebar-active" : ""
              }`}
              viewBox="0 0 16 16"
            >
              <path d="M12 0H4a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h8a2 2 0 0 0 2-2V2a2 2 0 0 0-2-2zM7 4.25a.75.75 0 1 1-1.5 0 .75.75 0 0 1 1.5 0zm-.861 1.542l1.33.886 1.854-1.855a.25.25 0 0 1 .289-.047l1.888.974V7.5a.5.5 0 0 1-.5.5H5a.5.5 0 0 1-.5-.5V7s1.54-1.274 1.639-1.208zM5 9h6a.5.5 0 0 1 0 1H5a.5.5 0 0 1 0-1zm0 2h3a.5.5 0 0 1 0 1H5a.5.5 0 0 1 0-1z" />
            </svg>
          </div>
        </WidgetWrapper>
      </div>
    </>
  );
};

export default LeftSideBar;
