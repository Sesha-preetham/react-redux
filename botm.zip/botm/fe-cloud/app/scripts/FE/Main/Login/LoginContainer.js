import React from "react";
import { useHistory } from "react-router-dom";

import signbanner from "../../../../assets/images/signin-banner.png";
import signbannerx2 from "../../../../assets/images/signin-banner@2x.png";
import signbannerx3 from "../../../../assets/images/signin-banner@3x.png";

import sellalogo from "../../../../assets/images/header_logo.png";

import username from "../../../../assets/images/username.png";
import usernamex2 from "../../../../assets/images/username@2x.png";
import usernamex3 from "../../../../assets/images/username@3x.png";

import password from "../../../../assets/images/password.png";
import passwordx2 from "../../../../assets/images/password@2x.png";
import passwordx3 from "../../../../assets/images/password@3x.png";
import axios from "axios";
import { beServiceUrls } from "../../Client/ClientProperties";

const LoginContainer = (props) => {
  let history = useHistory();

  let handleOnClick = () => {
    console.log(beServiceUrls().authenticate);
    axios
      .post(beServiceUrls().authenticate, {
        username: "sandy",
        password: "password123",
      })
      .then((response) => {
        if (response && response.data && response.data.token) {
          const AUTH_TOKEN = response.data.token;
          axios.defaults.headers.common["Authorization"] = AUTH_TOKEN;
          history.replace("/web/dashboard");
        }
      })
      .catch((err) => {
        console.error(err);
      });
  };

  return (
    <div className="login">
      <div className="row no-gutters">
        <div className="col-7">
          <img
            src={signbanner}
            srcSet={`${signbannerx2} 2x,${signbannerx3} 3x`}
            className="Signin_Banner"
          />
        </div>
        <div className="col-5">
          <div className="row justify-content-end">
            <div className="col-3">
              <img
                src={sellalogo}
                srcSet={`${sellalogo} 2x,${sellalogo} 3x`}
                className="Group-26"
              />
            </div>
          </div>
          <div className="row justify-content-center align-items-center login-input-group">
            <div className="col-8">
              <div className="input-group flex-nowrap mb-4">
                <div className="input-group-prepend">
                  <span
                    className="input-group-text bg-white rounded-0"
                    id="addon-wrapping"
                  >
                    <img
                      src={username}
                      srcSet={`${usernamex2} 2x,${usernamex3} 3x`}
                      className="Username"
                    />
                  </span>
                </div>
                <input
                  type="text"
                  className="form-control input-field bg-white rounded-0"
                  placeholder="Username"
                  aria-label="Username"
                  aria-describedby="addon-wrapping"
                />
              </div>
              <div className="input-group flex-nowrap mb-4">
                <div className="input-group-prepend">
                  <span
                    className="input-group-text bg-white rounded-0"
                    id="addon-wrapping"
                  >
                    <img
                      src={password}
                      srcSet={`${passwordx2} 2x,${passwordx3} 3x`}
                      className="Password"
                    />
                  </span>
                </div>
                <input
                  type="password"
                  className="form-control input-field bg-white rounded-0"
                  placeholder="Password"
                  aria-label="Password"
                  aria-describedby="addon-wrapping"
                />
              </div>
              <button
                type="button"
                className="btn col-12 rounded-0 Login_Button mb-4"
                onClick={handleOnClick}
              >
                <span className="Login_Text">LOG IN</span>
              </button>
              <div className="text-right">
                <a href="#" className="Forgotpassword">
                  Forgotpassword ?
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default LoginContainer;
