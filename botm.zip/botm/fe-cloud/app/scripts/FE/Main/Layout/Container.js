import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { CSSTransition } from "react-transition-group";
import { withErrorBoundary } from "../../CommonComponents/ErrorBoundary/withErrorBoudary";
import PreviewAnagraficaContainer from "../../Modules/Anagrafica/PreviewAnagraficaContainer";
import PreviewSupportContainer from "../../Modules/BPASupport/PreviewSupportContainer";
import PreviewHDCContainer from "../../Modules/Anagrafica/Components/HDCWidget/PreviewHDCContainer";
import PreviewLeasingContainer from "../../Modules/Anagrafica/Components/SellaLeasing/PreviewLeasingContainer";
import PreviewConsunMainContainer from "../../Modules/Consuntivazione/PreviewConsunMainContainer";
import PreviewEsitoWidgetContainer from "../../Modules/PhoneCollection/EsitoWidgetComponents/PreviewEsitoWidgetContainer";
import SimpleConversationContainer from "../../Modules/Conversation/SimpleConversationContainer";
import PreviewMotivoContattoHDC from "../../Modules/Anagrafica/Components/HDCWidget/PreviewMotivoContattoHDC";
import LightAuthenticationModal from "../../Modules/LightAuthentication/Container";
import PreviewStoricoContainer from "../../Modules/StoricoConversazione/PreviewStoricoContainer";
import StackElementWrapper from "../StackNavigation/StackElementWrapper";
import ExpandedWKSCContainer from "../../Modules/RetailDesk/ExpandedWKSCContainer";
import WidgetWrapper from "../../Modules/Widgets/WidgetWrapper";
import {
  auviousWidgetCode,
  getDisplayDataByCode,
  wkscWidgetCode,
} from "../../Modules/Widgets/widgetsSlice";
import { AuviousInternalContainer } from "../../Modules/Auvious/AuviousContainer";
import { getInternalWidgetByIdAndCode } from "../../Modules/Widgets/internalWidgetsSlice";

const leftSideNavCodes = {
  conversation: "CONVERSATION",
  auvious: "AUVIOUS",
  wksc: "WKSC",
};

const Container = (props) => {
  const { elStack = {} } = props;
  const [expandConversation, setExpandConversation] = useState(false);
  const [expandAuvious, setExpandAuvious] = useState(false);
  const [expandWKSC, setExpandWKSC] = useState(false);
  const [expandLeftSection, setExpandLeftSection] = useState(false);

  // to handle the component that we need to hide without destroy/create component (display-none-class)
  const defaultLeftSiceActiveNav = leftSideNavCodes.conversation;
  const [leftSideActiveNav, setLeftSideNav] = useState(
    defaultLeftSiceActiveNav
  );

  const { widgets } = useSelector((state) => state.widgets);

  const [wkscMenuEventState, , wkscTopMenuShow] =
    getDisplayDataByCode(widgets)(wkscWidgetCode);

  const [auviousMenuShow, auviousWidgetShow] =
    getDisplayDataByCode(widgets)(auviousWidgetCode);

  /* on WKSC menu click change the state */
  useEffect(() => {
    if (wkscMenuEventState) setLeftSideNav(leftSideNavCodes.wksc);
    else setLeftSideNav(defaultLeftSiceActiveNav);
    setExpandLeftSection(wkscMenuEventState);
  }, [wkscMenuEventState]);

  return (
    <StackElementWrapper elStack={elStack}>
      <div className="d-flex flex-fill">
        <div className="flex-fill sections-center-container">
          <div className="row no-gutters h-100 p-3">
            <div
              className={`col-12 d-flex flex-column 
                ${
                  leftSideActiveNav !== leftSideNavCodes.conversation &&
                  expandLeftSection
                    ? "display-none-class"
                    : ""
                }
                `}
            >
              {/* <NotificationContainer /> */}
              {/* <PreviewConversationContainer /> */}
              <>
                <SimpleConversationContainer
                  expandConversation={expandLeftSection}
                  setExpandConversation={setExpandLeftSection}
                  onExpand={() => {
                    setLeftSideNav(leftSideNavCodes.conversation);
                  }}
                />
                <PreviewStoricoContainer />
              </>
            </div>

            <WidgetWrapper widgetShow={auviousWidgetShow}>
              <AuviousInternalContainer
                additionalClass={`col-12 d-flex flex-column 
                  ${
                    expandLeftSection &&
                    leftSideActiveNav !== leftSideNavCodes.auvious
                      ? "display-none-class"
                      : ""
                  }
                  `}
                expandConfig={{
                  expand: expandLeftSection,
                  setExpand: setExpandLeftSection,
                  onExpand: () => {
                    setLeftSideNav(leftSideNavCodes.auvious);
                  },
                }}
              />
            </WidgetWrapper>

            <WidgetWrapper widgetShow={wkscTopMenuShow}>
              <div
                className={`col-12 d-flex flex-column 
                ${
                  !wkscMenuEventState ||
                  (leftSideActiveNav !== leftSideNavCodes.wksc &&
                    expandLeftSection)
                    ? "display-none-class"
                    : ""
                }
                `}
              >
                <ExpandedWKSCContainer
                  expandWKSC={expandLeftSection}
                  setExpandWKSC={setExpandLeftSection}
                />
              </div>
            </WidgetWrapper>
          </div>
        </div>
        <CSSTransition
          in={!expandLeftSection}
          timeout={300}
          classNames="slide-right-toggle"
          unmountOnExit={false}
          mountOnEnter={true}
        >
          <div className="flex-grow-0 section-right-container">
            <div className="d-flex flex-column h-100 py-3 pr-3">
              <PreviewAnagraficaContainer />
              <PreviewHDCContainer/>
              <PreviewLeasingContainer/>
              <PreviewEsitoWidgetContainer />
              <PreviewConsunMainContainer />
              <PreviewMotivoContattoHDC />
              <PreviewSupportContainer />
            </div>
          </div>
        </CSSTransition>
        <LightAuthenticationModal />
      </div>
    </StackElementWrapper>
  );
};

export default withErrorBoundary(Container);
