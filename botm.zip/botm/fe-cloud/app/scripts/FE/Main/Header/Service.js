import { pureCloudOrigin } from "../../Client/ClientProperties";
import { exposedDispatch } from "../../Store/store";
import { setUserStatus } from "../../Store/preferenceSlice";

const Service = () => {
  const dispatch = exposedDispatch;
  const userEventListener = (event) => {
    // console.log("userEventListener",event)
    if (event.origin == pureCloudOrigin) {
      let message = JSON.parse(event.data);
      if (message && message.type == "userActionSubscription") {
        console.log("userActionSubscription", message);
        let { data: userStatusData = {} } = message;
        let { category = "", data = {} } = userStatusData;
        if (category === "status") {
          dispatch(
            setUserStatus({
              data: data,
            })
          );
        }
      }
    }
  };

  return { userEventListener };
};

export const { userEventListener } = Service();
