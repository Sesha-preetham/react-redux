import React from "react";
import MyModal from "../../../../CommonComponents/Modal/MyModal";
import SimpleTable from "../../../../CommonComponents/SimpleTable/SimpleTable";

const MultiClienteModal = ({
  showMultiClienteModal = false,
  handleOnCloseModal = () => {},
  handleSelectedClient = () => {},
  modalData = []
}) => {

  const multiClienteModal = {
    uniqueID: "multiClienteModal",
    modalClass: "multi-cliente-modal my-modal",
    dialogClassName: "modal-w",
    title: {
      content: "Ricerca utente",
      class: "widget-title",
    },
    modalShow: showMultiClienteModal,
    modalHeaderShow: true,
    backdrop: {
      enable: true,
    },
    events: {
      onHide: () => {
        handleOnhide();
      },
      onEntered: () => {
        console.log("multiClienteModal modal onEntered");
      },
      onExited: () => {
        console.log("multiClienteModal modal onExited");
      },
    },
  };


  let simpleTableConfiguration = {
    uniqueID: "simpleTableConfiguration",
    metaData: [
      {
        Header: "Cliente",
        accessor: "client",
      },
      {
        Header: "Data",
        accessor: "data",
      },
      {
        Header: "Codice Fiscale",
        accessor: "codiceFiscale",
      },
      {
        Header: "Id Soggetto",
        accessor: "idSoggetto",
      }
    ],
    data: (modalData)?modalData:[],
    events: {
      onRowClick: handleSelectedClient
    }
  };

  let handleOnhide = () => {
    console.log("insertMediaType modal onHide");
    handleOnCloseModal(false);
  };

  return (
    <MyModal configuration={multiClienteModal}>
      <div className="d-flex">
        <div className="w-100">
          <SimpleTable configuration={simpleTableConfiguration} />
        </div>
      </div>
    </MyModal>
  );
};

export default MultiClienteModal;
