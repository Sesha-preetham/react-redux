import React, { useEffect, useState } from "react";
import { useSelector } from "react-redux";
import { withErrorBoundary } from "../../../CommonComponents/ErrorBoundary/withErrorBoudary";
import MyPopover from "../../../CommonComponents/Popover/MyPopover";
import { userEventListener } from "../Service";

const Container = (props) => {
  const { profile, userStatus } = useSelector((state) => state.preference);

  const [showProfileData, setShowProfileData] = useState(false);

  useEffect(() => {
    window.addEventListener("message", userEventListener, false);
    return () => {
      window.removeEventListener("message", userEventListener, false);
    };
  }, []);

  const profileImage = profile.imageUri || 'https://dhqbrvplips7x.cloudfront.net/directory/10.67.0-4/assets/images/svg/person.svg';

  return (
    <>
      <div className="profile">
        <div className="nickname">{profile.nickName}</div>
        <div className="title">{profile.id}</div>
      </div>

      <MyPopover
        configuration={{
          uniqueID: "profileDashboard",
          popoverShow: showProfileData,
          popoverPlacement: "bottom-start",
          popoverClass: "profile-container",
          overlayTriggerElement: (
            <button
              type="button"
              className="btn avatar-button rounded-0"
              onClick={() => {
                setShowProfileData(!showProfileData);
              }}
            >
              <img
                src={profileImage}
                srcSet={`${profileImage} 2x,${profileImage} 3x`}
                className={`avatar ${
                  userStatus && userStatus !== null ? userStatus : ""
                }`}
              />
            </button>
          ),
        }}
      >
        <div className="d-flex flex-column">
          <div className="row no-gutters justify-content-center">
            <div>
              <img
                src={profileImage}
                srcSet={`${profileImage} 2x,${profileImage} 3x`}
                className={`avatar ${
                  userStatus && userStatus !== null ? userStatus : ""
                }`}
              />
            </div>
          </div>
          <div className="row no-gutters justify-content-center">
            <div className="col-8 text-center text-capitalize font-weight-bolder">
              {profile.name}
            </div>
          </div>
          <div className="row no-gutters justify-content-center">
            <div className="col-8 text-center text-capitalize font-size-10">
              {profile.id}
            </div>
          </div>
          <div className="row no-gutters justify-content-center">
            <div className="col-8 text-center text-capitalize font-size-12">
              {profile.title}
            </div>
          </div>
        </div>
      </MyPopover>
    </>
  );
};

export default withErrorBoundary(Container);
