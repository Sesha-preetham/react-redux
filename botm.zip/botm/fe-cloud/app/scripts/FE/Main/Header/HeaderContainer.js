import React from "react";
import TopMenuBar from "../MenuBar/TopMenuBar";
import Logo from "./Logo/Container";
import Profile from "./Profile/Container";
import UserSeacrch from "./UserSearch/Container";

const HeaderContainer = (props) => {
  return (
    <div className="header">
      <nav className="navbar navbar-expand-lg navbar-light bg-white">
        <Logo />
        <span className="mr-auto"></span>
        <TopMenuBar />
        <UserSeacrch />
        {/* <span>
          <img src={group4} className="Group-4" />
        </span> */}
        <Profile />
      </nav>
    </div>
  );
};

export default HeaderContainer;
