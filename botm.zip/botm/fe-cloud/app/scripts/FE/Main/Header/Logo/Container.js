import React from "react";
import { useSelector } from "react-redux";
import sellalogo from "../../../../../assets/images/header_logo.png";
import bpalogo from "../../../../../assets/images/header_logo_bpa@2x.png";
import cntlogo from "../../../../../assets/images/Centrico-logo.png"

const Container = (props) => {

  const { organization = {}} = useSelector((state) => state.preference.profile);
  const { code } = organization; 

  let logo;
  if(code === "BSE"){
    logo = sellalogo;
  }else if(code === "BPA"){
    logo = bpalogo;
  }else if(code === "CNT" || code === "CNT_CC"){
    logo = cntlogo;
  }

  return (
    <div className="logo">
      <img
        src={logo}
        srcSet={`${logo} 2x,${logo} 3x`}
        className="logo-image"
      />
    </div>
  );
};

export default Container;
