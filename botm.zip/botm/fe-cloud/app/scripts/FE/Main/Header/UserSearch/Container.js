import React, { useEffect, useState } from "react";
import { useSelector } from "react-redux";
import { withErrorBoundary } from "../../../CommonComponents/ErrorBoundary/withErrorBoudary";
import FormFieldHandler from "../../../CommonComponents/Forms/FormFieldHandler";
import SelectField from "../../../CommonComponents/Forms/SelectField";
import TextField from "../../../CommonComponents/Forms/TextField";
import MyPopover from "../../../CommonComponents/Popover/MyPopover";
import { clearAnagraficaData, getCurrentTabKeyByInteraction, setCurrentTabKey, } from "../../../Modules/Anagrafica/anagraficaSlice";
import { getInteractionDetails } from "../../../Modules/Interaction/interactionSlice";
import { exposedDispatch } from "../../../Store/store";
import {
  httpGetClientSearchType,
  httpGetVisibleBanks,
  isCustomFunctionAvailable,
} from "../../../Utils/CommonUtil";
import MultiClienteModal from "./Modal/MultiClienteModal";
import {
  //httpGetCarteSearch,
  //httpGetStoricoCarteSearch,
  //httpGetContiSearch,
  httpPostClientSearch,
} from "./Service";
import {
  customFunctionCodes
} from "../../../Store/commonSlice";
import { httpGetTmlId , httpGetPosCommissioni  } from "../../../Main/Header/UserSearch/Service";
import { privatoWidgetCode } from "../../../Modules/Widgets/internalWidgetsSlice";
import { setIdSoggetto } from "../../../Store/preferenceSlice";

const Container = (props) => {
  const [showSearchPopover, setShowSearchPopover] = useState(false);
  const [showMultiClienteModal, setShowMultiClienteModal] = useState(false);
  const [userSearchBtnEnabled, setUserSearchBtnEnabled] = useState(true);

  // FormFieldHandler to true for refreshing fields when a new field that already exists is added.
  const [formFields] = useState(new FormFieldHandler(true));

  const {
    currentInteraction = "noInteraction",
    interactions = [],
  } = useSelector((state) => state.interaction);

  const {
    grantedCustomFunction = []
  } = useSelector((state) => state.common);

  const { widgets } = useSelector((state) => state.widgets);

  const { anagrafica = {} } = useSelector((state) => state.anagrafica);
  const { queueName = undefined, attributes = {}, intxId, barraDivisionId: intxDivisionId } = getInteractionDetails(
    interactions
  )(currentInteraction);

  const { barraDivisionId: preferenceBarraDivisionId } = useSelector((state) => state.preference.profile);

  //const localCurrentInteraction = useRef();
  //localCurrentInteraction.current=currentAnagraficaInteraction;

  const [multipleClientData, setMultipleClientData] = useState([]);

  let banksField = {
    uniqueID: "banksField",
    multiSelect: false,
    label: "",
    placeHolder: "Seleziona la Banca",
    readonly: false,
    visible: true,
    disabled: false,
    options: [],
    searchEnabled: true,
    setValue: (obj) => {
      console.log("setValue", obj);
    },
    form: formFields,
  };

  let dataSearchField = {
    uniqueID: "dataSearchField",
    multiSelect: false,
    label: "",
    placeHolder: "Seleziona il dato da ricercare",
    readonly: false,
    visible: true,
    disabled: false,
    options: [],
    searchEnabled: true,
    setValue: (obj) => {
      console.log("setValue", obj);
    },
    form: formFields,
  };

  let ricercaCodiceFiscaleField = {
    uniqueID: "ricercaCodiceFiscale",
    placeHolder: "Inserisci valore da ricercare",
    readonly: false,
    visible: true,
    validation: {
      mandatory: true,
      type: "Alphanumeric",
    },callBackOnKeyUp: (event, obj) => {
      if(event!="undefined" && event.keyCode==13){
        console.log("callBackOnKeyUp Event :"+obj.currentValue);
        handleOnClickCercaUtente();
      }
    },  
    form: formFields,
  };

  const setDefaultOptionOnForm = (options, fieldName) => {
    let defaultOption = undefined;
    for (let i = 0; i < options.length; i++) {
      const { rlData = {} } = options[i];
      const { default: def = false } = rlData;
      if (def === true) {
        defaultOption = options[i];
        break;
      }
    }
    if (defaultOption) {
      formFields.getField(fieldName).theField.setValue(defaultOption);
    }
  };

  useEffect(() => {
    const divisionId = intxDivisionId || preferenceBarraDivisionId;
    if (showSearchPopover) {
      httpGetVisibleBanks({
        divisionId
      }).then((options) => {
        formFields.getField("banksField").theField.reloadOptions(options);
        setDefaultOptionOnForm(options, "banksField");
      });
      httpGetClientSearchType({
        divisionId
      }).then((options) => {
        formFields.getField("dataSearchField").theField.reloadOptions(options);
        setDefaultOptionOnForm(options, "dataSearchField");
      });
    }
  }, [showSearchPopover]);

  useEffect(() => {
    let cfDisableSearch = isCustomFunctionAvailable(customFunctionCodes().disableSearchWithoutInteraction);
    console.log("cfDisableSearch -> ", cfDisableSearch);
    if(cfDisableSearch && currentInteraction === "noInteraction"){
      setUserSearchBtnEnabled(false);
    }else{
      setUserSearchBtnEnabled(true);
    }
  }, [grantedCustomFunction, currentInteraction]);


  let handleOnClickRicercaUtente = () => {
    setShowSearchPopover(!showSearchPopover);
  };

  let searchClient = (request) => {
    httpPostClientSearch(request).then((response) => {
      if (
        response &&
        response.multipleClient &&
        response.multipleClientFound === true
      ) {
        handleOnModal(response.multipleClient);
      } else {
        if (showSearchPopover === true)
          setShowSearchPopover(!showSearchPopover);
        if (showMultiClienteModal === true)
          setShowMultiClienteModal(!showMultiClienteModal);
      } /*else if (
        response &&
        response.multipleClientFound !== true &&
        response.privato &&
        response.privato[0]
      ) {
        const { idSoggetto = ""} = response.privato[0];
        if (idSoggetto !== "") {
          httpGetCarteSearch({ idSoggetto: idSoggetto, abicode: abicode, interactionId: currentI,});
          httpGetStoricoCarteSearch({
            idSoggetto: idSoggetto,
            interactionId: currentI,
            abicode: abicode
          })
        }
      }*/
      if (
        response &&
        response.multipleClientFound !== true &&
        response.privato &&
        response.privato[0] 
      ) {
        const { idSoggetto = ""} = response.privato[0];
        if (idSoggetto !== "") {
          const dispatch = exposedDispatch;
          dispatch(setIdSoggetto({idSoggettoValue: idSoggetto}));
        }
      }

      if( response && response.azienda && response.azienda.length > 0 ){

        const {
          esercenteId = "",
          codAgente = "",
        } = response.azienda[0] || {};
    
        if(currentInteraction && esercenteId && codAgente && esercenteId!= null && codAgente!= null ){
          httpGetTmlId({esercenteId: esercenteId,
          codAgente: codAgente,
          interactionId: currentInteraction
        });
      }

      if(currentInteraction && esercenteId && esercenteId != null){
         httpGetPosCommissioni({
          esercenteId: esercenteId,
          interactionId: currentInteraction
        });
      }
    }
    });
  };

  let handleOnClickCercaUtente = () => {
    const dispatch = exposedDispatch;
    const tabKey = getCurrentTabKeyByInteraction(anagrafica)(
      currentInteraction
    );
    dispatch(clearAnagraficaData({ interactionId: currentInteraction, currentTabKey: tabKey ? tabKey != null ? tabKey : privatoWidgetCode  : privatoWidgetCode }));

    console.log(formFields.getFields());
    let { rlData: bankRlData = {} } = formFields
      .getField("banksField")
      .theField.getValue();
    let { rlData: searchTypeData = {} } = formFields
      .getField("dataSearchField")
      .theField.getValue();
    let ricercaCodiceFiscaleValue = formFields
      .getField("ricercaCodiceFiscale")
      .theField.getValue();

    const { x_servizio } = attributes;
    let toUseInteraction =
      currentInteraction !== "noInteraction" ? currentInteraction : undefined;
    searchClient({
      searchType: searchTypeData.code,
      abiCode: bankRlData.abicode,
      value: ricercaCodiceFiscaleValue,
      interactionId: toUseInteraction,
      queueName: queueName,
      service: x_servizio,
      intxId: intxId
    });

    console.log(
      "handleOnClickCercaUtente End: ",
      bankRlData,
      searchTypeData,
      ricercaCodiceFiscaleValue
    );
  };

  let handleSelectedClient = (rowData) => {
    console.log("handleRowClick", rowData);
    const { original = {} } = rowData;
    // take bank from previous search (inserted on form)
    let { rlData: bankRlData = {} } = formFields
      .getField("banksField")
      .theField.getValue();
    const { idSoggetto = "" } = original;
    const { x_servizio } = attributes;
    let toUseInteraction =
      currentInteraction !== "noInteraction" ? currentInteraction : undefined;
    searchClient({
      searchType: "idSoggetto",
      value: idSoggetto,
      interactionId: toUseInteraction,
      queueName: queueName,
      abiCode: bankRlData.abicode,
      service: x_servizio,
      intxId: intxId
    });
  };

  let handleOnModal = (multipleClientData) => {
    setShowSearchPopover(!showSearchPopover);
    if (multipleClientData) {
      setMultipleClientData(multipleClientData);
      setShowMultiClienteModal(!showMultiClienteModal);
    }
  };

  let handleOnMultiClientModal = () => {
    setShowMultiClienteModal(!showMultiClienteModal);
    setMultipleClientData([]);
  };

  return (
    <>
      <MultiClienteModal
        showMultiClienteModal={showMultiClienteModal}
        handleOnCloseModal={handleOnMultiClientModal}
        handleSelectedClient={handleSelectedClient}
        modalData={multipleClientData}
      />
      <div className="d-flex flex-wrap header-search">
        <div className="row no-gutters">
          <div className="col-12">
            <MyPopover
              configuration={{
                uniqueID: "globalSearchPopover",
                popoverShow: showSearchPopover,
                popoverPlacement: "left",
                popoverClass: "header-search-popover",
                overlayTriggerElement: (
                  <button
                    type="button"
                    disabled={!userSearchBtnEnabled}
                    className={`btn Rectangle-Button-White w-100 ${
                      showSearchPopover ? "ricerca-utente-active" : ""
                    }`}
                    onClick={handleOnClickRicercaUtente}
                  >
                    Ricerca utente
                  </button>
                ),
              }}
            >
              <div className="d-flex flex-column header-search-content">
                <div className="row no-gutters mb-3">
                  <div className="col-12">
                    <span className="title">Ricerca utente</span>
                  </div>
                </div>
                <div className="row no-gutters">
                  <div className="col-12">
                    <SelectField configuration={banksField} />
                  </div>
                </div>
                <div className="row no-gutters">
                  <div className="col-12">
                    <SelectField configuration={dataSearchField} />
                  </div>
                </div>
                <div className="row no-gutters">
                  <div className="col-12">
                    <TextField configuration={ricercaCodiceFiscaleField} />
                  </div>
                </div>
                <div className="mt-auto">
                  <div className="row no-gutters">
                    <div className="col-10 offset-1 ">
                      <button
                        type="button"
                        className={`btn Rectangle-Button-Blue w-100`}
                        onClick={handleOnClickCercaUtente}
                      >
                        Cerca utente
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </MyPopover>
          </div>
        </div>
      </div>
    </>
  );
};

export default withErrorBoundary(Container);
