import { toast } from "react-toastify";
import { beServiceUrls } from "../../../Client/ClientProperties";
import { globalAlertId } from "../../../CommonComponents/AlertToast/AlertIdConstants";
import {
  globalSpinnerId,
  toggleSpinnerById,
} from "../../../CommonComponents/Spinner/spinnerSlice";
import {
  loadCarteData,
  loadClientSearchAnagraficaData,
  loadClientSearchPrivatoData,
  loadContiData,
  loadTmlData,
  loadPosCommissioniData,
} from "../../../Modules/Anagrafica/anagraficaSlice";
import { updateProspectDataByProperty,aziendaProspectData,privatoProspectData } from "../../../Modules/Prospect/prospectSlice";
import { exposedDispatch } from "../../../Store/store";
import { getBaseErrorMessage } from "../../../Utils/CommonUtil";
import HttpClient from "../../../Utils/HttpClient";

export const httpPostClientSearch = async (request = {}) => {
  const dispatch = exposedDispatch;
  let httpClient = new HttpClient();
  httpClient.setUrl(beServiceUrls().clientsearch);
  let interactionId = request.interactionId;
  dispatch(toggleSpinnerById(globalSpinnerId));
  let responseData = await httpClient
    .httpPost(request)
    .then((response) => {
      const { status = "", response: clientSearchResponse = {} } = response;
      const {
        multipleClientFound = false,
        multipleClient: multipleClientResponse = [],
        warningMessages = [],
      } = clientSearchResponse;
      dispatch(toggleSpinnerById(globalSpinnerId));
      if (status === "OK") {
        if (multipleClientFound === true) {
          return clientSearchResponse;
        } else {
          updateStateAfterClientSearch({
            interactionId: interactionId,
            clientSearchData: clientSearchResponse,
          });
          /*dispatch(
            loadClientSearchAnagraficaData({
              interactionId: interactionId,
              clientSearchData: clientSearchResponse,
            })
          );
          dispatch(
            updateProspectDataByProperty({
              interactionId: interactionId,
              data: {
                property: "privatoPropestClientDisabled",
                value: false,
              },
            })
          );
          dispatch(
            updateProspectDataByProperty({
              interactionId: interactionId,
              data: {
                property: "loadDataFromAnagrafica",
                value: true,
              },
              orginData : privatoProspectData
            })
          );
          dispatch(
            updateProspectDataByProperty({
              interactionId: interactionId,
              data: {
                property: "loadDataFromAnagrafica",
                value: true,
              },
              orginData : aziendaProspectData
            })
          );
          */
          return clientSearchResponse;
        }
      } else if (status === "KO") {
        toast.warn(getBaseErrorMessage("Warning", response), {
          containerId: globalAlertId,
        });
      } else if (status === "EXCEPTION") {
        toast.error(getBaseErrorMessage("Error", response), {
          containerId: globalAlertId,
        });
      }
      return {};
    })
    .catch((err) => {
      console.error("clientsearch", err);
      toast.error(getBaseErrorMessage("Error", err), {
        containerId: globalAlertId,
      });
    });
  return responseData;
};

/**
 *  Service to update redux state after the client search. 
 * 
 *  This method has been created to have on one point the common logic to use after:
 *    - httpPostClientSearch
 *    - Modules/Anagrafe/httpService/httpGetLastClientSearched
 * 
 *   to solve issue on @link { https://svil.bansel.it/jira/browse/CCCLOUD-546 }
 * @param {*} data 
 */
export const updateStateAfterClientSearch = (data = {}) => {
  const dispatch = exposedDispatch;
  const {interactionId = "noInteraction", clientSearchData = {}} = data;
  dispatch(
    loadClientSearchAnagraficaData({
      interactionId: interactionId,
      clientSearchData: clientSearchData,
    })
  );
  dispatch(
    updateProspectDataByProperty({
      interactionId: interactionId,
      data: {
        property: "privatoPropestClientDisabled",
        value: false,
      },
    })
  );
  dispatch(
    updateProspectDataByProperty({
      interactionId: interactionId,
      data: {
        property: "loadDataFromAnagrafica",
        value: true,
      },
      orginData : privatoProspectData
    })
  );
  dispatch(
    updateProspectDataByProperty({
      interactionId: interactionId,
      data: {
        property: "loadDataFromAnagrafica",
        value: true,
      },
      orginData : aziendaProspectData
    })
  );
}

export const httpPostPrivatoData = async (request = {}) => {
  const dispatch = exposedDispatch;
  let httpClient = new HttpClient();
  httpClient.setUrl(beServiceUrls().clientsearch);
  let interactionId = request.interactionId;
  dispatch(toggleSpinnerById(globalSpinnerId));
  let responseData = await httpClient.httpPost(request).then((response) => {
    const { status = "", response: clientSearchResponse = {} } = response;
    const {
      multipleClientFound = false,
      multipleClient: multipleClientResponse = [],
      warningMessages = [],
    } = clientSearchResponse;
    dispatch(toggleSpinnerById(globalSpinnerId));
    if (status === "OK") {
      if (multipleClientFound === true) {
        return clientSearchResponse;
      } else {
        dispatch(
          loadClientSearchPrivatoData({
            interactionId: interactionId,
            clientSearchData: clientSearchResponse,
          })
        );
        return clientSearchResponse;
      }
    }
    return {};
  });
  return responseData;
};

export const httpGetCarteSearch = async (request = {}) => {
  const dispatch = exposedDispatch;
  let httpClient = new HttpClient();
  httpClient.setUrl(beServiceUrls().clientCarte);
  let interactionId = request.interactionId;
  let responseData = await httpClient.httpGet(request).then((response) => {
    const { status = "", response: carteResponse = {} } = response;
    if (status === "OK") {
      dispatch(
        loadCarteData({ interactionId: interactionId, carte: carteResponse })
      );
      return carteResponse;
    }
    return {};
  });
  return responseData;
};

export const httpGetContiSearch = async (request = {}) => {
  const dispatch = exposedDispatch;
  let httpClient = new HttpClient();
  httpClient.setUrl(beServiceUrls().clientConti);
  let responseData = await httpClient.httpGet(request).then((response) => {
    const { status = "", response: contiResponse = {} } = response;
    if (status === "OK") {
      dispatch(
        loadContiData({ interactionId: interactionId, conti: contiResponse })
      );
      return contiResponse;
    }
    return {};
  });
  return responseData;
};

export const httpGetAuthInfo = async (request = {}) => {
  let httpClient = new HttpClient();
  httpClient.setUrl(beServiceUrls().authenticationInfo);
  let responseData = await httpClient.httpPost(request).then((response) => {
    const { status = "", errorCode = "", errorMessage = "" } = response;
    if (status === "OK") {
      console.log("Success " + response);
      return response;
    }
    return { response: {} };
  });
  return responseData;
};

export const httpGetTmlId = async (request = {}) => {
  let httpClient = new HttpClient();
  const dispatch = exposedDispatch;
  httpClient.setUrl(beServiceUrls().posTmlSearch);
  dispatch(toggleSpinnerById(globalSpinnerId));
  let interactionId = request.interactionId;
  let responseData = await httpClient.httpPost(request).then((resp) => {
    const { status = "", errorCode = "", errorMessage = "" } = resp;
    if (status === "OK") {
      console.log("Success " + resp);
      dispatch(
        loadTmlData({interactionId: interactionId,tmlData: resp.response })
      );
      return resp;
    }
    else if (status === "KO") {
      toast.warn(getBaseErrorMessage("Warning", response), {
        containerId: globalAlertId,
      });
    } else if (status === "EXCEPTION") {
      toast.error(getBaseErrorMessage("Error", response), {
        containerId: globalAlertId,
      });
    }
    return { resp: {} };
  }).catch((err) => {
    toast.error(getBaseErrorMessage("Error", err), {
      containerId: globalAlertId,
    });
    return { resp: {} };
  });
  dispatch(toggleSpinnerById(globalSpinnerId));
  return responseData;
};


export const httpGetPosCommissioni = async (request = {}) => {
  let httpClient = new HttpClient();
  const dispatch = exposedDispatch;
  httpClient.setUrl(beServiceUrls().posCommissioni);
  dispatch(toggleSpinnerById(globalSpinnerId));
  let interactionId = request.interactionId;
  let responseData = await httpClient.httpPost(request).then((resp) => {
    const { status = "", errorCode = "", errorMessage = "" } = resp;
    if (status === "OK") {
      console.log("Success " + resp);
      dispatch(
        loadPosCommissioniData({interactionId: interactionId,posCommissioniData: resp.response })
      );
      return resp;
    }
    else if (status === "KO") {
      toast.warn(getBaseErrorMessage("Warning", response), {
        containerId: globalAlertId,
      });
    } else if (status === "EXCEPTION") {
      toast.error(getBaseErrorMessage("Error", response), {
        containerId: globalAlertId,
      });
    }
    return { resp: {} };
  }).catch((err) => {
    toast.error(getBaseErrorMessage("Error", err), {
      containerId: globalAlertId,
    });
    return { resp: {} };
  });
  dispatch(toggleSpinnerById(globalSpinnerId));
  return responseData;
};