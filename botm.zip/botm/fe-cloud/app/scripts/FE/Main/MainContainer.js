import React, { useEffect, useState } from "react";
import { useDispatch } from "react-redux";
import { toast } from "react-toastify";
import { beServiceUrls } from "../Client/ClientProperties";
import { globalAlertId } from "../CommonComponents/AlertToast/AlertIdConstants";
import AlertToast from "../CommonComponents/AlertToast/AlertToast";
import { withErrorBoundary } from "../CommonComponents/ErrorBoundary/withErrorBoudary";
import MySpinner from "../CommonComponents/Spinner/MySpinner";
import {
  globalSpinnerId,
  toggleSpinnerById,
} from "../CommonComponents/Spinner/spinnerSlice";
import { interactionEventListener } from "../Modules/Interaction/Service";
import { logoutEventListener } from "../Modules/Session/Service";
import { lightAuthenticationEventListeners } from "../Modules/LightAuthentication/Service";
import SessionExpiresModal from "../Modules/Session/SessionExpiresModal";
import SoftphoneContainer from "../Modules/Softphone/Container";
import { phoneCollectionEventListeners } from "../Modules/PhoneCollection/Service";
import { phoneCollectionCRMEventListeners } from "../Modules/PhoneCollectionCRM/Service";
import {
  httpGetInternalWidget,
  httpGetWidget,
  iwInteractionEventListener,
} from "../Modules/Widgets/Service";
import RouteContainer from "../Routes/RouteContainer";
import { setCurrentProfile, setWKSCUrl } from "../Store/preferenceSlice";
import {
  httpGetChannelsAndCallTypes,
  httpGetSystemPresences,
  httpGetOrganizationPresences,
  httpGetVisibleBanks,
  httpGetCities,
  httpGetNations,
  httpGetCustomFunctionGranted,
  httpPostNotificationChannel
} from "../Utils/CommonUtil";
import HttpClient from "../Utils/HttpClient";
import HeaderContainer from "./Header/HeaderContainer";
import { customFunctionCodes } from "../Store/commonSlice";
import PureCloudWebSocketComponent from "../CommonComponents/WebSocket/PureCloudWebSocketComponent";
import { contactSearchEventListener } from "../Modules/ContactSearch/PhoneBookContactSearchService";

const MainContainer = () => {
  const dispatch = useDispatch();

  const [orgCode , setOrgCode] = useState();
  const [barraContainerStyle, setBarraContainerStyle] = useState();

  const onComponentDidMount = async () => {
    let httpClientPref = new HttpClient();
    httpClientPref.setUrl(beServiceUrls().preference);
    const profileRes = await httpClientPref
      .httpGet()
      .then((response) => {
        const { status = "", response: profileResponse = {} } = response;
        if (status === "OK") {
          //toast.success("Success", { containerId: globalAlertId });
          const { profile = {} , wkscURL = "" } = profileResponse;
          dispatch(setWKSCUrl({wkscUrlVal:wkscURL}));
          dispatch(setCurrentProfile({ profile }));
          const {organization = {}} = profile;
          const { code } = organization;
          setOrgCode(code);
        } else {
          toast.warn("Warning", { containerId: globalAlertId });
        }
        return profileResponse
      })
      .catch((err) => {
        toast.error("Error", { containerId: globalAlertId });
      });
    const { profile } = profileRes || {};
    const { barraDivisionId } = profile || {};
    httpGetSystemPresences();
    httpGetOrganizationPresences();
    await httpGetWidget({
      main: "Y",
      filterByGroup: "Y",
    });
    await httpGetInternalWidget({
      default: "Y",
      main: "N",
      filterByGroup: "Y",
    });
    await httpGetCustomFunctionGranted({}).then((grantsList = []) => {
      dispatch(toggleSpinnerById(globalSpinnerId));
      let purecloudNotificationIndex = grantsList.findIndex(el => 
        el.enabled === true && el.cfCode === customFunctionCodes().purecloudNotification
      );
      if(purecloudNotificationIndex !== -1){
        httpPostNotificationChannel();
      }
    });
    await httpGetVisibleBanks({
      divisionId: barraDivisionId
    }, true);
    await httpGetChannelsAndCallTypes({}, true);
    httpGetCities();
    httpGetNations();
  };

  useEffect(() => {
    dispatch(toggleSpinnerById(globalSpinnerId));
    onComponentDidMount();
  }, []);

  useEffect(()=> {
    if(orgCode==="BPA"){
      setBarraContainerStyle("bpa-main-container");
    }
  },[orgCode]);

  useEffect(() => {
    window.addEventListener("message", iwInteractionEventListener, false);
    return () => {
      window.removeEventListener("message", iwInteractionEventListener, false);
    };
  }, []);

  useEffect(() => {
    //const unsubscribe = store.subscribe(interactionIdChangeSubcription());
    window.addEventListener("message", interactionEventListener, false);
    return () => {
      //unsubscribe();
      window.removeEventListener("message", interactionEventListener, false);
    };
  }, []);


  useEffect(() => {
    window.addEventListener("message", contactSearchEventListener, false);
    return () => {
      window.removeEventListener("message", contactSearchEventListener, false);
    };
  }, []);

  useEffect(() => {
    window.addEventListener("message", logoutEventListener, false);
    return () => {
      window.removeEventListener("message", logoutEventListener, false);
    };
  }, []);

  useEffect(() => {
    window.addEventListener(
      "message",
      lightAuthenticationEventListeners,
      false
    );
    return () => {
      window.removeEventListener(
        "message",
        lightAuthenticationEventListeners,
        false
      );
    };
  }, []);

  useEffect(() => {
    window.addEventListener("message", phoneCollectionEventListeners, false);
    return () => {
      window.removeEventListener("message", phoneCollectionEventListeners, false);
    };
  }, []);

  useEffect(() => {
    window.addEventListener("message", phoneCollectionCRMEventListeners, false);
    return () => {
      window.removeEventListener("message", phoneCollectionCRMEventListeners, false);
    };
  }, []);

  return (
    <>
      <MySpinner uniqueID={globalSpinnerId} type="global" />
      <AlertToast
        configuration={{
          unqiueID: globalAlertId,
          className: "global-toast-container",
        }}
      />
      <PureCloudWebSocketComponent />
      <div className={`main ${barraContainerStyle}`}>
        <HeaderContainer />
        <>
          <SessionExpiresModal />
          <div className="row no-gutters flex-nowrap">
            {/* <LeftSideBar /> */}
            <div className="content">
              <div className="d-flex">
                <SoftphoneContainer />
                <RouteContainer />
              </div>
            </div>
          </div>
        </>
      </div>
    </>
  );
};

export default withErrorBoundary(MainContainer);
