import { createSlice } from "@reduxjs/toolkit";
import { stackNavHome, stackNavConversation } from "./StackNavComponents";

const stackLayouts = {
  stackPreview: "preview",
  stackExpand: "expand",
};

export const { stackPreview, stackExpand } = stackLayouts;

let initialState = {
  globalStack: [
    {
      stackCode: stackNavHome,
      stackShow: true,
    },
    {
      stackCode: stackNavConversation,
      stackShow: false,
      stackHide: true,
    },
  ],
  history: [stackNavHome],
};

const stackNavigationSlice = createSlice({
  name: "stackNavigation",
  initialState,
  reducers: {
    stackNavPush(state, action) {
      const { payload } = action;
      if (!payload) return;
      let isAvail = findIndexByCode(state.globalStack)(payload);
      if (isAvail === -1) {
        let lastIndexOfHistory = state.history.length - 1;
        let prevStackCodeIndex = findIndexByCode(state.globalStack)(
          state.history[lastIndexOfHistory]
        );
        state.globalStack[prevStackCodeIndex].stackShow = false;
        state.history.push(payload);
        state.globalStack.push({
          stackCode: payload,
          stackShow: true,
        });
      }
    },
    stackNavToggle(state, action) {
      const { payload } = action;
      if (!payload) return;
      let isAvail = findIndexByCode(state.globalStack)(payload);
      if (isAvail !== -1) {
        let currentElementShow = state.globalStack[isAvail].stackShow;
        state.globalStack[isAvail].stackShow = !currentElementShow;
        if (!currentElementShow) {
          let lastIndexOfHistory = state.history.length - 1;
          let prevStackCodeIndex = findIndexByCode(state.globalStack)(
            state.history[lastIndexOfHistory]
          );
          state.globalStack[prevStackCodeIndex].stackShow = currentElementShow;
          state.history.push(payload);
        } else {
          state.history.pop();
          let lastIndexOfHistory = state.history.length - 1;
          let prevStackCodeIndex = findIndexByCode(state.globalStack)(
            state.history[lastIndexOfHistory]
          );
          state.globalStack[prevStackCodeIndex].stackShow = currentElementShow;
        }
      }
    },
    stackNavPop(state, action) {
      if (state.globalStack.length <= 2) return;
      state.globalStack.pop();
      state.history.pop();
      let lastIndexOfHistory = state.history.length - 1;
      let prevStackCodeIndex = findIndexByCode(state.globalStack)(
        state.history[lastIndexOfHistory]
      );
      state.globalStack[prevStackCodeIndex].stackShow = true;
    },
    stackNavEnableByHide(state, action) {
      const { payload } = action;
      if (!payload) return;
      let isAvail = findIndexByCode(state.globalStack)(payload);
      if (
        isAvail === -1 ||
        state.globalStack[isAvail].stackHide === undefined ||
        !state.globalStack[isAvail].stackHide
      )
        return;
      state.globalStack[isAvail].stackHide = false;
    },
    stackNavReset(state) {
      state = initialState;
    },
  },
});

export const {
  stackNavPop,
  stackNavPush,
  stackNavToggle,
  stackNavEnableByHide,
  stackNavReset,
} = stackNavigationSlice.actions;

export const findIndexByCode = (globalStack = []) => {
  return (stackCode = "") => {
    let isAvail = globalStack.findIndex((elStack) => {
      return elStack.stackCode === stackCode;
    });
    return isAvail;
  };
};

export default stackNavigationSlice.reducer;
