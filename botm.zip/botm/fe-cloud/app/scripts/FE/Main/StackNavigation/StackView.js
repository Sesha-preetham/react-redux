import React from "react";
import { useSelector } from "react-redux";
import { withErrorBoundary } from "../../CommonComponents/ErrorBoundary/withErrorBoudary";
import { findStackNavComponentKey } from "./StackNavComponents";

const TransitionStackNavigation = (props) => {
  const { elStack = {} } = props;
  const { stackCode = "" } = elStack;

  return findStackNavComponentKey(elStack)(stackCode);
};

const StackView = (props) => {
  const { globalStack = [] } = useSelector((state) => state.stackNavigation);

  return (
    <>
      {globalStack.map((elStack) => {
        return (
          <TransitionStackNavigation
            key={elStack.stackCode}
            elStack={elStack}
          />
        );
      })}
    </>
  );
};

export default withErrorBoundary(StackView);
