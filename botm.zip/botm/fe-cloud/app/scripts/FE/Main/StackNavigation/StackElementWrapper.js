import React, { useEffect } from "react";
import { CSSTransition } from "react-transition-group";

const StackElementWrapper = (props) => {
  const { elStack = {}, events = {} } = props;
  const { stackShow = false } = elStack;
  const {
    onStackMounted = (currentStack) => {
      console.log("StackElementWrapper onStackMounted: ", currentStack);
    },
    onStackUnMounted = (currentStack) => {
      console.log("StackElementWrapper onStackUnMounted: ", currentStack);
    },
    onStackEntered = (currentStack) => {
      console.log("StackElementWrapper onStackEntered: ", currentStack);
    },
    onStackExited = (currentStack) => {
      console.log("StackElementWrapper: onStackExited", currentStack);
    },
  } = events;

  useEffect(() => {
    onStackMounted(elStack);
    return () => {
      onStackUnMounted(elStack);
    };
  }, []);

  return (
    <CSSTransition
      in={stackShow}
      timeout={300}
      classNames="slide-left-toggle"
      unmountOnExit={false}
      mountOnEnter={false}
      onEntered={() => {
        onStackEntered(elStack);
      }}
      onExited={() => {
        onStackExited(elStack);
      }}
    >
      {props.children}
    </CSSTransition>
  );
};

export default StackElementWrapper;
