import React from "react";
import ExpandAnagrficaContainer from "../../Modules/Anagrafica/ExpandAnagrficaContainer";
import ExpandAuthenticationContainer from "../../Modules/Authentication/ExpandAuthenticationContainer";
import ExpandConsunMainContainer from "../../Modules/Consuntivazione/ExpandConsunMainContainer";
import ExpandConversationContainer from "../../Modules/Conversation/ExpandConversationContainer";
import ExpandQueueActivityContainer from "../../Modules/QueueActivity/ExpandQueueActivityContainer";
import ExpandAbanonRecallContainer from "../../Modules/AbandonRecall/ExpandAbandonRecallContainer";
import ExpandedSospesiContainer from "../../Modules/Sospesi/ExpandedSospesiContainer";
import ExpandedRetailDeskContainer from "../../Modules/RetailDesk/ExpandedRetailDeskContainer";
import ExpandPhoneCollectionContainer from "../../Modules/PhoneCollection/ExpandPhoneCollectionContainer";
import ExpandedWKSCContainer from "../../Modules/RetailDesk/ExpandedWKSCContainer";
import ExpandEsitoWidgetContainer from "../../Modules/PhoneCollection/EsitoWidgetComponents/ExpandEsitoWidgetContainer"
import ExpandMotivoContattoHDC from "../../Modules/Anagrafica/Components/HDCWidget/ExpandMotivoContattoHDC";
import ExpandHDCContainer from "../../Modules/Anagrafica/Components/HDCWidget/ExpandHDCContainer";
import LayoutContainer from "../Layout/Container";
import ExpandPhoneCollectionCRMContainer from "../../Modules/PhoneCollectionCRM/ExpandPhoneCollectionCRMContainer";
import ExpandLeasingContainer from "../../Modules/Anagrafica/Components/SellaLeasing/ExpandLeasingContainer";

const StackNavCode = {
  stackNavHome: "HOME",
  stackNavAnagrafica: "ANAGRAFICA",
  stackNavSospesi: "SOSPESI",
  stackNavConsun: "CONSULT",
  stackNavConversation: "CONVERSATION",
  stackNavMandAuth: "MAND_AUTH",
  stackNavQueueActivity: "QUEUE_ACTIVITY",
  stackNavAbandonRecall: "ABANDON_RECALL",
  stackNavRetailDesk:"RETAIL_DESK",
  stackNavWKSC :"WKSC",
  stackNavPhoneCollection:"PHONE_COLLECTION",
  stackNavEsitoContainer:"ESITO_CONTAINER",
  stackNavHDC: "HDC_CONSUNTIVA",
  stackNavHDCMainContainer:"HDC_MAIN",
  stackNavPhoneCollectionCRM:"PHONE_COLLECTION_CRM",
  stackNavLeasingMainContainer:"LEASING_MAIN",
};

export const {
  stackNavHome,
  stackNavAnagrafica,
  stackNavSospesi,
  stackNavConsun,
  stackNavConversation,
  stackNavMandAuth,
  stackNavAbandonRecall,
  stackNavQueueActivity,
  stackNavRetailDesk,
  stackNavWKSC,
  stackNavPhoneCollection,
  stackNavEsitoContainer,
  stackNavHDC,
  stackNavHDCMainContainer,
  stackNavPhoneCollectionCRM,
  stackNavLeasingMainContainer
} = StackNavCode;

const StackNavComponents = {
  [stackNavHome]: (elStack) => {
    return <LayoutContainer elStack={elStack} />;
  },
  [stackNavAnagrafica]: (elStack) => {
    return <ExpandAnagrficaContainer elStack={elStack} />;
  },
  [stackNavSospesi]: (elStack) => {
    return <ExpandedSospesiContainer elStack={elStack} />;
  },
  [stackNavConsun]: (elStack) => {
    return <ExpandConsunMainContainer elStack={elStack} />;
  },
  [stackNavConversation]: (elStack) => {
    // return <ExpandConversationContainer elStack={elStack} />;
    return null;
  },
  [stackNavMandAuth]: (elStack) => {
    return <ExpandAuthenticationContainer elStack={elStack} />;
  },
  [stackNavAbandonRecall]: (elStack) => {
    return <ExpandAbanonRecallContainer elStack={elStack} />;
  },
  [stackNavQueueActivity]: (elStack) => {
    return <ExpandQueueActivityContainer elStack={elStack} />;
  },
  [stackNavRetailDesk]: (elStack) => {
    return <ExpandedRetailDeskContainer elStack={elStack} />;
  },
  [stackNavPhoneCollection]: (elStack) => {
    return <ExpandPhoneCollectionContainer elStack={elStack} />;
  },
  [stackNavEsitoContainer]: (elStack) => {
    return <ExpandEsitoWidgetContainer elStack={elStack} />;
  },  
  [stackNavHDC]: (elStack) => {
    return <ExpandMotivoContattoHDC elStack={elStack} />;
  },
  [stackNavHDCMainContainer]: (elStack) => {
    return <ExpandHDCContainer elStack={elStack} />;
  }, 
  [stackNavPhoneCollectionCRM]: (elStack) => {
    return <ExpandPhoneCollectionCRMContainer elStack={elStack} />;
  }, 
  [stackNavLeasingMainContainer]: (elStack) => {
    return <ExpandLeasingContainer elStack={elStack} />;
  }
};

export const findStackNavComponentKey = (elStack) => {
  return (keyName) => {
    if (StackNavComponents[keyName]) {
      return StackNavComponents[keyName](elStack);
    }
  };
};

export default StackNavComponents;
