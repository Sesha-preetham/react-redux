import React from "react";
import { HashRouter as Router, Switch, Route } from "react-router-dom";
import { Provider } from "react-redux";

import store from "./FE/Store/store";

import MainContainer from "./FE/Main/MainContainer";
import EventEmitter from "./FE/CommonComponents/WebSocket/EventEmitter";

export const eventEmitter = new EventEmitter();

const App = () => {
  return (
    <Provider store={store}>
      <Router>
        <Switch>
          {/* <Route exact path="/" component={LoginContainer} /> */}
          <Route path="/" component={MainContainer} />
        </Switch>
      </Router>
    </Provider>
  );
};

export default App;
