import React from "react";
import { shallow } from "enzyme";
import TestRenderer from "react-test-renderer";
import AlertToast from "../../../../../scripts/FE/CommonComponents/AlertToast/AlertToast";
//  ../CommonComponents/AlertToast/AlertToast"

describe("<AlertToast />", () => {
  it("React Test Renderer", () => {
    let customFilterMultiselectField = {
        unqiueID: "prospectModalAlertId",
        className: "inline-toast-container",
        transition: "flip",
    };
    const testRenderer = TestRenderer.create(
        <AlertToast configuration= { customFilterMultiselectField }  />
    );
    const testInstance = testRenderer.root;
    expect(testInstance.props.configuration.uniqueID).toBe("prospectModalAlertId");
    
  });
});


