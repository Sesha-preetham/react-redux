const phoneCollectionUrlsWithPath = [
    {
      method: "GET",
      url: "/barratelefonicabe-web/service/pc/assegnatiAlCDR",
      path: "server/src/phoneCollection/assegnatiAlCDR.json",
      params: {},
    },
    {
      method: "GET",
      url: "/barratelefonicabe-web/service/pc/agentList",
      path: "server/src/phoneCollection/pcAgentList.json",
      query: {}, // servType: "PRIVATO"
      params: {}
    },
    {
      method: "POST",
      url: "/barratelefonicabe-web/service/pc/stato",
      path: "server/src/phoneCollection/pcStato.json",
    },
    {
      method: "POST",
      url: "/barratelefonicabe-web/service/pc/estrai",
      path: "server/src/phoneCollection/pcEstrai.json",
    },
    {
      method: "POST",
      url: "/barratelefonicabe-web/service/pc/noteColumnPopup",
      path: "server/src/phoneCollection/getNoteOperator.json",
    },
    {
      method: "POST",
      url: "/barratelefonicabe-web/service/pc/aggiornaNote",
      path: "server/src/phoneCollection/aggiornaNote.json",
    },
    {
      method: "POST",
      url: "/barratelefonicabe-web/service/email/draftPhoneCollection",
      path: "server/src/phoneCollection/aggiorna.json",
    },
    {
      method: "POST",
      url: "/barratelefonicabe-web/service/pc/assistenza",
      path: "server/src/phoneCollection/assistenza.json",
    },
    {
      method: "POST",
      url: "/barratelefonicabe-web/service/pc/esitoContactCenter",
      path: "server/src/phoneCollection/getEsitoVal.json",
    },
    {
      method: "POST",
      url: "/barratelefonicabe-web/service/pc/aggiorna",
      path: "server/src/phoneCollection/aggiorna.json",
    },
    {
      method: "POST",
      url: "/barratelefonicabe-web/service/interaction/:interactionId/phonecollection/trace",
      path: "server/src/phoneCollection/aggiorna.json",
      query: {},
      params: {
        interactionId: "*",
      },
    },
    
  ];
  
  export default phoneCollectionUrlsWithPath;