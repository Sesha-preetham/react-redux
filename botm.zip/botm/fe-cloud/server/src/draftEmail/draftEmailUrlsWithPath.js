const draftEmailUrlsWithPath = [
    {
      method: "POST",
      url: "/barratelefonicabe-web/service/email/draftPrivato",
      path: "server/src/draftEmail/privato.json",
      query: {},
      params: {},
    },
  ];
  
  export default draftEmailUrlsWithPath;