const prospectUrlsWithPath = [
  {
    method: "GET",
    url: "/barratelefonicabe-web/service/anagrafica/prospect/products",
    path: "server/src/prospect/prodotto.json",
    query: {},
    params: {},
  },
  {
    method: "GET",
    url: "/barratelefonicabe-web/service/anagrafica/prospect/esiti",
    path: "server/src/prospect/tipoesiti.json",
    query: {},
    params: {},
  },
  {
    method: "POST",
    url: "/barratelefonicabe-web/service/anagrafica/prospect/inserisci",
    path: "server/src/prospect/inserisci.json",
    query: {},
    params: {},
  },
];

export default prospectUrlsWithPath;
