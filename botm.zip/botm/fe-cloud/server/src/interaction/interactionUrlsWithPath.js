const interactionUrlsWithPath = [
    {
      method: "POST",
      url: "/barratelefonicabe-web/service/chat/clientmessagecheck",
      path: "server/src/interaction/clientmessagecheck.json",
      query: {},
      params: {},
    },
    {
      method: "POST",
      url: "/barratelefonicabe-web/service/email/create",
      path: "server/src/interaction/createemail.json",
      query: {},
      params: {},
    },
];
  
export default interactionUrlsWithPath;