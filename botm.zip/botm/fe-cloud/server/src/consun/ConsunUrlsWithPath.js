const consunUrlsWithPath = [
  {
    method: "GET",
    url: "/barratelefonicabe-web/service/platform",
    path: "server/src/consun/platform.json",
    query: {
      queueName: "*"
    },
    params: {},
  },
  {
    method: "GET",
    url: "/barratelefonicabe-web/service/tags",
    path: "server/src/consun/gettags.json",
    query: {},
    params: {},
  },
  {
    method: "POST",
    url: "/barratelefonicabe-web/service/linkedtags",
    path: "server/src/consun/gettags.json",
    params: {},
    body: {
      queueName: "*",
      wrapupcodeId: "*"
    }
  },
  {
    method: "POST",
    url: "/barratelefonicabe-web/service/linkedtags",
    path: "server/src/consun/linkedtags.json",
    query: {},
    params: {},
    body: {
      queueName: "*",
      wrapupcodeId: "*",
      parentTagId: "*"
    }
  },
  {
    method: "GET",
    url: "/barratelefonicabe-web/service/interaction/:interactionId/getwrapupcode",
    path: "server/src/consun/getwrapcode.json",
    query: {},
    params: {
      interactionId: "*",
    },
  },
  {
    method: "POST",
    url: "/barratelefonicabe-web/service/interaction/:interactionId/trace/disconnect",
    path: "server/src/consun/disconnect.json",
    query: {},
    params: {
      interactionId: "*",
    },
  },
  {
    method: "POST",
    url: "/barratelefonicabe-web/service/interaction/:interactionId/trace",
    path: "server/src/consun/trace.json",
    query: {},
    params: {
      interactionId: "*",
    },
  },
  {
    method: "POST",
    url: "/barratelefonicabe-web/service/interaction/:interactionId/trace/insertinteraction",
    path: "server/src/consun/insertinteraction.json",
    query: {},
    params: {
      interactionId: "*",
    },
  },
  {
    method: "POST",
    url: "/barratelefonicabe-web/service/interaction/:interactionId/transfer/trace",
    path: "server/src/consun/disconnect.json",
    query: {},
    params: {
      interactionId: "*",
    },
  },
  {
    method: "POST",
    url: "/barratelefonicabe-web/service/interaction/:interactionId/acw/trace",
    path: "server/src/consun/disconnect.json",
    query: {},
    params: {
      interactionId: "*",
    },
  },
  {
    method: "GET",
    url: "/barratelefonicabe-web/service/interaction/:interactionId/trace/getintxid",
    path: "server/src/consun/getintxid.json",
    query: {},
    params: {
      interactionId: "*",
    },
  },
  {
    method: "GET",
    url: "/barratelefonicabe-web/service/recallservicecontactlist",
    path: "server/src/consun/contactlistStub.json",
    query: {},
    params: {},
  },
  {
    method: "GET",
    url: "/barratelefonicabe-web/service/anagrafica/getAllNationData",
    path: "server/src/consun/prefixlistStub.json",
    query: {},
    params: {},
  },
  {
    method: "GET",
    url: "/barratelefonicabe-web/service/transfertoivr/:interactionId",
    path: "server/src/consun/surveyVoice.json",
    query: {},
    params: {
      interactionId: "*",
    },

  },
];

export default consunUrlsWithPath;
