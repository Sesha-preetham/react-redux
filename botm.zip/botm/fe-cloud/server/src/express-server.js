import express from "express";
import bodyParser from "body-parser";
import fs from "fs";
import { loadUrls, 
  findPathByUrl
 } from "./express-urls";
//import wsServer from "./websocket-server";

const app = express();
const serviceUrls = loadUrls();
console.log("serviceUrls", serviceUrls);
app.use((req, res, next) => {
  res.header("Access-Control-Allow-Origin", "*");
  res.header("Access-Contrl-Allow-Methods", "PUT, POST, GET, DELETE, OPTIONS");
  res.header(
    "Access-Control-Allow-Headers",
    "Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With"
  );
  next();
});
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

app.all(serviceUrls, (req, res) => {
  console.log(
    "--------------- ExpressJS servicePath: " + req.method + " METHOD "
  );
  let servicePath = req.originalUrl;
  servicePath = servicePath.substring(1, servicePath.length);
  let reqData = {
    params: req.params ? req.params : {},
    query: req.query ? req.query : {},
    body: req.body ? req.body: {}
  };
  let path = findPathByUrl(req.method, servicePath, reqData);
  console.log(path);
  if (path) {
    /* for testing different statusCode
    if(path.includes("clientsearch.json"))
        res.status(404);
    */
    readFile(path, (err, data) => {
      res.send(data);
      console.log(err);
    });
  } else {
    res.send({ path: path });
  }
});
let readFile = (file, cbk) => {
  fs.readFile(file, (err, data) => {
    if (err) {
      cbk(err);
      return;
    }
    try {
      cbk(null, data);
    } catch (exception) {
      cbk(exception);
    }
  });
};

app.listen(8090, () => {
  console.log("----------------- ExpressJS Started on PORT 8090");
});

/*const wsapp = express();

wsapp.listen(8091, () => {
  console.log("----------------- ExpressJS Started on PORT 8091");
});

websocket(wsapp);*/

