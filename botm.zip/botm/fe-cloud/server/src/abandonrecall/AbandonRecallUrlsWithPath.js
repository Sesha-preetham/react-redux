const AbandonRecallUrlsWithPath = [
  {
    method: "POST",
    url: "/barratelefonicabe-web/service/abandonrecall/list",
    path: "server/src/abandonrecall/list.json",
    query: {},
    params: {},
  },
  {
    method: "POST",
    url: "/barratelefonicabe-web/service/abandonrecall/trace",
    path: "server/src/abandonrecall/list.json",
    query: {},
    params: {},
  },
];

export default AbandonRecallUrlsWithPath;
