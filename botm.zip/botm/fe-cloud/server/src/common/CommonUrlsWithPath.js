const commonUrlsWithPath = [
  {
    method: "GET",
    url: "/barratelefonicabe-web/service/visiblebanks",
    path: "server/src/common/visiblebanks.json",
    query: {},
    params: {},
  },
  {
    method: "GET",
    url: "/barratelefonicabe-web/service/anagrafica/clientsearchtype",
    path: "server/src/common/clientsearchtype.json",
    query: {},
    params: {},
  },
  {
    method: "GET",
    url: "/barratelefonicabe-web/service/agents",
    path: "server/src/common/agents.json",
    query: {},
    params: {},
  },
  {
    method: "POST",
    url: "/barratelefonicabe-web/service/anagrafica/clientsearch2",
    path: "server/src/common/clientsearch_ecommerce.json",
    query: {},
    params: {},
  },
  {
    method: "POST",
    url: "/barratelefonicabe-web/service/anagrafica/clientsearch",
    path: "server/src/common/clientsearch_leasing.json",
    query: {},
    params: {},
  },
  {
    method: "POST",
    url: "/barratelefonicabe-web/service/anagrafica/clientsearch1",
    path: "server/src/common/clientsearchpos_ecommerce.json",
    query: {},
    params: {},
  },
  {
    method: "POST",
    url: "/barratelefonicabe-web/service/anagrafica/posCommissione",
    path: "server/src/common/posCommissione_TML.json",
    query: {},
    params: {},
  },
  {
    method: "POST",
    url: "/barratelefonicabe-web/service/anagrafica/posCommissioneDettaglio",
    path: "server/src/common/posCommissioneDettaglio_Commissioni.json",
    query: {},
    params: {},
  },
  {
    method: "POST",
    url: "/barratelefonicabe-web/service/anagrafica/lightAuthenticationSearch",
    path: "server/src/common/lightAuthenticationSearch.json",
    query: {},
    params: {},
  },
  {
    method: "POST",
    url: "/barratelefonicabe-web/service/errorlog",
    path: "server/src/common/errorLog.json",
    query: {},
    params: {},
  },
  {
    method: "GET",
    url: "/barratelefonicabe-web/service/anagrafica/cities",
    path: "server/src/common/cities.json",
    query: {},
    params: {},
  },
  {
    method: "GET",
    url: "/barratelefonicabe-web/service/anagrafica/nations",
    path: "server/src/common/nations.json",
    query: {},
    params: {},
  },
  {
    method: "GET",
    url: "/barratelefonicabe-web/service/anagrafica/lastclientsearch",
    path: "server/src/common/lastclientsearch.json",
    query: {
      interactionId: "*"
    },
    params: {},
  },
  {
    method: "POST",
    url: "/barratelefonicabe-web/service/event",
    path: "server/src/common/event.json",
    query: {},
    params: {},
  },
  {
    method: "GET",
    url: "/barratelefonicabe-web/service/customfunction/user/grants",
    path: "server/src/common/customfunctionusergrants.json",
    query: {},
    params: {},
  },
  {
    method: "POST",
    url: "/barratelefonicabe-web/service/insertcampaigncontact",
    path: "server/src/common/insertcampaigncontact.json",
    query: {},
    params: {},
  },
  {
    method: "POST",
    url: "/barratelefonicabe-web/service/interaction/getWrapUpHashTagDetails",
    path: "server/src/common/getWrapUpHashTagDetails.json",
    query: {},
    params: {},
  },
  {
    method: "GET",
    url: "/barratelefonicabe-web/service/getAttachmentList/:interactionId",
    path: "server/src/common/getAttachmentTableData.json",
    query: {},
    params: {
      interactionId: "*",
    },
  },
  {
    method: "GET",
    url: "/barratelefonicabe-web/service/downloadFile/:attachmentId",
    path: "server/src/common/sample.xlsx",
    query: {},
    params: {
      attachmentId: "*",
    },
  },
  {
    method: "POST",
    url: "/barratelefonicabe-web/service/uploadFile/:interactionId",
    path: "server/src/common/getUploadFileResponse.json",
    query: {},
    params: {
      interactionId: "*",
    },
  },
  
];

export default commonUrlsWithPath;
