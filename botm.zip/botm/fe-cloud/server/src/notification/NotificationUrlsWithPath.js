const notificationUrlsWithPath = [
    
    {
      method: "POST",
      url: "/barratelefonicabe-web/service/notification/createchannel",
      path: "server/src/notification/createchannel.json",
      query: {},
      params: {},
    },
    {
        method: "POST",
        url: "/barratelefonicabe-web/service/notification/subscribe",
        path: "server/src/notification/createchannel.json",
        query: {},
        params: {},
    },
    {
      method: "GET",
      url: "/barratelefonicabe-web/service/getmemberqueues",
      path: "server/src/notification/getmemberqueues.json",
      query: {},
      params: {},
    }
];

export default notificationUrlsWithPath;