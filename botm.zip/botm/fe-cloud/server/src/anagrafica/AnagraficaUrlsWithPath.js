const anagraficaUrlsWithPath = [
    {
      method: "GET",
      url: "/barratelefonicabe-web/service/anagrafica/conti",
      path: "server/src/anagrafica/getconti.json",
      query: { 
        ibCode: "03582322",
        idSoggetto: "9217275",
        interactionId: "270b646b-2bcc-4cc8-82ba-19b58063c5a5",
        abicode: "03268",
      },
      params: {},
    },
    {
      method: "GET",
      url: "/barratelefonicabe-web/service/anagrafica/conti",
      path: "server/src/anagrafica/getconti.json",
      query: { 
        ibCode: "03582322",
        idSoggetto: "9217275",
        abicode: "03268"
      },
      params: {},
    },
    {
      method: "GET",
      url: "/barratelefonicabe-web/service/anagrafica/carte",
      path: "server/src/anagrafica/getcarte.json",
      query: { 
        idSoggetto: "9217275",
        interactionId: "270b646b-2bcc-4cc8-82ba-19b58063c5a5",
        abicode: "03268"
      },
      params: {},
    },
    {
      method: "GET",
      url: "/barratelefonicabe-web/service/anagrafica/carte",
      path: "server/src/anagrafica/getcarte.json",
      query: { 
        idSoggetto: "9217275",
        abicode: "03268"
      },
      params: {},
    },
    {
      method: "GET",
      url: "/barratelefonicabe-web/service/anagrafica/storicocarte",
      path: "server/src/anagrafica/getstoricocarte.json",
      query: { 
        idSoggetto: "9217275",
        interactionId: "270b646b-2bcc-4cc8-82ba-19b58063c5a5",
        abicode: "03268"
      },
      params: {},
    },
    {
      method: "GET",
      url: "/barratelefonicabe-web/service/anagrafica/storicocarte",
      path: "server/src/anagrafica/getstoricocarte.json",
      query: { 
        idSoggetto: "9217275",
        abicode: "03268"
      },
      params: {},
    },
    {
      method: "POST",
      url: "/barratelefonicabe-web/service/anagrafica/trace/privato",
      path: "server/src/anagrafica/getprivatoclient.json",
      query: {},
      params: {},
    },
    {
      method: "POST",
      url: "/barratelefonicabe-web/service/anagrafica/trace/esercente",
      path: "server/src/anagrafica/getesercenteclient.json",
      query: {},
      params: {},
    },
    { method: "POST",
      url: "/barratelefonicabe-web/service/anagrafica/clientwarningmessage",
      path: "server/src/anagrafica/clientwarningmessage.json",
      query: {},
      params: {},
    },
    { method: "POST",
      url: "/barratelefonicabe-web/service/anagrafica/trace/remote",
      path: "server/src/anagrafica/getesercenteclient.json",
      query: {},
      params: {},
    }
  ];
  
  export default anagraficaUrlsWithPath;