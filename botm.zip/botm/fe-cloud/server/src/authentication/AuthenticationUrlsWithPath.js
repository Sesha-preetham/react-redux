const authenticationUrlsWithPath = [
    {
      method: "POST",
      url: "/barratelefonicabe-web/service/auth/authenticationInfo",
      path: "server/src/authentication/authenticationinfo.json",
      query: {},
      params: {},
    },
    {
        method: "POST",
        url: "/barratelefonicabe-web/service/auth/validateCodice",
        path: "server/src/authentication/validateCodice.json",
        query: {},
        params: {},
    },
    {
        method: "POST",
        url: "/barratelefonicabe-web/service/auth/validatePin",
        path: "server/src/authentication/validatePin.json",
        query: {},
        params: {},
    },
    {
        method: "POST",
        url: "/barratelefonicabe-web/service/auth/validatePwd",
        path: "server/src/authentication/validatePwd.json",
        query: {},
        params: {},
    },
    {
        method: "POST",
        url: "/barratelefonicabe-web/service/auth/validateToken",
        path: "server/src/authentication/validatePwd.json",
        query: {},
        params: {},
    },
    {
        method: "POST",
        url: "/barratelefonicabe-web/service/auth/validateSms",
        path: "server/src/authentication/validatePwd.json",
        query: {},
        params: {},
    },
    {
        method: "POST",
        url: "/barratelefonicabe-web/service/auth/sendSmsOtpRequest",
        path: "server/src/authentication/validatePin.json",
        query: {},
        params: {},
    },
    {
        method: "POST",
        url: "/barratelefonicabe-web/service/auth/validateSmsOtp",
        path: "server/src/authentication/validateSmsOtp.json",
        query: {},
        params: {},
    },
    {
        method: "POST",
        url: "/barratelefonicabe-web/service/auth/validateTokenForNewAuth",
        path: "server/src/authentication/validateTokenForNewAuth.json",
        query: {},
        params: {},
    },
    {
        method: "POST",
        url: "/barratelefonicabe-web/service/auth/v2/init",
        path: "server/src/authentication/authv2init.json",
        query: {},
        params: {},
    },
    {
        method: "POST",
        url: "/barratelefonicabe-web/service/auth/v2/validate",
        path: "server/src/authentication/authv2validate.json",
        query: {},
        params: {},
    },
    {
        method: "POST",
        url: "/barratelefonicabe-web/service/auth/v3/init",
        path: "server/src/authentication/authv3init.json",
        query: {},
        params: {},
    },
    {
        method: "POST",
        url: "/barratelefonicabe-web/service/auth/v3/validate",
        path: "server/src/authentication/authv3validate.json",
        query: {},
        params: {},
    },
    {
        method: "PUT",
        url: "/barratelefonicabe-web/service/auth/authenticationstate",
        path: "server/src/authentication/updateauthenticationstate.json",
        query: {},
        params: {},
    }
  ];
  
  export default authenticationUrlsWithPath;
  