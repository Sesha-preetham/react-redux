const initUrlsWithPath = [
  {
    method: "POST",
    url: "/authenticate",
    path: "server/src/init/authenticate.json",
  },
  {
    method: "GET",
    url: "/barratelefonicabe-web/service/preference",
    path: "server/src/init/preference.json",
  },
  {
    method: "GET",
    url: "/barratelefonicabe-web/service/channelsandcalltypes",
    path: "server/src/init/channelscalltypes.json",
  },
  // {
  //   method: "POST",
  //   url: "",
  //   path: "",
  // },
];

export default initUrlsWithPath;
