const hdcConsunUrlsWithPath = [
    {
      method: "GET",
      url: "/barratelefonicabe-web/service/hdcbanks",
      path: "server/src/hdcConsuntiva/hdcBanks.json",
      query: {},
      params: {},
    },
    {
      method: "POST",
      url: "/barratelefonicabe-web/service/queueAnomalia",
      path: "server/src/hdcConsuntiva/queueAnomalia.json",
    }
    ,
    {
      method: "POST",
      url: "/barratelefonicabe-web/service/categorizationList",
      path: "server/src/hdcConsuntiva/categorizationList.json",
    },
    {
      method: "POST",
      url: "/barratelefonicabe-web/service/createIncident",
      path: "server/src/hdcConsuntiva/createIncident.json",
    },
    {
      method: "POST",
      url: "/barratelefonicabe-web/service/interaction/:interactionId/hdc/trace",
      path: "server/src/hdcConsuntiva/createIncident.json",
      params: {
        interactionId: "*",
      },
    },
  ];
  
  export default hdcConsunUrlsWithPath;