import anagraficaUrlsWithPath from "./anagrafica/AnagraficaUrlsWithPath";
import commonUrlsWithPath from "./common/CommonUrlsWithPath";
import consunUrlsWithPath from "./consun/ConsunUrlsWithPath";
import initUrlsWithPath from "./init/InitUrlsWithPath";
import prospectUrlsWithPath from "./prospect/ProspectUrlsWithPath";
import interactionUrlsWithPath from "./interaction/interactionUrlsWithPath";
import notificationUrlsWithPath from "./notification/NotificationUrlsWithPath";
import sospesiUrlsWithPath from "./sospesi/SospesiUrlsWithPath";
import AbandonRecallUrlsWithPath from "./abandonrecall/AbandonRecallUrlsWithPath";
import authenticationUrlsWithPath from "./authentication/AuthenticationUrlsWithPath";
import widgetsUrlsWithPath from "./widgets/WidgetsUrlsWithPath";
import draftEmailUrlsWithPath from "./draftEmail/draftEmailUrlsWithPath";
import retailDeskUrlsWithPath from "./retailDesk/RetailDeskUrlsWithPath";
import phoneCollectionUrlsWithPath from "./phoneCollection/PhoneCollectionUrlsWithPath"
import hdcConsunUrlsWithPath from "./hdcConsuntiva/HDCConsunUrlsWithPath";


const serviceUrlsWithPath = [
  ...initUrlsWithPath,
  ...widgetsUrlsWithPath,
  ...anagraficaUrlsWithPath,
  ...commonUrlsWithPath,
  ...notificationUrlsWithPath,
  ...sospesiUrlsWithPath,
  ...AbandonRecallUrlsWithPath,
  ...interactionUrlsWithPath,
  ...authenticationUrlsWithPath,
  ...consunUrlsWithPath,
  ...prospectUrlsWithPath,
  ...draftEmailUrlsWithPath,
  ...retailDeskUrlsWithPath,
  ...phoneCollectionUrlsWithPath,
  ...hdcConsunUrlsWithPath,
];

export const loadUrls = () => {
  let length = serviceUrlsWithPath.length;
  let returnServiceUrls = [];
  for (let i = 0; i < length; i++) {
    if(returnServiceUrls.findIndex(el => el ===serviceUrlsWithPath[i].url) === -1)
      returnServiceUrls.push(serviceUrlsWithPath[i].url);
  }
  return returnServiceUrls;
};

export const findPathByUrl = (method = "", url = "", reqData = {}) => {
  console.log("findPathByUrl: ", method, url, reqData);
  let { params = {}, query = {}, body = {} } = reqData;
  let httpVerbs = ["GET", "DELETE", "HEAD", "OPTIONS", "POST", "PUT"];
  let isHttpVerb = httpVerbs.includes(method);
  if (isHttpVerb) {
    for (let [key, value] of Object.entries(params)) {
      console.log(`${key}: ${value}`);
      if (value) {
        url = url.replace(value, ":" + key);
      }
    }
    console.log(url);
    url = url.split("?")[0];
    console.log("findPathByUrl: updated", url);
  }

  let index = serviceUrlsWithPath.findIndex((serviceUrl) => {
    let {
      method: currentMethod = "",
      url: currentUrl = "",
      path: currentPath = "",
      query: currentQuery = {},
      params: currentParams = {},
      body: currentBody = {}
    } = serviceUrl;
    console.log("findIndex url: ", currentUrl);
    let booleanIndex = currentMethod === method && currentUrl === "/" + url;
    if (isHttpVerb) {
      console.log("findIndex params: ", currentParams, params);
      console.log("findIndex query: ", currentQuery, query);
      console.log("findIndex body: ", currentBody, body);

      let isValidParam =
        Object.keys(currentParams).length > 0
          ? mockEqualsObj(currentParams, params)
          : true;
      let isValidQuery = Object.keys(currentQuery).length > 0 ? mockEqualsObj(currentQuery, query): true;
      let isValidBody = Object.keys(currentBody).length > 0 ? mockEqualsObj(currentBody, body):true;
      booleanIndex = booleanIndex && isValidParam;
      booleanIndex = booleanIndex && isValidQuery;
      booleanIndex = booleanIndex && isValidBody;
    }
    console.log("findIndex booleanIndex: ", booleanIndex);
    return booleanIndex;
  });
  console.log(index);
  return index != -1 ? serviceUrlsWithPath[index].path : "";
};

const mockEqualsObj = (definedObj = {}, requestObj = {}) => {
  let isValid = false;
  if (
    Object.keys(definedObj).length === 0 &&
    Object.keys(requestObj).length === 0
  ) {
    isValid = true;
    return isValid;
  }
  for (let [key, value] of Object.entries(definedObj)) {
    if (requestObj[key]) {
      if (value === "*") {
        isValid = true;
      } else {
        if (requestObj[key] === value) {
          isValid = true;
        } else {
          isValid = false;
          break;
        }
      }
    } else {
      isValid = false;
      break;
    }
  }
  return isValid;
};
