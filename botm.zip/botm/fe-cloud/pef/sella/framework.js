var contactSearchCallback;

var parentDomain;
var languagePreference = "it-IT";
var pefCustumStyleUri = "";
var purecloudInteractionFrameLoaded = false;

var url = window.location.search;
var segments = url.replace("?", "").split("&");
for (var i = 0; i < segments.length; i++) {
  if (segments[i].indexOf("parentDomain") >= 0) {
    var keyValue = segments[i].split("=");
    parentDomain = keyValue[1];
    pefCustumStyleUri =
      parentDomain + "/barratelefonicafe-web/pef/pef-custom-style.css";
    if ("http://localhost:9080" === parentDomain) {
      pefCustumStyleUri = "http://localhost/pef-custom-style.css";
    }
  } else if (segments[i].indexOf("languagePreference") >= 0) {
    var keyValue = segments[i].split("=");
    if (keyValue[1]) {
      languagePreference = keyValue[1];
    }
  }
}

var addCssLink = function (doc, cssUri) {
  if (doc) {
    var l = doc.createElement("link");
    l.href = cssUri;
    l.rel = "stylesheet";
    l.type = "text/css";
    doc.head.appendChild(l);
  }
};

/*window.top["purecloud-interaction-expanded"].addEventListener('load',function(){
	let intWindow = window.top["purecloud-interaction-expanded"];
	console.log("purecloud-interaction-expanded load event!",intWindow.frames);
	addCssLink(intWindow.document,pefCustumStyleUri);
	for(var i=0;i<intWindow.frames.length;i++){
		addCssLink(intWindow.frames[i].document,pefCustumStyleUri);
	}
});*/

window.top["purecloud-interaction"].addEventListener("load", function () {
  purecloudInteractionFrameLoaded = true;
  let intWindow = window.top["purecloud-interaction"];
  console.log(
    "PEF Load Event: purecloud-interaction!",
    purecloudInteractionFrameLoaded
  );
  addCssLink(intWindow.document, pefCustumStyleUri);
  for (var i = 0; i < intWindow.frames.length; i++) {
    addCssLink(intWindow.frames[i].document, pefCustumStyleUri);
  }
});

window.addEventListener("load", function () {
  console.log("PEF Load Event: PEF", purecloudInteractionFrameLoaded);
  // add link to softphone frame, this window..
  addCssLink(window.document, pefCustumStyleUri);
  let intWindow = window.top["purecloud-interaction"];
  addCssLink(intWindow.document, pefCustumStyleUri);
  for (var i = 0; i < intWindow.frames.length; i++) {
    addCssLink(intWindow.frames[i].document, pefCustumStyleUri);
  }
  /*intWindow = window.top["purecloud-interaction-expanded"];
	addCssLink(intWindow.document,pefCustumStyleUri);
	for(var i=0;i<intWindow.frames.length;i++){
		addCssLink(intWindow.frames[i].document,pefCustumStyleUri);
	}*/

  if (document.getElementById("statusListArrow_test")) {
    var elMenuStatusContainer = document.getElementById(
      "statusListArrow_test"
    ).parentElement;
    if (elMenuStatusContainer) {
      menuDropdownObserver.observe(elMenuStatusContainer, { attributes: true });
    }
  }
});

var menuDropdownObserver = new MutationObserver(function (mutations) {
  mutations.forEach((mu) => {
    if (mu.type !== "attributes" && mu.attributeName !== "class") return;
    if (mu.target.className.includes("open")) {
      window.parent.postMessage(
        JSON.stringify({
          type: "customAction",
          data: { category: "menuStatusState", open: true },
        }),
        parentDomain
      );
    } else {
      window.parent.postMessage(
        JSON.stringify({
          type: "customAction",
          data: { category: "menuStatusState", open: false },
        }),
        parentDomain
      );
    }
  });
});

window.Framework = {
  config: {
    name: "BarraTelefonicaFE-PEF",
    clientIds: {
      "mypurecloud.de": "32bb1ef5-5e3c-478c-b404-4144d631c984",
    },
    getUserLanguage: function (callback) {
      callback(languagePreference);
    },
    customInteractionAttributes: [
      "X_Servizio",
      "First_Geolocalizzazione",
      "transferType",
      "payload trasfAcd",
      //for authenticated chat
      "context.verified:ibCode",
      "context.authenticated",
      "context.verified:abiCode",
      "context.email",
      "context.category",
      "context.firstName",
      "context.lastName",
      "context.CHANNEL",
      // for authentication from IVR
      "Auth1",
      "Auth2",
      "Auth3",
      "AuthToken",
      "Auth_Challenge Step3",
      "Auth_Challenge Ultimo",
      "AutenticazioneObbligatoria",
      "IBCode",
      "TML",
      "isAgentTransfer",
      "startQueueUTC",
      //authv3
      "IvrAuthToken",
      "BarraAuthToken",
      "sondaggio",
      "ContactId",
      //ChatAuthentication
      "chatIbcode",
      "chatAbicode",
      "authenticatedChat",
      "idSoggetto",
      "idSospeso",
      "abicode",
      "Ani",
      //PEG
      "idPEG",
      "idNotifica",
      "idSoggetto",
      "sectionId", 
      "ruleId",
      "subsystem",
      "stato"
    ],
    settings: {
      embedWebRTCByDefault: true,
      hideWebRTCPopUpOption: false,
      enableCallLogs: true,
      enableCallHistory: true,
      enableTransferContext: true,
      hideCallLogSubject: true,
      hideCallLogContact: false,
      embeddedInteractionWindow: true,
      hideCallLogRelation: false,
      callControls: [
        "pickup",
        "hold",
        "mute",
        "transfer",
        "disconnect",
        "dtmf",
        "scheduleCallback",
      ],
      searchTargets: ["people", "queues", "frameworkcontacts"],
      theme: {
        primary: "#0033CC",
        text: "#fff",
      },
      sso: {
        provider: "adfs",
        orgName: "bancasella",
      },
    },
  },
  initialSetup: function () {
    window.PureCloud.subscribe([
      {
        type: "Interaction",
        callback: function (category, interaction) {
          console.log("PEF Event: interactionSubscription", {
            type: "interactionSubscription",
            data: { category: category, interaction: interaction },
          });
          window.parent.postMessage(
            JSON.stringify({
              type: "interactionSubscription",
              data: { category: category, interaction: interaction },
            }),
            parentDomain
          );
        },
      },
      {
        type: "UserAction",
        callback: function (category, data) {
          console.log("PEF Event: userActionSubscription", {
            type: "userActionSubscription",
            data: { category: category, data: data },
          });
          window.parent.postMessage(
            JSON.stringify({
              type: "userActionSubscription",
              data: { category: category, data: data },
            }),
            parentDomain
          );
        },
      },
      {
        type: "Notification",
        callback: function (category, data) {
          console.log("PEF Event: notificationSubscription", {
            type: "notificationSubscription",
            data: { category: category, data: data },
          });
          window.parent.postMessage(
            JSON.stringify({
              type: "notificationSubscription",
              data: { category: category, data: data },
            }),
            parentDomain
          );
        },
      },
    ]);

    window.addEventListener("message", function (event) {
      try {
        if (event.origin == parentDomain) {
          var message = JSON.parse(event.data);
          if (message) {
            if (message.type == "clickToDial") {
              window.PureCloud.clickToDial(message.data);
            } else if (message.type == "addAssociation") {
              window.PureCloud.addAssociation(message.data);
            } else if (message.type == "addAttribute") {
              window.PureCloud.addCustomAttributes(message.data);
            } else if (message.type == "addTransferContext") {
              window.PureCloud.addTransferContext(message.data);
            } else if (message.type == "sendContactSearch") {
              if (contactSearchCallback) {
                contactSearchCallback(message.data);
              }
            } else if (message.type == "updateUserStatus") {
              window.PureCloud.User.updateStatus(message.data);
            } else if (message.type == "updateInteractionState") {
              window.PureCloud.Interaction.updateState(message.data);
            } else if (message.type == "setView") {
              window.PureCloud.User.setView(message.data);
            } else if (message.type == "updateAudioConfiguration") {
              window.PureCloud.User.Notification.setAudioConfiguration(
                message.data
              );
            } else if (message.type == "sendCustomNotification") {
              window.PureCloud.User.Notification.notifyUser(message.data);
            }
          }
        }
      } catch {
        //ignore if you can not parse the payload into JSON
      }
    });
  },
  screenPop: function (searchString, interaction) {
    window.parent.postMessage(
      JSON.stringify({
        type: "screenPop",
        data: { searchString: searchString, interaction: interaction },
      }),
      parentDomain
    );
  },
  processCallLog: function (
    callLog,
    interaction,
    eventName,
    onSuccess,
    onFailure
  ) {
    window.parent.postMessage(
      JSON.stringify({
        type: "processCallLog",
        data: {
          callLog: callLog,
          interactionId: interaction,
          eventName: eventName,
        },
      }),
      parentDomain
    );
    var success = true;
    if (success) {
      onSuccess({
        id: callLog.id || Date.now(),
      });
    } else {
      onFailure();
    }
  },
  openCallLog: function (callLog, interaction) {
    window.parent.postMessage(
      JSON.stringify({
        type: "openCallLog",
        data: { callLog: callLog, interaction: interaction },
      }),
      parentDomain
    );
  },
  contactSearch: function (searchString, onSuccess, onFailure) {
    contactSearchCallback = onSuccess;
    window.parent.postMessage(
      JSON.stringify({
        type: "contactSearch",
        data: { searchString: searchString },
      }),
      parentDomain
    );
  },
};
