var parentDomain;
var languagePreference = "it-IT";
var contactSearchCallback;

var url = window.location.search;
var segments = url.replace("?", "").split("&");
var pefCustumStyleUri = "";

for (var i = 0; i < segments.length; i++) {
  if (segments[i].indexOf("parentDomain") >= 0) {
    var keyValue = segments[i].split("=");
    parentDomain = keyValue[1];
    /*pefCustumStyleUri =
      parentDomain + "/barratelefonicafe-web/pef/pef-custom-style.css";
    if ("http://localhost:9080" === parentDomain) {
      pefCustumStyleUri = "http://localhost/pef-custom-style.css";
    }*/
    console.log("PEF parentDomain: ", parentDomain);
  } else if (segments[i].indexOf("languagePreference") >= 0) {
    var keyValue = segments[i].split("=");
    if (keyValue[1]) {
      languagePreference = keyValue[1];
      console.log("PEF languagePreference: ", languagePreference);
    }
  }
}

var addCssLink = function (doc, cssUri) {
  if (doc) {
    var l = doc.createElement("link");
    l.href = cssUri;
    l.rel = "stylesheet";
    l.type = "text/css";
    doc.head.appendChild(l);
  }
};

window.Framework = {
  config: {
    name: "BarraTelefonicaFE-PEF",
    clientIds: {
      "mypurecloud.de": "9a41c2a5-d019-44c9-a9a4-84f55c3efa2a",
    },
    getUserLanguage: function (callback) {
      callback(languagePreference);
    },
    customInteractionAttributes: [
      "isAgentTransfer",
      "transferType",
      "startQueueUTC",
      "payload trasfAcd",
      "UserNT",
      "Abi",
      "AbandonRecallConversation"
    ],
    settings: {
      embedWebRTCByDefault: true,
      hideWebRTCPopUpOption: false,
      enableCallLogs: true,
      enableCallHistory: true,
      enableTransferContext: true,
      hideCallLogSubject: true,
      hideCallLogContact: false,
      embeddedInteractionWindow: true,
      hideCallLogRelation: false,
      //callControls: [	"pickup", "hold", "mute", "transfer", "disconnect", "record","securePause", "dtmf", "scheduleCallback", "flag","requestAfterCallWork" ]
      callControls: [
        "pickup",
        "hold",
        "mute",
        "transfer",
        "disconnect",
        "scheduleCallback",
      ],
      searchTargets: ["people", "queues", "frameworkcontacts"],
      display:{
        interactionDetails: {
          call: [
            "call.State",
            "framework.DisplayAddress",
            "call.QueueName",
            "framework.CallTimeElapsed",
            "participant.Nome",
            "participant.Cognome",
            "participant.UserNT"
            ]
          }
      },
      theme: {
        primary: "#0033CC",
        text: "#fff",
      },
      sso: {
        provider: "adfs",
        orgName: "bancapatrimonisella",
      },
    },
  },
  initialSetup: function () {
    window.PureCloud.subscribe([
      {
        type: "Interaction",
        callback: function (category, interaction) {
          console.log("PEF Event: interactionSubscription", {
            type: "interactionSubscription",
            data: { category: category, interaction: interaction },
          });
          window.parent.postMessage(
            JSON.stringify({
              type: "interactionSubscription",
              data: { category: category, interaction: interaction },
            }),
            parentDomain
          );
        },
      },
      {
        type: "UserAction",
        callback: function (category, data) {
          console.log("PEF Event: userActionSubscription", {
            type: "userActionSubscription",
            data: { category: category, data: data },
          });
          window.parent.postMessage(
            JSON.stringify({
              type: "userActionSubscription",
              data: { category: category, data: data },
            }),
            parentDomain
          );
        },
      },
      {
        type: "Notification",
        callback: function (category, data) {
          console.log("PEF Event: notificationSubscription", {
            type: "notificationSubscription",
            data: { category: category, data: data },
          });
          window.parent.postMessage(
            JSON.stringify({
              type: "notificationSubscription",
              data: { category: category, data: data },
            }),
            parentDomain
          );
        },
      },
    ]);

    window.addEventListener("message", function (event) {
      try {
        if (event.origin == parentDomain) {
          var message = JSON.parse(event.data);
          if (message) {
            if (message.type == "clickToDial") {
              window.PureCloud.clickToDial(message.data);
            } else if (message.type == "addAssociation") {
              window.PureCloud.addAssociation(message.data);
            } else if (message.type == "addAttribute") {
              window.PureCloud.addCustomAttributes(message.data);
            } else if (message.type == "addTransferContext") {
              window.PureCloud.addTransferContext(message.data);
            } else if (message.type == "sendContactSearch") {
              if (contactSearchCallback) {
                contactSearchCallback(message.data);
              }
            } else if (message.type == "updateUserStatus") {
              window.PureCloud.User.updateStatus(message.data);
            } else if (message.type == "updateInteractionState") {
              window.PureCloud.Interaction.updateState(message.data);
            } else if (message.type == "setView") {
              window.PureCloud.User.setView(message.data);
            } else if (message.type == "updateAudioConfiguration") {
              window.PureCloud.User.Notification.setAudioConfiguration(
                message.data
              );
            } else if (message.type == "sendCustomNotification") {
              window.PureCloud.User.Notification.notifyUser(message.data);
            } else if (message.type === "injectCss") {
              let iframeName =
                (message.data && message.data.iframeName) ||
                pureCloudInteractionIFrameName;
              let intWindow = window.top[iframeName];
              if (intWindow) {
                addCssLink(intWindow.document, pefCustumStyleUri);
              }
            }
          }
        }
      } catch {
        //ignore if you can not parse the payload into JSON
      }
    });
  },
  screenPop: function (searchString, interaction) {
    window.parent.postMessage(
      JSON.stringify({
        type: "screenPop",
        data: { searchString: searchString, interaction: interaction },
      }),
      parentDomain
    );
  },
  processCallLog: function (
    callLog,
    interaction,
    eventName,
    onSuccess,
    onFailure
  ) {
    window.parent.postMessage(
      JSON.stringify({
        type: "processCallLog",
        data: {
          callLog: callLog,
          interactionId: interaction,
          eventName: eventName,
        },
      }),
      parentDomain
    );
    var success = true;
    if (success) {
      onSuccess({
        id: callLog.id || Date.now(),
      });
    } else {
      onFailure();
    }
  },
  openCallLog: function (callLog, interaction) {
    window.parent.postMessage(
      JSON.stringify({
        type: "openCallLog",
        data: { callLog: callLog, interaction: interaction },
      }),
      parentDomain
    );
  },
  contactSearch: function (searchString, onSuccess, onFailure) {
    contactSearchCallback = onSuccess;
    window.parent.postMessage(
      JSON.stringify({
        type: "contactSearch",
        data: { searchString: searchString },
      }),
      parentDomain
    );
  },
};
