package it.sella.btfe.filter;


import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class SecurityFilter implements Filter {

	
	@Override
	public void destroy() 
	{
		

	}

	@Override
	public void doFilter(ServletRequest arg0, ServletResponse arg1, FilterChain arg2)
			throws IOException, ServletException {
		HttpServletRequest  req = (HttpServletRequest)arg0;
		HttpServletResponse res = (HttpServletResponse)arg1;
		
		if(!isCacheable(req.getRequestURI())) {
			res.addHeader("Cache-Control","no-cache, no-store, must-validate");//HTTP 1.1
			res.addHeader("Pragma", "no-cache");//HTTP 1.0
			res.setDateHeader("Expires", 0);//prevents caching at the proxy server 
		}
		
		res.addHeader( "X-FRAME-OPTIONS", "SAMEORIGIN" );
		res.addHeader("X-UA-Compatible","IE=edge");
		arg2.doFilter(arg0, arg1);
	}
	
	private boolean isCacheable(final String url) {
		boolean cachable = false;
		
		if( (url != null) && (url.endsWith(".js") || url.endsWith(".jgz") || url.endsWith(".css")) ){
			cachable = true;
		}
		return cachable;
	}

	@Override
	public void init(FilterConfig arg0) throws ServletException {
		// TODO Auto-generated method stub

	}

}
